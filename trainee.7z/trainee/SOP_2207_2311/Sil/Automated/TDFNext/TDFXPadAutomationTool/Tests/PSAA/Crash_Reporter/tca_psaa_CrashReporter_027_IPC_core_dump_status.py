from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter_With_Proxy_App import *


class tca_psaa_CrashReporter_027_IPC_core_dump_status(testfixture_PSAA_Crash_Reporter_With_Proxy_App):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_027_IPC_core_dump_status"
    REQ_ID = ["/item/6588649", "/item/6588684", "/item/6529388"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check IPC coredump status notification is sent when application is killed"
    STATUS = "Ready"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Clear old core dumps")
        remove_is_done = self.remove_old_coredumps()
        self.expectTrue(remove_is_done, Severity.MAJOR, "Check the remove of old coredumps is done")

        self.setPrecondition("Check crash reporter is running")
        crash_reporter_is_running = self.parse_crash_reporter_commandline_parameters()
        self.expectTrue(crash_reporter_is_running, Severity.MAJOR, "Check that crash reporter is running")

        self.setPrecondition("Import proxy app library")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.FUSA.value)

    def test_tca_psaa_CrashReporter_027_IPC_core_dump_status(self):
        self.startTestStep("Subscribe to IPC event using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.subscribe_to_crash_reporter()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_subcriptionState == CrashReporterEventType.SUBSCRIBE.value, Severity.MAJOR, "Check that Crash Reporter is unsubscribed successfully")

        self.startTestStep("Checking that Planning is running")
        app_is_running = self.check_application_is_started(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(app_is_running, Severity.MAJOR, "Check that Planning is running ")

        self.startTestStep("Killing Planning application")
        application_is_killed = self.kill_application_CR(app_name=self.PLANNING_APP_NAME, signal=self.killall_options["SIGABRT"])
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check command is successfully executed")

        self.startTestStep("Getting crash reporter status using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.get_crash_reporter_status()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_coreDumpState == CrashReporterCoreDumpStatus.COREDUMP_Active.value, Severity.MAJOR, "Check IPC coredump notification is sent")

        #self.startTestStep("Checking coredump active notification of Planning is sent to proxy app")
        #message_count, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.PROXY_APP_APP_ID, searchMsgArray=self.kCoreDumpActive_Message_PrApp)
        #self.expectTrue(message_count > 0, Severity.BLOCKER, "Check coredump active notification of Planning is sent to proxy app")

        #self.startTestStep("Checking coredump active notification of Planning is sent to CrashReporterAraProxy")
        #kCoreDumpsDetected, dlt_messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.CRASH_REPORTER_ARA_PROXY_APP_NAME_APP_ID, searchMsgArray=self.kCoreDumpActive_Message_CRP)
        #self.expectTrue(kCoreDumpsDetected > 0, Severity.BLOCKER, "Check coredump active notification of Planning is sent to CrashReporterAraProxy")

        self.startTestStep("Wait for coredumps creation")
        self.sleep_for(self.WAIT_FOR_COREDUMPS_GENERATION_MS)

        self.startTestStep("Checking that Planning application is killed")
        app_is_running = self.check_application_is_started(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(not app_is_running, Severity.MAJOR, "Check that Planning is running")

        self.startTestStep("Check IPC coredump completed notification of Planning contains the request of persistent log file and the coredump file path")
        exit_code = self.proxy_app_manager.FUSA_comm.get_crash_reporter_status()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        logger.info(f'Coredump file path: {self.proxy_app_manager.FUSA_comm.crashReporter_coreDumpPath}')
        self.expectTrue(self.PLANNING_APP_NAME in str(self.proxy_app_manager.FUSA_comm.crashReporter_coreDumpPath), Severity.MAJOR, "Check IPC coredump file path is sent")

        self.startTestStep("Checking coredump completed notification of Planning is sent to proxy app")
        message_count, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.PROXY_APP_APP_ID, searchMsgArray=self.kCoreDumpCompleted_Message_PrApp)
        self.expectTrue(message_count > 0, Severity.BLOCKER, "Check that coredump completed notification of Planning is sent to proxy app")

        #self.startTestStep("Checking coredump completed notification of Planning is sent to CrashReporterAraProxy")
        #kCoreDumpCompleted, dlt_messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.CRASH_REPORTER_ARA_PROXY_APP_NAME_APP_ID, searchMsgArray=self.kCoreDumpCompleted_Message_CRP)
        #self.expectTrue(kCoreDumpCompleted > 0, Severity.BLOCKER, "Check coredump completed notification of Planning is sent to CrashReporterAraProxy")

        self.startTestStep("Checking that Planning coredumps are successfully created")
        #context file check
        app_name_in_context_file = self.context_file_check(app_name=self.PLANNING_APP_NAME)
        self.expectTrue(app_name_in_context_file, Severity.MAJOR, "Check the context file is created successfully under /persistent/coredumps")
        # core file check
        app_name_in_core_file = self.core_file_check(app_name=self.PLANNING_APP_NAME)
        self.expectTrue(app_name_in_core_file, Severity.MAJOR, "Check the core file is created successfully under /persistent/coredumps")

        self.startTestStep("Unsubscribe to IPC event using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.unsubscribe_to_crash_reporter()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_subcriptionState == CrashReporterEventType.UNSUBSCRIBE.value, Severity.MAJOR, "Check that Crash Reporter is unsubscribed successfully")

        self.startTestStep("Remove proxy app library")
        self.proxy_app_manager.remove_proxy_app_lib(libName.FUSA.value)

        self.startTestStep("Resetting the Performance Controller")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.startTestStep("Check ECU")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after reset")

        self.startTestStep("Import proxy app library")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.FUSA.value)

        self.startTestStep("Subscribe to IPC event using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.subscribe_to_crash_reporter()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_subcriptionState == CrashReporterEventType.SUBSCRIBE.value, Severity.MAJOR, "Check that Crash Reporter is unsubscribed successfully")

        self.startTestStep("Get IPC coredump notification")
        exit_code = self.proxy_app_manager.FUSA_comm.get_crash_reporter_status()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_coreDumpState == CrashReporterCoreDumpStatus.NO_COREDUMP_DETECTED.value, Severity.MAJOR, "Check IPC coredump notification is sent")

        self.startTestStep("Checking no coredump detected notification of Planning is sent to proxy app")
        message_count, message = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.PROXY_APP_APP_ID, searchMsgArray=self.kNoCoreDumpsDetected_Message_PrApp)
        logger.info(f"Time IPC no coredumps message count: {message_count}")
        self.expectTrue(message_count > 0, Severity.BLOCKER, "Check no coredump notification of Planning is sent to proxy app")

        self.startTestStep("Get timestamp of IPC no coredump from DLT message")
        time_ipc_1 = float(message[0].get("timestamp"))
        logger.info(f"Time IPC no coredumps 1: {time_ipc_1}")
        self.expectTrue(time_ipc_1 > 0, Severity.MAJOR, "Check that Timestamp of IPC no coredump is retrieved")

        self.startTestStep("Get timestamp of IPC no coredump from DLT message")
        time_ipc_2 = float(message[1].get("timestamp"))
        logger.info(f"Time IPC no coredumps 2: {time_ipc_2}")
        self.expectTrue(time_ipc_2 > 0, Severity.MAJOR, "Check that Timestamp of IPC no coredump is retrieved")

        self.startTestStep("Check kNoCoreDumpsDetected IPC coredump notification cyclicity equal to 1 second")
        time_check = time_ipc_1 - time_ipc_2
        logger.info(f"Time difference: {time_check}")
        self.assertTrue(int(time_check) == 1, Severity.MAJOR, "Check that timestamp of MSM termiation is bigger than timestamp of shutdown")

        self.startTestStep("Unsubscribe to IPC event using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.unsubscribe_to_crash_reporter()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_subcriptionState == CrashReporterEventType.UNSUBSCRIBE.value, Severity.MAJOR, "Check that Crash Reporter is unsubscribed successfully")

    def tearDown(self):
        self.setPostcondition("Remove proxy app library")
        self.proxy_app_manager.remove_proxy_app_lib(libName.FUSA.value)
