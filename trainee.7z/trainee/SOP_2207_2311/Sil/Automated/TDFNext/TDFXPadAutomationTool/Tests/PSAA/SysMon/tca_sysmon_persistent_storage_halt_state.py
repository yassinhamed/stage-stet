from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_persistent_storage_halt_state(testfixture_PSAA_SysMon):
    TEST_ID = "PSAA/sysmon/tca_sysmon_persistent_storage_halt_state"
    REQ_ID = ["/item/2679875"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check statistics and state loaded from persistent storage in startup and saved in shutdown in halt state"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Check KVS exists")
        self.ssh_manager.downloadFileFromTarget("key_value_storage", "/persistent/sysmon/nvmblock/", OutputPathManager.get_test_case_path())
        returnValue = self.ssh_manager.executeCommandInTarget("ls /persistent/sysmon/nvmblock | grep key_value_storage")
        self.assertTrue(returnValue['exec_recv'] == 0, Severity.MAJOR, "Linux command  fails")
        self.assertTrue("key_value_storage" in returnValue["stdout"], Severity.MAJOR, "key_value_storage is not present under /persistent")

    def test_tca_sysmon_persistent_storage_halt_state(self):
        self.startTestStep("Set Halt state")
        self.diag_manager.start()
        res = self.diag_manager.syn_send(0xf4, self.diag_address, self.diag_to_set_halt_state)
        self.assertTrue(res == DiagResult.positive, Severity.BLOCKER, "no positive response for Diag job")
        self.diag_manager.stop()

        self.startTestStep("Get statistics")
        returnValue = self.ssh_manager.executeCommandInTarget("cat /persistent/sysmon/nvmblock/key_value_storage |grep -c statistics")
        self.assertTrue(returnValue['exec_recv'] == 0, Severity.MAJOR, "Linux command  fails")
        self.assertTrue(returnValue['stdout'].strip() == "1", Severity.MAJOR, f"statistics doesn't exist in key_value_storage, stdout = {returnValue['stdout'].strip()}")
        returnValue1 = self.ssh_manager.executeCommandInTarget("cat /persistent/sysmon/nvmblock/key_value_storage")
        self.assertTrue(returnValue1['exec_recv'] == 0, Severity.MAJOR, "Linux command  fails")
        statistics1 = returnValue1['stdout'].strip().split("statistics")[1].split("}")[0].split(",\"data\":")[1]
        logger.info(f"statistics1: {statistics1}")

        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")

        self.startTestStep("Get statistics")
        returnValue2 = self.ssh_manager.executeCommandInTarget("cat /persistent/sysmon/nvmblock/key_value_storage")
        self.assertTrue(returnValue2['exec_recv'] == 0, Severity.MAJOR, "Linux command  fails")
        statistics2 = returnValue2['stdout'].strip().split("statistics")[1].split("}")[0].split(",\"data\":")[1]
        logger.info(f"statistics2: {statistics2}")

        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")

        self.startTestStep("Get statistics")
        returnValue3 = self.ssh_manager.executeCommandInTarget("cat /persistent/sysmon/nvmblock/key_value_storage")
        self.assertTrue(returnValue3['exec_recv'] == 0, Severity.MAJOR, "Linux command  fails")
        statistics3 = returnValue3['stdout'].strip().split("statistics")[1].split("}")[0].split(",\"data\":")[1]
        logger.info(f"statistics3: {statistics3}")

        self.assertTrue(str(statistics2) == str(statistics3), Severity.MAJOR, f"statistics values before and after second reboot are the same")

    def tearDown(self):
        self.setPostcondition("Set continue state")
        self.diag_manager.start()
        res = self.diag_manager.syn_send(0xf4, self.diag_address, self.diag_to_set_continue_state)
        self.expectTrue(res == DiagResult.positive, Severity.BLOCKER, "no positive response for Diag job")
        self.diag_manager.stop()
