from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_emmc_io_statistics_LINUX_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_emmc_io_statistics_LINUX_non_verbose"
    REQ_ID = ["/item/5888380", "/item/5888677"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports EMMC IO statistics in Non-Verbose mode"
    OS = ['LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        # TODO add message id
        self.dlt_manager.apply_filter(messageId="")
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_emmc_io_statistics_LINUX_non_verbose(self):
        # TODO add message short name
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name="", sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait cycle of eMMC  * 2")
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get DLT EMMC non-verbose messages")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(True, Severity.MAJOR, "Check that non-verbose DLT EMMC IO statistics messages are available")
        self.expectTrue(True, Severity.MAJOR, "Check that dlt messages contain all required statistics")
        self.expectTrue(True, Severity.MAJOR, "Check that the value of the required statistics are different to -1")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
