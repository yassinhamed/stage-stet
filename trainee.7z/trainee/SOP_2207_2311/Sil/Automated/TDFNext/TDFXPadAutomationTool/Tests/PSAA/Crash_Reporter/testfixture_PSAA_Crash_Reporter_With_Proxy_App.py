from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter import *


class testfixture_PSAA_Crash_Reporter_With_Proxy_App(testfixture_PSAA_Crash_Reporter):

    kCoreDumpActive_Message_PrApp = ["Crashreporter", "received kCoreDumpActive"]
    kCoreDumpCompleted_Message_PrApp = ["Crashreporter", "received kCoreDumpCompleted"]
    kNoCoreDumpsDetected_Message_PrApp = ["Crashreporter", "received kNoCoreDumpsDetected"]

    kCoreDumpActive_Message_CRP = ["CrashReporterAraProxy", "received kCoreDumpActive"]
    kCoreDumpCompleted_Message_CRP = ["CrashReporterAraProxy", "received kCoreDumpCompleted"]
    kNoCoreDumpsDetected_Message_CRP = ["CrashReporterAraProxy", "received kNoCoreDumpsDetected"]

    WAIT_IPC_notification_MS = 5000

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_crashreporter setUpclsss")
        cls.deploy_proxy_app()
        cls.start_tdf_proxy_communication()
        cls.check_proxy_app()
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_tests_group_path(),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_crashreporter tearDownclsss")
        cls.stop_tdf_proxy_communication()
        cls.undeploy_proxy_app()

    def setUp(self):
        self.check_proxy_app()
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appId=self.PROXY_APP_APP_ID)
        self.dlt_manager.apply_filter(appId=self.CRASH_REPORTER_ARA_PROXY_APP_NAME_APP_ID)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def tearDown(self):
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
