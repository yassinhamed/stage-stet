from Tests.PSAA.STD_Frame.testfixture_PSAA_STDFrame import *


class tca_psaa_STDF_002_Hw_version(testfixture_PSAA_STDFrame):

    TEST_ID = "PSAA\tca_psaa_STDF_002_Hw_version"
    REQ_ID = ["/item/2175806"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check non verbose message 'HW_version_msg_short_name' is logged"
    OS = ['LINUX','QNX']
    STATUS = "Ready"

    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_HWVersion)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_STDF_002_Hw_version(self):
        self.startTestStep("Get non verbose message 'HW_version_msg_short_name'")
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.HW_version_msg_short_name, sender=self.PP_ECUID, filter_attributes=None)
        self.sleep_for(self.wait_for_STDF_dlt_message)
        self.dlt_manager.stop_capturing_non_verbose_message()
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check the non verbose message 'HW_version_msg_short_name' was received")
        self.expectTrue(str(dlt_messages[-1]['payload']['ecu_hwel_major']) != "", Severity.MAJOR, f"Check the ecu_hwel_major in payload{dlt_messages[-1]['payload']['ecu_hwel_major']} is not empty")
        self.expectTrue(str(dlt_messages[-1]['payload']['ecu_hwel_minor']) != "", Severity.MAJOR, f"Check the ecu_hwel_minor in payload{dlt_messages[-1]['payload']['ecu_hwel_minor']} is not empty")
        self.expectTrue(str(dlt_messages[-1]['payload']['ecu_hwel_patch']) != "", Severity.MAJOR, f"Check the ecu_hwel_patch in payload{dlt_messages[-1]['payload']['ecu_hwel_patch']} is not empty")

    def tearDown(self):
        pass
