from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter import *


class tca_psaa_CrashReporter_006_file_permissions(testfixture_PSAA_Crash_Reporter):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_006_file_permissions"
    REQ_ID = ["/item/6159353"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps files permissions"
    STATUS = "Ready"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Clear old core dumps")
        remove_is_done = self.remove_old_coredumps()
        self.expectTrue(remove_is_done, Severity.MAJOR, "Check the remove of old coredumps is done")
        self.setPrecondition("Check crash reporter is running")
        crash_reporter_is_running = self.parse_crash_reporter_commandline_parameters()
        self.expectTrue(crash_reporter_is_running != None, Severity.MAJOR, "Check that crash reporter is running")

    def test_tca_psaa_CrashReporter_006_file_permissions(self):
        self.startTestStep("Get pid of the application to be killed")
        Plannning_pid = self.get_process_id(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(Plannning_pid != -1, Severity.MAJOR, "Check the application is running")
        self.startTestStep("Kill application")
        application_is_killed = self.kill_application_CR(app_name=self.PLANNING_APP_NAME, signal="SIGABRT")
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check the kill command is executed")
        self.startTestStep("Wait for coredumps creation")
        self.sleep_for(self.default_dumper_timeout)
        self.startTestStep("Check application is killed")
        Plannning_still_running = self.check_application_is_started(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(not Plannning_still_running, Severity.MAJOR, "Check the application is killed")
        self.startTestStep("Get coredumps names using ls command")
        # context file check
        app_name_in_context_file = self.context_file_check(app_name=self.PLANNING_APP_NAME)
        self.expectTrue(app_name_in_context_file, Severity.MAJOR, "Check the context file is created successfully under /persistent/coredumps")
        # core file check
        app_name_in_core_file = self.core_file_check(app_name=self.PLANNING_APP_NAME)
        self.expectTrue(app_name_in_core_file, Severity.MAJOR, "Check the core file is created successfully under /persistent/coredumps")

        self.startTestStep("Get coredumps files access permissions using ls -l /persistent/coredumps command")
        coredumps_info = self.ssh_manager.executeCommandInTarget(command=f"ls -l -h /persistent/coredumps/", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue("-r--r-----" in coredumps_info["stdout"], Severity.MAJOR, "Check coredumps files access is -r--r-----")

    def tearDown(self):
        self.setPostcondition("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
