from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_011_transfert_coredumps_via_DLT_kernel(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_011_transfert_coredumps_via_DLT_kernel"
    REQ_ID = ["/item/2593168", "/item/2593334"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check core dumps for kernel panic transferred over the DLT"
    STATUS = "Ready"
    OS = ['LINUX']

    msg_transfer = ["Transferred", "/persistent/coredumps/kernel/kdump.vmcore", "successfully"]

    def setUp(self):
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appId=self.CRASH_HANDLER_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.Default_Context_Id)
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.sleep_for(self.DLT_START_MONITORING_TIMEOUT)

    def test_tca_psaa_Chandler_011_transfert_coredumps_via_DLT_kernel(self):

        self.startTestStep("Perform kernel panic")
        self.ssh_manager.executeCommandInTargetNoWait(command=self.kernel_panic_command, ip_address=self.PP_IP)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.startTestStep("get kernel coredumps names")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"ls -la {self.CoreDumps_Path}/kernel | grep -c kdump.vmcore",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Checking that the coredumps were generated")
        self.startTestStep("Get DLT messages")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        messages_count, messages_array_set = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.msg_transfer)
        logger.info("Dlt message count=" + str(messages_count))
        self.expectTrue(messages_count > 0, Severity.BLOCKER, "Check {0} was transferred via DLT".format(self.msg_transfer))

    def tearDown(self):
        self.dlt_manager.clear_all_dlt_messages()
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()

