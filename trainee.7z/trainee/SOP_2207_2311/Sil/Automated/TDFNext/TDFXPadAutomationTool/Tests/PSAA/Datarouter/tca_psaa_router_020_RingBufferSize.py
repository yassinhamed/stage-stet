from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter_ProxyApp import *


class tca_psaa_router_020_RingBufferSize(testfixture_PSAA_Datarouter_ProxyApp):

    TEST_ID = "PSAA\tca_psaa_router_020_RingBufferSize"
    REQ_ID = ["/item/145004"]
    DEV_OBJ = ['mPAD_Performance_2C']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX','QNX']


    def setUp(self):
        self.dlt_manager.clear_all_dlt_messages()
        self.ssh_manager.uploadFileToTarget(self.input_folder,'logging_ring.json','/tmp')
        returnValue = self.ssh_manager.executeCommandInTarget(r"cp /opt/proxy_app/etc/logging.json /persistent/Technica/prxa_logging.json")
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.MAJOR, "Check the copy of the original json file")
        returnValue = self.ssh_manager.executeCommandInTarget(r"cp /tmp/logging_ring.json /opt/proxy_app/etc/logging.json")
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.MAJOR, "Check the copy of the updated logging file")
        self.ssh_manager.executeCommandInTarget(command=f"chmod 644 /opt/proxy_app/etc/logging.json", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        result = self.ssh_manager.executeCommandInTarget(command=f'ls -l /opt/sysmon/etc/logging.json',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('-rw-r--r--' in result['stdout'], Severity.MAJOR,f"False Permission, Permission = {result['stdout']}")
        self.ssh_manager.executeCommandInTarget(command=f"sync -d /opt/proxy_app/etc/logging.json", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.ssh_manager.executeCommandInTarget(command="mount -o ro,remount /", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)

        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECU_status = self.check_ECUs()
        self.expectTrue(ECU_status, Severity.BLOCKER, "Checking that ECU status is OK")

        returnValue = self.ssh_manager.executeCommandInTarget("cat /opt/proxy_app/etc/logging.json | grep -c ringBufferSize")
        self.expectTrue(returnValue["stdout"].strip() =="1", Severity.BLOCKER,"Check ring BufferSize exist")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.ARA_LOG.value)
        self.dlt_manager.apply_filter(appId=self.PROXY_APP_APP_ID)
        self.dlt_manager.apply_filter(contextId="L1")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_router_020_RingBufferSize(self):
        self.startTestStep("Start Bitrate with multi threads performance test")
        result=self.proxy_app_manager.ARA_LOG_comm.start_perf_bitrate_logging(logLevel = araLogLevel.INFO.value, iterationNumber = self.performance_bitrate_logging_iterationNumber, logStringSize = self.performance_bitrate_logging_logStringSize, timeIntervalus = self.performance_bitrate_logging_timeIntervalus, threadNumber = self.performance_bitrate_logging_threadNumber)
        self.expectTrue(result==araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the START of PERF BITRAITE")

        self.sleep_for(self.wait_for_performance_bitrate_logging_to_finish)

        self.startTestStep("Stop Bitrate with multi threads performance test")
        result=self.proxy_app_manager.ARA_LOG_comm.stop_pref_bitrate_logging()
        self.expectTrue(result==araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the stop of PERF BITRAITE")

        self.startTestStep("Get DLT message before the update of ringBufferSize")
        messages_count, messages_array_set = self.dlt_manager.get_messages(searchMsg="A")
        self.expectTrue(messages_count > (self.performance_bitrate_logging_iterationNumber-self.performance_bitrate_logging_iterationNumber*0.03), Severity.BLOCKER, "Check messages are logged")

        logger.info("Messages Count = " + str(messages_count))
        self.dlt_manager.clear_all_dlt_messages()
        self.dlt_manager.stop_monitoring()
        self.proxy_app_manager.remove_proxy_app_lib(libName.ARA_LOG.value)

        self.startTestStep("Reduce ringBufferSize")
        exitcode=self.json_manager.updateNodeIntoJsonFile(filePath="/opt/proxy_app/etc/logging.json", nodePath="ringBufferSize", value=10, use_cache = False, delete_cache = True, upload_file = True)
        self.expectTrue(exitcode, Severity.BLOCKER, "Check the update of ringBufferSize")

        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECU_status = self.check_ECUs()
        self.expectTrue(ECU_status, Severity.BLOCKER, "Checking that ECU status is OK")

        returnValue = self.ssh_manager.executeCommandInTarget("cat /opt/proxy_app/etc/logging.json | grep -c ringBufferSize")
        self.expectTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER, "Check ring BufferSize exist")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.ARA_LOG.value)
        self.dlt_manager.apply_filter(appId=self.PROXY_APP_APP_ID)
        self.dlt_manager.apply_filter(contextId="L1")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.start_monitoring("SRR-DLT")

        self.startTestStep("Start Bitrate with multi threads performance test")
        result=self.proxy_app_manager.ARA_LOG_comm.start_perf_bitrate_logging(logLevel = araLogLevel.INFO.value, iterationNumber = self.performance_bitrate_logging_iterationNumber, logStringSize = self.performance_bitrate_logging_logStringSize, timeIntervalus = self.performance_bitrate_logging_timeIntervalus, threadNumber = self.performance_bitrate_logging_threadNumber)
        self.expectTrue(result==araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the START of PERF BITRAITE")

        self.sleep_for(self.wait_for_performance_bitrate_logging_to_finish)

        self.startTestStep("Stop Bitrate with multi threads performance test")
        result=self.proxy_app_manager.ARA_LOG_comm.stop_pref_bitrate_logging()
        self.expectTrue(result==araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the stop of PERF BITRAITE")

        self.startTestStep("Get DLT message after the update of ringBufferSize")
        messages_count_2, messages_array_set = self.dlt_manager.get_messages(searchMsg="A")
        self.expectTrue(messages_count_2 < messages_count, Severity.BLOCKER, "Check that some messages are lost after reducing ringBufferSize")
        logger.info("Messages Count_2 = " + str(messages_count_2))

    def tearDown(self):
        self.dlt_manager.stop_monitoring()
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.clear_all_dlt_messages()

        self.proxy_app_manager.remove_proxy_app_lib(libName.ARA_LOG.value)

        self.RevertConfigFile()

        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECU_status = self.check_ECUs()
        self.expectTrue(ECU_status, Severity.BLOCKER, "Checking that ECU status is OK")
