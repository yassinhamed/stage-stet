from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_cpu_06_iowait_CPUC_non_verbose_linux(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_cpu_06_iowait_CPUC_non_verbose_linux"
    REQ_ID = ["/item/5831414"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon report iowait CPU usage of the each core in non-verbose mode"
    OS = ['LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.CPU_core_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_CPUC)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_cpu_06_iowait_CPUC_non_verbose_linux(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_CPUC, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 10)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get CPUC non-verbose DLT messages that contains iowait per core cpu usage")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that iowaut DLT message exist")

        self.startTestStep("Get iowait value")
        iowait = float(dlt_messages[0]["payload"]["iowait"])
        self.expectTrue(iowait != self.INVALID_VALUE, Severity.MAJOR, "Check that iowait is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
