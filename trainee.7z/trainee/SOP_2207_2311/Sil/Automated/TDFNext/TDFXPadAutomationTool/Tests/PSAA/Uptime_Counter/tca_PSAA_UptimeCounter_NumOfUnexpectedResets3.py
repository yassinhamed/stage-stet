from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *


class tca_PSAA_UptimeCounter_NumOfUnexpectedResets3(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_NumOfUnexpectedResets3"
    REQ_ID = ["/item/3316218"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ["QNX", "LINUX"]

    def setUp(self):
        pass

    def test_tca_PSAA_UptimeCounter_NumOfUnexpectedResets3(self):

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting Num Of Unexpected Resets value")
        First_NumOfUnexpectedResets = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.Unexpected_reset_counter)
        logger.info(f"First_NumOfUnexpectedResets_value: {First_NumOfUnexpectedResets}")

        self.startTestStep("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK == True, Severity.MAJOR, "Check ECUS are correctly reset")

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting Num Of Unexpected Resets value value after counters incrementation ")
        Second_NumOfUnexpectedResets = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.Unexpected_reset_counter)
        logger.info(f"Second_NumOfUnexpectedResets_value: {Second_NumOfUnexpectedResets}")
        self.assertTrue(First_NumOfUnexpectedResets == Second_NumOfUnexpectedResets, Severity.MAJOR, "Check number of unexpected resets after reset")

    def tearDown(self):

        pass
