from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_003_OOM_detailed_memory_usage_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_003_OOM_detailed_memory_usage_LINUX"
    REQ_ID = ["/item/5911326", "/item/5911246", "/item/5911334"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports detailed memory usage when the usage threshold is reached"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Clear DTC memory")
        self.diag_manager.start()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)

        self.setPrecondition("Upload stress-ng files under the direction /persistent/Technica")
        self.ssh_manager.uploadFileToTarget(self.input_folder, "libaio1-0.3.112-2.3.x86_64.rpm", "/persistent/Technica", self.PP_IP)
        self.ssh_manager.uploadFileToTarget(self.input_folder, "libbsd0-0.10.0-1.2.x86_64.rpm", "/persistent/Technica", self.PP_IP)
        self.ssh_manager.uploadFileToTarget(self.input_folder, "lksctp-tools-1.0.16-2.4.x86_64.rpm", "/persistent/Technica", self.PP_IP)
        self.ssh_manager.uploadFileToTarget(self.input_folder, "stress-ng-0.11.10-lp152.1.1.x86_64.rpm", "/persistent/Technica", self.PP_IP)

        self.setPrecondition("Give the Execution Right to all the rpm files.")
        self.ssh_manager.executeCommandInTarget(command="chmod +x /persistent/Technica/*.rpm", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)

        self.setPrecondition("Give the Execution Right to all the rpm executer.")
        self.ssh_manager.executeCommandInTarget(command="chmod +x /usr/lib/sysimage/rpm/.rpm.lock", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)

        self.setPrecondition("Give the Execution Right to all the rpm executer.")
        self.ssh_manager.executeCommandInTarget(command="cd /persistent/Technica/ && rpm -ivh *.rpm", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)

        self.setPrecondition("Get logging time interval of OOM")
        self.OOM_time_interval = self.get_time_interval(contextID=self.cgroup_oom_report_context_id)
        logger.info(f"Time interval of OOM = {self.OOM_time_interval}")
        self.assertTrue(self.OOM_time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        self.setPrecondition("Get threshold of OOM")
        self.OOM_threshold = self.get_time_interval(contextID=self.cgroup_oom_report_context_id + "limit")
        logger.info(f"threshold of OOM = {self.OOM_threshold}")
        self.assertTrue(self.OOM_threshold != self.INVALID_VALUE, Severity.BLOCKER, "Check that threshold was successfully retrieved")

        self.setPrecondition("Read Secondary info memory and get Status of DTC Maximale Speicherplatz Ausnutzung erreicht.")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Maximale_Speicherplatz_Ausnutzung_erreicht"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC Maximale Speicherplatz Ausnutzung erreicht in SetUp :" + str(read_status))
        self.expectTrue(read_status == self.DTC_NOT_PRESENT, Severity.BLOCKER, "Checking that DTC Maximale Speicherplatz Ausnutzung erreicht is Not Present: 0x50 or None.")

        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.cgroup_oom_report_context_id)
        self.dlt_manager.apply_filter(contextId="DTC")
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_memory_003_OOM_detailed_memory_usage_LINUX(self):
        self.startTestStep("Execute stress-ng with 0.95% ram usage for 20 sec.")
        self.ssh_manager.executeCommandInTarget(command="""stress-ng --vm-bytes $(awk '/MemAvailable/{printf"%d", $2 * 0.95;}' < /proc/meminfo)k --vm 8 --timeout 20s""", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)

        self.sleep_for(self.wait_for_oom_reports_ms)

        self.startTestStep("Get DTC OOM detailed DLT message")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=["kFailed", "DTC", "DiagnosticMonitorMaxRAMUsagePPort"])
        self.expectTrue(message_count > 0, Severity.MAJOR, "Check that DLT OOM detailed message exits")

        self.startTestStep("Get DLT OOM detailed DLT message")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=["OOM", "triggered", "Limit"])
        self.expectTrue(message_count > 0, Severity.MAJOR, "Check that DLT OOM detailed message exits")

        self.startTestStep("Reset safety")
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_MS)
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)

        self.startTestStep("Read Secondary info memory and get Status of DTC Maximale Speicherplatz Ausnutzung erreicht.")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Maximale_Speicherplatz_Ausnutzung_erreicht"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC Maximale Speicherplatz Ausnutzung erreicht in test main :" + str(read_status))
        self.expectTrue(read_status == self.DTC_STATUS_AFTER_RESET_OnStartupDTC, Severity.BLOCKER, "Checking that DTC Maximale Speicherplatz Ausnutzung erreicht is ACTIVE.")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.diag_manager.stop()
