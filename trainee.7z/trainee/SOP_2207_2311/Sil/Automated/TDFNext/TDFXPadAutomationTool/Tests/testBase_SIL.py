# inheritence
from Tests_Common.testfixture_Common import testfixture_Common
# PA un/deployment
from os import path, remove, mkdir, environ
from Helper_Common.BusHelper import *
from TDFNextApi.Utilities import *
from TDFNextApi.BusListener import *
from Helper.ProxyApp.ProxyAppManager import ProxyAppManager
from Helper.ProxyApp.ProxyAppDeployer import ProxyAppDeployer
from Helper.ProxyApp.TestAppDeployer import TestAppDeployer
from Helper.StressTools import StressTools
from Utilities_Common.Automation.Decorators import *
from Tests_Common.TestBase import TestBase
from TDFNextApi.Dtc.DtcController import DtcController
import traceback
import json
import gzip
import shutil
import struct
import io
from enum import Enum
import datetime

from TDFNextApi.SomeIP.SomeIpCorrupter import SomeIpCorrupter
from TDFNextApi.Dtc.DtcManager import memory_type
# needed in BCP simulation
from TDFNextApi.NM.NMController import NMController, CtrBsPrtnt, CtrFktnPrtnt
from TDFNextApi.CdcToolbox import CdcToolbox

# needed in TCs
from TestRunner.UnitTest.case import Severity
from Utilities_Common.CmdProcess import CmdProcess
from Utilities.ProxyAppTools.proxy_message import *
from Utilities.ProxyAppTools.aracom_pb2 import *
from Utilities.ProxyAppTools.aralog_pb2 import *
from Utilities.ProxyAppTools.araper_pb2 import *
from Utilities.ProxyAppTools.intc_pb2 import *
from Utilities.ProxyAppTools.linux_pb2 import *
from Utilities.ProxyAppTools.xpad_pb2 import *
from Utilities.ProxyAppTools.enumTypes import *
from Helper.ProxyApp.ProxyAppSettings import *
from Helper.Coredump.CoredumpChecker import *
from Helper.EcuFilePatcher import *
from Utilities_Common.OutputPathManager import *
from TDFNextApi.Diag.DiagManager import *
from TDFNextApi.SfaManager import EcuMode, Feature_Status
from TDFNextApi.SomeIP.SomeipSDWatcher import EntryType
from TDFNextApi.time import xtime

from TDFNextApi.Dlt.DltManager import PartialNetwork


class testBase_SIL(testfixture_Common):
    INVALID_VALUE = -1

    input_folder = path.join(path.sep.join(path.abspath(__file__).split(path.sep)[:-2]), "Files")
    tmp_folder = path.join('\\'.join(path.abspath(__file__).split("\\")[:-2]), "Tmp")
    PERSISTENT_FOLDER = "/persistent"
    technica_persistent_folder = "/persistent/Technica"
    proxy_app_manager = None
    __stress_tools = None
    bIs_BCP_Simulated = False
    PROXY_APP_SERVICE_ID = 0x07be
    PROXY_APP_NOTIF_EVENT_GROUP = 150
    PROXY_APP_NOTIF_EVENT_METHOD_ID = 32800

    WAIT_FOR_VSOMEIP_START_MS = 5000
    WAIT_FOR_DLT_LOG_MS = 1000

    FDL_CODING_TIMEOUT_MS = 60000
    FDL_CODING_TIMEOUT = 60000

    ECU_DEGRADATED = 0x5A
    ECU_NOT_DEGRADATED = 0xA5

    TESTER_DIAG_ADR = 0xF4
    BCP_DIAG_ADR = 0x10
    MSM_RUNNING = 0x03
    MSM_PLATFORMONLY = 0x05
    HSFZ_INTERN = 0x1002
    DLT_CHECK_TIMEOUT = 5000
    SOMEIPSD_CHECK_TIMEOUT_MS = 30000
    SOMEIPSD_CHECK_TIMEOUT_S = 30
    STOP_OFFER_TIMEOUT = 5
    OFFER_SERVICE_TIMEOUT = 5
    OFFER_SERVICE_TIMEOUT_MS = 5000
    SET_MG_CONFIG_S = 5
    SET_MG_CONFIG_MS = 5000
    MG_RESET_S = 5
    MG_RESET_MS = 5000
    DLT_TIMEOUT = 10000
    # MG_RESET_TIMEOUT = 5000

    # startup & shutdown timeout
    PP_STARTUP_TIMEOUT_S = 30
    PP_SHUTDOWN_TIMEOUT_S = 5
    SC_STARTUP_TIMEOUT_S = 3
    SC_SHUTDOWN_TIMEOUT_S = 2

    TTL_STOP_OFFER_SERVICE = 0x0
    TTL_OFFER_SERVICE = 0x3
    PROVIDED_SERVICE_TIMEOUT = 2000
    FIND_SERVICE_TIMEOUT = 20
    STOP_UDPNM = 5000
    START_UDPNM_MS = 5000
    STOP_UDPNM_MS = 5000
    UDPNM_LISTENER = 5000
    SET_ADATER_CONFIG_MS = 5000
    WAIT_AFTER_SET_SIGNAL_MS = 1000

    START_SIMULATION_TIMEOUT_MS = 5000
    SET_SIGNAL_TIMEOUT_MS = 5000

    COREDUMP_GENERATION_TIMEOUT_MS = 15000
    SSH_EXECUTION_TIMEOUT_MS = 3000
    TOKEN_STATUS_UPDATE_TIMEOUT_MS = 3000
    SET_NEW_MACHINE_STATE_MS = 10000
    GET_CURRENT_MACHINE_STATE_MS = 10000
    Wait_for_stacktrace_MS = 10000
    KILL_TIMEOUT_MS = 5000
    WAIT_FOR_APPLICATION_KILL_MS = 30000
    WAIT_FOR_APPLICATION_START_MS = 5000
    WAIT_FOR_REACTION_ON_FREEZE = 10000
    MACHINE_STATE_TRANSITION_MS = 5000
    RECOVERY_MODE_TIMEOUT_MS = 70000
    SLEEP_TIME_AFTER_ERROR_FAULT_INJECTION_JOB_MS = 2000

    # Diag jobs
    STATUS_MSM_STATE_GETTER = [0x22, 0x65, 0x1e]
    STEUERGERAETE_RESET = [0x11, 0x01]
    STEUERN_ACTIVATE_PARALLEL_FLASHMODE = [0x31, 0x01, 0x10, 0x0E]
    STEUERN_ACTIVATE_NORMAL_PROGRAMMING = [0x31, 0x01, 0x10, 0x0F]
    DIAG_SERIAL_NUMBER_LESEN = [0x22, 0xF1, 0x8C]
    DIAG_SVK_LESEN = [0x22, 0xf1, 0x01]
    STEUERN_LOESCHEN_UNGEWOLLTE_RESETS_STATISTIKEN = [0x2e, 0x43, 0x4a, 0x00]
    STEUERN_CORE_IO_MODE = [0x31, 0x01, 0xF0, 0x0F]
    FS_LOESCHEN = [0x14, 0xff, 0xff, 0xff]
    IS_LOESCHEN = [0x31, 0x1, 0xF, 0x6]
    IS_LESEN = [0x19, 0x17, 0x0c, 0x01]
    STEUERN_DLT_RESET_TO_DEFAULT = [0x31, 0x01, 0x10, 0x91]
    STEUERN_DLT_STORE_CONFIGURATION = [0x31, 0x01, 0x10, 0x94]
    STEUERN_DLT_SET_LOGLEVEL = [0x31, 0x01, 0x10, 0x90]
    STEUERN_DLT_SET_DEFAULT_LOGLEVEL = [0x31, 0x01, 0x10, 0x96, 0x03]
    STATUS_DLT_READ_LOG_CHANNEL_NAMES = [0x22, 0x18, 0x28]
    STATUS_FIREWALL_ETHERNET_HISTORIE = [0x22, 0x12, 0x10]
    COMMUNICATION_CONTROL_RX_ON_TX_OFF = [0x28, 0x01, 0x01]
    COMMUNICATION_CONTROL_RX_ON_TX_ON = [0x28, 0x00, 0x01]
    COMMUNICATION_CONTROL_RX_OFF_TX_ON = [0x28, 0x02, 0x01]
    COMMUNICATION_CONTROL_RX_OFF_TX_OFF = [0x28, 0x03, 0x01]
    STEUERGERAETE_RESET_SOFT = [0x11, 0x03]
    APPLICATION_RESTART = [0x11, 0x42]
    STEUERGERAETE_SHUTDOWN = [0x11, 0x04]
    DIAG_DEACTIVATE_FLASH_MODE = [0x31, 0x01, 0x0f, 0x0C, 0x00]
    STATUS_RXSWIN_INT = [0x22, 0x25, 0xC0]
    CONTROL_DTC_SETTING_OFF = [0x85, 0x02]
    DIAG_ACTIVATE_FLASH_MODE = [0x31, 0x01, 0x0f, 0x0C, 0x03]
    CONTROL_EXTENDED_ENERGY_SAVING_STATE = [0x31, 0x01, 0x10, 0x03, 0x01]
    STATUS_ACTIVE_SESSION_STATE = [0x22, 0xF1, 0x00]
    STEUERN_EMMC_WEAROUT_ERROR_INJECTION = [0x2E, 0x40, 0xAC]
    STEUERN_RECOVERY_MODE = [0x2e, 0x42, 0x42, 0x01, 0x01]
    STEUERN_RECOVERY_MODE_DISABLED = [0x2e, 0x42, 0x42, 0x01, 0x04]

    SET_IE_PAYLOAD = [0x2E, 0x5C, 0x6C, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x00, 0x00, 0x00, 0x00,
                      0x00, 0x00, 0x00, 0xFF]
    SET_A_UNIT_PAYLOAD = [0x2E, 0x5C, 0x6C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x65, 0x88, 0x00, 0x00, 0x00,
                          0x00, 0x00, 0x00, 0x00, 0xFF]
    SET_BIU_PAYLOAD = [0x2E, 0x5C, 0x6B, 0x00, 0x00, 0x04, 0x01, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00]
    SET_B_UNIT_PAYLOAD = [0x2E, 0x5C, 0x6C, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x6E, 0x04, 0x00, 0x00, 0x00,
                          0x00, 0x00, 0x00, 0x00, 0xFF]
    SET_FEC_PAYLOAD = [0x2E, 0x5C, 0x6B, 0x00, 0x00, 0x04, 0x09, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00]
    SET_MEC_PAYLOAD = [0x2E, 0x5C, 0x6B, 0x00, 0x00, 0x04, 0x0D, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    SET_PMC_PAYLOAD = [0x2E, 0x5C, 0x6C, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x1C, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x01]
    SET_PMU_PAYLOAD = [0x2E, 0x5C, 0x6B, 0x00, 0x00, 0x04, 0x15, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    SET_RAM_PAYLOAD = [0x2E, 0x5C, 0x6B, 0x00, 0x00, 0x04, 0x05, 0xFF, 0xFF, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00]
    SET_RESET_CAUSE_PAYLOAD = [0x2E, 0x5C, 0x6C, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x24, 0x00, 0x00, 0x00,
                               0x00, 0x00, 0x00, 0x00, 0xFF]
    SET_SYSTEM_AGENT_PAYLOAD = [0x2E, 0x5C, 0x6B, 0x00, 0x00, 0x04, 0x11, 0xFF, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                                0x00]

    # DTC list
    DTC_LIST = {
        "PLATFORM_HEALTH_MANAGER_RESET_REQUEST": {'mPAD_Performance': 0x482ED9, 'mPAD_Performance_AddOn': 0x482ED9,
                                                  'mPAD_Performance_High': 0x808B05},
        "SW_Integritätsprüfung_fehlgeschlagen": {'mPAD_Performance': 0x022292, 'mPAD_Performance_AddOn': 0x022292,
                                                 'mPAD_Performance_High': 0x029192},
        "Interne_System_Manipulation_erkannt": {'mPAD_Performance': 0x482EA9, 'mPAD_Performance_AddOn': 0x482EA9,
                                                'mPAD_Performance_High': 0x808B10},
        "Software_Fehler": {'mPAD_Performance': 0x482E81, 'mPAD_Performance_AddOn': 0x482E81,
                            'mPAD_Performance_High': 0x808B03},
        "Kernelpanik_oder_Kernel_OOP": {'mPAD_Performance': 0x482F76, 'mPAD_Performance_AddOn': 0x482F76,
                                        'mPAD_Performance_High': 0x808B17},
        "Applikation_wurde_unerwartet_beendet": {'mPAD_Performance': 0x482F7E, 'mPAD_Performance_AddOn': 0x482F7E,
                                                 'mPAD_Performance_High': 0x808B21},
        "Software_Test_Library_Fehler": {'mPAD_Performance': 0x482F7C, 'mPAD_Performance_AddOn': 0x482F7C,
                                         'mPAD_Performance_High': 0x808B20},
        "Interner_Steuergeraetefehler": {'mPAD_Performance': 0x482E80, 'mPAD_Performance_AddOn': 0x482E80,
                                         'mPAD_Performance_High': 0x808B02},
        "UART_Communication_Error": {'mPAD_Performance': 0x7E03FA, 'mPAD_Performance_AddOn': 0x7E03FA,
                                     'mPAD_Performance_High': 0x7E03FA},
        "Maximale_Speicherplatz_Ausnutzung_erreicht": {'mPAD_Performance': 0x482F6E, 'mPAD_Performance_AddOn': 0x482F6E,
                                                       'mPAD_Performance_High': 0x808B08},
        "EMMC_WEAR_OUT": {'mPAD_Performance': 0x482E90, 'mPAD_Performance_AddOn': 0x482E90,
                          'mPAD_Performance_High': 0x808B0D},
        "IE Fehler": {'mPAD_Performance': 0x482E86, 'mPAD_Performance_AddOn': 0x482E86,
                      'mPAD_Performance_High': 0x808B1B},
        "FEC_Fehler": {'mPAD_Performance': 0x482E88, 'mPAD_Performance_AddOn': 0x482E88,
                       'mPAD_Performance_High': 0x808B0A},
        "MEC_Fehler": {'mPAD_Performance': 0x482E89, 'mPAD_Performance_AddOn': 0x482E89,
                       'mPAD_Performance_High': 0x808B09},
        "PMC_Fehler": {'mPAD_Performance': 0x482F6F, 'mPAD_Performance_AddOn': 0x482F6F,
                       'mPAD_Performance_High': 0x808B0C},
        "PMU_Fehler": {'mPAD_Performance': 0x482F70, 'mPAD_Performance_AddOn': 0x482F70,
                       'mPAD_Performance_High': 0x808B22},
        "BIU_Fehler": {'mPAD_Performance': 0x482F72, 'mPAD_Performance_AddOn': 0x482F72,
                       'mPAD_Performance_High': 0x808B1D},
        "L2_RAM_Fehler": {'mPAD_Performance': 0x482F73, 'mPAD_Performance_AddOn': 0x482F73,
                          'mPAD_Performance_High': 0x808B07},
        "Thermischer Fehler": {'mPAD_Performance': 0x482F75, 'mPAD_Performance_AddOn': 0x482F75,
                               'mPAD_Performance_High': 0x808B12},
        "System_Agent_Fehler": {'mPAD_Performance': 0x482E9F, 'mPAD_Performance_AddOn': 0x482E9F,
                                'mPAD_Performance_High': 0x808B18},
        "Reset_cause": {'mPAD_Performance': 0x482EA0, 'mPAD_Performance_AddOn': 0x482EA0,
                        'mPAD_Performance_High': 0x808B15},
        "Uncorrectable_Error_Status_Register-A-Unit": {'mPAD_Performance': 0x482EA1, 'mPAD_Performance_AddOn': 0x482EA1,
                                                       'mPAD_Performance_High': 0x808B1E},
        "Uncorrectable_Error_Status_Register-B-Unit": {'mPAD_Performance': 0x482EA2, 'mPAD_Performance_AddOn': 0x482EA2,
                                                       'mPAD_Performance_High': 0x808B1F},
        "Machine_State_Manager_Fehler": {'mPAD_Performance': 0x482F77, 'mPAD_Performance_AddOn': 0x482F77,
                                     'mPAD_Performance_High': 0x808B16},
    }

    UWB_ENV = {
        "LOG_COLLECTOR_INFO": '5C65'
    }

    DTC_ACTIVE = 0x2F
    DTC_INACTIVE = 0x2E
    DTC_STATUS_AFTER_CLEAR = 0x50
    DTC_NOT_PRESENT = None
    DTC_STATUS_AFTER_RESET_OnStartupDTC = 0x2C
    DTC_STATUS_AFTER_RESET_OnEventDTC = 0x6C
    DTC_STATUS_AFTER_TWO_RESETS = 0x28
    DTC_NOT_PRESENT_LIST = [None, 0x50]

    MASK_FF = 0xFF

    UWB_PHM_RESET_INFO_SUPERVISION_ID = "5C70"
    UWB_PHM_RESET_INFO_SUPERVISIONSTATETYPE = "5C71"
    UWB_PHM_RESET_INFO_SUPERVISIONTYPE = "5C72"
    UWB_PHM_RESET_INFO_SUPERVISIONSTATETYPE_EXPIRED = "00"
    UWB_PHM_RESET_INFO_SUPERVISIONTYPE_LOCAL = "00"

    SSH_CONNECTION_TIMEOUT_MS = 3000
    SOMEIP_SIMULATION_START_TIMEOUT = 5000
    GETTER_RESPONSE_TIMEOUT_MS = 1000
    SETTER_NOTIF_TIMEOUT_MS = 1000

    SET_ADAPTER_GONFIGUARTION_TIMEOUT = 5000
    SET_ADAPTER_GONFIGUARTION_TIMEOUT_S = 5
    CLEAR_ADAPTER_CONFIGURATION_TIMEOUT = 5000
    SNIFFING_TIMEOUT = 60000
    WAIT_TIME_KILLING_PLANNING_APPLICATION_MS = 30000
    WAIT_FOR_COREDUMPS_GENERATION_MS = 10000

    NEW_MACHINE_STATE_TIMEOUT_MS = 10000

    SID_DIAGNOSTIC_SESSION_CONTROL = [0x10]
    SID_READ_DATA_BY_IDENTIFIER = [0x22]
    SID_ECU_RESET = [0x11]
    SID_ROUTINE_CONTROL = [0x31]
    SID_READ_DTC_INFORMATION = [0x19]
    SID_WRITE_DATA_BY_IDENTIFIER = [0x2e]
    SID_TESTER_PRESENT = [0x3e]
    SID_COMMUNICATION_CONTROL = [0x28]

    NRC_REQUEST_OUT_OF_RANGE = 0x31
    NRC_CONDITION_NOT_CORRECT = 0x22
    NRC_GENERAL_REJECT = 0x10
    NRC_INCORRECT_MESSAGE_LENGTH_OR_INVALID_FORMAT = 0x13
    NRC_SERVICE_NOT_SUPPORTED_IN_ACTIVE_SESSION = 0x7f
    NRC_SERVICE_NOT_SUPPORTED = 0x11
    NRC_SUBFUCTION_NOT_SUPPORTED_IN_ACTIVE_SESSION = 0x7e

    SOMEIP_MULTICAST_IP = '239.192.255.251'
    BCP_IP = '160.48.199.64'
    ZGW_IP = '160.48.199.16'
    ZGW_EXT_IP = '169.254.21.11'
    TESTER_IP = '160.48.199.125'
    TESTER_IP2 = '160.48.199.118'
    MGU_IP = '160.48.199.99'
    WAVE_IP = '160.48.199.97'
    RAM_IP = '160.48.199.55'
    DLT_HIGH_IP = '231.255.42.99'
    DLT_LOW_IP = '239.255.42.99'
    DEFAULT_MASK = '255.255.255.128'
    NON_ROUTABLE_META_ADDRESS = '0.0.0.0'
    LIMITED_BROADCAST_ADDRESS = '255.255.255.255'
    PP_EXTERNAL_IP_FOR_ELK = "169.254.21.103"

    serial_channel = "PP-Serial"

    SFA_ID = 0x001D1A
    DM_VERITY = 0x00D1C5

    DLT_LOG_FATAL = 0x01
    DLT_LOG_ERROR = 0x02
    DLT_LOG_WARN = 0x03
    DLT_LOG_INFO = 0x04
    DLT_LOG_DEBUG = 0x05
    DLT_LOG_VERBOSE = 0x06

    DLT_CHANNEL = "SRR-DLT"

    MSM_kUnknown = 0
    MSM_kRestart = 1
    MSM_kStartup = 2
    MSM_kRunning = 3
    MSM_kShutdown = 4
    MSM_kPlatformOnly = 5
    MSM_kApplicationRestart = 6
    MSM_kSoftRestart = 7
    MSM_kStartupStep2 = 8
    MSM_kStartupStep3 = 9

    VSOMEIP_SIGNAL_UPDATE_TIMEOUT_MS = 100
    EnhancedTestabilityServiceTP_SERVICE_ID = 0x106
    EnhancedTestabilityServiceLow2_SERVICE_ID = 0x103
    EnhancedTestabilityServiceTP_INSTANCE_IDs = {
        "mPAD_Performance": 0x0022,
        "mPAD_Performance_AddOn": 0x0022,
        "mPAD_Performance_High": 0x0091
    }
    # SOMEIP 0x1531
    VEHICLECONDITION_SERVICE_ID = 0x1531
    VEHICLECONDITION_INSTANCE_ID = 0x0001
    VEHICLECONDITION_METHOD_ID = 0x8001
    # SOMEIP 0x101D
    MILEAGESUPREME_SERVICE_ID = 0x101D
    MILEAGESUPREME_INSTANCE_ID = 0x0001
    MILEAGESUPREME_METHOD_ID = 0x8001
    SOMEIP_VEH_COND_STATUS_Pruefen_Analyse_Diagnose = 7
    SOMEIP_VEH_COND_STATUS_Fahrbereitschaft_herstellen = 8
    SOMEIP_VEH_COND_STATUS_Fahren = 10
    SOMEIP_VEH_COND_STATUS_Fahrbereitschaft_beenden = 12
    SOMEIP_VEH_COND_QUALIFIER_valid_value = 2

    DEFAULT_FUNCTIONAL_PARTIAL_NETWORK = 0x19befd

    # SOMEIP 0x139A - RxswinIntern
    RXSWININTERN_SERVICE_ID = 0x139A

    # app names
    PHMAEH_APP_NAME = "PhmApplicationErrorHandler"
    PHMBP_APP_NAME = "PhmHeartBeatProxy"
    PLANNING_APP_NAME = "Planning"
    PHM_DAEMON_APP_NAME = "vPhmDaemon"
    PHM_WATCHDOG_APP_NAME = "PhmWatchdogMonitorApp"
    FASINFO_APP_NAME = "Fasinfo"
    CSA_APP_NAME = "CustomerSafetyApplicationDv"
    DIAGNOSTIC_MANAGER_APP_NAME = "DiagnosticManagerSwc"
    MSM_APP_NAME = "MachineStateManager"
    PARAM_SERVER_APP_NAME = "param_server"
    SOMEIP_POSIX_APP_NAME = "someipd_posix"
    IPSec_CONTROLLER_APP_NAME = "IPsecController"
    SYSMON_APP_NAME = "sysmon"
    UPTIME_COUNTER_APP_NAME = 'uptime_counter'
    LOG_COLLECTOR_APP_NAME = "log_collector"
    STD_Frame_APP_NAME = "std_frame"
    PARTITION_SELECTOR_APP_Name = "PartitionSelector"
    TEMP_SENDER_APP_NAME = "temperature_sender"
    EXECUTION_MANAGER_APP_NAME = "execution_manager"
    RxSWIN_APP_NAME = "RxSwin"
    ETS_APP_NAME = "ets"
    XPC_APP_NAME = "xpc_gateway"
    PSL_APP_NAME = "psl"
    DATA_ROUTER_APP_NAME = "datarouter"
    DATA_ROUTER_CONF_APP_NAME = "datarouterconf"
    PROXY_APP_APP_NAME = "proxy_app"
    TEST_APP_APP_NAME = "test_app"
    UDSD_APP_NAME = "Udsd"
    SYS_TIME_APP_NAME = "SysTime"
    TIME_SYNC_APP_NAME = "localTimeSyncMaster"
    PERCEPTION_APP_NAME = "Perception"
    DUMPER_APP_NAME = "dumper"
    CRASH_HANDLER_APP_NAME = "crash_handler"
    CRASH_REPORTER_APP_NAME = "crash_reporter"
    PHMAEH_APP_NAME = "PhmApplicationErrorHandler"
    PHMBP_APP_NAME = "PhmHeartBeatProxy"
    SDAT2SYS_APP_NAME = "sdat2sys"

    # Process names
    RCU_PREEMPT_PROCESS_NAME = "rcu_preempt"
    RCUC0_PROCESS_NAME = "rcuc/0"
    RCUC1_PROCESS_NAME = "rcuc/1"
    RCUB0_APP_NAME = "rcub/0"

    # dlt application IDs
    PARTITION_SELECTOR_APP_ID = "PSEL"
    CSA_APP_ID = "CSAD"
    EM_APP_ID = "EM"
    MSM_APP_ID = "MSM"
    XPC_APP_ID = "XPC"
    STDFrame_APP_ID = 'STDF'
    LOG_COLLECTOR_APP_ID = 'LOGC'
    PSL_APP_ID = "PSL"
    CRASH_HANDLER_APP_ID = 'CHD'
    PROXY_APP_APP_ID = 'PRXA'
    UDSD_APP_ID = "udsd"
    ETS_APP_ID = "ETS"
    SYSMON_APP_ID = "MON"
    PHMWD_APP_ID = "PHWM"
    PHMAEH_APP_ID = "PHEH"
    PHMBP_APP_ID = "PHBP"
    CRASH_REPORTER_ARA_PROXY_APP_NAME_APP_ID = "CRP"

    # dlt context IDs
    AA_CONTEXT_ID = "AA"

    HSFZ_Destination_Port = 6801
    HSFZ_Source_Port = 0
    proxy_app_etc_path = "/opt/proxy_app/etc"
    CoreDumps_Path = "/persistent/coredumps"

    # Machine state names
    STARTUP_STATE = "Startup"
    StartupStep2_STATE = "StartupStep2"
    StartupStep3_STATE = "StartupStep3"
    PLATFORMONLY_STATE = "PlatformOnly"
    RUNNING_STATE = "Running"
    RESTART_STATE = "Restart"
    SHUTDOWN_STATE = "Shutdown"
    SOFTRESTART_STATE = "SoftRestart"

    # Machine_states_Successfully_messages
    StartupStep2_Successfully_messages = ["Successfully set state to", "StartupStep2"]
    StartupStep3_Successfully_messages = ["Successfully set state to", "StartupStep3"]
    SOFTRESTART_Successfully_messages = ["Successfully set state to", "SoftRestart"]
    RUNNING_Successfully_messages = ["Successfully set state to", "Running"]
    PLATFORMONLY_Successfully_messages = ["Successfully set state to", "PlatformOnly"]
    SHUTDOWN_Successfully_messages = ["Successfully set state to", "Shutdown"]
    RESTART_Successfully_messages = ["Successfully set state to", "Restart"]

    # SSH commands
    kernel_panic_command_LINUX = "modprobe panic"
    kernel_panic_command_QNX = "on -c /bin/ls"

    # reference https://cc-github.bmwgroup.net/swh/xpad_documentation/blob/6bfa5d95923e065283c4846088fff4b7ea6cf8eb/architecture/architecture_concept/Denverton_eMMC.md
    # Partition IDs
    APP1_PARTITION_ID = "mmcblk0p5"
    APP2_PARTITION_ID = "mmcblk0p6"
    PERSISTENT_PARTITION_ID = "mmcblk0p7"
    BOOT_1_PSEL_PARTITION_ID = "mmcblk0p1"
    BOOT_2_PARTITION_ID = "mmcblk0p2"

    # Access rights
    readWrite_linux = "rw"
    readOnly_linux = "ro"
    readOnly_qnx = "rdonly"

    # Partition names linux
    PERSISTENT_PARTITION_NAME = "persistent"

    # Partition size 4C
    APP1_PARTITION_SIZE = "1100M"
    APP2_PARTITION_SIZE = "1100M"
    PERSISTENT_PARTITION_SIZE = "1050M"
    # Partition size 2C
    BOOT_1_PSEL_PARTITION_SIZE_2C = "200M"
    BOOT_2_PARTITION_SIZE_2C = "200M"
    APP1_PARTITION_SIZE_2C = "1300M"
    APP2_PARTITION_SIZE_2C = "1300M"
    PERSISTENT_PARTITION_SIZE_2C = "650M"

    # GPIO mapping
    CSAdv_GPIO_PIN = 490
    PARTITION_SELECTOR_GPIO_PIN = 445
    PHMWD_GPIO_PIN = 370

    # GPIO mapping QNX
    CSAdv_GPIO_PIN_QNX = 65
    PARTITION_SELECTOR_GPIO_PIN_QNX = 5
    PHMWD_GPIO_PIN_QNX = 26

    killall_options = {
        "SIGABRT": "6",
        "SIGKILL": "9",
        "SIGSEGV": "11",
        "SIGCONT": "18",
        "SIGSTOP": "19",
    }

    # log levels
    Log_levels = {
        "verbose": "kVerbose",
        "debug": "kDebug",
        "off": "kOff",
        "fatal": "kFatal",
        "info": "kInfo"
    }

    # log modes
    Log_modes = {
        "remote": "kRemote"
    }

    EXEC_CONFIG_FILE_NAME = "exec_config.json"
    SOMEIP_CONFIG_FILE_NAME = "someip_config.json"
    LOGGING_FILE_NAME = "logging.json"

    IS_ADAPTIVE_KEY = "isExecutionManager"
    LOG_LEVEL_KEY = "logLevel"
    STARTUP_CONFIG_KEY = "processes[0].startupConfigs[0].options"
    QNX_IS_ADAPTIVE_KEY = "REPORTS-EXECUTION-STATE"

    Round_Robin_SCHED = "2"

    KEY_VALUE_STORAGE_NAME = "proxy_app/proxy_app_RootSwc/KeyValueStoragePPort"
    KEY_VALUE_STORAGE_ID = 1
    RUNNING_CORES_2C = "0,1"
    RUNNING_CORES_4C = "0,1,2,3"

    SCHEDULE_TYPE_OTHER = "SCHED_OTHER"
    SCHEDULE_TYPE_FIFO = "SCHED_FIFO"
    SCHEDULE_TYPE_RR = "SCHED_RR"
    SCHEDULE_TYPE_SPORADIC = "SCHED_SP"

    qnx_scheduling = {
        "f": SCHEDULE_TYPE_FIFO,
        "r": SCHEDULE_TYPE_RR,
        "o": SCHEDULE_TYPE_OTHER,
        "s": SCHEDULE_TYPE_SPORADIC
    }

    # PWF States
    PWF_STATE_FAHREN = "FAHREN"
    PWF_STATE_PAD = "PAD"
    PWF_STATE_WOHNEN = "WOHNEN"
    PWF_FAHRBEREITSCHAFT_HERSTELLEN = "FAHRBEREITSCHAFT_HERSTELLEN"
    PWF_FAHRBEREITSCHAFT_BEENDEN = "FAHRBEREITSCHAFT_BEENDEN"
    PWF_STATE_PARKEN_BN_IO = "PARKEN_BN_IO"
    PWF_STATE_PARKEN_BN_NIO = "PARKEN_BN_NIO"
    PWF_STATE_STANDFUNKTIONEN_KUNDE_NICHT_IM_FZG = "STANDFUNKTIONEN_KUNDE_NICHT_IM_FZG"

    Veh_Cond_Status = {
        PWF_STATE_FAHREN: 10,
        PWF_STATE_PAD: 7,
        PWF_STATE_WOHNEN: 5,
        PWF_FAHRBEREITSCHAFT_HERSTELLEN: 8,
        PWF_FAHRBEREITSCHAFT_BEENDEN: 12,
        PWF_STATE_PARKEN_BN_IO: 2,
        PWF_STATE_PARKEN_BN_NIO: 1,
        PWF_STATE_STANDFUNKTIONEN_KUNDE_NICHT_IM_FZG: 3
    }

    Ctr_Basic_PN = {
        PWF_STATE_FAHREN: CtrBsPrtnt.KOM_Fahren,
        PWF_STATE_PAD: CtrBsPrtnt.KOM_Pruefen_Analyse_Diagnose,
        PWF_STATE_WOHNEN: CtrBsPrtnt.KOM_Wohnen,
        PWF_FAHRBEREITSCHAFT_HERSTELLEN: CtrBsPrtnt.KOM_Fahrbereitschaft_herstellen,
        PWF_FAHRBEREITSCHAFT_BEENDEN: CtrBsPrtnt.KOM_Fahrbereitschaft_beenden,
        PWF_STATE_PARKEN_BN_IO: CtrBsPrtnt.KOM_Parken_BN_iO,
        PWF_STATE_PARKEN_BN_NIO: CtrBsPrtnt.KOM_Parken_BN_niO,
        PWF_STATE_STANDFUNKTIONEN_KUNDE_NICHT_IM_FZG: CtrBsPrtnt.KOM_Standfunktionen_Kunde_nicht_im_FZG

    }

    ECU_IDs = {
        "pp_taf": "MPP1",
        "pp_4core": "MPTP",
        "pp_taf_mcip": "MPP1",
        "pp_4core_mcip": "MPTP",
        "pp_cp_plus": "MPCH",
        "pp_cp_addon": "MPCA",
    }

    BOLO_ECU_ID = "MPBL"

    BOLO_ECU_ID = "MPBL"
    WAIT_FOR_DLT_LOG_MS = 1000

    @classmethod
    def setUpClass(cls):
        logger.info("start testBase_SIL setUpclsss")
        cls.tb = TestBase()

        cls.PP_DIAG_ADR = supported_ecus.GetList()[0].targetaddress
        #cls.PP_DIAG_ADR = supported_target_ecus[0].targetaddress
        cls.PP_IP = supported_ecus.GetList()[0].ip
        cls.PP_NAME = supported_ecus.GetList()[0].dut_name
        cls.PP_ECU_NAME = supported_ecus.GetList()[0].ecu_name
        cls.PP_ECUID = cls.ECU_IDs[cls.PP_ECU_NAME]
        cls.PP_CORES = 2 if cls.PP_ECUID == "MPP1" else 4

        cls.SC_DIAG_ADR = supported_ecus.GetList()[1].targetaddress
        cls.SC_IP = supported_ecus.GetList()[1].ip
        cls.SC_ECUID = supported_ecus.GetList()[1].dlt_id
        cls.SC_NAME = supported_ecus.GetList()[1].dut_name

        logger.info("Check_ECU_in_ELK_mode")
        cls.Check_ECU_in_ELK_mode()
        logger.info("Check_ECU_degradated")
        cls.Check_ECU_degradated()

        cls.os_name = cls.get_os_name()
        cls.d1c5_activated = False
        # cls.d1c5_activated = cls.check_d1c5_is_activated()
        if cls.os_name == "QNX":
            if os.environ.get('CT4ZSG_PARAMETER_QNX_Overlay', None) == "writable.fs":
                logger.info("The D1C5 is activated.")
                cls.d1c5_activated = True
        cmd = "ps aux"
        if cls.os_name == "QNX":
            cmd = "ps -A -o pid,args"
        cls.ssh_manager.executeCommandInTarget(command=cmd, ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        if cls.os_name == "Linux":
            cls.ssh_manager.executeCommandInTarget(command="mount -o rw,remount /", ip_address=cls.PP_IP,
                                                   timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        cls.ssh_manager.executeCommandInTarget(command=f"mkdir {cls.technica_persistent_folder}", ip_address=cls.PP_IP)
        cls.ssh_manager.executeCommandInTarget(command=f"chmod -R 777 {cls.technica_persistent_folder}",
                                               ip_address=cls.PP_IP)

        if cls.PP_NAME == "mPAD_Performance_AddOn" or cls.PP_NAME == "mPAD_Performance_High":
            cls.Default_MG = 'MG_MPAD_CP60_Default_V2.cfg'
            cls.LifeCycle_MG = 'MG_mPAD_VLAN_Default_v2.2_Lifecycle_CP60.cfg'
        else:
            cls.Default_MG = 'MG_mPAD_VLAN_alpha_V3.1.cfg'
            cls.LifeCycle_MG = 'MG_mPAD_VLAN_Default_v2.2_Lifecycle.cfg'

        if cls.PP_IP == "160.48.199.101":
            cls.PP_CAF_NAME = "MPAD_PP2"
        else:
            cls.PP_CAF_NAME = "MPAD_PP"

        if cls.SC_IP == "160.48.199.35":
            cls.SC_CAF_NAME = "MPAD_SSC"
        elif cls.SC_IP == "160.48.199.100":
            cls.SC_CAF_NAME = "MPAD_SC2"

        # WA SWP-39644
        if cls.os_name == "QNX":
            # startup & shutdown timeout
            cls.PP_STARTUP_TIMEOUT_S = 60
            cls.PP_SHUTDOWN_TIMEOUT_S = 10
        # -------------------
        cls.PP_RESET_TIMEOUT_S = cls.PP_STARTUP_TIMEOUT_S + cls.PP_SHUTDOWN_TIMEOUT_S
        cls.PP_RESET_TIMEOUT_MS = cls.PP_RESET_TIMEOUT_S * 1000
        cls.PP_STARTUP_TIMEOUT_MS = cls.PP_STARTUP_TIMEOUT_S * 1000
        cls.PP_SHUTDOWN_TIMEOUT_MS = cls.PP_SHUTDOWN_TIMEOUT_S * 1000

        cls.SC_RESET_TIMEOUT_S = cls.SC_STARTUP_TIMEOUT_S + cls.SC_SHUTDOWN_TIMEOUT_S
        cls.SC_RESET_TIMEOUT_MS = cls.SC_RESET_TIMEOUT_S * 1000
        cls.SC_STARTUP_TIMEOUT_MS = cls.SC_STARTUP_TIMEOUT_S * 1000
        cls.SC_SHUTDOWN_TIMEOUT_MS = cls.SC_SHUTDOWN_TIMEOUT_S * 1000

        # Desactivate Flash Mode
        cls.diag_manager.start()
        cls.diag_manager.syn_send(cls.TESTER_DIAG_ADR, cls.PP_DIAG_ADR, cls.DIAG_DEACTIVATE_FLASH_MODE)
        cls.diag_manager.stop()

        if cls.os_name == "QNX" and not cls.d1c5_activated:
            # mount rw_overlay.img
            cls.mount_rw_overlay()
        if cls.os_name == "Linux":
            cls.ssh_manager.use_rwfs(True)

        # DTC
        cls.Software_Test_Library_Fehler = cls.DTC_LIST["Software_Test_Library_Fehler"][cls.PP_NAME]
        cls.Interner_Steuergeraetefehler = cls.DTC_LIST["Interner_Steuergeraetefehler"][cls.PP_NAME]
        cls.Software_Fehler = cls.DTC_LIST["Software_Fehler"][cls.PP_NAME]
        cls.Application_Terminated_Unexpectedly = cls.DTC_LIST["Applikation_wurde_unerwartet_beendet"][cls.PP_NAME]

        if cls.os_name == "QNX":
            cls.kernel_panic_command = cls.kernel_panic_command_QNX
        else:
            cls.kernel_panic_command = cls.kernel_panic_command_LINUX

    @classmethod
    def tearDownClass(cls):
        logger.info("Teardown started")

        if cls.os_name == "QNX" and cls.d1c5_activated is False:
            cls.ssh_manager.executeCommandInTarget(command="sync && mount -o ro,remount /", ip_address=cls.PP_IP,
                                                   timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
            cls.clean_up_rw_overlay()
        if cls.os_name == "QNX":
            if os.environ.get('CT4ZSG_PARAMETER_QNX_Overlay', None) == "writable.fs":
                logger.info("The D1C5 is activated.")
                cls.d1c5_activated = True
            if not cls.d1c5_activated:
                cls.clean_up_rw_overlay()

    default_check_empty = True

    @classmethod
    def temp_mount_and_rm_dui(cls):
        cls.ssh_manager.executeCommandInTarget(
            command=f"mount -t qnx6 /persistent/{cls.image_name} /persistent/checkMount",
            timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        cls.ssh_manager.executeCommandInTarget(command=f"rm /persistent/checkMount/var/lib/dui/*",
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        cls.ssh_manager.executeCommandInTarget(command=f"ls /persistent/checkMount/var/lib/dui/",
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        cls.ssh_manager.executeCommandInTarget(
            command="ls -R /persistent/checkMount | grep \":$\" | sed -e 's/:$//' -e 's/[^-][^\/]*\//--/g' -e 's/^/   /' -e 's/-/|/'",
            timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        cls.ssh_manager.executeCommandInTarget(command="umount -f /persistent/checkMount",
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)

    rw_overlay_file_name = ""

    @classmethod
    def mount_rw_overlay(cls, with_proxy_app=False):
        logger.info("mount_rw_overlay(): Mounting rw_overlay.img")
        if 'CT4ZSG_PARAMETER_PROXY_APP_DEPLOYMENT' in environ.keys():
            if environ["CT4ZSG_PARAMETER_PROXY_APP_DEPLOYMENT"] == "disable":
                logger.warn("mounting rw_overlay skipped")
                return
        cls.ssh_manager.use_rwfs(False)
        cls.rw_overlay_file_name = f"rw_overlay_{cls.PP_ECU_NAME}.tar"
        cls.image_name = f"rw_overlay.img"
        if with_proxy_app:
            cls.rw_overlay_file_name = f"rw_overlay_pa_{cls.PP_ECU_NAME}.tar"

        logger.warn(f"rw_overlay image file name is: {cls.rw_overlay_file_name}")

        result = cls.ssh_manager.executeCommandInTarget(command=f"ls /persistent | grep {cls.rw_overlay_file_name}",
                                                        ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        if cls.rw_overlay_file_name in result['stdout']:
            cls.ssh_manager.executeCommandInTarget(command=f"rm /persistent/{cls.rw_overlay_file_name}",
                                                   ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
            cls.ssh_manager.executeCommandInTarget(command=f"ls /persistent | grep {cls.rw_overlay_file_name}",
                                                   ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

        cls.ssh_manager.uploadFileToTarget(source_path=cls.input_folder, source_file=cls.rw_overlay_file_name,
                                           destination_path="/persistent", ip_address=cls.PP_IP)

        cls.remount_rw_image()
        cls.ssh_manager.use_rwfs(True)

        cls.diag_manager.start()
        cls.diag_manager.ecu_reset(target=cls.PP_DIAG_ADR, reset_duration=cls.PP_RESET_TIMEOUT_S * 2)
        cls.diag_manager.stop()
        ECUs_are_OK = cls.check_ECUs()

    @classmethod
    def remount_rw_image(cls):
        result = cls.ssh_manager.executeCommandInTarget(command=f"ls /persistent | grep {cls.image_name}",
                                                        ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        if cls.image_name in result['stdout']:
            cls.ssh_manager.executeCommandInTarget(command=f"umount -f / && rm /persistent/{cls.image_name}",
                                                   ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
            cls.ssh_manager.executeCommandInTarget(command=f"ls /persistent | grep {cls.image_name}",
                                                   ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

        cls.ssh_manager.executeCommandInTarget(
            command=f"tar -xvf /persistent/{cls.rw_overlay_file_name} -C /persistent", ip_address=cls.PP_IP,
            timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        cls.temp_mount_and_rm_dui()

    @classmethod
    def clean_up_rw_overlay(cls):
        logger.info("clean_up_rw_overlay(): unmounting and removing rw_overlay.img")
        if 'CT4ZSG_PARAMETER_PROXY_APP_UNDEPLOYMENT' in environ.keys():
            if environ["CT4ZSG_PARAMETER_PROXY_APP_UNDEPLOYMENT"] == "disable":
                logger.warn("clenup rw_overlay skipped")
                return
        cls.ssh_manager.use_rwfs(False)
        cls.ssh_manager.executeCommandInTarget(command=f"umount -f / && rm /persistent/rw_overlay*",
                                               ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        cls.ssh_manager.use_rwfs(True)

    @classmethod
    def set_MG_For_BCP_Simulation(cls):
        logger.info("set_MG_For_BCP_Simulation")
        if cls.PP_ECU_NAME == "pp_cp_plus" or cls.PP_ECU_NAME == "pp_cp_addon":
            cls.MediaGateway_controller.set_mediagateway_config("MG_mPAD_VLAN_Default_v2.2_Lifecycle_CP60.cfg")
        else:
            cls.MediaGateway_controller.set_mediagateway_config("MG_mPAD_VLAN_Default_v2.2_Lifecycle.cfg")
        cls.tb.sleep_for(cls.SET_MG_CONFIG_MS)
        cls.MediaGateway_controller.reset_device()
        cls.tb.sleep_for(cls.MG_RESET_MS)
        cls.bus.power_supply.power_on_reset(downtime=cls.PP_SHUTDOWN_TIMEOUT_MS, startup_time=cls.PP_STARTUP_TIMEOUT_MS)

    @classmethod
    def set_standard_MG(cls):
        logger.info("set_standard_MG")
        if cls.PP_ECU_NAME == "pp_cp_plus" or cls.PP_ECU_NAME == "pp_cp_addon":
            cls.MediaGateway_controller.set_mediagateway_config("MG_MPAD_CP60_Default_V2.cfg")
        else:
            cls.MediaGateway_controller.set_mediagateway_config("MG_mPAD_VLAN_alpha_V3.1.cfg")
        cls.tb.sleep_for(cls.SET_MG_CONFIG_MS)
        cls.MediaGateway_controller.reset_device()
        cls.tb.sleep_for(cls.MG_RESET_MS)
        cls.bus.power_supply.power_on_reset(downtime=cls.PP_SHUTDOWN_TIMEOUT_MS, startup_time=cls.PP_STARTUP_TIMEOUT_MS)

    @classmethod
    def start_bcp_simulation(cls):
        logger.info("start_bcp_simulation")
        cls.someip_controller.set_adapter_configuration("Stimulation", "160.48.199.16", "255.255.255.128")
        cls.tb.sleep_for(cls.SET_ADATER_CONFIG_MS)

        cls.someip_controller.start_ecu_with_all_services("BCP21_GW")
        cls.someip_controller.offer_service("BCP21_GW", service_id=0x100d, instance_id=0x0001, major=1, minor=0)
        cls.tb.sleep_for(cls.START_SIMULATION_TIMEOUT_MS)
        cls.someip_controller.register_response_preprocessor("BCP21_GW", service_id=0x100d,
                                                             instance_id=0x0001,
                                                             method_id=0x0001,
                                                             preProcessorFunction=CdcToolbox().get_trusted_time_callback)

        VIN = [{"Name": "numberVehicleChassis1", "Value": 0x48}, {"Name": "numberVehicleChassis2", "Value": 0x31},
               {"Name": "numberVehicleChassis3", "Value": 0x32}, {"Name": "numberVehicleChassis4", "Value": 0x33},
               {"Name": "numberVehicleChassis5", "Value": 0x34}, {"Name": "numberVehicleChassis6", "Value": 0x35},
               {"Name": "numberVehicleChassis7", "Value": 0x36}]
        for signal in VIN:
            cls.someip_controller.set_someip_signal("BCP21_GW", service_id=0x1536, instance_id=0x0001, method_id=0x8001,
                                                    signal_name="ChassisNumber." + signal["Name"],
                                                    signal_value=signal["Value"])
            cls.tb.sleep_for(cls.SET_SIGNAL_TIMEOUT_MS)

    @classmethod
    def stop_bcp_simulation(cls):
        logger.info("stop_bcp_simulation")
        cls.someip_controller.stop_offer_service("BCP21_GW", service_id=0x100d, instance_id=0x0001)
        cls.someip_controller.stop_ecu_with_all_services("BCP21_GW")
        cls.someip_controller.clear_adapter_configuration('Stimulation', '160.48.199.16', '239.192.255.251')

    @classmethod
    def check_ECUs(cls, is_BCP_simulated=False, rw_overlay=True):
        logger.info("check_ECUs")
        # check ssc is pingable
        ping_ssc_result = cls.network.system_ping(cls.SC_IP)
        if ping_ssc_result:
            logger.info("mPAD Safety is available via ICMP")
        else:
            logger.error("mPAD Safety is not available via ICMP")
            return False
        # check pp is pingable
        ping_pp_result = cls.network.system_ping(cls.PP_IP)
        if ping_pp_result:
            logger.info("mPAD performance is available via ICMP")
        else:
            logger.error("mPAD performance is not available via ICMP")
            return False
        if is_BCP_simulated:
            logger.info("Starting Diag Manager with BCP simulation")
            cls.diag_manager.start_with_param(chName="ETH-HSFZ-DIAG", srcPort=0, dstPort=6801, remoteIP=cls.PP_IP)
        else:
            cls.diag_manager.start()
        # check pp is in running state
        diag_request = cls.diag_manager.syn_send(src=cls.TESTER_DIAG_ADR, target=cls.PP_DIAG_ADR,
                                                 payload=cls.STATUS_MSM_STATE_GETTER)
        response_is_positive = (diag_request == DiagResult.positive)
        if response_is_positive:
            logger.info("mPAD performance responds to DIAG")
            diag_response = cls.diag_manager.get_latest_Response(target=cls.PP_DIAG_ADR).get_payload()[3]
            logger.info('STATUS_MSM_STATE_GETTER Response: %s' % (diag_response))
            pp_is_in_running_state = (diag_response == cls.MSM_RUNNING)
            if pp_is_in_running_state:
                logger.info("mPAD performance is in running state")
            else:
                logger.error("mPAD performance is not in running state")
                cls.diag_manager.stop()
                return False
        else:
            logger.error("mPAD performance does not respond to DIAG")
            cls.diag_manager.stop()
            return False

        cls.diag_manager.stop()

        # check ssh connection
        if cls.os_name == "QNX":
            result = cls.ssh_manager.executeCommandInTarget(
                command=f"ps -A | grep {cls.XPC_APP_NAME} | grep -v grep | awk -F' ' " + r"{'print $1'}",
                ip_address=cls.PP_IP)
        else:
            logger.info(f"uname result2:{cls.os_name}")
            result = cls.ssh_manager.executeCommandInTarget(command=f"pidof {cls.XPC_APP_NAME}", ip_address=cls.PP_IP)
        ssh_ok = result is not None
        if ssh_ok:
            logger.info("It is possible to establish SSH connection on mPAD performance")
        else:
            logger.error("It is possible to establish SSH connection on mPAD performance")
            return False

        if cls.os_name == "QNX":
            pass
        else:
            logger.info(f"uname result1:{cls.os_name}")
            # check mount rw is possible
            if rw_overlay:
                result = cls.ssh_manager.executeCommandInTarget(
                    command="mount -o rw,remount / && sync && mount -o ro,remount / && sync", ip_address=cls.PP_IP)
                pp_is_rw = len(result['stderr'].strip()) == 0
                if pp_is_rw:
                    logger.info("We have RW access over SSH on mPAD performance")
                else:
                    logger.error("We don't have RW access over SSH on mPAD performance")
                    return False
        return True

    @classmethod
    def Start_Diag_Manager(cls, is_BCP_simulated=False):
        logger.info("Starting Diag Manager")
        if is_BCP_simulated:
            cls.diag_manager.start_with_param(chName="ETH-HSFZ-DIAG", srcPort=0, dstPort=6801, remoteIP=cls.PP_IP)
        else:
            cls.diag_manager.start()

    @classmethod
    def get_VehicleCondition_signals(cls, timeout=1000):
        logger.debug("get VehicleCondition signals")
        result = {
            "ControlbasePartialNetwork": -1,
            "StatusConditionVehicle": -1,
            "qualifierStatusConditionVehicle": -1
        }
        cls.network.sniffer.start_tshark_watching(
            filter=f"someip.serviceid == 0x1531 && someip.methodid == 0x8001 && ip.src ==160.48.199.16 && ip.dst =={cls.PP_IP} && someip.messagetype == 0x02",
            adapater_name='Stimulation')
        past = 0
        while past < timeout and len(cls.network.sniffer.get_packets()) == 0:
            cls.tb.sleep_for(100)
            past += 100
        cls.network.sniffer.stop_tshark_watching()
        if cls.network.sniffer.get_packets() == 0:
            logger.error(f"No VehicleCondition notification detected in the last {timeout} ms")
            return result
        logger.debug("VehicleCondition notification detected")
        try:
            payload = cls.network.sniffer.get_packets()[0]['SOMEIP'].payload.replace(":", "")
            result["ControlbasePartialNetwork"] = int(payload[2], 16)
            result["StatusConditionVehicle"] = int(payload[13], 16)
            result["qualifierStatusConditionVehicle"] = int(payload[12], 16)
        except:
            logger.error("Error while getting VehicleCondition signal values")
            logger.error(traceback.format_exc())
        return result

    @classmethod
    def get_UDPNM_signals(cls, timeout=5000):
        logger.debug("get_UDPNM_signals")
        udpnm_signals = {
            "Control Bit Vector": {
                "Repeat Message Request": -1,
                "NM Coordinator sleep Bit": -1,
                "Partial Network Information": -1
            },
            "Source Node Identifier": -1,
            "User data": {
                "CTR_BS_PRINT_NM": {
                    "KOM_Parken_BN_niO": -1,
                    "KOM_Parken_BN_iO": -1,
                    "KOM_Standfunktionen_Kunde_nicht_im_FZG": -1,
                    "Keine_kommunikation_0008h": -1,
                    "KOM_Wohnen": -1,
                    "Keine_kommunikation_0020h": -1,
                    "KOM_Pruefen_Analyse_Diagnose": -1,
                    "KOM_Fahrbereitschaft_herstellen": -1,
                    "Keine_kommunikation_0100h": -1,
                    "KOM_Fahren": -1,
                    "Keine_kommunikation_0400h": -1,
                    "KOM_Fahrbereitschaft_beenden": -1,
                    "Keine_kommunikation_1000h": -1,
                    "Keine_kommunikation_2000h": -1
                },

                "CTR_FKTN_PRINT_NM": {
                    "Konfiguration_ein": -1,
                    "Ethernet_Infrastruktur_ein": -1,
                    "DatenKommunikation_ein": -1,
                    "Fernwartung_ein": -1,
                    "Klima_Basis_ein": -1,
                    "Safe_Exit_ein": -1,
                    "RSU_Hochvoltstuetzung_ein": -1,
                    "Autonomous_Driving_Ready_ein": -1,

                    "Klimabetrieb_ein": -1,
                    "Entertainmentbetrieb_ein": -1,
                    "Externe_Kommunikation_ein": -1,
                    "Entertainmentbetrieb_Fond_ein": -1,
                    "Assistenz_Parken_high_ein": -1,
                    "Autonomous_Driving_Secondary_Power_Supply_ein": -1,
                    "Laden_ein": -1,

                    "Fahrzeug_Infrastruktur_ein": -1,
                    "Licht_ein": -1,
                    "TN_48V_ein": -1
                }
            }
        }
        cls.network.sniffer.start_tshark_watching(
            filter="udp.port == 30500 and ip.dst == 239.192.255.1",
            adapater_name='Stimulation')
        past = 0
        while past < timeout and len(cls.network.sniffer.get_packets()) == 0:
            cls.tb.sleep_for(100)
            past += 100
        cls.network.sniffer.stop_tshark_watching()
        if cls.network.sniffer.get_packets() == 0:
            logger.error(f"No UDPNM signal detected in the last {timeout} ms")
            return udpnm_signals
        logger.debug("UDPNM signal detected")
        try:
            payload = cls.network.sniffer.get_packets()[0]['UDP'].payload.split(":")
            logger.info(f"{cls.network.sniffer.get_packets()[0]['UDP'].payload}")
            udpnm_signals['Control Bit Vector']['Repeat Message Request'] = 1 if int(payload[0], 16) & 1 else 0
            udpnm_signals['Control Bit Vector']['NM Coordinator sleep Bit'] = 1 if int(payload[0], 16) & 8 else 0
            udpnm_signals['Control Bit Vector']['Partial Network Information'] = 1 if int(payload[0], 16) & 64 else 0

            udpnm_signals['Source Node Identifier'] = int(payload[1], 16)

            udpnm_signals['User data']['CTR_BS_PRINT_NM']['KOM_Parken_BN_niO'] = 1 if int(payload[3], 16) & 1 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['KOM_Parken_BN_iO'] = 1 if int(payload[3], 16) & 2 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['KOM_Standfunktionen_Kunde_nicht_im_FZG'] = 1 if int(
                payload[3], 16) & 4 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['Keine_kommunikation_0008h'] = 1 if int(payload[3],
                                                                                                  16) & 8 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['KOM_Wohnen'] = 1 if int(payload[3], 16) & 16 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['Keine_kommunikation_0020h'] = 1 if int(payload[3],
                                                                                                  16) & 32 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['KOM_Pruefen_Analyse_Diagnose'] = 1 if int(payload[3],
                                                                                                     16) & 64 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['KOM_Fahrbereitschaft_herstellen'] = 1 if int(payload[3],
                                                                                                        16) & 128 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['Keine_kommunikation_0100h'] = 1 if int(payload[2],
                                                                                                  16) & 1 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['KOM_Fahren'] = 1 if int(payload[2], 16) & 2 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['Keine_kommunikation_0400h'] = 1 if int(payload[2],
                                                                                                  16) & 4 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['KOM_Fahrbereitschaft_beenden'] = 1 if int(payload[2],
                                                                                                     16) & 8 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['Keine_kommunikation_1000h'] = 1 if int(payload[2],
                                                                                                  16) & 16 else 0
            udpnm_signals['User data']['CTR_BS_PRINT_NM']['Keine_kommunikation_2000h'] = 1 if int(payload[2],
                                                                                                  16) & 32 else 0

            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Konfiguration_ein'] = 1 if int(payload[7], 16) & 1 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Ethernet_Infrastruktur_ein'] = 1 if int(payload[7],
                                                                                                     16) & 2 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['DatenKommunikation_ein'] = 1 if int(payload[7],
                                                                                                 16) & 4 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Fernwartung_ein'] = 1 if int(payload[7], 16) & 8 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Klima_Basis_ein'] = 1 if int(payload[7], 16) & 16 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Safe_Exit_ein'] = 1 if int(payload[7], 16) & 32 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['RSU_Hochvoltstuetzung_ein'] = 1 if int(payload[7],
                                                                                                    16) & 64 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Autonomous_Driving_Ready_ein'] = 1 if int(payload[7],
                                                                                                       16) & 128 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Klimabetrieb_ein'] = 1 if int(payload[6], 16) & 1 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Entertainmentbetrieb_ein'] = 1 if int(payload[6],
                                                                                                   16) & 2 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Externe_Kommunikation_ein'] = 1 if int(payload[6],
                                                                                                    16) & 4 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Entertainmentbetrieb_Fond_ein'] = 1 if int(payload[6],
                                                                                                        16) & 8 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Assistenz_Parken_high_ein'] = 1 if int(payload[6],
                                                                                                    16) & 16 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Autonomous_Driving_Secondary_Power_Supply_ein'] = 1 if int(
                payload[6], 16) & 32 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Laden_ein'] = 1 if int(payload[6], 16) & 128 else 0

            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Fahrzeug_Infrastruktur_ein'] = 1 if int(payload[5],
                                                                                                     16) & 1 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Licht_ein'] = 1 if int(payload[5], 16) & 8 else 0
            udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['TN_48V_ein'] = 1 if int(payload[5], 16) & 16 else 0

            logger.debug(f"{json.dumps(udpnm_signals, indent=4)}")
        except:
            logger.error("Error while getting UDPNM signal values")
            logger.error(traceback.format_exc())
        return udpnm_signals

    @classmethod
    def display_cafd_parameters(cls, cafd):
        for caf in cafd:
            logger.info(f"{cafd[caf]}")

    @classmethod
    def deploy_proxy_app_FUSA(cls):
        logger.info("Start ProxyApp deployment")
        if 'CT4ZSG_PARAMETER_PROXY_APP_DEPLOYMENT' in environ.keys():
            if environ["CT4ZSG_PARAMETER_PROXY_APP_DEPLOYMENT"] == "disable":
                logger.warn("ProxyApp deployment is disabled from ASIA trigger")
                return
        deployment_files = path.join(path.sep.join(path.abspath(__file__).split(path.sep)[:-2]), "Files")
        logger.debug("Current used path : {0}".format(deployment_files))

        cls.ecu_utilities.os_check()
        if cls.os_name == "QNX":
            ProxyAppDeployer.init(supported_ecus.get_pp_list(), cls.input_folder, cls.PERSISTENT_FOLDER)
            ProxyAppDeployer.qnx_deploy()
        else:
            cls.ssh_manager.use_rwfs(True)
            ProxyAppDeployer.init(supported_ecus.get_pp_list(), cls.input_folder, cls.technica_persistent_folder)
            ProxyAppDeployer.deploy()
        cls.ecu_utilities.rebootALLSSCTarget(SSCResetTimeOut=cls.SC_RESET_TIMEOUT_S,
                                             waitTimeAfterReset=cls.PP_STARTUP_TIMEOUT_S)
        ECUs_are_OK = cls.check_ECUs()
        if not ECUs_are_OK:
            logger.error("ECUs are not OK")
        if cls.os_name == "QNX":
            returnValue = cls.ssh_manager.executeCommandInTarget(
                command=f"ps -A -o pid,args | grep proxy | grep -v grep", ip_address=cls.PP_IP,
                timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        else:
            returnValue = cls.ssh_manager.executeCommandInTarget(
                command=f"ps aux | grep -v grep | grep proxy_app | wc -l", ip_address=cls.PP_IP,
                timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        if returnValue["stdout"].strip() == "0":
            logger.error("No proxy_app instance is running")
        elif returnValue["stdout"].strip() != "3":
            logger.error("Not all instances of proxy_app instance are running")
        else:
            logger.info("All instances of proxy_app instance are running")

    @classmethod
    def deploy_proxy_app(cls):
        logger.info("Start ProxyApp deployment")
        if 'CT4ZSG_PARAMETER_PROXY_APP_DEPLOYMENT' in environ.keys():
            if environ["CT4ZSG_PARAMETER_PROXY_APP_DEPLOYMENT"] == "disable":
                logger.warn("ProxyApp deployment is disabled from ASIA trigger")
                return
        if cls.os_name == "QNX" and cls.d1c5_activated is False:
            cls.mount_rw_overlay(with_proxy_app=True)
            return
        deployment_files = path.join(path.sep.join(path.abspath(__file__).split(path.sep)[:-2]), "Files")
        logger.debug("Current used path : {0}".format(deployment_files))
        if cls.os_name == "Linux":
            cls.ecu_utilities.os_check()
            cls.ssh_manager.use_rwfs(True)
        ProxyAppDeployer.init(supported_ecus.get_pp_list(), cls.input_folder, cls.technica_persistent_folder)
        ProxyAppDeployer.deploy(d1c5_activated=cls.d1c5_activated)
        cls.ecu_utilities.rebootALLSSCTarget(SSCResetTimeOut=cls.SC_RESET_TIMEOUT_S,
                                             waitTimeAfterReset=cls.PP_STARTUP_TIMEOUT_S)
        ECUs_are_OK = cls.check_ECUs()
        if not ECUs_are_OK:
            logger.error("ECUs are not OK")

        returnValue = cls.ssh_manager.executeCommandInTarget(command=f"ps aux | grep -v grep | grep proxy_app | wc -l",
                                                             ip_address=cls.PP_IP,
                                                             timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        if returnValue["stdout"].strip() == "0":
            logger.error("No proxy_app instance is running")
        elif returnValue["stdout"].strip() != "3":
            logger.error("Not all instances of proxy_app instance are running")
        else:
            logger.info("All instances of proxy_app instance are running")

    @classmethod
    def undeploy_proxy_app_FUSA(cls):
        logger.info("Start ProxyApp undeployment")
        if 'CT4ZSG_PARAMETER_PROXY_APP_UNDEPLOYMENT' in environ.keys():
            if environ["CT4ZSG_PARAMETER_PROXY_APP_UNDEPLOYMENT"] == "disable":
                logger.warn("ProxyApp undeployment is disabled from ASIA trigger")
                return
        del cls.proxy_app_manager
        if cls.os_name == "QNX":
            ProxyAppDeployer.qnx_undeploy()
        else:
            ProxyAppDeployer.undeploy()
        clean_folder(cls, cls.tmp_folder)
        cls.ecu_utilities.rebootALLSSCTarget(SSCResetTimeOut=cls.SC_RESET_TIMEOUT_S,
                                             waitTimeAfterReset=cls.PP_STARTUP_TIMEOUT_S)
        for my_target_ecu in supported_ecus.get_pp_list():
            if ProxyAppDeployer.is_running(ip_address=my_target_ecu.ip) == True:
                logger.warn("ProxyApp process still running")
            else:
                logger.warn("ProxyApp process was stopped successfully")

    @classmethod
    def undeploy_proxy_app(cls):
        logger.info("Start ProxyApp undeployment")
        if cls.os_name == "QNX" and cls.d1c5_activated is False:
            logger.info("skip linux undeployment of ProxyApp")
            return
        if 'CT4ZSG_PARAMETER_PROXY_APP_UNDEPLOYMENT' in environ.keys():
            if environ["CT4ZSG_PARAMETER_PROXY_APP_UNDEPLOYMENT"] == "disable":
                logger.warn("ProxyApp undeployment is disabled from ASIA trigger")
                return
        del cls.proxy_app_manager

        ProxyAppDeployer.undeploy(d1c5_activated=cls.d1c5_activated)
        clean_folder(cls, cls.tmp_folder)
        cls.ecu_utilities.rebootALLSSCTarget(SSCResetTimeOut=cls.SC_RESET_TIMEOUT_S,
                                             waitTimeAfterReset=cls.PP_STARTUP_TIMEOUT_S)
        for my_target_ecu in supported_ecus.get_pp_list():
            if ProxyAppDeployer.is_running(ip_address=my_target_ecu.ip) == True:
                logger.warn("ProxyApp process still running")
            else:
                logger.warn("ProxyApp process was stopped successfully")

    @classmethod
    def start_tdf_proxy_communication(cls):
        logger.info("Start TDFnext ProxyApp communication")
        # if environ["CT4ZSG_PARAMETER_TDFNEXT_PROXA_APP_COMMUNICATION"] == "disable":
        #     logger.warn("ProxyApp TDFnext ProxyApp communication is disabled from ASIA trigger")
        #     return
        cls.someip_controller.init_simulation("TDFNext", NKconfig_mode=False)
        cls.proxy_app_manager = ProxyAppManager(supported_ecus.get_pp_list())

        for my_target_ecu in supported_ecus.get_pp_list():
            # Subscribe to message and event callback in bus
            BusQueue.add_ethernet_bus(my_target_ecu.bus_name, my_target_ecu.ecu_name, my_target_ecu.ip)

            cls.tb.sleep_for(1000)
            # send find request from TDFNext to proxy app
            cls.someip_controller.request_service("TDFNext", service_id=cls.PROXY_APP_SERVICE_ID,
                                                  instance_id=my_target_ecu.defaultInstanceId)
            # # subscribe to the event
            cls.someip_controller.request_event(ecu="TDFNext", service_id=cls.PROXY_APP_SERVICE_ID,
                                                instance_id=my_target_ecu.defaultInstanceId,
                                                event_id=cls.PROXY_APP_NOTIF_EVENT_METHOD_ID,
                                                eventgroup=cls.PROXY_APP_NOTIF_EVENT_GROUP, is_field=False)
            # # subscribe to the event
            cls.someip_controller.subscribe(ecu="TDFNext", service_id=cls.PROXY_APP_SERVICE_ID,
                                            instance_id=my_target_ecu.defaultInstanceId,
                                            event_id=cls.PROXY_APP_NOTIF_EVENT_METHOD_ID,
                                            eventgroup=cls.PROXY_APP_NOTIF_EVENT_GROUP, is_field=False)
            cls.someip_controller.register_message_handler(ecu="TDFNext", service_id=cls.PROXY_APP_SERVICE_ID,
                                                           instance_id=my_target_ecu.defaultInstanceId,
                                                           event_id=cls.PROXY_APP_NOTIF_EVENT_METHOD_ID,
                                                           callback=ProxyAppManager.someip_notification_dispatcher)

        cls.someip_controller.start_simulation(ecu="TDFNext")

    @classmethod
    def stop_tdf_proxy_communication(cls):
        logger.info("Stop TDFnext ProxyApp communication")
        # if environ["CT4ZSG_PARAMETER_TDFNEXT_PROXA_APP_COMMUNICATION"] == "disable":
        #     logger.warn("ProxyApp TDFnext ProxyApp communication is disabled from ASIA trigger")
        #     return
        cls.proxy_app_manager.destroy()

        for my_target_ecu in supported_ecus.get_pp_list():
            if BusQueue.get_bus(my_target_ecu.bus_name) is not None:
                if BusQueue.get_bus(my_target_ecu.bus_name).is_connected is True:
                    BusQueue.get_bus(my_target_ecu.bus_name).stop()
                BusQueue.remove_bus(my_target_ecu.bus_name)

            cls.someip_controller.unsubscribe(ecu="TDFNext", service_id=cls.PROXY_APP_SERVICE_ID,
                                              instance_id=my_target_ecu.defaultInstanceId,
                                              eventgroup=cls.PROXY_APP_NOTIF_EVENT_GROUP)
        cls.someip_controller.stop_simulation(ecu="TDFNext")

    @ClassProperty
    @classmethod
    def stress_tools(self):
        """
        serial manager
        :getter: Returns this serial manager's value
        :type: SerialController
        """
        if testBase_SIL.__stress_tools is None:
            testBase_SIL.__stress_tools = StressTools()
        return testBase_SIL.__stress_tools

    def wait_for_app_crash(self, app_name, old_pid=None, timeout=5000):
        old_pid = int(old_pid) if old_pid else None
        time_passed = 0
        while time_passed < timeout:
            command_results = self.ssh_manager.executeCommandInTarget(command=f"pidof {app_name}",
                                                                      ip_address=self.PP_IP)
            current_pid = command_results["stdout"].strip()

            if current_pid == "":
                return True
            else:
                if old_pid is not None and int(current_pid) != old_pid:
                    return True
                else:
                    time_passed += 1000
        return False

    @classmethod
    def get_process_id(cls, app_name, option=None, exclude=False, exclude_app_name=""):
        exclude_grep = f"| grep -v {exclude_app_name}" if exclude else ""
        optional_grep = f"| grep {option}" if option is not None else ""
        if cls.os_name == "QNX":
            result = cls.ssh_manager.executeCommandInTarget(
                command=f"ps -A -o pid,args | grep {app_name} {optional_grep} {exclude_grep} | grep -v grep | awk -F' ' " + r"{'print $1'}",
                timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            if result['stdout'].strip() == "":
                return -1
            else:
                try:
                    logger.info(f"PID_APP : {str(int(result['stdout'].strip()))}")
                    return int(result['stdout'].strip())
                except:
                    logger.error("Error while converting pid to int")
                    logger.error(traceback.format_exc())
                    return -1
        else:
            result = cls.ssh_manager.executeCommandInTarget(
                command=f"ps aux | grep -v grep | grep {app_name} {optional_grep} {exclude_grep} | awk -F' ' " + "{'print $2'}",
                timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            if result['stdout'].strip() == "":
                return -1
            else:
                try:
                    logger.info(f"PID_APP : {str(int(result['stdout'].strip()))}")
                    return int(result['stdout'].strip())
                except:
                    logger.error("Error while converting pid to int")
                    logger.error(traceback.format_exc())
                    return -1

    @classmethod
    def get_partition_size(cls, partition_name, option=None):
        if cls.os_name == "QNX":
            logger.info(f"Getting partition size for {partition_name}")
            result = cls.ssh_manager.executeCommandInTarget(command=f"fdisk -l | grep /dev/{partition_name}",
                                                            timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                                                            ip_address=cls.PP_EXTERNAL_IP_FOR_ELK)
            if result['stdout'].strip() == "":
                return -1
            else:
                try:
                    return result['stdout'].strip()
                except:
                    logger.error("Error while stripping the partition size")
                    logger.error(traceback.format_exc())
                    return -1
        else:
            logger.info(f"Getting partition size for {partition_name}")
            result = cls.ssh_manager.executeCommandInTarget(command=f"fdisk -l | grep /dev/{partition_name}",
                                                            timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            if result['stdout'].strip() == "":
                return -1
            else:
                try:
                    return result['stdout'].strip()
                except:
                    logger.error("Error while stripping the partition size")
                    logger.error(traceback.format_exc())
                    return -1

    @classmethod
    def get_process_sched_policy_and_priority(cls, app_name):
        logger.info(f"Start getting {app_name} Scheduling Policy and Priority")
        if cls.os_name == "QNX":
            process_info = cls.ssh_manager.executeCommandInTarget(command=f'pidin -F "%p" -p {app_name}',
                                                                  timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                                                                  ip_address=cls.PP_IP)
            if process_info['stdout'].strip() == "":
                logger.error(f"Error while getting Scheduling Policy and Priority for {app_name}")
                return -1, -1
            else:
                try:
                    sched_prio = process_info['stdout'].split("\n")[1].strip()
                    import re
                    result = re.search(r"(\d+)([a-z])", sched_prio)
                    priority = int(result.group(1))
                    sch_policy = cls.qnx_scheduling[result.group(2)]
                    return sch_policy, priority
                except:
                    logger.error("Error while extracting Scheduling Policy and Priority")
                    logger.error(traceback.format_exc())
                    return -1, -1

        else:
            logger.info(f"Getting Process ID for {app_name}")
            process_id = cls.get_process_id(app_name)

            if process_id != -1:
                logger.info(f"Getting Scheduling Policy and Priority for {app_name}")
                process_info = cls.ssh_manager.executeCommandInTarget(command=f"chrt -p {process_id}",
                                                                      timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                                                                      ip_address=cls.PP_IP)
                if process_info['stdout'].strip() == "":
                    logger.error(f"Error while getting Scheduling Policy and Priority for {app_name}")
                    return -1, -1
                else:
                    try:
                        sch_policy = (process_info['stdout'].split("\n")[0]).split(": ")[1]
                        priority = (process_info['stdout'].split("\n")[1]).split(": ")[1]
                        return sch_policy, int(priority)
                    except:
                        logger.error("Error while extracting Scheduling Policy and Priority")
                        logger.error(traceback.format_exc())
                        return -1, -1
            else:
                logger.error(f"Error while getting pid for {app_name}")
                return -1, -1

    @classmethod
    def get_process_affinity(cls, app_name):
        logger.info(f"Start getting {app_name} Affinity")
        threads_core = []
        if cls.os_name == "QNX":
            result = cls.ssh_manager.executeCommandInTarget(command=f"pidin -p {app_name} | awk " + r"{'print $2'} ",
                                                            ip_address=cls.PP_IP,
                                                            timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

            threads_ids = result['stdout'].strip().split("\n")
            logger.info(f"threads_id_TF:  {threads_ids}")
            if result['stdout'].strip() == "":
                return -1
            else:
                for i in range(1, len(threads_ids)):
                    thread_id = cls.ssh_manager.executeCommandInTarget(
                        command="pidin -f alb | awk '{if($3 == " + f"{threads_ids[i]}" + " && $1 == " + f"{app_name}" + "){print($2)}}'",
                        ip_address=cls.PP_IP,
                        timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

                    thread_core = thread_id['stdout'].strip().split("\n")
                    logger.info(f"Result_get_Thread_id:  {thread_core}")
                    threads_core.append(thread_core[0])
                logger.info(f"threads_get_core: {threads_core}")

                return threads_core
        else:
            logger.info(f"Getting Process ID for {app_name}")
            process_id = cls.get_process_id(app_name)

            if process_id != -1:
                logger.info(f"Getting Affinity for {app_name}")
                process_info = cls.ssh_manager.executeCommandInTarget(
                    command=f"taskset -c -p {process_id} | cut -d : -f 2", timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                    ip_address=cls.PP_IP)
                if process_info['stdout'].strip() == "":
                    logger.error(f"Error while getting Affinity for {app_name}")
                    return -1
                else:
                    try:
                        affinity = (process_info['stdout'].split(" ")[1]).split("\n")[0]
                        return affinity
                    except:
                        logger.error("Error while extracting Affinity")
                        logger.error(traceback.format_exc())
                        return -1
            else:
                logger.error(f"Error while getting pid for {app_name}")
                return -1

    @classmethod
    def check_application_availability_in_system(cls, app_name):
        result = cls.ssh_manager.executeCommandInTarget(command=f"ls /opt | grep {app_name}",
                                                        timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        if result['stdout'].strip() == "":
            return -1
        else:
            if app_name in result['stdout']:
                return True
            else:
                logger.error(f"{app_name} not available in system")
                return -1

    @classmethod
    def get_process_id_with_instances(cls, app_name):
        if cls.os_name == "QNX":
            result = cls.ssh_manager.executeCommandInTarget(
                command=f"ps -A -o pid,args | grep {app_name} | grep -v grep |awk -F' ' " + r"{'print $1'}",
                timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)

            if result['stdout'].strip() == "":
                return -1
            else:
                try:
                    return int(result['stdout'].strip().split("\n")[0])
                except:
                    logger.error("Error while converting pid to int")
                    logger.error(traceback.format_exc())
                    return -1

        else:
            result = cls.ssh_manager.executeCommandInTarget(command=f"pidof {app_name}",
                                                            timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            if result['stdout'].strip() == "":
                return -1
            else:
                try:
                    return int(result['stdout'].strip().split(" ")[0])
                except:
                    logger.error("Error while converting pid to int")
                    logger.error(traceback.format_exc())
                    return -1

    @classmethod
    def get_short_name(cls, app_name):
        short_name_Path = cls.json_manager.findNodeFromJsonFile(
            filePath="/opt/" + str(app_name) + "/etc/exec_config.json", nodePath="processes[0].shortNamePath",
            use_cache=False, delete_cache=True, upload_file=False)
        logger.info("short_name_Path: " + str(short_name_Path))
        if app_name == cls.SOMEIP_POSIX_APP_NAME:
            short_name = "'" + str(short_name_Path.split('/')[5]) + "': 0"
        elif app_name == cls.MSM_APP_NAME:
            short_name = "'" + str(short_name_Path.split('/')[4]) + "': 0"
        else:
            short_name = "'" + str(short_name_Path.split('/')[3]) + "': 0"
        return short_name

    @classmethod
    def get_dependency(cls, app_name):
        dependency = cls.json_manager.findNodeFromJsonFile(filePath="/opt/" + str(app_name) + "/etc/exec_config.json",
                                                           nodePath="processes[0].startupConfigs[0].executionDependency",
                                                           use_cache=False, delete_cache=True, upload_file=False)
        logger.info("dependency  is : " + str(dependency))
        return dependency

    @classmethod
    def check_application_is_started_linux(cls, app_name):
        pid = cls.get_process_id(app_name=app_name)
        return pid != -1

    @classmethod
    def check_application_is_started_qnx(cls, app_name):
        pid = cls.get_process_id(app_name=app_name)
        logger.info(f"get_process_id_qnx returns {pid} with type {str(type(pid))}")
        logger.info(f"get_process_id_qnx returns {pid != -1} with type {str(type(pid != -1))}")
        return pid != -1

    @classmethod
    def check_application_is_started_with_instances(self, app_name):
        pid = self.get_process_id_with_instances(app_name=app_name)
        return pid != -1

    @classmethod
    def kill_application(cls, app_name, signal, option=None):
        returnValue = None
        if cls.os_name == "QNX":
            pid = cls.get_process_id(app_name=app_name, option=option)
            if pid != -1:
                returnValue = cls.ssh_manager.executeCommandInTarget(command=f"slay -s {signal} {pid}",
                                                                     timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                                                                     ip_address=cls.PP_IP)
        else:
            returnValue = cls.ssh_manager.executeCommandInTarget(command=f"killall -s {signal} {app_name}",
                                                                 timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                                                                 ip_address=cls.PP_IP)
        if returnValue["stderr"].strip() == "" or returnValue != None:
            return True
        else:
            return False

    @classmethod
    def freeze_application(cls, app_name, option=None):
        returnValue = None
        if cls.os_name == "QNX":
            returnValue = cls.ssh_manager.executeCommandInTarget(command=f"kill -STOP {app_name}",
                                                                 timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                                                                 ip_address=cls.PP_IP)
            return returnValue
        else:
            returnValue = cls.ssh_manager.executeCommandInTarget(command=f"killall -STOP {app_name}",
                                                                 timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                                                                 ip_address=cls.PP_IP)
        return returnValue

    @classmethod
    def check_application_is_killed(self, app_name):
        if self.os_name == "QNX":

            app_is_killed = False
            for i in range(int(self.WAIT_FOR_APPLICATION_KILL_MS / 1000)):
                returnValue = self.ssh_manager.executeCommandInTarget(
                    command=f"ps -A | grep -v grep | grep {app_name}", ip_address=self.PP_IP,
                    timeout=self.SSH_CONNECTION_TIMEOUT_MS)
                if app_name not in returnValue["stdout"]:
                    app_is_killed = True
                    break
                self.tb.sleep_for(1000)
            return app_is_killed
        else:
            app_is_killed = False
            for i in range(int(self.WAIT_FOR_APPLICATION_KILL_MS / 1000)):
                returnValue = self.ssh_manager.executeCommandInTarget(
                    command=f"ps axw | grep -v grep | grep {app_name}", ip_address=self.PP_IP,
                    timeout=self.SSH_CONNECTION_TIMEOUT_MS)
                if app_name not in returnValue["stdout"]:
                    app_is_killed = True
                    break
                self.tb.sleep_for(1000)
            return app_is_killed

    @classmethod
    def get_nr_processors(cls):
        if cls.os_name == "QNX":
            result = cls.ssh_manager.executeCommandInTarget(
                command="top -i 1 | grep CPU | grep Idle | awk -F' {'print $2'}", ip_address=cls.PP_IP,
                timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
            try:
                return int(result['stdout'].strip().split('\n')[-1]) + 1
            except:
                logger.error("Error while getting nr of processors")
                logger.error(traceback.format_exc())
                return -1
        else:
            result = cls.ssh_manager.executeCommandInTarget(command="getconf _NPROCESSORS_ONLN", ip_address=cls.PP_IP,
                                                            timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
            try:
                return int(result['stdout'].strip())
            except:
                logger.error("Error while getting nr of processors")
                logger.error(traceback.format_exc())
                return -1

    def check_ecu_default_state(self):
        # ToDo: {
        self.diag_manager.start()
        # 1- check ecu in engineering mode
        self.sfa_manager.set_up(target_address=self.PP_DIAG_ADR)
        mode = self.sfa_manager.sfa_get_ecu_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(EcuMode.Engineering.value == mode, Severity.BLOCKER, 'Check ECU mode is engineering')
        # 2- check ecu in default session
        self.expectTrue(self.diag_manager.is_default_session_app_fmd_set(target=self.PP_DIAG_ADR) == True,
                        Severity.BLOCKER, "Ecu is not in default session FMD")
        # 3- check debug token installed with diag job 31010f29001d1a00 returns f471010f29001d1a01
        if self.os_name == "QNX":
            logger.info(f"Not yet supported in QNX !")
        else:
            feature_status = self.sfa_manager.sfa_get_status(self.PP_DIAG_ADR, feature_id=self.SFA_ID)
            self.expectTrue(feature_status == Feature_Status.Enabled.value, Severity.BLOCKER,
                            "check that 1D1A token is enabled")
        self.sfa_manager.stop_sfa_manager()

    @classmethod
    def check_proxy_app(self):
        # -------------------
        proxy_app_directory_exist = self.ssh_manager.executeCommandInTarget(command="ls /opt/proxy_app/bin && ls /opt/proxy_app/etc",ip_address=self.PP_IP,timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        logger.info(f"####### proxy_app directory exist start #######\n")
        logger.info(f"{proxy_app_directory_exist['stdout']}\n")
        logger.info(f"####### proxy_app directory exist end #######")
        grep_ProxyApp = self.check_application_is_started_with_instances(app_name=self.PROXY_APP_APP_NAME)
        self.assertTrue(grep_ProxyApp, Severity.MAJOR, "Check The application was started")
        # -------------------

    @classmethod
    def check_d1c5_is_activated(cls):
        d1c5_activated = False
        logger.debug("Starting the check of D1C5")
        cls.diag_manager.start()
        feature_status = cls.sfa_manager.sfa_get_status(cls.PP_DIAG_ADR, cls.DM_VERITY)
        if feature_status == Feature_Status.Enabled.value:
            logger.info("SW debug token is enabled")
            if len(cls.ssh_manager.executeCommandInTarget(command="ls /persistent/ | grep writable.fs ",
                                                          ip_address=cls.PP_IP,
                                                          timeout=cls.SSH_CONNECTION_TIMEOUT_MS)[
                       "stdout"].splitlines()) == 1:
                logger.info("The flag file was created")
                d1c5_activated = True
        else:
            cls.sfa_manager.set_up(target_address=cls.PP_DIAG_ADR)
            cls.ecu_uid = cls.sfa_manager.get_ecu_uid(cls.PP_DIAG_ADR, use_cache=False)
            cls.sfa_manager.safe_set_to_engineering_mode(target=cls.PP_DIAG_ADR)
            mode = cls.sfa_manager.sfa_get_ecu_mode(target=cls.PP_DIAG_ADR)
            if mode == EcuMode.Engineering.value:
                feature_status = cls.sfa_manager.sfa_get_status(cls.PP_DIAG_ADR, feature_id=cls.DM_VERITY)
                if feature_status != Feature_Status.Enabled.value:
                    res = cls.sfa_manager.set_secure_feature(target=cls.PP_DIAG_ADR, ecu_uid=cls.ecu_uid,
                                                             feature_id=cls.DM_VERITY)
                    xtime.sleep(cls.PP_STARTUP_TIMEOUT_S)
                    feature_status = cls.sfa_manager.sfa_get_status(cls.PP_DIAG_ADR, feature_id=cls.DM_VERITY)
                    if feature_status == Feature_Status.Enabled.value:
                        logger.info("SW debug token is enabled")
                        if len(cls.ssh_manager.executeCommandInTarget(command="ls /persistent/ | grep writable.fs ",
                                                                      ip_address=cls.PP_IP,
                                                                      timeout=cls.SSH_CONNECTION_TIMEOUT_MS)[
                                   "stdout"].splitlines()) == 1:
                            logger.info("The flag file was created")
                            d1c5_activated = True
                elif feature_status == Feature_Status.Enabled.value:
                    logger.info("SW debug token is enabled")
                    if len(cls.ssh_manager.executeCommandInTarget(command="ls /persistent/ | grep writable.fs ",
                                                                  ip_address=cls.PP_IP,
                                                                  timeout=cls.SSH_CONNECTION_TIMEOUT_MS)[
                               "stdout"].splitlines()) == 1:
                        logger.info("The flag file was created")
                        d1c5_activated = True
            cls.sfa_manager.stop_sfa_manager()
        cls.diag_manager.stop()
        logger.info(f"The D1C5 activation is {d1c5_activated}")
        return d1c5_activated

    @classmethod
    def clear_and_activate_d1c5(cls):
        logger.debug("Starting the check of D1C5")
        cls.diag_manager.start()
        cls.sfa_manager.start_sfa_manager()
        feature_status = cls.sfa_manager.sfa_get_status(cls.PP_DIAG_ADR, cls.DM_VERITY)
        if feature_status == Feature_Status.Enabled.value:

            logger.info("The feature ID D1C5 deactivation")
            # ECU must be in ENG mode to clear features
            cf_res = cls.sfa_manager.sfa_clear_feature(cls.PP_DIAG_ADR, cls.DM_VERITY)
            cls.expectTrue(cf_res, Severity.BLOCKER, "Feature token clear failed")
            xtime.sleep(cls.PP_STARTUP_TIMEOUT_S)
            status = cls.sfa_manager.sfa_get_status(cls.PP_DIAG_ADR, cls.DM_VERITY)
            cls.expectTrue(status == Feature_Status.IntialDisabled.value, Severity.BLOCKER,
                           "Feature D1C5 should be disabled after clearing")
        # ENABLE D1C5
        res = cls.sfa_manager.set_secure_feature(target=cls.PP_DIAG_ADR, ecu_uid=cls.ecu_uid,
                                                 feature_id=cls.DM_VERITY)
        xtime.sleep(cls.PP_STARTUP_TIMEOUT_S)
        feature_status = cls.sfa_manager.sfa_get_status(cls.PP_DIAG_ADR, feature_id=cls.DM_VERITY)
        if feature_status == Feature_Status.Enabled.value:
            logger.info("D1C5 token is enabled")
        if len(cls.ssh_manager.executeCommandInTarget(command="ls /persistent/ | grep writable.fs ",
                                                      ip_address=cls.PP_IP,
                                                      timeout=cls.SSH_CONNECTION_TIMEOUT_MS)[
                   "stdout"].splitlines()) == 1:
            logger.info("writable.fs found")
        else:
            logger.warn("writable.fs not found")

        cls.diag_manager.stop()
        cls.sfa_manager.stop_sfa_manager()
        cls.ssh_manager.use_rwfs(True)

    @classmethod
    def check_test_app(self):
        # -------------------
        test_app_directory_exist = self.ssh_manager.executeCommandInTarget(command="ls /opt/test_app/",
                                                                           ip_address=self.PP_IP,
                                                                           timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        logger.info(f"####### test_app directory exist start #######\n")
        logger.info(f"{test_app_directory_exist['stdout']}\n")
        logger.info(f"####### test_app directory exist end #######")
        grep_testApp = self.check_application_is_started_with_instances(app_name=self.TEST_APP_APP_NAME)
        self.expectTrue(grep_testApp, Severity.MAJOR, "Check The application was started")
        # -------------------

    @classmethod
    def get_os_name(cls):
        os_name = cls.ssh_manager.executeCommandInTarget(command="uname", ip_address=cls.PP_IP,
                                                         timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        logger.info(f"uname result:{os_name}")
        return os_name['stdout'].strip().split('\n')[0]

    @classmethod
    def check_application_is_started(cls, app_name):
        logger.info(f"os_name = {cls.os_name}")
        if cls.os_name == "QNX":
            return cls.check_application_is_started_qnx(app_name)
        else:
            return cls.check_application_is_started_linux(app_name)

    @classmethod
    def recursive_sum_to_n(cls, n):
        return n if n <= 1 else (n + cls.recursive_sum_to_n(n - 1))

    @classmethod
    def Simulate_PWF_State(self, state):
        logger.info(f"Simulating PWF state to {state}")
        self.bcp21_nmController.set_basic_partial_network(self.Ctr_Basic_PN[state])
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.VEHICLECONDITION_SERVICE_ID,
                                                 instance_id=self.VEHICLECONDITION_INSTANCE_ID,
                                                 method_id=self.VEHICLECONDITION_METHOD_ID,
                                                 signal_name="VehicleCondition.controlBasePartialNetworks",
                                                 signal_value=self.Veh_Cond_Status[state]
                                                 )
        self.tb.sleep_for(self.VSOMEIP_SIGNAL_UPDATE_TIMEOUT_MS)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.VEHICLECONDITION_SERVICE_ID,
                                                 instance_id=self.VEHICLECONDITION_INSTANCE_ID,
                                                 method_id=self.VEHICLECONDITION_METHOD_ID,
                                                 signal_name="VehicleCondition.statusConditionVehicle",
                                                 signal_value=self.Veh_Cond_Status[state]
                                                 )
        self.tb.sleep_for(self.VSOMEIP_SIGNAL_UPDATE_TIMEOUT_MS)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.VEHICLECONDITION_SERVICE_ID,
                                                 instance_id=self.VEHICLECONDITION_INSTANCE_ID,
                                                 method_id=self.VEHICLECONDITION_METHOD_ID,
                                                 signal_name="VehicleCondition.qualifierStatusConditionVehicle",
                                                 signal_value=self.SOMEIP_VEH_COND_QUALIFIER_valid_value)
        self.tb.sleep_for(self.VSOMEIP_SIGNAL_UPDATE_TIMEOUT_MS)

    @classmethod
    def Check_GPIO_toggling(self, gpio_id):
        bIsToggling = False
        if self.os_name == "QNX":
            logger.info(f"Checking the GPIO {gpio_id} toggling for 4 seconds")
            GPio_state = self.ssh_manager.executeCommandInTarget(command=f"cat /dev/gpio/{gpio_id} |head -c 1",
                                                                 ip_address=self.PP_IP,
                                                                 timeout=self.SSH_CONNECTION_TIMEOUT_MS)
            GPio_init_state = int(GPio_state["stdout"])
            for loop_index in range(10):
                self.tb.sleep_for(400)
                returnValue = self.ssh_manager.executeCommandInTarget(command=f"cat /dev/gpio/{gpio_id} |head -c 1",
                                                                      ip_address=self.PP_IP,
                                                                      timeout=self.SSH_CONNECTION_TIMEOUT_MS)
                if int(returnValue["stdout"]) != GPio_init_state:
                    bIsToggling = True
        else:
            logger.info(f"Checking the GPIO {gpio_id} toggling for 4 seconds")
            GPio_state = self.ssh_manager.executeCommandInTarget(command=f"cat /sys/class/gpio/{gpio_id}/value",
                                                                 ip_address=self.PP_IP,
                                                                 timeout=self.SSH_CONNECTION_TIMEOUT_MS)
            GPio_init_state = int(GPio_state["stdout"].strip())
            for loop_index in range(10):
                self.tb.sleep_for(400)
                returnValue = self.ssh_manager.executeCommandInTarget(command=f"cat /sys/class/gpio/{gpio_id}/value",
                                                                      ip_address=self.PP_IP,
                                                                      timeout=self.SSH_CONNECTION_TIMEOUT_MS)
                if int(returnValue["stdout"].strip()) != GPio_init_state:
                    bIsToggling = True
        return bIsToggling

    @classmethod
    def is_adaptive_in_exec_config(cls, application_name):
        logger.info(f"is_adaptive_in_exec_config for application {application_name}")
        isExecutionManager = cls.json_manager.findNodeFromJsonFile(
            filePath=f"/opt/{application_name}/etc/{cls.EXEC_CONFIG_FILE_NAME}", nodePath="isExecutionManager",
            use_cache=False, delete_cache=False)
        if isExecutionManager is not None and isExecutionManager != []:
            logger.debug(f"isExecutionManager retrieved with value {isExecutionManager}")
            return isExecutionManager == 0

        executableType = cls.json_manager.findNodeFromJsonFile(
            filePath=f"/opt/{application_name}/etc/{cls.EXEC_CONFIG_FILE_NAME}", nodePath="executableType",
            use_cache=False, delete_cache=False)
        if executableType is not None and executableType != []:
            logger.debug(f"executableType retrieved with value {executableType}")
            return executableType == "NOT_DAEMON"
        return False

    @classmethod
    def set_state_in_exec_config(cls, config_path, instance_index, fg_index, state_list):
        cls.json_manager.updateNodeIntoJsonFile(filePath=config_path,
                                                nodePath=f"processes[{instance_index}].startupConfigs[0].functionGroups[{fg_index}].states",
                                                value=state_list, use_cache=False, delete_cache=True, upload_file=True)
        cls.ssh_manager.executeCommandInTarget(command=f"sync", ip_address=cls.PP_IP,
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

    @classmethod
    def get_states_in_exec_config(cls, config_path, instance_index, fg_index):
        states_list = cls.json_manager.findNodeFromJsonFile(filePath=config_path,
                                                            nodePath=f"processes[{instance_index}].startupConfigs[0].functionGroups[{fg_index}].states",
                                                            use_cache=False, delete_cache=False)
        return states_list

    @classmethod
    def set_functionGroups_in_exec_config(cls, config_path, instance_index, fgs_array):
        cls.json_manager.updateNodeIntoJsonFile(filePath=config_path,
                                                nodePath=f"processes[{instance_index}].startupConfigs[0].functionGroups",
                                                value=fgs_array, use_cache=False, delete_cache=True, upload_file=True)
        cls.ssh_manager.executeCommandInTarget(command=f"sync", ip_address=cls.PP_IP,
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

    @classmethod
    def set_options_in_exec_config(cls, config_path, instance_index, options_list):
        cls.json_manager.updateNodeIntoJsonFile(filePath=config_path,
                                                nodePath=f"processes[{instance_index}].startupConfigs[0].options",
                                                value=options_list, use_cache=False, delete_cache=True,
                                                upload_file=True)
        cls.ssh_manager.executeCommandInTarget(command=f"sync", ip_address=cls.PP_IP,
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

    @classmethod
    def set_dependencies_in_exec_config(cls, config_path, instance_index, dependencies_dict):
        cls.json_manager.updateNodeIntoJsonFile(filePath=config_path,
                                                nodePath=f"processes[{instance_index}].startupConfigs[0].executionDependency",
                                                value=dependencies_dict, use_cache=False, delete_cache=True,
                                                upload_file=True)
        cls.ssh_manager.executeCommandInTarget(command=f"sync", ip_address=cls.PP_IP,
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

    @classmethod
    def set_scheduling_policy_in_exec_config(cls, config_path, instance_index, policy):
        cls.json_manager.updateNodeIntoJsonFile(filePath=config_path,
                                                nodePath=f"processes[{instance_index}].startupConfigs[0].schedulingPolicy",
                                                value=policy, use_cache=False, delete_cache=True, upload_file=True)
        cls.ssh_manager.executeCommandInTarget(command=f"sync", ip_address=cls.PP_IP,
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

    @classmethod
    def set_scheduling_priority_in_exec_config(cls, config_path, instance_index, priority):
        cls.json_manager.updateNodeIntoJsonFile(filePath=config_path,
                                                nodePath=f"processes[{instance_index}].startupConfigs[0].schedulingPriority",
                                                value=priority, use_cache=False, delete_cache=True, upload_file=True)
        cls.ssh_manager.executeCommandInTarget(command=f"sync", ip_address=cls.PP_IP,
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

    @classmethod
    def add_new_function_group(cls, function_group_dict):
        fgs = cls.initial_function_groups.copy()
        fgs.append(function_group_dict)
        cls.json_manager.updateNodeIntoJsonFile(filePath=cls.machine_exec_config_path,
                                                nodePath="machine.functionGroups", value=fgs, use_cache=False,
                                                delete_cache=True, upload_file=True)
        cls.ssh_manager.executeCommandInTarget(command=f"sync", ip_address=cls.PP_IP,
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

    @classmethod
    def set_cores_in_exec_config(cls, config_path, instance_index, cores_list):
        cls.json_manager.updateNodeIntoJsonFile(filePath=config_path,
                                                nodePath=f"processes[{instance_index}].startupConfigs[0].cores",
                                                value=cores_list, use_cache=False, delete_cache=True, upload_file=True)
        cls.ssh_manager.executeCommandInTarget(command=f"sync", ip_address=cls.PP_IP,
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS)

    @classmethod
    def get_scheduling_policy(cls, pid):
        if cls.os_name == "QNX":
            scheduling_policy_value_list = []
            result = cls.ssh_manager.executeCommandInTarget(command=f"pidin -p {pid}| awk " + r"{'print $4'} ",
                                                            ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
            logger.info(f'result_SP : {result}')
            try:
                result_SP = result['stdout'].strip().split("\n")
                logger.info(f'result_SP : {result_SP}')
                for i in range(1, len(result_SP)):
                    scheduling_policy_priority_value = result_SP[i]
                    logger.info(f'scheduling_policy_priority_value : {scheduling_policy_priority_value}')
                    scheduling_policy_value = str(''.join(filter(str.isalpha, result_SP[i])))
                    logger.info(f'scheduling_priority_value : {scheduling_policy_value}')
                    scheduling_policy_value_list.append(scheduling_policy_value)
                logger.info(f'scheduling_priority_value_list : {scheduling_policy_value_list}')
                return scheduling_policy_value_list[0]

            except:
                return -1
        else:
            result = cls.ssh_manager.executeCommandInTarget(command=f"cat /proc/{pid}/stat | cut -d ' ' -f 41",
                                                            ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
            if result['stderr'].strip() != "":
                return -1
            try:
                return result['stdout'].strip()
            except:
                return -1

    @classmethod
    def get_scheduling_priority(cls, pid):
        if cls.os_name == "QNX":
            scheduling_priority_value_list = []
            result = cls.ssh_manager.executeCommandInTarget(command=f"pidin -p {pid}| awk " + r"{'print $4'} ",
                                                            ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
            logger.info(f'result_SP : {result}')
            try:
                result_SP = result['stdout'].strip().split("\n")
                logger.info(f'result_SP : {result_SP}')
                for i in range(1, len(result_SP)):
                    scheduling_policy_priority_value = result_SP[i]
                    logger.info(f'scheduling_policy_priority_value : {scheduling_policy_priority_value}')
                    scheduling_priority_value = int(''.join(filter(str.isdigit, result_SP[i])))
                    logger.info(f'scheduling_priority_value : {scheduling_priority_value}')
                    scheduling_priority_value_list.append(scheduling_priority_value)
                logger.info(f'scheduling_priority_value_list : {scheduling_priority_value_list}')
                return scheduling_priority_value_list[0]
            except:
                return -1
        else:
            result = cls.ssh_manager.executeCommandInTarget(command=f"cat /proc/{pid}/stat | cut -d ' ' -f 40",
                                                            ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
            logger.info(f"result: {result}")
            if result['stderr'].strip() != "":
                return -1
            try:
                logger.info(f"scheduling_priority_value: {result['stdout'].strip()}")
                return result['stdout'].strip()
            except:
                return -1

    def check_partition_mounts(cls, partition_name):
        logger.info(f"Start getting {partition_name} access rights")
        accessRight = ''
        if cls.os_name == "QNX":
            partition = cls.ssh_manager.executeCommandInTarget(
                command=f"mount -f | grep $(ls -l /dev/ | grep {partition_name} | awk -F  '->' {'print $2'})",
                timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                ip_address=cls.PP_IP)
            check_accessRight = partition["stdout"]
            if "rdonly" in check_accessRight:
                logger.info("Partition system is read only")
                accessRight = "rdonly"
                return accessRight
            else:
                logger.info("Partition system is read write")
                accessRight = " "
                return accessRight
        else:
            logger.info("Enter else")
            partition = cls.ssh_manager.executeCommandInTarget(command=f"cat /proc/mounts | grep {partition_name}",
                                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                                                               ip_address=cls.PP_IP)
            check_accessRight = partition["stdout"].split(" ")[3].split(",")[0]
            logger.info(f"File system is {check_accessRight}")
            if check_accessRight == "rw":
                logger.info("Partition system is read only")
                accessRight = check_accessRight
                return accessRight
            elif check_accessRight == "ro":
                logger.info("Partition system is read write")
                accessRight = check_accessRight
                return accessRight
            else:
                logger.info("ERROR")
                return accessRight

    @classmethod
    def get_number_of_cores(cls):
        if cls.os_name.lower() == "linux":
            result = cls.ssh_manager.executeCommandInTarget(command="getconf _NPROCESSORS_ONLN",
                                                            timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        else:
            result = cls.ssh_manager.executeCommandInTarget(
                command="pidin syspage=cpuinfo | head -n 1 | awk '{print substr($5,6,1)}'",
                timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        if result['stdout'].strip() in [str(x + 1) for x in range(8)]:
            return int(result['stdout'].strip())
        else:
            return cls.INVALID_VALUE

    @classmethod
    def get_last_dlt_message(cls, messages):
        timestamp = 0
        last_message = None
        for message in messages:
            if int(message['timestamp'].split(".")[0]) > timestamp:
                timestamp = int(message['timestamp'].split(".")[0])
                last_message = message

        return last_message

    @classmethod
    def Check_ECU_in_ELK_mode(cls):
        serial_logs = cls.serial_controller.get_readed_data()
        cls.serial_controller.clear_data()
        checkPLK = "mmc2:/app_2.kpi" in serial_logs or "mmc2:/app_1.kpi" in serial_logs
        cls.expectTrue(checkPLK, Severity.BLOCKER, "Checking ECU is booting in ELK mode")


    @classmethod
    def Check_ECU_degradated(cls):
        diag_request = cls.diag_manager.syn_send(src=cls.TESTER_DIAG_ADR, target=cls.PP_DIAG_ADR,payload=[0x31, 0x03, 0x10, 0x77])
        cls.expectTrue(diag_request != DiagResult.timeout, Severity.BLOCKER, "Checking PP reaches timeout")
        cls.expectTrue(diag_request != DiagResult.unknown, Severity.BLOCKER, "Checking Unknown response")
        cls.expectTrue(diag_request == DiagResult.positive, Severity.BLOCKER, "Checking Positive response")
        diag_response = cls.diag_manager.get_latest_Response(target= cls.PP_DIAG_ADR).get_payload()
        if diag_request == DiagResult.positive:
            logger.info('Degradation_Status')
            diag_response = cls.diag_manager.get_latest_Response(target=cls.PP_DIAG_ADR).get_payload()[4]
            logger.info(f"Degradation_Status: {diag_response}")
        logger.info(f"Degradation_Status: {diag_response}")
        cls.expectTrue(diag_response == cls.ECU_NOT_DEGRADATED, Severity.BLOCKER, "Checking ECU is not degradated")

    def setUp(self):
        logger.info("testBase_SIL start setUp")
        if not self.bIs_BCP_Simulated:
            ECUs_are_OK = self.check_ECUs()
            self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUs are correctly reset")
            self.check_ecu_default_state()
            if self.os_name == "QNX":
                started_apps = self.ssh_manager.executeCommandInTarget(command="ps -A -o pid,args",
                                                                       ip_address=self.PP_IP,
                                                                       timeout=self.SSH_CONNECTION_TIMEOUT_MS)
            else:
                started_apps = self.ssh_manager.executeCommandInTarget(command="ps aux", ip_address=self.PP_IP,
                                                                       timeout=self.SSH_CONNECTION_TIMEOUT_MS)
                logger.info(f"####### Running applications start #######\n")
                logger.info(f"{started_apps['stdout']}\n")
                logger.info(f"####### Running applications end #######")
        else:
            logger.info("BCP Simulated, nothing to be setUp")
        logger.info("testBase_SIL end setUp")

    def tearDown(self):
        logger.info("testBase_SIL start teardown")
        if not self.bIs_BCP_Simulated:
            ECUs_are_OK = self.check_ECUs()
            self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUs are correctly reset")
            self.check_ecu_default_state()
            if self.os_name == "QNX":
                started_apps = self.ssh_manager.executeCommandInTarget(command="ps -A -o pid,args",
                                                                       ip_address=self.PP_IP,
                                                                       timeout=self.SSH_CONNECTION_TIMEOUT_MS)
            else:
                started_apps = self.ssh_manager.executeCommandInTarget(command="ps aux", ip_address=self.PP_IP,
                                                                       timeout=self.SSH_CONNECTION_TIMEOUT_MS)
                logger.info(f"####### Running applications start #######\n")
                logger.info(f"{started_apps['stdout']}\n")
                logger.info(f"####### Running applications end #######")
                self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",
                                                                output_folder=OutputPathManager.get_test_case_path(),
                                                                check_empty=False,
                                                                ip_address=self.PP_IP,
                                                                ignored_files=["currentswversion", "tmp"])
        else:
            logger.info("BCP Simulated, nothing to be tearDown")
        logger.info("testBase_SIL end teardown")

