from Tests.PSAA.Param_Server.testfixture_PSAA_param_server import *


class tca_ParamS_001_Getter_not_coding(testfixture_PSAA_param_server):

    TEST_ID = "ParamServer\tca_ParamS_001_Getter_not_coding"
    REQ_ID = ["/item/53142", "/item/53153", "/item/727611", "/item/53137", "/item/53138"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    field_depends_on_coding = False

    def setUp(self):
        pass

    def test_Getter_not_coding(self):

        self.someip_controller.send_request("TestEquipmentIntern", service_id=self.AdpParameters_service_ID, instance_id=self.AdpParameters_instances[self.PP_NAME],
                                            method_id=self.someipIds['getterID'], interface_version=1, is_TCP=False)

        self.sleep_for(self.GETTER_RESPONSE_TIMEOUT_MS)

        someip_response_messages = self.get_someip_messages_from_queue(method_id=self.someipIds['getterID'])

        self.expectTrue(len(someip_response_messages) > 0, Severity.BLOCKER, "Check that a response of the getter request is received")
        self.expectTrue(len(someip_response_messages) == 1, Severity.MAJOR, "Check that exactly 1 response of the getter request is received")

        messages_count, dlt_messages = self.dlt_manager.get_messages(searchMsg=self.DLT_message_GET)

        self.expectTrue(messages_count > 0, Severity.BLOCKER, "Check that DLT Get message exists")
        self.expectTrue(messages_count == 1, Severity.BLOCKER, "Check that only 1 DLT Get message exists")
        logger.info(f"message count = {messages_count}")
        logger.info(f"message count type= {type(messages_count)}")
        getter_response = someip_response_messages[-1].payload
        logger.info(f"Response payload of the getter = {getter_response}")

        getter_response_size = len(getter_response)
        logger.info(f"The size of the received Getter response = {getter_response_size}")
        self.assertTrue(getter_response_size == self.field_size, Severity.BLOCKER, "Check that the payload size of the getter response is correct.")

        parsed_getter_response = self.parse_field_someip_payload(payload=getter_response, field_structure=self.field_structure)
        logger.info(f"Parsed Getter response :\n{json.dumps(parsed_getter_response, indent=4)}")

        parameter_values_are_correct = self.check_if_all_parameter_values_are_default(parsed_payload=parsed_getter_response)
        self.assertTrue(parameter_values_are_correct, Severity.BLOCKER, "Check that the parameter Values equal default value if exist else initValue")

    def tearDown(self):
        pass
