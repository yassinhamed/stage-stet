from Tests.PSAA.Log_Collector.testfixture_PSAA_Log_Collector import *

class tca_PSAA_052_logC_Slog_DTCs_3_checks(testfixture_PSAA_Log_Collector):

    TEST_ID = "PSAA\tca_PSAA_052_logC_Slog_DTCs_3_checks"
    REQ_ID = ["/item/6037383","/item/6040647","/item/2939949"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check primary SW_Integritätsprüfung_fehlgeschlagen DTC and secondary Interne_System_Manipulation_erkannt DTC are set and Check Slog messages are being forwarded with Slog context ID"
    STATUS = "Ready"
    OS = ['QNX']

    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appId=self.LOG_COLLECTOR_APP_ID)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_PSAA_052_logC_Slog_DTCs_3_checks(self):
        self.startTestStep("Modify two DTCs of Slog ")
        self.ssh_manager.downloadFileFromTarget(source_file=self.Config_file_name, source_path=self.Config_file_path, destination_path=OutputPathManager.get_test_case_path())
        self.ssh_manager.executeCommandInTarget(command=f"mv {self.Config_file_path}{self.Config_file_name} /persistent/Technica/ ", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.edit_JSON_file()
        self.ssh_manager.uploadFileToTarget(source_file=self.Config_file_name, source_path=OutputPathManager.get_test_case_path(), destination_path=self.Config_file_path)
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.startTestStep("Check log collector application is running")
        grep_LogC = self.check_application_is_started(app_name=self.LOG_COLLECTOR_APP_NAME)
        self.expectTrue(grep_LogC, Severity.MAJOR, "Check The application was started")
        self.startTestStep("Add Slog messages for primary DTC")
        self.logCollectorAddSLog(MessageRegex=self.qnx2_random_text)
        self.startTestStep("Get Slog messages for primary DTC")
        Message0 = self.logCollectorGetSLog(MessageRegex=self.qnx2_random_text)
        logger.info(Message0)
        self.assertTrue(Message0 is not None, "check that message exist in slog2info")
        self.sleep_for(self.wait_message_to_be_logged)
        self.startTestStep("Add Slog messages for secondary DTC")
        self.logCollectorAddSLog(MessageRegex=self.qnx_random_text)
        self.startTestStep("Get Slog messages for secondary DTC")
        Message1 = self.logCollectorGetSLog(MessageRegex=self.qnx_random_text)
        logger.info(Message1)
        self.assertTrue(Message1 is not None, "check that message exist in slog2info")
        self.sleep_for(self.wait_message_to_be_logged)
        self.startTestStep("Add Slog messages for DLT")
        self.logCollectorAddSLog(MessageRegex=self.first_random_text)
        self.startTestStep("Get Slog messages for DLT")
        Message3 = self.logCollectorGetSLog(MessageRegex=self.first_random_text)
        logger.info(Message3)
        self.assertTrue(Message3 is not None, "check that message exist in slog2info")
        self.sleep_for(self.wait_message_to_be_logged)

        self.startTestStep("Get DLT messages")
        number, messages = self.dlt_manager.wait_for_message(search_message=self.qnx2_random_text)
        self.assertTrue(number > 0, Severity.BLOCKER, "Check Slog messages are being forwarded with SYSL context ID to primary DTC")
        self.startTestStep("Get DLT messages")
        number, messages = self.dlt_manager.wait_for_message(search_message=self.qnx_random_text)
        self.assertTrue(number > 0, Severity.BLOCKER, "Check Slog messages are being forwarded with SYSL context ID to secondary DTC")
        self.startTestStep("Get DLT messages")
        number, messages = self.dlt_manager.wait_for_message(search_message=self.first_random_text)
        self.assertTrue(number > 0, Severity.BLOCKER, "Check Slog messages are being forwarded with SYSL context ID to DLT")
        self.startTestStep("Check primary SW_Integritätsprüfung_fehlgeschlagen DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][self.PP_NAME], memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that primary DTC is set")
        self.startTestStep("Check secondary Interne_System_Manipulation_erkannt DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Interne_System_Manipulation_erkannt"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that secondary DTC is set")

        self.startTestStep("Get all snapshots of SW_Integritätsprüfung_fehlgeschlagen DTC")
        service_response = self.dtc_manager.get_all_snapshots(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][self.PP_NAME], memory_type=memory_type.PRIMARY)
        logger.info("result= " + str(service_response))
        message0 = self.get_snapshots(dtc_snapshots=service_response, env_variable=self.qnx2_random_text, index=0, message="63757465")
        self.assertTrue(message0 is not None, Severity.BLOCKER, "The message cute exist in primary DTC snapshot")
        self.assertTrue(self.qnx2_random_text in (bytes.fromhex(message0.split('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')[0]).decode('utf-8')), Severity.BLOCKER, "Checking that DTC environment variable is filled")

        self.startTestStep("Get all snapshots of Interne_System_Manipulation_erkannt DTC")
        service_response = self.dtc_manager.get_all_snapshots(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Interne_System_Manipulation_erkannt"][self.PP_NAME], memory_type=memory_type.SECONDARY)
        logger.info("result= " + str(service_response))
        message1 = self.get_snapshots(dtc_snapshots=service_response, env_variable=self.qnx_random_text, index=0, message="4E696365")
        self.assertTrue(message1 is not None, Severity.BLOCKER, "The messages Nice exist in secondary DTC snapshot")
        self.assertTrue(self.qnx_random_text in (bytes.fromhex(message1.split('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')[0]).decode('utf-8')), Severity.BLOCKER, "Checking that DTC environment variable is filled")




    def tearDown(self):
        self.diag_manager.start()
        self.setPostcondition("Revert Config file")
        self.logCollectorRevertConfigFile_QNX()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.diag_manager.start()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)

