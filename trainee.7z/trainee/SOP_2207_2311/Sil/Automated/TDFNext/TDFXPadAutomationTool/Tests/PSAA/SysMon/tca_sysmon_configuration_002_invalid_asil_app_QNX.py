from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_configuration_002_invalid_asil_app_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_configuration_002_invalid_asil_app_QNX"
    REQ_ID = ["/item/5906499"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports initialization error and exit"
    OS = ['QNX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get sysmon PID")
        app_is_running = self.check_application_is_started(app_name=self.SYSMON_APP_NAME)
        self.assertTrue(app_is_running, Severity.MAJOR, "Check that sysmon is running ")

        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appId=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.version_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

        self.clear_and_activate_d1c5()

    def test_tca_sysmon_configuration_002_invalid_asil_app_QNX(self):
        self.startTestStep("Checking asil_app.conf is present under sysmon path")
        search_file = self.asil_app_file_name in self.list_sysmon_files()
        self.assertTrue(search_file, Severity.MAJOR, "Check asil_app.conf file is present")

        self.startTestStep("Create asil_app.conf backup under /persistent/")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"cp {self.sysmon_etc_path}{self.asil_app_file_name} /persistent/", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.MAJOR, "Check command executed")

        self.startTestStep("Empty asil_app.conf")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"echo ' ' > {self.sysmon_etc_path}{self.asil_app_file_name}", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.MAJOR, "Check command executed")

        self.startTestStep("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        #Feature not implemented SWP-16571
        self.startTestStep("Find DLT messages that reports the initialiazation error due to invalid asil_app.conf")
        message_count, message = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, searchMsgArray=self.asil_app_error_message)
        self.assertTrue(message_count > 0, Severity.BLOCKER, "Check that error message is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()

        self.setPostcondition("Load sysmon_config.json backup via Serial")
        self.serial_controller.start(channel="PP-Serial")
        self.diag_manager.syn_send(src=self.TESTER_DIAG_ADR, target=self.SC_DIAG_ADR, payload=self.STEUERGERAETE_RESET)
        if self.wait_until(somepredicate=self.check_serial_output, timeout=60, period=0.25, text_check="Launching EM"):
            logger.info("Loading sysmon_config.json backup via Serial")
            self.serial_controller.send_command(command="\n rm -rf /opt/sysmon/etc/asil_apps.conf && cp /persistent/asil_apps.conf /opt/sysmon/etc/asil_apps.conf")
            self.serial_controller.send_command(command="\n rm -rf /opt/sysmon/etc/asil_apps.conf && cp /persistent/asil_apps.conf /opt/sysmon/etc/asil_apps.conf")
        else:
            logger.info("Loading sysmon_config.json backup via Serial")
            self.serial_controller.send_command(command="\n rm -rf /opt/sysmon/etc/asil_apps.conf && cp /persistent/asil_apps.conf /opt/sysmon/etc/asil_apps.conf")
            self.serial_controller.send_command(command="\n rm -rf /opt/sysmon/etc/asil_apps.conf && cp /persistent/asil_apps.conf /opt/sysmon/etc/asil_apps.conf")

        self.setPostcondition("Resetting the Safety Controller")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)

        self.setPostcondition("Check ECUs")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUs are Ok after ECU reset")
