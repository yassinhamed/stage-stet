from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_forking_03_THRD_thread_creation_selected_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_forking_03_THRD_thread_creation_selected_QNX"
    REQ_ID = ["/item/5833180"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports thread creation of selected porcesses"
    OS = ['QNX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Start DLT monitoring")

    def test_tca_sysmon_forking_03_THRD_thread_creation_selected_QNX(self):
        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.startTestStep("Get PID of the process exec_manager")
        self.startTestStep("Wait for DLT messages (3 seconds)")
        self.startTestStep("Get THRD DLT messages")
        self.assertTrue(True, Severity.MAJOR, "Check that the creation of the threads was reported")
        self.assertTrue(True, Severity.MAJOR, "Check that the report contains the thread ID, parent Process ID and name")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.setPostcondition("Revert The config file of selected processes")
        self.setPostcondition("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
