from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_HW_IRQ_01_IRQH_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_HW_IRQ_01_IRQH_LINUX"
    REQ_ID = ["/item/5888650", "/item/5888716", "/item/5888728", "/item/5889454", "/item/5888802"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports HW IRQ statistics"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.hardware_irqs_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.Search_msg_array = self.statistic_data["IRQ"]["HW"]["Search_msg_array"]
        logger.info(f"Search message array = {self.Search_msg_array}")
        self.assertTrue(self.Search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.hardware_irqs_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_HW_IRQ_01_IRQH_LINUX(self):
        self.startTestStep("Wait the configured time interval * 4.5")
        self.sleep_for(self.time_interval * 4.5)
        self.startTestStep("Get IRGH DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.Search_msg_array)
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that IRQH statistics DLT messages are available")

        self.startTestStep("Get eth0 value")
        eth0 = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.eth0")
        self.expectTrue(eth0 != self.INVALID_VALUE, Severity.MAJOR, "Check that eth0 is reported")

        self.startTestStep("Get mmc0 value")
        mmc0 = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.mmc0")
        self.expectTrue(mmc0 != self.INVALID_VALUE, Severity.MAJOR, "Check that mmc0 is reported")

        self.startTestStep("Get rtc0 value")
        rtc0 = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.rtc0")
        self.expectTrue(rtc0 != self.INVALID_VALUE, Severity.MAJOR, "Check that rtc0 is reported")

        self.startTestStep("Get timer value")
        timer = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.timer")
        self.expectTrue(timer != self.INVALID_VALUE, Severity.MAJOR, "Check that timer is reported")

        self.startTestStep("Get ttyS0 value")
        ttyS0 = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.ttyS0")
        self.expectTrue(ttyS0 != self.INVALID_VALUE, Severity.MAJOR, "Check that ttyS0 is reported")

        self.startTestStep("Get ttyS2 value")
        ttyS2 = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.ttyS2")
        self.expectTrue(ttyS2 != self.INVALID_VALUE, Severity.MAJOR, "Check that ttyS2 is reported")

        self.startTestStep("Get CAL value")
        CAL = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.CAL")
        self.expectTrue(CAL != self.INVALID_VALUE, Severity.MAJOR, "Check that CAL is reported")

        self.startTestStep("Get IWI value")
        IWI = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.IWI")
        self.expectTrue(IWI != self.INVALID_VALUE, Severity.MAJOR, "Check that IWI is reported")

        self.startTestStep("Get LOC value")
        LOC = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.LOC")
        self.expectTrue(LOC != self.INVALID_VALUE, Severity.MAJOR, "Check that LOC is reported")

        self.startTestStep("Get MCP value")
        MCP = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.MCP")
        self.expectTrue(MCP != self.INVALID_VALUE, Severity.MAJOR, "Check that MCP is reported")

        self.startTestStep("Get NMI value")
        NMI = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.NMI")
        self.expectTrue(NMI != self.INVALID_VALUE, Severity.MAJOR, "Check that NMI is reported")

        self.startTestStep("Get PMI value")
        PMI = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.PMI")
        self.expectTrue(PMI != self.INVALID_VALUE, Severity.MAJOR, "Check that PMI is reported")

        self.startTestStep("Get RES value")
        RES = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.RES")
        self.expectTrue(RES != self.INVALID_VALUE, Severity.MAJOR, "Check that RES is reported")

        self.startTestStep("Get TLB value")
        TLB = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.TLB")
        self.expectTrue(TLB != self.INVALID_VALUE, Severity.MAJOR, "Check that TLB is reported")

        self.startTestStep("Get the order of the values")
        Order = self.get_statistic_value(message=messages[0], statistic_path="IRQ.HW.Statistics.Order")
        self.expectTrue(Order != self.INVALID_VALUE, Severity.MAJOR, "Check that interrupt names are sorted a alphabetical order (lowercase than uppercase)")

        self.expectTrue("MIS" not in messages, Severity.MAJOR, "Check that MIS interrupt is not reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
