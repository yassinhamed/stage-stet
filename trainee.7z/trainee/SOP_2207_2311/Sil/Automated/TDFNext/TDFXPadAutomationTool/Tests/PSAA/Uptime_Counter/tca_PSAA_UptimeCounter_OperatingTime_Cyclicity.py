from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *


class tca_PSAA_UptimeCounter_OperatingTime_Cyclicity(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_OperatingTime_Cyclicity"
    REQ_ID = ["/item/6233414"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check Operating time counter update cyclicity"
    OS = ["QNX", "LINUX"]
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get cyclicity from exec_config file")
        cyclicity = self.get_cyclicity_from_exec_config()
        self.assertTrue(cyclicity == self.Cyclicity_60m_MS, Severity.MAJOR, "Checking cyclicity is equale to 60min")

        self.setPrecondition("Create backup of exec_config_file")
        self.create_uptime_counter_exec_config_backup()


        self.setPrecondition("Changing uptime_counter cyclicity under exec_config file to 10s")
        self.change_cyclicity(new_cyclicity=self.Cyclicity_10s_MS)

        self.setPrecondition("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        self.setPrecondition("Check Ecus")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUS are correctly reset")

        self.startTestStep("Get cyclicity from exec_config file")
        cyclicity = self.get_cyclicity_from_exec_config()
        self.assertTrue(cyclicity == self.Cyclicity_10s_MS,Severity.MAJOR,"Checking cyclicity is successfully changed to 10s")

    def test_tca_PSAA_UptimeCounter_OperatingTime_Cyclicity(self):

        self.startTestStep("Getting Operating time counter value from kvs every second for 30s")
        OperatingTime_list = self.get_values_list(counter_name=self.OperatingTime_counter)
        logger.info(f"UpTimeCounter_list: {OperatingTime_list}")


        self.assertTrue(len(OperatingTime_list) > 0 , Severity.MAJOR, "Checking command is successfully executed")

        self.startTestStep("Getting delta time of value changes")
        delta_time_list = self.get_delta_time_list(values_list=OperatingTime_list)
        logger.info(f"delta_time_list: {delta_time_list}")

        self.startTestStep("Checking Cyclicity")
        check_cyclicity = self.check_delta_time(delta_time_list= delta_time_list,cyclicity=self.Cyclicity_10s_MS)
        self.assertTrue(check_cyclicity, Severity.MAJOR, "Checking that delta time of changes is equal to cyclicity")

    def tearDown(self):
        self.setPostcondition("Reverting uptime_counter exec_config file ")
        self.set_default_uptime_counter_exec_config()

        self.setPostcondition("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.setPostcondition("Check uptime_counter exec_config file is reverted")
        cyclicity = self.get_cyclicity_from_exec_config()
        self.expectTrue(cyclicity == self.Cyclicity_60m_MS, Severity.MAJOR,"Checking cyclicity is successfully reverted")
