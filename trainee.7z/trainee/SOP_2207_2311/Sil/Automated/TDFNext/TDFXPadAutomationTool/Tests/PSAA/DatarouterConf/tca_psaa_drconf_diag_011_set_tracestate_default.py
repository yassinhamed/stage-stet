from Tests.PSAA.DatarouterConf.testfixture_PSAA_DatarouterConf import *


class tca_psaa_drconf_diag_011_set_tracestate_default(testfixture_PSAA_DatarouterConf):
    TEST_ID = "PSAA\tca_psaa_drconf_diag_011_set_tracestate_default"
    REQ_ID = ["/item/853028"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check the set of the default trace status of the DLT subsystem in the ECU using diag"
    STATUS = "Ready"
    OS = ['LINUX','QNX']



    def setUp(self):
        grep_DConf = self.check_application_is_started(app_name=self.DATA_ROUTER_CONF_APP_NAME)
        self.expectTrue(grep_DConf, Severity.MAJOR, "Check The application was started")
        self.diag_manager.start()

    def test_tca_psaa_drconf_diag_011_set_tracestate_default(self):
        self.startTestStep("Set default trace status using diag")
        res = self.diag_manager.syn_send(0xF4, self.PP_DIAG_ADR,
                                         self.STEUERN_DLT_SET_DEFAULT_TRACESTATE_AUS)

        self.assertTrue(res == DiagResult.positive, Severity.BLOCKER, "Check the response of the diag")


    def tearDown(self):
        self.diag_manager.stop()
