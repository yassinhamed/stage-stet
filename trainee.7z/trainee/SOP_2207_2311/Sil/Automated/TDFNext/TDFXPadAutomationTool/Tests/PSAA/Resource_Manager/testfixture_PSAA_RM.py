from Tests.PSAA.testfixture_PSAA import *

from io import open


class testfixture_PSAA_RM(testfixture_PSAA):

    MSR_EXPOSED_FILES_LIST = ["/dev/cpu/0/msr", "/dev/cpu/1/msr", "/dev/cpu/2/msr", "/dev/cpu/3/msr"]
    MSR_JSON_PATH = "/opt/msr_reader/etc/hw_reg.json"
    MMR_JSON_PATH = "/opt/mmr_reader/etc/hw_reg.json"
    MMR_BERG_PATHS = {"0x10": "/dev/mmr/sbreg/10", "0x12": "/dev/mmr/sbreg/12", "0xC2": "/dev/mmr/sbreg/c2", "0xC5": "/dev/mmr/sbreg/c5"}
    MMR_PWRMBASE_PATH = "/dev/mmr/pwrmbase"
    MMR_MCHBAR_PATH = "/dev/mmr/mchbar"

    initial_msr_config_dict = None
    initial_mmr_config_dict = None

    def decrement_mmr_register_offset(self, register_offset):
        logger.info("Get all registers addresses from {0} in INT format".format(self.MMR_JSON_PATH))
        all_reg_addrs = self.get_all_registers_addresses(self.MMR_JSON_PATH)
        while register_offset in all_reg_addrs:
            register_offset -= 1

        return register_offset

    def increment_mmr_register_offset(self, register_offset):
        logger.info("Get all registers addresses from {0} in INT format".format(self.MMR_JSON_PATH))
        all_reg_addrs = self.get_all_registers_addresses(self.MMR_JSON_PATH)
        while register_offset in all_reg_addrs:
            register_offset +=1

        return register_offset

    def decrement_msr_register_offset(self, register_offset):
        logger.info("Get all registers addresses from {0} in INT format".format(self.MSR_JSON_PATH))
        all_reg_addrs = self.get_all_registers_addresses(self.MSR_JSON_PATH)
        while register_offset in all_reg_addrs:
            register_offset -= 1

        return register_offset

    def increment_msr_register_offset(self, register_offset):
        logger.info("Get all registers addresses from {0} in INT format".format(self.MSR_JSON_PATH))
        all_reg_addrs = self.get_all_registers_addresses(self.MSR_JSON_PATH)
        while register_offset in all_reg_addrs:
            register_offset += 1

        return register_offset

    def get_all_registers(self, path_to_json):
        """
        Gets all MMR, MSR & BAR registers.

        :param path_to_json: Path to "hw_reg.json"
        :return: list of registers, each one serialized as dict
        """
        hw_registers = self.json_manager.getInfoFromJsonFile(filePath = path_to_json, valuePath="*")
            
        logger.info(f"{len(hw_registers)} registers were found under {path_to_json}.")
        return hw_registers


    def get_registers_based_on_type(self, path_to_json, reg_type):
        """
        Gets registers based on a specified type.

        :param path_to_json: Path to "hw_reg.json"
        :param reg_type: Type of the desired register (MMR, MSR, BAR)
        :return: List of type-specified registers, each serialized as dict
        """

        hw_registers = self.json_manager.getInfoFromJsonFile(filePath = path_to_json, valuePath="*")
        
        selected_regs = list()
        for register in hw_registers:
            if register["register_type"] == reg_type.upper():
                selected_regs.append(register)
        
        print(f"{len(selected_regs)} {reg_type.upper()} registers were found under {path_to_json}.")
        return selected_regs


    def get_all_registers_addresses(self, path_to_json):
        """
        Gets all registers addresses.

        :param path_to_json: path to register file
        :return: List of all registers addresses
        """

        all_registers = self.json_manager.getInfoFromJsonFile(filePath=path_to_json, valuePath="*")

        all_registers_addresses = list()
        for register in all_registers:
            try:
                all_registers_addresses.append(int(register["register_address"], 16))
            except:
                all_registers_addresses.append(int(register["bar_offset"], 16))

        return all_registers_addresses


    def get_all_registers_sizes(self, path_to_json):
        """
        Gets all registers sizes.

        :param path_to_json: path to register file
        :return: List of all registers sizes
        """

        all_registers = self.json_manager.getInfoFromJsonFile(filePath=path_to_json, valuePath="*")

        all_registers_sizes = list()
        for register in all_registers:
            all_registers_sizes.append(int(register["register_size"], 16))

        return all_registers_sizes


    def get_decimal_address_list_from_msr_registers(self, msr_hw_reg):
        """
        Gets the MSR register's addresses.

        :param msr_hw_reg: List of MSR registers
        :return: List of MSR register's addresses
        """

        msr_addr_list = list()

        for register in msr_hw_reg:
                msr_addr_list.append(int(register["register_address"], 16))

        logger.info(f"{len(msr_addr_list)} MSR address were found.")
        return msr_addr_list
    

    def get_size_list_from_msr_registers(self, msr_hw_reg):
        """
        Gets the register's sizes.

        :param hw_reg: List of registers
        :return: List of register's sizes
        """

        msr_size_list = list()

        for register in msr_hw_reg:
                msr_size_list.append(register["register_size"])

        logger.info(f"{len(msr_size_list)} MSR register sizes were found.")
        return msr_size_list


    def get_decimal_size_list_from_msr_registers(self, msr_hw_reg):
        """
        Gets the register's sizes.

        :param hw_reg: List of registers
        :return: List of register's sizes
        """

        msr_size_list = list()

        for register in msr_hw_reg:
                msr_size_list.append(int(register["register_size"], 16))

        logger.info(f"{len(msr_size_list)} MSR register sizes were found.")
        return msr_size_list
    

    def get_address_list_from_msr_registers(self, msr_hw_reg):
        """
        Gets the MSR register's addresses.

        :param msr_hw_reg: List of MSR registers
        :return: List of MSR register's addresses
        """

        msr_addr_list = list()

        for register in msr_hw_reg:
                msr_addr_list.append(register["register_address"])

        logger.info(f"{len(msr_addr_list)} MSR address were found.")
        return msr_addr_list
    

    def get_bar_offset_list_from_bar_registers(self, bar_hw_reg):
        """
        Gets the BAR register's offsets.

        :param bar_hw_reg: List of BAR registers
        :return: List of BAR register's offsets
        """

        bar_addr_list = list()

        for register in bar_hw_reg:
                if register["register_type"] == "BAR":
                    bar_addr_list.append(register["bar_offset"])

        logger.info(f"{len(bar_addr_list)} BAR offset were found.")
        return bar_addr_list

    def get_bar_offset_list_from_mmr_registers(self, mmr_hw_reg):
        """
        Gets the MMR register's offsets.

        :param mmr_hw_reg: List of MMR registers
        :return: 3 lists (PWRMBASE & MCHBAR & SBREG) of MMR register's offsets
        """

        mmr_PWRMBASE_addr = list()
        mmr_MCHBAR_addr = list()
        mmr_SBREG_addr = list()
        for register in mmr_hw_reg:
            if register["register_type"] == "MMR":
                if register["bar_type"] == "PWRMBASE":
                    mmr_PWRMBASE_addr.append(register["bar_offset"])
                
                if register["bar_type"] == "MCHBAR":
                    mmr_MCHBAR_addr.append(register["bar_offset"])
                
                if register["bar_type"] == "SBREG":
                    mmr_SBREG_addr.append(register["bar_offset"])

        logger.info(f"{len(mmr_PWRMBASE_addr)} MMR PWRMBASE address were found.")
        logger.info(f"{len(mmr_MCHBAR_addr)} MMR MCHBAR address were found.")
        logger.info(f"{len(mmr_SBREG_addr)} MMR SBREG address were found.")

        return mmr_PWRMBASE_addr, mmr_MCHBAR_addr, mmr_SBREG_addr


    def get_size_list_from_mmr_registers(self, mmr_hw_reg):
        """
        Gets the MMR register's offsets.

        :param mmr_hw_reg: List of MMR registers
        :return: 3 lists (PWRMBASE & MCHBAR & SBREG) of MMR register's sizes
        """

        mmr_PWRMBASE_sizes = list()
        mmr_MCHBAR_sizes = list()
        mmr_SBREG_sizes = list()
        for register in mmr_hw_reg:
            if register["register_type"] == "MMR":
                if register["bar_type"] == "PWRMBASE":
                    mmr_PWRMBASE_sizes.append(register["register_size"])
                
                if register["bar_type"] == "MCHBAR":
                    mmr_MCHBAR_sizes.append(register["register_size"])
                
                if register["bar_type"] == "SBREG":
                    mmr_SBREG_sizes.append(register["register_size"])

        logger.info(f"{len(mmr_PWRMBASE_sizes)} MMR PWRMBASE register's sizes were found.")
        logger.info(f"{len(mmr_MCHBAR_sizes)} MMR MCHBAR register's sizes were found.")
        logger.info(f"{len(mmr_SBREG_sizes)} MMR SBREG register's sizes were found.")

        return mmr_PWRMBASE_sizes, mmr_MCHBAR_sizes, mmr_SBREG_sizes
    
    
    def get_exposed_files_paths(self, path_to_json):
        """
        Gathers all the possible paths dynamically, based on the hw_reg.json file.

        :param path_to_json: Path to hw_reg.json
        :return: Dictionary containing as keys: mm_pwrmbase (dict element), mmr_mchbar (dict element), mmr_sbreg (dict containing SBREG paths)
        """
        all_registers = self.get_all_registers(path_to_json)
        
        register_types_list = list()
        mmr_types_list = list()
        mmr_ports_list = list()
        bar_types_list = list()
        paths_dict = dict()
        sbreg_paths_dict = dict()
        bar_paths_dict = dict()
        for reg in all_registers:
            if reg["register_type"].lower() not in register_types_list:
                register_types_list.append(reg["register_type"].lower())
            
            if reg["register_type"] == "MMR" and reg["bar_type"].lower() not in mmr_types_list:
                mmr_types_list.append(reg["bar_type"].lower())
            
            if reg["register_type"] == "MMR" and reg["bar_type"] == "SBREG":
                if reg["bar_port"][2:].lower() not in mmr_ports_list:
                    mmr_ports_list.append(reg["bar_port"][2:].lower())
            
            if reg["register_type"] == "BAR" and reg["bar_type"].lower() not in bar_types_list:
                bar_types_list.append(reg["bar_type"].lower())
            
            for mmr_type in mmr_types_list:
                paths_dict[f"mmr_{mmr_type}"] = f"/dev/mmr/{mmr_type}"

            for port_type in mmr_ports_list:
                if mmr_type == "sbreg":
                    sbreg_paths_dict[f"{port_type}"] = f"/dev/mmr/{mmr_type}/{port_type}"
            paths_dict[f"mmr_sbreg"] = sbreg_paths_dict

            for bar_type in bar_types_list:
                    bar_paths_dict[f"{bar_type}"] = f"/dev/bar/{bar_type}"
            paths_dict[f"bar"] = bar_paths_dict
        
        return paths_dict


    def perform_operation_on_msr_registers(self, cpu_core_number, bytes_to_pread = None, op_type = "PREAD"):
        """
        Performs the following operation: OPEN -> READ/PREAD -> CLOSE for all the bar-type-specified MSR registers.

        :param cpu_core_number: Number of the cpu core ("0", "1", "2", "3")
        :param bytes_to_pread: Number of bytes to be read (int), defaults to None
        :param op_type: Type of operation to be performed (READ or PREAD), defaults to "PREAD"
        :return: 3 exit codes for the 3 performed operations: (exit_open: int, exit_pread: list of int, exit_close: int)
        """

        m_path_dict_to_mmr = {"0": "/dev/cpu/0/msr", 
                              "1": "/dev/cpu/1/msr", 
                              "2": "/dev/cpu/2/msr", 
                              "3": "/dev/cpu/3/msr"}
        
        m_exit_open = None
        m_list_exit_pread = list()
        m_exit_close = None
        
        m_msr_regs = self.get_registers_based_on_type("/opt/msr_reader/etc/hw_reg.json", "MSR")
        m_msr_addr_list = self.get_decimal_address_list_from_msr_registers(m_msr_regs)
        m_msr_size_list = self.get_decimal_size_list_from_msr_registers(m_msr_regs)
        
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> {op_type.upper()} -> CLOSE: started: cpu core {cpu_core_number}, bytes: {bytes_to_pread} ...
        ---------------------------------------------------------
                        """)
            
        logger.info(f"Opening {m_path_dict_to_mmr[cpu_core_number]} ...")
        m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_dict_to_mmr[cpu_core_number], RMOflag.RDONLY.value)
        
        m_msr_size_list = [bytes_to_pread for x in m_msr_size_list] if bytes_to_pread is not None else m_msr_size_list
        
        for addr_indx in range(len(m_msr_addr_list)):
            logger.info(f"Reading {m_msr_size_list[addr_indx]} bytes, from {m_path_dict_to_mmr[cpu_core_number]}, with address {m_msr_addr_list[addr_indx]} ...")
            
            if(op_type.upper() == "PREAD"):
                ret = self.proxy_app_manager.FUSA_comm.read_with_resource_manager_from_offset(m_msr_size_list[addr_indx], m_msr_addr_list[addr_indx])
            if(op_type.upper() == "READ"):
                ret = self.proxy_app_manager.FUSA_comm.read_with_resource_manager(m_msr_size_list[addr_indx])
            
            m_list_exit_pread.append(ret)
            
        m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
                    
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> {op_type.upper()} -> CLOSE: cpu core {cpu_core_number}, bytes to read {bytes_to_pread} 
        ended with the following flags:

        exit_open = {m_exit_open}
        exit_pread = {m_list_exit_pread}
        exit_close = {m_exit_close}
        ---------------------------------------------------------
                        """)
        return m_exit_open, m_list_exit_pread, m_exit_close
    

    def perform_operation_on_mmr_registers(self, bar_type, bytes_to_pread = None, sbreg_bar_port = None, op_type = "PREAD"):
        """
        Performs the following operation: OPEN -> READ/PREAD -> CLOSE for all the bar-type-specified MMR registers.

        :param bar_type: Bar type ("pwrmbase", "mchbar", "sbreg")
        :param bytes_to_pread: Number of bytes to be read (int), defaults to None [DISABLED]
        :param sbreg_bar_port: SBREG type to be used (Mandatory only when bar_type was specified as "sbreg"), defaults to None
        :param op_type: Type of operation to be performed (READ or PREAD), defaults to "PREAD"
        :return: 3 exit codes for the 3 performed operations: (exit_open: int, exit_pread: list of int, exit_close: int)
        """
        
        paths_dict = self.get_exposed_files_paths(self.MMR_JSON_PATH)
        m_path_to_mmr_pwrmbase = paths_dict["mmr_pwrmbase"]
        m_path_to_mmr_mchbar = paths_dict["mmr_mchbar"]
        m_path_dict_to_mmr_sbreg = paths_dict["mmr_sbreg"]
        
        m_exit_open = None
        m_list_exit_pread = list()
        m_exit_close = None
        
        m_mmr_regs = self.get_registers_based_on_type("/opt/mmr_reader/etc/hw_reg.json", "MMR")
        m_mmr_PWRMBASE_offsets, m_mmr_MCHBAR_offsets, m_mmr_SBREG_offsets = self.get_decimal_bar_offset_list_from_mmr_registers(m_mmr_regs)
        m_mmr_PWRMBASE_sizes, mmr_MCHBAR_sizes, m_mmr_SBREG_sizes = self.get_decimal_size_list_from_mmr_registers(m_mmr_regs)

        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> {op_type.upper()} -> CLOSE started: bar type: {bar_type}, bytes: {bytes_to_pread}, port: {sbreg_bar_port} ...
        ---------------------------------------------------------
                        """)
                    
        if (bar_type.upper() == "PWRMBASE"):
            m_mmr_PWRMBASE_sizes = [bytes_to_pread for x in m_mmr_PWRMBASE_sizes] if bytes_to_pread is not None else m_mmr_PWRMBASE_sizes
            
            logger.info(f"Opening {m_path_to_mmr_pwrmbase} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_to_mmr_pwrmbase, RMOflag.RDONLY.value)

            for offset_indx in range(len(m_mmr_PWRMBASE_offsets)):
                logger.info(f"Reading {m_mmr_PWRMBASE_sizes[offset_indx]} bytes, from {m_path_to_mmr_pwrmbase}, with offset {m_mmr_PWRMBASE_offsets[offset_indx]} ...")

                if (op_type.upper() == "PREAD"):
                    ret = self.proxy_app_manager.FUSA_comm.read_with_resource_manager_from_offset(m_mmr_PWRMBASE_sizes[offset_indx], m_mmr_PWRMBASE_offsets[offset_indx]) 
                if (op_type.upper() == "READ"):
                    ret = self.proxy_app_manager.FUSA_comm.read_with_resource_manager(m_mmr_PWRMBASE_sizes[offset_indx]) 
                
                m_list_exit_pread.append(ret)

            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        if (bar_type.upper() == "MCHBAR"): 
            mmr_MCHBAR_sizes = [bytes_to_pread for x in mmr_MCHBAR_sizes] if bytes_to_pread is not None else mmr_MCHBAR_sizes

            logger.info(f"Opening {m_path_to_mmr_mchbar} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_to_mmr_mchbar, RMOflag.RDONLY.value)

            for offset_indx in range(len(m_mmr_MCHBAR_offsets)):
                logger.info(f"Reading {mmr_MCHBAR_sizes[offset_indx]} bytes, from {m_path_to_mmr_mchbar}, with offset {m_mmr_MCHBAR_offsets[offset_indx]} ...")

                if (op_type.upper() == "PREAD"):
                    ret = self.proxy_app_manager.FUSA_comm.read_with_resource_manager_from_offset(mmr_MCHBAR_sizes[offset_indx], m_mmr_MCHBAR_offsets[offset_indx]) 
                if (op_type.upper() == "READ"):
                    ret = self.proxy_app_manager.FUSA_comm.read_with_resource_manager(mmr_MCHBAR_sizes[offset_indx])

                m_list_exit_pread.append(ret)
            
            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        if (bar_type.upper() == "SBREG"):
            mmr_SBREG_regs = {}

            for reg in m_mmr_regs:
                if reg["bar_type"] == "SBREG":
                    value = reg["bar_port"]
                    if value not in mmr_SBREG_regs:
                        mmr_SBREG_regs[value] = []

                    mmr_SBREG_regs[value].append(reg)

            l_sbreg_sizes = list()
            l_sbreg_offsets = list()
            l_sbreg_sizes = [bytes_to_pread for x in l_sbreg_sizes] if bytes_to_pread is not None else l_sbreg_sizes

            for sbreg_reg in mmr_SBREG_regs[sbreg_bar_port]: 
                l_sbreg_sizes.append(int(sbreg_reg["register_size"], 16))
                l_sbreg_offsets.append(int(sbreg_reg["bar_offset"], 16))

            logger.info(f"Opening {m_path_dict_to_mmr_sbreg[sbreg_bar_port[2:].lower()]} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_dict_to_mmr_sbreg[sbreg_bar_port[2:].lower()], RMOflag.RDONLY.value)
            logger.info(f"getting into the for loop after opening {m_path_dict_to_mmr_sbreg[sbreg_bar_port[2:].lower()]}")

            for offset_indx in range(len(l_sbreg_offsets)):
                logger.info(f"Reading {l_sbreg_sizes[offset_indx]} bytes, from {m_path_dict_to_mmr_sbreg[sbreg_bar_port[2:].lower()]}, with offset {l_sbreg_offsets[offset_indx]} ...")
                
                if (op_type.upper() == "PREAD"):
                    ret = self.proxy_app_manager.FUSA_comm.read_with_resource_manager_from_offset(l_sbreg_sizes[offset_indx], l_sbreg_offsets[offset_indx]) 
                if (op_type.upper() == "READ"):
                    ret = self.proxy_app_manager.FUSA_comm.read_with_resource_manager(l_sbreg_sizes[offset_indx]) 
                
                m_list_exit_pread.append(ret)
            
            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> {op_type.upper()} -> CLOSE: bar type: {bar_type}, bytes to read: {bytes_to_pread}, bar port: {sbreg_bar_port} 
        ended with the following flags:

        exit_open = {m_exit_open}
        exit_pread = {m_list_exit_pread}
        exit_close = {m_exit_close}
        ---------------------------------------------------------
                        """)
        return m_exit_open, m_list_exit_pread, m_exit_close


    def get_decimal_size_list_from_mmr_registers(self, mmr_hw_reg):
        """
        Gets the MMR register's offsets.

        :param mmr_hw_reg: List of MMR registers
        :return: 3 lists (PWRMBASE & MCHBAR & SBREG) of MMR register's sizes
        """

        mmr_PWRMBASE_sizes = list()
        mmr_MCHBAR_sizes = list()
        mmr_SBREG_sizes = list()
        for register in mmr_hw_reg:
            if register["register_type"] == "MMR":
                if register["bar_type"] == "PWRMBASE":
                    mmr_PWRMBASE_sizes.append(int(register["register_size"], 16))
                
                if register["bar_type"] == "MCHBAR":
                    mmr_MCHBAR_sizes.append(int(register["register_size"], 16))
                
                if register["bar_type"] == "SBREG":
                    mmr_SBREG_sizes.append(int(register["register_size"], 16))

        logger.info(f"{len(mmr_PWRMBASE_sizes)} MMR PWRMBASE register's sizes were found.")
        logger.info(f"{len(mmr_MCHBAR_sizes)} MMR MCHBAR register's sizes were found.")
        logger.info(f"{len(mmr_SBREG_sizes)} MMR SBREG register's sizes were found.")

        return mmr_PWRMBASE_sizes, mmr_MCHBAR_sizes, mmr_SBREG_sizes


    def get_decimal_bar_offset_list_from_mmr_registers(self, mmr_hw_reg):
        """
        Gets the MMR register's offsets.

        :param mmr_hw_reg: List of MMR registers
        :return: 3 lists (PWRMBASE & MCHBAR & SBREG) of MMR register's offsets
        """

        mmr_PWRMBASE_addr = list()
        mmr_MCHBAR_addr = list()
        mmr_SBREG_addr = list()
        for register in mmr_hw_reg:
            if register["register_type"] == "MMR":
                if register["bar_type"] == "PWRMBASE":
                    mmr_PWRMBASE_addr.append(int(register["bar_offset"], 16))
                
                if register["bar_type"] == "MCHBAR":
                    mmr_MCHBAR_addr.append(int(register["bar_offset"], 16))
                
                if register["bar_type"] == "SBREG":
                    mmr_SBREG_addr.append(int(register["bar_offset"], 16))

        logger.info(f"{len(mmr_PWRMBASE_addr)} MMR PWRMBASE address were found.")
        logger.info(f"{len(mmr_MCHBAR_addr)} MMR MCHBAR address were found.")
        logger.info(f"{len(mmr_SBREG_addr)} MMR SBREG address were found.")

        return mmr_PWRMBASE_addr, mmr_MCHBAR_addr, mmr_SBREG_addr


    def get_mmr_registers_by_bar_type(self, register_list):

        pwrmbase = list()
        mchbar = list()
        sberg = list()
        for register in register_list:
            if register["bar_type"] == "PWRMBASE":
                pwrmbase.append(register)

            if register["bar_type"] == "MCHBAR":
                mchbar.append(register)

            if register["bar_type"] == "SBREG":
                sberg.append(register)

        return pwrmbase, mchbar, sberg
    

    def get_node_index(self, hw_reg, key, value):
        """
        Gets the index of a register based on a unique key,value.

        :param hw_reg: List of registers
        :param key: Key related to the desired register
        :param value: Value related to the specified key
        :return: Index of the desired register inside that list
        """

        indx = hw_reg.index(next(filter(lambda n: n.get(key) == value, hw_reg)))
        return indx
    

    def delete_node_from_hw_reg_file(self, node_index, path_to_json):
        """
        Deletes a node (register) from the "hw_reg.json".

        :param node_index: Index of the register to be removed
        :param path_to_json: Path to the "hw_reg.json"
        :return: Boolean exit code indicating the success/failure of the operation
        """

        hw_register = self.json_manager.getInfoFromJsonFile(filePath = path_to_json, valuePath="*")

        del hw_register[node_index]

        exit_bool = self.json_manager.updateNodeIntoJsonFile(filePath= path_to_json, nodePath='$', value=hw_register)
        
        return exit_bool
    

    def delete_register_from_hw_reg_file(self, path_to_json, reg_type, reg_address, mmr_bar_type=None, mmr_sbreg_port=None):
        """
        Deletes a register based on the specified parameters.

        :param path_to_json: Path to the "hw_reg.json"
        :param reg_type: Type of the reigiter to be removed ("PWRMBASE", "MCHBAR", "SBREG")
        :param reg_address: Register address/offset of the register to be removed (Must be str)
        :param mmr_bar_type: Bar type of the register to be removed, defaults to None
        :param mmr_sbreg_port: Bar port of the SBREG register to be removed ("0x10", "0x12", "0xc2", "0xc5"), defaults to None
        :return: Boolean exit code indicating the success/failure of the operation
        """

        hw_registers = self.json_manager.getInfoFromJsonFile(filePath = path_to_json, valuePath="*")
        index = None

        if(reg_type == "MSR"):
            to_check = {"register_type": "MSR", "register_address": reg_address}

        if(reg_type == "MMR"):
            if(mmr_bar_type == "PWRMBASE" or "MCHBAR")  :
                to_check = {"register_type": "MMR", "bar_offset": reg_address, "bar_type": mmr_bar_type}
            
            if(mmr_bar_type == "SBREG")  :
                to_check = {"register_type": "MMR", "bar_offset": reg_address, "bar_type": mmr_bar_type, "bar_port": mmr_sbreg_port}
        
        for i, d in enumerate(hw_registers):
            if all(key in d and d[key] == to_check[key] for key in to_check):
                index = i
                break
            
        deleted_reg = hw_registers[index]
        del hw_registers[index]
        
        exit_bool_python = deleted_reg not in hw_registers
        exit_bool_json = self.json_manager.updateNodeIntoJsonFile(filePath= path_to_json, nodePath='$', value=hw_registers)
        exit_bool = exit_bool_python and exit_bool_json
        
        return exit_bool
        
    
    def update_msr_register_address(self, new_addr, node_index, path_to_json = "/opt/msr_reader/etc/hw_reg.json"):
        """
        Updates MSR register's address.

        :param new_addr: New address to be written
        :param node_index: Index of the register to be updated
        :param path_to_json: Path to the "hw_reg.json", defaults to "/opt/msr_reader/etc/hw_reg.json"
        :return: Boolean exit code indicating the success/failure of the operation
        """

        hw_register = self.json_manager.getInfoFromJsonFile(filePath=path_to_json, valuePath="*")

        hw_register[node_index]["register_address"] = new_addr

        exit_bool = self.json_manager.updateNodeIntoJsonFile(filePath= path_to_json, nodePath='$', value=hw_register)
        
        return exit_bool

    
    def update_bar_offset(self, new_bar_offset, node_index, path_to_json = "/opt/mmr_reader/etc/hw_reg.json"):
        """
        Updates offset for MMR or BAR registers.

        :param new_bar_offset: New offset to be written
        :param node_index: Index of the register to be updated
        :param path_to_json: Path to the "hw_reg.json", defaults to "/opt/mmr_reader/etc/hw_reg.json"
        :return: Boolean exit code indicating the success/failure of the operation
        """

        hw_reg = self.json_manager.getInfoFromJsonFile(filePath = path_to_json, valuePath="*")

        hw_reg[node_index]["bar_offset"] = new_bar_offset
        
        exit_bool = self.json_manager.updateNodeIntoJsonFile(filePath= path_to_json, nodePath='$', value=hw_reg)
        
        return exit_bool

    def update_register_size(self, new_size_hex, node_index, path_to_json):
        """
        Updates register's size.

        :param new_size_hex: New size to be written
        :param node_index: Index of the register to be updated
        :param path_to_json: Path to the "hw_reg.json"
        :return: Boolean exit code indicating the success/failure of the operation
        """
        hw_reg = self.json_manager.getInfoFromJsonFile(filePath=path_to_json, valuePath="*")

        hw_reg[node_index]["register_size"] = new_size_hex
        
        exit_bool = self.json_manager.updateNodeIntoJsonFile(filePath= path_to_json, nodePath='$', value=hw_reg)
        
        return exit_bool

    def get_mmr_bar_info(self, hw_reg_dict):
        register_type = hw_reg_dict["register_type"]
        register_offset = hw_reg_dict["bar_offset"]
        register_offset_int = int(hw_reg_dict["bar_offset"], 16)
        register_size = hw_reg_dict["register_size"]
        register_size_int = int(hw_reg_dict["register_size"], 16)
        bar_type = hw_reg_dict["bar_type"]
        file_path = f"/dev/{register_type.lower()}/{bar_type.lower()}"
        bar_port = None
        if bar_type == "SBREG":
            bar_port = hw_reg_dict["bar_port"]
            file_path = f"{file_path}/{bar_port.replace('0x', '').lower()}"

        logger.info(f"register offset = {register_offset}\nregister size = {register_size}\nbar type = {bar_type}\nfile path = {file_path}")

        return file_path, register_offset, register_offset_int, register_size, register_size_int, bar_type, bar_port


    def get_all_mmr_info(self, path_to_json):
        """
        Gathers all the informations related to all MMR registers.

        :param path_to_json: Path to the MMR hw_reg.json
        :return: returns 7 lists (file_path, register_offset, register_offset_int, register_size, register_size_int, bar_type, bar_port)
        """
        mmr_hw_reg = self.get_registers_based_on_type(path_to_json, "MMR")
        register_offset = list()
        register_offset_int = list()
        register_size = list()
        register_size_int = list()
        bar_type = list()
        file_path = list()
        bar_port = list()
        sbreg_indx = 0
        for indx in range(len(mmr_hw_reg)):
            register_offset.append(mmr_hw_reg[indx]["bar_offset"])
            register_offset_int.append(int(mmr_hw_reg[indx]["bar_offset"], 16))
            
            register_size.append(mmr_hw_reg[indx]["register_size"])
            register_size_int.append(int(mmr_hw_reg[indx]["register_size"], 16))
            bar_type.append(mmr_hw_reg[indx]["bar_type"])
            
            file_path.append(f"/dev/mmr/{bar_type[indx].lower()}")
            
            if bar_type[indx] == "SBREG":
                bar_port.append(mmr_hw_reg[indx]["bar_port"])
                file_path.append(f"/dev/mmr/{bar_type[indx].lower()}/{bar_port[sbreg_indx][2:].lower()}")
                sbreg_indx+=1
        file_path = [x for x in file_path if x != "/dev/mmr/sbreg"]
        
        logger.info(f"register offset = {register_offset}\n----------\nregister size = {register_size}\n----------\nbar type = {bar_type}\n----------\nfile path = {file_path}")
        logger.info(f"\n----------\nregister offset length = {len(register_offset)}\nregister size length = {len(register_size)}\nbar type length = {len(bar_type)}\nfile path length = {len(file_path)}")

        return file_path, register_offset, register_offset_int, register_size, register_size_int, bar_type, bar_port



    def pwrite_all_msr_registers_and_check_if_not_allowed(self, register_addresses, msr_file_path):
        results = {}
        logger.info(f"open exposed file {msr_file_path}")
        result = self.proxy_app_manager.FUSA_comm.open_resource_manager(path=msr_file_path, oflag=RMOflag.RDWR.value)
        if result != linuxExitCode.SUCCESS.value:
            logger.error(f"ProxyApp ExitCode is FAILED after Operation open exposed  {msr_file_path}")
            return False

        for address in register_addresses:
            results[address] = {"write_exist_code": -1, "errno": -1}
            result = self.proxy_app_manager.FUSA_comm.write_with_resource_manager_from_offset("ff", bytes_number=8, offset=int(address, 16))
            results[address]["write_exist_code"] = result
            rm_error = self.proxy_app_manager.FUSA_comm.rm_error
            results[address]["errno"] = rm_error

        check_results = True

        for address in results:
            if results[address]["write_exist_code"] != linuxExitCode.FAILED.value:
                check_results = False
                logger.error(f"Write opereation did not fail for address {address}")
            if results[address]["errno"] != RMSystemError.ENOSYS.value:
                check_results = False
                logger.error(f"errno for Write opereation is not correct for address {address}")

        logger.debug(f"{json.dumps(results, indent=4)}")

        result = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        logger.info(f"close exposed file {msr_file_path}")
        if result != linuxExitCode.SUCCESS.value:
            logger.error(f"ProxyApp ExitCode is FAILED after Operation close exposed  {msr_file_path}")
            return False

        return check_results

    def write_all_msr_registers_and_check_if_not_allowed(self, register_addresses, msr_file_path):
        results = {}
        logger.info(f"open exposed file {msr_file_path}")
        result = self.proxy_app_manager.FUSA_comm.open_resource_manager(path=msr_file_path, oflag=RMOflag.RDWR.value)
        if result != linuxExitCode.SUCCESS.value:
            logger.error(f"ProxyApp ExitCode is FAILED after Operation open exposed  {msr_file_path}")
            return False

        for address in register_addresses:
            results[address] = {"lseek_exit_code": -1, "write_exist_code": -1, "errno": -1}
            result = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(int(address, 16), whence=RMWhence.SEEK_SET.value)
            results[address]["lseek_exit_code"] = result
            if result != linuxExitCode.SUCCESS.value:
                continue
            result = self.proxy_app_manager.FUSA_comm.write_with_resource_manager("ff", bytes_number=8)
            results[address]["write_exist_code"] = result
            rm_error = self.proxy_app_manager.FUSA_comm.rm_error
            results[address]["errno"] = rm_error

        check_results = True

        for address in results:
            if results[address]["lseek_exit_code"] != linuxExitCode.SUCCESS.value:
                check_results = False
                logger.error(f"lseek failed for address {address}")
            if results[address]["write_exist_code"] != linuxExitCode.FAILED.value:
                check_results = False
                logger.error(f"Write opereation did not fail for address {address}")
            if results[address]["errno"] != RMSystemError.ENOSYS.value:
                check_results = False
                logger.error(f"errno for Write opereation is not correct for address {address}")

        logger.debug(f"{json.dumps(results, indent=4)}")

        result = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        logger.info(f"close exposed file {msr_file_path}")
        if result != linuxExitCode.SUCCESS.value:
            logger.error(f"ProxyApp ExitCode is FAILED after Operation close exposed  {msr_file_path}")
            return False

        return check_results

    def perform_lseek_set_offset_on_msr_registers(self, cpu_core_number, decimal_offset=None):
        """
        Performs the following operation: OPEN -> LSEEK -> CLOSE for all the bar-type-specified MSR registers.
        :param cpu_core_number: Number of the cpu core ("0", "1", "2", "3")
        :param decimal_offset: decimal offset of registers to be lseek (int), defaults to None
        :return: 3 exit codes for the 3 performed operations: (exit_open: int, exit_lseek: list of int, exit_close: int)
        """

        m_path_dict_to_mmr = {"0": "/dev/cpu/0/msr", 
                              "1": "/dev/cpu/1/msr", 
                              "2": "/dev/cpu/2/msr", 
                              "3": "/dev/cpu/3/msr"}
        
        m_exit_open = None
        m_list_exit_lseek = list()
        m_lseek_error_codes = []
        m_exit_close = None
        
        m_msr_regs = self.get_registers_based_on_type("/opt/msr_reader/etc/hw_reg.json", "MSR")
        m_msr_addr_list = self.get_decimal_address_list_from_msr_registers(m_msr_regs)
        
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: started: cpu core {cpu_core_number}, offset: {decimal_offset} ...
        ---------------------------------------------------------
                        """)
            
        logger.info(f"Opening {m_path_dict_to_mmr[cpu_core_number]} ...")
        m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_dict_to_mmr[cpu_core_number], RMOflag.RDWR.value)
        
        m_msr_addr_list = [decimal_offset for x in m_msr_addr_list] if decimal_offset is not None else m_msr_addr_list
        
        for addr_indx in range(len(m_msr_addr_list)):
            logger.info(f"lseaking {m_msr_addr_list[addr_indx]}, from {m_path_dict_to_mmr[cpu_core_number]} ...")
            
            ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(m_msr_addr_list[addr_indx], RMWhence.SEEK_SET.value)
            m_list_exit_lseek.append(ret)
            
            output = self.proxy_app_manager.FUSA_comm.rm_error
            logger.info("System error received from proxApp response is: {0}".format(output))
            self.expectTrue(output == RMSystemError.EINVAL.value, Severity.MAJOR,f'Checking that an error was raised while lseeking address: {decimal_offset}')
            m_lseek_error_codes.append(output)
            
        m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
                    
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: cpu core {cpu_core_number}, offset {decimal_offset} 
        ended with the following flags:
        exit_open = {m_exit_open}
        exit_lseek = {m_list_exit_lseek}
        exit_lseek_error = {m_lseek_error_codes}
        exit_close = {m_exit_close}
        ---------------------------------------------------------
                        """)
        return m_exit_open, m_list_exit_lseek, m_exit_close, m_lseek_error_codes



    
    def perform_lseek_on_msr_registers(self, cpu_core_number,decimal_offset=None):
        """
        Performs the following operation: OPEN -> READ/PREAD -> CLOSE for all the bar-type-specified MSR registers.
        :param cpu_core_number: Number of the cpu core ("0", "1", "2", "3")
        :param bytes_to_pread: Number of bytes to be read (int), defaults to None
        :param op_type: Type of operation to be performed (READ or PREAD), defaults to "PREAD"
        :return: 3 exit codes for the 3 performed operations: (exit_open: int, exit_pread: list of int, exit_close: int)
        """

        m_path_dict_to_mmr = {"0": "/dev/cpu/0/msr", 
                              "1": "/dev/cpu/1/msr", 
                              "2": "/dev/cpu/2/msr", 
                              "3": "/dev/cpu/3/msr"}
        
        m_exit_open = None
        m_list_exit_lseek = list()
        m_exit_close = None
        
        m_msr_regs = self.get_registers_based_on_type("/opt/msr_reader/etc/hw_reg.json", "MSR")
        m_msr_addr_list = self.get_decimal_address_list_from_msr_registers(m_msr_regs)
        
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: started: cpu core {cpu_core_number}, offset: {decimal_offset} ...
        ---------------------------------------------------------
                        """)
            
        logger.info(f"Opening {m_path_dict_to_mmr[cpu_core_number]} ...")
        m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_dict_to_mmr[cpu_core_number], RMOflag.RDONLY.value)
        
        m_msr_addr_list = [decimal_offset for x in m_msr_addr_list] if decimal_offset is not None else m_msr_addr_list
        
        for addr_indx in range(len(m_msr_addr_list)):
            logger.info(f"lseaking {m_msr_addr_list[addr_indx]} bytes, from {m_path_dict_to_mmr[cpu_core_number]} ...")
            
            ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(m_msr_addr_list[addr_indx], RMWhence.SEEK_SET.value)
                
            m_list_exit_lseek.append(ret)
            
        m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
                    
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: cpu core {cpu_core_number}, offset {decimal_offset} 
        ended with the following flags:
        exit_open = {m_exit_open}
        exit_lseek = {m_list_exit_lseek}
        exit_close = {m_exit_close}
        ---------------------------------------------------------
                        """)
        return m_exit_open, m_list_exit_lseek, m_exit_close
    

    def perform_lseek_on_mmr_registers(self, bar_type, sbreg_bar_port = None, offset = None):
        """
        Performs the following operation: OPEN -> LSEEK -> CLOSE for all the bar-type-specified MMR registers.
        :param bar_type: Bar type ("pwrmbase", "mchbar", "sbreg")
        :param sbreg_bar_port: SBREG type to be used (Mandatory only when bar_type was specified as "sbreg"), defaults to None
        :param offset: The offset that would be seeked
        :return: 3 exit codes for the 3 performed operations: (exit_open: int, exit_lseek: list of int, exit_close: int)
        """

        paths_dict = self.get_exposed_files_paths(self.MMR_JSON_PATH)
        m_path_to_mmr_pwrmbase = paths_dict["mmr_pwrmbase"]
        m_path_to_mmr_mchbar = paths_dict["mmr_mchbar"]
        m_path_dict_to_mmr_sbreg = paths_dict["mmr_sbreg"]

        m_exit_open = None
        m_list_exit_lseek = list()
        m_exit_close = None
        
        m_mmr_regs = self.get_registers_based_on_type("/opt/mmr_reader/etc/hw_reg.json", "MMR")
        m_mmr_PWRMBASE_offsets, m_mmr_MCHBAR_offsets, m_mmr_SBREG_offsets = self.get_decimal_bar_offset_list_from_mmr_registers(m_mmr_regs)
        m_mmr_PWRMBASE_sizes, mmr_MCHBAR_sizes, m_mmr_SBREG_sizes = self.get_decimal_size_list_from_mmr_registers(m_mmr_regs)

        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE started: bar type: {bar_type}, port: {sbreg_bar_port}, offset: {offset} ...
        ---------------------------------------------------------
                        """)
                    
        if (bar_type.upper() == "PWRMBASE"):
            m_mmr_PWRMBASE_offsets = [offset for x in m_mmr_PWRMBASE_offsets] if offset is not None else m_mmr_PWRMBASE_offsets
            
            logger.info(f"Opening {m_path_to_mmr_pwrmbase} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_to_mmr_pwrmbase, RMOflag.RDONLY.value)

            for offset_indx in range(len(m_mmr_PWRMBASE_offsets)):
                logger.info(f"Lseaking offset {m_mmr_PWRMBASE_offsets[offset_indx]} ...")

                ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(m_mmr_PWRMBASE_offsets[offset_indx], RMWhence.SEEK_SET.value) 

                m_list_exit_lseek.append(ret)

            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        if (bar_type.upper() == "MCHBAR"): 
            m_mmr_MCHBAR_offsets = [offset for x in m_mmr_MCHBAR_offsets] if offset is not None else m_mmr_MCHBAR_offsets

            logger.info(f"Opening {m_path_to_mmr_mchbar} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_to_mmr_mchbar, RMOflag.RDONLY.value)

            for offset_indx in range(len(m_mmr_MCHBAR_offsets)):
                logger.info(f"Lseaking offset {m_mmr_MCHBAR_offsets[offset_indx]} ...")

                ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(m_mmr_MCHBAR_offsets[offset_indx], RMWhence.SEEK_SET.value) 

                m_list_exit_lseek.append(ret)
            
            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        if (bar_type.upper() == "SBREG"):
            mmr_SBREG_10 = list()
            mmr_SBREG_12 = list()
            mmr_SBREG_c2 = list()
            mmr_SBREG_c5 = list()
            mmr_SBREG_regs = {"10": mmr_SBREG_10,
                              "12": mmr_SBREG_12,
                              "c2": mmr_SBREG_c2,
                              "c5": mmr_SBREG_c5}

            for mmr_reg in m_mmr_regs:
                if(mmr_reg["bar_type"] == "SBREG"):
                    if (mmr_reg["bar_port"] == "0x10"):
                        mmr_SBREG_10.append(mmr_reg)
                    if (mmr_reg["bar_port"] == "0x12"):
                        mmr_SBREG_12.append(mmr_reg)
                    if (mmr_reg["bar_port"] == "0xC2"):
                        mmr_SBREG_c2.append(mmr_reg)
                    if (mmr_reg["bar_port"] == "0xC5"):
                        mmr_SBREG_c5.append(mmr_reg)

            l_sbreg_sizes = list()
            l_sbreg_offsets = list()

            for sbreg_reg in mmr_SBREG_regs[sbreg_bar_port]: 
                l_sbreg_sizes.append(int(sbreg_reg["register_size"], 16))
                l_sbreg_offsets.append(int(sbreg_reg["bar_offset"], 16))
            
            l_sbreg_offsets = [offset for x in l_sbreg_offsets] if offset is not None else l_sbreg_offsets

            logger.info(f"Opening {m_path_dict_to_mmr_sbreg[sbreg_bar_port]} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_dict_to_mmr_sbreg[sbreg_bar_port], RMOflag.RDONLY.value)

            for offset_indx in range(len(l_sbreg_offsets)):
                logger.info(f"Lseaking offset {l_sbreg_offsets[offset_indx]} ...")
                
                ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(l_sbreg_offsets[offset_indx], RMWhence.SEEK_SET.value) 

                m_list_exit_lseek.append(ret)
            
            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: bar type: {bar_type}, bar port: {sbreg_bar_port}, offset {offset}
        ended with the following flags:
        exit_open = {m_exit_open}
        exit_pread = {m_list_exit_lseek}
        exit_close = {m_exit_close}
        ---------------------------------------------------------
                        """)
        return m_exit_open, m_list_exit_lseek, m_exit_close


    def perform_lseek_set_offset_on_msr_registers(self, cpu_core_number, decimal_offset=None):
        """
        Performs the following operation: OPEN -> LSEEK -> CLOSE for all the bar-type-specified MSR registers.
        :param cpu_core_number: Number of the cpu core ("0", "1", "2", "3")
        :param decimal_offset: decimal offset of registers to be lseek (int), defaults to None
        :return: 3 exit codes for the 3 performed operations: (exit_open: int, exit_lseek: list of int, exit_close: int)
        """

        m_path_dict_to_mmr = {"0": "/dev/cpu/0/msr", 
                              "1": "/dev/cpu/1/msr", 
                              "2": "/dev/cpu/2/msr", 
                              "3": "/dev/cpu/3/msr"}
        
        m_exit_open = None
        m_list_exit_lseek = list()
        m_lseek_error_codes = []
        m_exit_close = None
        
        m_msr_regs = self.get_registers_based_on_type("/opt/msr_reader/etc/hw_reg.json", "MSR")
        m_msr_addr_list = self.get_decimal_address_list_from_msr_registers(m_msr_regs)
        
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: started: cpu core {cpu_core_number}, offset: {decimal_offset} ...
        ---------------------------------------------------------
                        """)
            
        logger.info(f"Opening {m_path_dict_to_mmr[cpu_core_number]} ...")
        m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_dict_to_mmr[cpu_core_number], RMOflag.RDWR.value)
        
        m_msr_addr_list = [decimal_offset for x in m_msr_addr_list] if decimal_offset is not None else m_msr_addr_list
        
        for addr_indx in range(len(m_msr_addr_list)):
            logger.info(f"lseaking {m_msr_addr_list[addr_indx]}, from {m_path_dict_to_mmr[cpu_core_number]} ...")
            
            ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(m_msr_addr_list[addr_indx], RMWhence.SEEK_SET.value)
            m_list_exit_lseek.append(ret)
            
            output = self.proxy_app_manager.FUSA_comm.rm_error
            logger.info("System error received from proxApp response is: {0}".format(output))
            self.expectTrue(output == RMSystemError.EINVAL.value, Severity.MAJOR,f'Checking that an error was raised while lseeking address: {decimal_offset}')
            m_lseek_error_codes.append(output)
            
        m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
                    
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: cpu core {cpu_core_number}, offset {decimal_offset} 
        ended with the following flags:
        exit_open = {m_exit_open}
        exit_lseek = {m_list_exit_lseek}
        exit_lseek_error = {m_lseek_error_codes}
        exit_close = {m_exit_close}
        ---------------------------------------------------------
                        """)
        return m_exit_open, m_list_exit_lseek, m_exit_close, m_lseek_error_codes



    
    def perform_lseek_on_msr_registers(self, cpu_core_number,decimal_offset=None):
        """
        Performs the following operation: OPEN -> READ/PREAD -> CLOSE for all the bar-type-specified MSR registers.
        :param cpu_core_number: Number of the cpu core ("0", "1", "2", "3")
        :param bytes_to_pread: Number of bytes to be read (int), defaults to None
        :param op_type: Type of operation to be performed (READ or PREAD), defaults to "PREAD"
        :return: 3 exit codes for the 3 performed operations: (exit_open: int, exit_pread: list of int, exit_close: int)
        """

        m_path_dict_to_mmr = {"0": "/dev/cpu/0/msr", 
                              "1": "/dev/cpu/1/msr", 
                              "2": "/dev/cpu/2/msr", 
                              "3": "/dev/cpu/3/msr"}
        
        m_exit_open = None
        m_list_exit_lseek = list()
        m_exit_close = None
        
        m_msr_regs = self.get_registers_based_on_type("/opt/msr_reader/etc/hw_reg.json", "MSR")
        m_msr_addr_list = self.get_decimal_address_list_from_msr_registers(m_msr_regs)
        
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: started: cpu core {cpu_core_number}, offset: {decimal_offset} ...
        ---------------------------------------------------------
                        """)
            
        logger.info(f"Opening {m_path_dict_to_mmr[cpu_core_number]} ...")
        m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_dict_to_mmr[cpu_core_number], RMOflag.RDONLY.value)
        
        m_msr_addr_list = [decimal_offset for x in m_msr_addr_list] if decimal_offset is not None else m_msr_addr_list
        
        for addr_indx in range(len(m_msr_addr_list)):
            logger.info(f"lseaking {m_msr_addr_list[addr_indx]} bytes, from {m_path_dict_to_mmr[cpu_core_number]} ...")
            
            ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(m_msr_addr_list[addr_indx], RMWhence.SEEK_SET.value)
                
            m_list_exit_lseek.append(ret)
            
        m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
                    
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: cpu core {cpu_core_number}, offset {decimal_offset} 
        ended with the following flags:
        exit_open = {m_exit_open}
        exit_lseek = {m_list_exit_lseek}
        exit_close = {m_exit_close}
        ---------------------------------------------------------
                        """)
        return m_exit_open, m_list_exit_lseek, m_exit_close
    

    def perform_lseek_on_mmr_registers(self, bar_type, sbreg_bar_port = None, offset = None):
        """
        Performs the following operation: OPEN -> LSEEK -> CLOSE for all the bar-type-specified MMR registers.
        :param bar_type: Bar type ("pwrmbase", "mchbar", "sbreg")
        :param sbreg_bar_port: SBREG type to be used (Mandatory only when bar_type was specified as "sbreg"), defaults to None
        :param offset: The offset that would be seeked
        :return: 3 exit codes for the 3 performed operations: (exit_open: int, exit_lseek: list of int, exit_close: int)
        """

        paths_dict = self.get_exposed_files_paths(self.MMR_JSON_PATH)
        m_path_to_mmr_pwrmbase = paths_dict["mmr_pwrmbase"]
        m_path_to_mmr_mchbar = paths_dict["mmr_mchbar"]
        m_path_dict_to_mmr_sbreg = paths_dict["mmr_sbreg"]

        m_exit_open = None
        m_list_exit_lseek = list()
        m_exit_close = None
        
        m_mmr_regs = self.get_registers_based_on_type("/opt/mmr_reader/etc/hw_reg.json", "MMR")
        m_mmr_PWRMBASE_offsets, m_mmr_MCHBAR_offsets, m_mmr_SBREG_offsets = self.get_decimal_bar_offset_list_from_mmr_registers(m_mmr_regs)
        m_mmr_PWRMBASE_sizes, mmr_MCHBAR_sizes, m_mmr_SBREG_sizes = self.get_decimal_size_list_from_mmr_registers(m_mmr_regs)

        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE started: bar type: {bar_type}, port: {sbreg_bar_port}, offset: {offset} ...
        ---------------------------------------------------------
                        """)
                    
        if (bar_type.upper() == "PWRMBASE"):
            m_mmr_PWRMBASE_offsets = [offset for x in m_mmr_PWRMBASE_offsets] if offset is not None else m_mmr_PWRMBASE_offsets
            
            logger.info(f"Opening {m_path_to_mmr_pwrmbase} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_to_mmr_pwrmbase, RMOflag.RDONLY.value)

            for offset_indx in range(len(m_mmr_PWRMBASE_offsets)):
                logger.info(f"Lseaking offset {m_mmr_PWRMBASE_offsets[offset_indx]} ...")

                ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(m_mmr_PWRMBASE_offsets[offset_indx], RMWhence.SEEK_SET.value) 

                m_list_exit_lseek.append(ret)

            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        if (bar_type.upper() == "MCHBAR"): 
            m_mmr_MCHBAR_offsets = [offset for x in m_mmr_MCHBAR_offsets] if offset is not None else m_mmr_MCHBAR_offsets

            logger.info(f"Opening {m_path_to_mmr_mchbar} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_to_mmr_mchbar, RMOflag.RDONLY.value)

            for offset_indx in range(len(m_mmr_MCHBAR_offsets)):
                logger.info(f"Lseaking offset {m_mmr_MCHBAR_offsets[offset_indx]} ...")

                ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(m_mmr_MCHBAR_offsets[offset_indx], RMWhence.SEEK_SET.value) 

                m_list_exit_lseek.append(ret)
            
            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        if (bar_type.upper() == "SBREG"):
            mmr_SBREG_10 = list()
            mmr_SBREG_12 = list()
            mmr_SBREG_c2 = list()
            mmr_SBREG_c5 = list()
            mmr_SBREG_regs = {"10": mmr_SBREG_10,
                              "12": mmr_SBREG_12,
                              "c2": mmr_SBREG_c2,
                              "c5": mmr_SBREG_c5}

            for mmr_reg in m_mmr_regs:
                if(mmr_reg["bar_type"] == "SBREG"):
                    if (mmr_reg["bar_port"] == "0x10"):
                        mmr_SBREG_10.append(mmr_reg)
                    if (mmr_reg["bar_port"] == "0x12"):
                        mmr_SBREG_12.append(mmr_reg)
                    if (mmr_reg["bar_port"] == "0xC2"):
                        mmr_SBREG_c2.append(mmr_reg)
                    if (mmr_reg["bar_port"] == "0xC5"):
                        mmr_SBREG_c5.append(mmr_reg)

            l_sbreg_sizes = list()
            l_sbreg_offsets = list()

            for sbreg_reg in mmr_SBREG_regs[sbreg_bar_port]: 
                l_sbreg_sizes.append(int(sbreg_reg["register_size"], 16))
                l_sbreg_offsets.append(int(sbreg_reg["bar_offset"], 16))
            
            l_sbreg_offsets = [offset for x in l_sbreg_offsets] if offset is not None else l_sbreg_offsets

            logger.info(f"Opening {m_path_dict_to_mmr_sbreg[sbreg_bar_port]} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_dict_to_mmr_sbreg[sbreg_bar_port], RMOflag.RDONLY.value)

            for offset_indx in range(len(l_sbreg_offsets)):
                logger.info(f"Lseaking offset {l_sbreg_offsets[offset_indx]} ...")
                
                ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(l_sbreg_offsets[offset_indx], RMWhence.SEEK_SET.value) 

                m_list_exit_lseek.append(ret)
            
            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: bar type: {bar_type}, bar port: {sbreg_bar_port}, offset {offset}
        ended with the following flags:
        exit_open = {m_exit_open}
        exit_pread = {m_list_exit_lseek}
        exit_close = {m_exit_close}
        ---------------------------------------------------------
                        """)
        return m_exit_open, m_list_exit_lseek, m_exit_close

    def perform_lseek_set_offset_on_mmr_registers(self, bar_type, sbreg_bar_port = None, decimal_offset = None):
        """
        Performs the following operation: OPEN -> LSEEK -> CLOSE for all the bar-type-specified MMR registers.
        :param bar_type: Bar type ("pwrmbase", "mchbar", "sbreg")
        :param sbreg_bar_port: SBREG type to be used (Mandatory only when bar_type was specified as "sbreg"), defaults to None
        :param decimal_offset: The offset that would be seeked
        :return: 3 exit codes for the 3 performed operations: (exit_open: int, exit_lseek: list of int, exit_close: int)
        """

        paths_dict = self.get_exposed_files_paths(self.MMR_JSON_PATH)
        m_path_to_mmr_pwrmbase = paths_dict["mmr_pwrmbase"]
        m_path_to_mmr_mchbar = paths_dict["mmr_mchbar"]
        m_path_dict_to_mmr_sbreg = paths_dict["mmr_sbreg"]


        m_exit_open = None
        m_list_exit_lseek = list()
        m_lseek_error_codes = []
        m_exit_close = None
        
        m_mmr_regs = self.get_registers_based_on_type("/opt/mmr_reader/etc/hw_reg.json", "MMR")
        m_mmr_PWRMBASE_offsets, m_mmr_MCHBAR_offsets, m_mmr_SBREG_offsets = self.get_decimal_bar_offset_list_from_mmr_registers(m_mmr_regs)
        m_mmr_PWRMBASE_sizes, mmr_MCHBAR_sizes, m_mmr_SBREG_sizes = self.get_decimal_size_list_from_mmr_registers(m_mmr_regs)

        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE started: bar type: {bar_type}, port: {sbreg_bar_port}, offset: {decimal_offset} ...
        ---------------------------------------------------------
                        """)
                    
        if (bar_type.upper() == "PWRMBASE"):
            m_mmr_PWRMBASE_offsets = [decimal_offset for x in m_mmr_PWRMBASE_offsets] if decimal_offset is not None else m_mmr_PWRMBASE_offsets
            
            logger.info(f"Opening {m_path_to_mmr_pwrmbase} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_to_mmr_pwrmbase, RMOflag.RDONLY.value)

            for offset_indx in range(len(m_mmr_PWRMBASE_offsets)):
                logger.info(f"Lseaking offset {m_mmr_PWRMBASE_offsets[offset_indx]} ...")

                ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(m_mmr_PWRMBASE_offsets[offset_indx], RMWhence.SEEK_SET.value) 
                m_list_exit_lseek.append(ret)

                output = self.proxy_app_manager.FUSA_comm.rm_error
                logger.info("System error received from proxApp response is: {0}".format(output))
                self.expectTrue(output == RMSystemError.EINVAL.value, Severity.MAJOR,f'Checking that an error was raised while lseeking address: {decimal_offset}')
                m_lseek_error_codes.append(output)


            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        if (bar_type.upper() == "MCHBAR"): 
            m_mmr_MCHBAR_offsets = [decimal_offset for x in m_mmr_MCHBAR_offsets] if decimal_offset is not None else m_mmr_MCHBAR_offsets

            logger.info(f"Opening {m_path_to_mmr_mchbar} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_to_mmr_mchbar, RMOflag.RDONLY.value)

            for offset_indx in range(len(m_mmr_MCHBAR_offsets)):
                logger.info(f"Lseaking offset {m_mmr_MCHBAR_offsets[offset_indx]} ...")

                ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(m_mmr_MCHBAR_offsets[offset_indx], RMWhence.SEEK_SET.value) 
                m_list_exit_lseek.append(ret)
                output = self.proxy_app_manager.FUSA_comm.rm_error
                logger.info("System error received from proxApp response is: {0}".format(output))
                self.expectTrue(output == RMSystemError.EINVAL.value, Severity.MAJOR,f'Checking that an error was raised while lseeking address: {decimal_offset}')
                m_lseek_error_codes.append(output)
            
            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        if (bar_type.upper() == "SBREG"):
            mmr_SBREG_10 = list()
            mmr_SBREG_12 = list()
            mmr_SBREG_c2 = list()
            mmr_SBREG_c5 = list()
            mmr_SBREG_regs = {"10": mmr_SBREG_10,
                              "12": mmr_SBREG_12,
                              "c2": mmr_SBREG_c2,
                              "c5": mmr_SBREG_c5}

            for mmr_reg in m_mmr_regs:
                if(mmr_reg["bar_type"] == "SBREG"):
                    if (mmr_reg["bar_port"] == "0x10"):
                        mmr_SBREG_10.append(mmr_reg)
                    if (mmr_reg["bar_port"] == "0x12"):
                        mmr_SBREG_12.append(mmr_reg)
                    if (mmr_reg["bar_port"] == "0xC2"):
                        mmr_SBREG_c2.append(mmr_reg)
                    if (mmr_reg["bar_port"] == "0xC5"):
                        mmr_SBREG_c5.append(mmr_reg)

            l_sbreg_sizes = list()
            l_sbreg_offsets = list()

            for sbreg_reg in mmr_SBREG_regs[sbreg_bar_port]: 
                l_sbreg_sizes.append(int(sbreg_reg["register_size"], 16))
                l_sbreg_offsets.append(int(sbreg_reg["bar_offset"], 16))
            
            l_sbreg_offsets = [decimal_offset for x in l_sbreg_offsets] if decimal_offset is not None else l_sbreg_offsets

            logger.info(f"Opening {m_path_dict_to_mmr_sbreg[sbreg_bar_port]} ...")
            m_exit_open = self.proxy_app_manager.FUSA_comm.open_resource_manager(m_path_dict_to_mmr_sbreg[sbreg_bar_port], RMOflag.RDONLY.value)

            for offset_indx in range(len(l_sbreg_offsets)):
                logger.info(f"Lseaking offset {l_sbreg_offsets[offset_indx]} ...")
                
                ret = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(l_sbreg_offsets[offset_indx], RMWhence.SEEK_SET.value) 
                m_list_exit_lseek.append(ret)
                output = self.proxy_app_manager.FUSA_comm.rm_error
                logger.info("System error received from proxApp response is: {0}".format(output))
                self.expectTrue(output == RMSystemError.EINVAL.value, Severity.MAJOR,f'Checking that an error was raised while lseeking address: {decimal_offset}')
                m_lseek_error_codes.append(output)
            
            m_exit_close = self.proxy_app_manager.FUSA_comm.close_resource_manager()
        
        logger.info(    f"""
        ---------------------------------------------------------
        Operation: OPEN -> LSEEK -> CLOSE: bar type: {bar_type}, bar port: {sbreg_bar_port}, offset {decimal_offset}
        ended with the following flags:
        exit_open = {m_exit_open}
        exit_pread = {m_list_exit_lseek}
        exit_lseek_error = {m_lseek_error_codes}
        exit_close = {m_exit_close}
        ---------------------------------------------------------
                        """)
        return m_exit_open, m_list_exit_lseek, m_exit_close, m_lseek_error_codes

    @classmethod
    def setUpClass(cls):
        cls.ssh_manager.downloadFileFromTarget(source_file="hw_reg.json", source_path="/opt/msr_reader/etc/", destination_path=OutputPathManager.get_tests_group_path())
        rename(path.join(OutputPathManager.get_tests_group_path(), "hw_reg.json"), path.join(OutputPathManager.get_tests_group_path(), "msr_hw_reg.json"))

        with open(path.join(OutputPathManager.get_tests_group_path(), "msr_hw_reg.json")) as fl:
            cls.initial_msr_config_dict = json.load(fl)

        cls.ssh_manager.downloadFileFromTarget(source_file="hw_reg.json", source_path="/opt/mmr_reader/etc/", destination_path=OutputPathManager.get_tests_group_path())
        rename(path.join(OutputPathManager.get_tests_group_path(), "hw_reg.json"), path.join(OutputPathManager.get_tests_group_path(), "mmr_hw_reg.json"))

        with open(path.join(OutputPathManager.get_tests_group_path(), "mmr_hw_reg.json")) as fl:
            cls.initial_mmr_config_dict = json.load(fl)

        cls.deploy_proxy_app()
        cls.start_tdf_proxy_communication()
        cls.check_proxy_app()

    def setUp(self):
        self.check_proxy_app()

        self.setPrecondition("Get the config files and check they are not modified")
        self.ssh_manager.downloadFileFromTarget(source_file="hw_reg.json", source_path="/opt/msr_reader/etc/", destination_path=OutputPathManager.get_test_case_path())
        rename(path.join(OutputPathManager.get_test_case_path(), "hw_reg.json"), path.join(OutputPathManager.get_test_case_path(), "msr_hw_reg.json"))

        with open(path.join(OutputPathManager.get_test_case_path(), "msr_hw_reg.json")) as fl:
            msr_config_dict = json.load(fl)

        self.ssh_manager.downloadFileFromTarget(source_file="hw_reg.json", source_path="/opt/mmr_reader/etc/", destination_path=OutputPathManager.get_test_case_path())
        rename(path.join(OutputPathManager.get_test_case_path(), "hw_reg.json"), path.join(OutputPathManager.get_test_case_path(), "mmr_hw_reg.json"))

        with open(path.join(OutputPathManager.get_test_case_path(), "mmr_hw_reg.json")) as fl:
            mmr_config_dict = json.load(fl)

        self.expectTrue(msr_config_dict == self.initial_msr_config_dict, Severity.BLOCKER, "Checking that msr hw_reg.json is not modified")
        self.expectTrue(mmr_config_dict == self.initial_mmr_config_dict, Severity.BLOCKER, "Checking that mmr hw_reg.json is not modified")

        self.setPrecondition("Load FuSa Library and check PP and msr_reader/mmr_reader are running")
        self.proxy_app_manager.using_proxy_app_lib(libName.FUSA.value)

        logger.info("Check proxyApp is started and running")
        returnValue = self.ssh_manager.executeCommandInTarget("ps -A | grep proxy_app", ip_address=self.PP_IP)
        self.expectTrue(returnValue["stdout"].find('proxy_app') != -1, Severity.MAJOR, "Checking proxy_app is running")

        self.diag_manager.start()
        logger.info("mpad-pp is in running state")
        diag_request = self.diag_manager.syn_send(src=self.TESTER_DIAG_ADR, target=self.PP_DIAG_ADR, payload=self.STATUS_MSM_STATE_GETTER)
        self.expectTrue(diag_request != DiagResult.timeout, Severity.BLOCKER, "Checking PP does NOT reach timeout")
        self.expectTrue(diag_request != DiagResult.unknown, Severity.BLOCKER, "Checking NO unknown response received")
        self.expectTrue(diag_request == DiagResult.positive, Severity.BLOCKER, "Checking Positive response received")
        diag_response = self.diag_manager.get_latest_Response(target=self.PP_DIAG_ADR).get_payload()[3]
        logger.info('STATUS_MSM_STATE_GETTER Response: %s' % (diag_response))
        self.expectTrue(diag_response == self.MSM_RUNNING, Severity.BLOCKER, "Checking mpad-pp is in running state")

        logger.info("Check msr_reader is started and running")
        returnValue = self.ssh_manager.executeCommandInTarget(f"ps -A | grep msr_reader")
        self.expectTrue(returnValue["stdout"].find('msr_reader') != -1, Severity.MAJOR, "Checking msr_reader is started and running")

        logger.info("Check mmr_reader is started and running")
        returnValue = self.ssh_manager.executeCommandInTarget(f"ps -A | grep mmr_reader")
        self.expectTrue(returnValue["stdout"].find('mmr_reader') != -1, Severity.MAJOR, "Checking mmr_reader is started and running")


    def tearDown(self):
        self.setPostcondition("Unload FuSa Library and check PP and mmr_reader are running")
        self.proxy_app_manager.remove_proxy_app_lib(libName.FUSA.value)

        logger.info("Check msr_reader is started and running")
        returnValue = self.ssh_manager.executeCommandInTarget(f"ps -A | grep msr_reader")
        self.expectTrue(returnValue["stdout"].find('msr_reader') != -1, Severity.MAJOR, "Checking msr_reader is started and running")
        
        logger.info("Check mmr_reader is started and running")
        returnValue = self.ssh_manager.executeCommandInTarget(f"ps -A | grep mmr_reader")
        self.expectTrue(returnValue["stdout"].find('mmr_reader') != -1, Severity.MAJOR, "Checking msr_reader is started and running")

        self.diag_manager.stop()

    @classmethod
    def tearDownClass(cls):

        cls.stop_tdf_proxy_communication()
        cls.undeploy_proxy_app()
