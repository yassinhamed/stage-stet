from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_low_level_003_LLED_temperature_report_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_low_level_003_LLED_temperature_report_non_verbose"
    REQ_ID = ["/item/5897072", "/item/5889679"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that  sysmon reports the temperature for each CPU core in non-verbose mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get number of cores")
        self.assertTrue(self.number_of_cores != self.INVALID_VALUE, Severity.MAJOR, "Check that number of online cores is available")
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.Low_level_error_diagnostics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_LLED)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_low_level_003_LLED_temperature_report_non_verbose(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_LLED, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 6)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get LLED temperature report DLT message")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that message is reported")

        self.startTestStep("Get cores tempratures value")
        cores_reproted = self.get_cores_tempratures(dlt_messages=dlt_messages, number_of_cores=self.number_of_cores)
        self.expectTrue(cores_reproted, Severity.MAJOR, "Check that all cores are reported")
        temperature = float(dlt_messages[0]["payload"]["temperature"])
        self.expectTrue(temperature != self.INVALID_VALUE, Severity.MAJOR, "Check that temperature is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
