from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_SW_IRQ_01_IRQS_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_SW_IRQ_01_IRQS_LINUX"
    REQ_ID = ["/item/5888805", "/item/5889418", "/item/5889616", "/item/5889630"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports SW IRQ statistics"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.softirqs_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.Search_msg_array = self.statistic_data["IRQ"]["SW"]["Search_msg_array"]
        logger.info(f"Search message array = {self.Search_msg_array}")
        self.assertTrue(self.Search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")

        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.softirqs_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_SW_IRQ_01_IRQS_LINUX(self):
        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get IRQS DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.Search_msg_array)
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that IRQS statistics DLT messages are available")

        self.startTestStep("Get name value")
        name = self.get_statistic_value(message=messages[0], statistic_path="IRQ.SW.Statistics.name")
        self.expectTrue(name != self.INVALID_VALUE, Severity.MAJOR, "Check that name is reported")

        self.startTestStep("Get sum value")
        sum = self.get_statistic_value(message=messages[0], statistic_path="IRQ.SW.Statistics.sum")
        self.expectTrue(sum != self.INVALID_VALUE, Severity.MAJOR, "Check that sum is reported")

        self.startTestStep("Get irq_sec value")
        irq_sec = self.get_statistic_value(message=messages[0], statistic_path="IRQ.SW.Statistics.irq_sec")
        self.expectTrue(irq_sec != self.INVALID_VALUE, Severity.MAJOR, "Check that irq_sec is reported")

        self.startTestStep("Get cpu_1 value")
        cpu_1 = self.get_statistic_value(message=messages[0], statistic_path="IRQ.SW.Statistics.cpu_1")
        self.expectTrue(cpu_1 != self.INVALID_VALUE, Severity.MAJOR, "Check that cpu_1 is reported")

        self.startTestStep("Get cpu_2 value")
        cpu_2 = self.get_statistic_value(message=messages[0], statistic_path="IRQ.SW.Statistics.cpu_2")
        self.expectTrue(cpu_2 != self.INVALID_VALUE, Severity.MAJOR, "Check that cpu_2 is reported")

        self.startTestStep("Get cpu_3 value")
        cpu_3 = self.get_statistic_value(message=messages[0], statistic_path="IRQ.SW.Statistics.cpu_3")
        self.expectTrue((cpu_3 != self.INVALID_VALUE) == (self.number_of_cores == 4), Severity.MAJOR, "Check that cpu_3 is reported")

        self.startTestStep("Get cpu_4 value")
        cpu_4 = self.get_statistic_value(message=messages[0], statistic_path="IRQ.SW.Statistics.cpu_4")
        self.expectTrue((cpu_4 != self.INVALID_VALUE) == (self.number_of_cores == 4), Severity.MAJOR, "Check that cpu_4 is reported")

        interrupt_names = [self.get_statistic_value(message=x, statistic_path="IRQ.SW.Statistics.name") for x in messages]

        self.expectTrue(all(interrupt_name.upper() != "HRTIMER" for interrupt_name in interrupt_names), Severity.MAJOR, "Check that HRTIMER interrupt is not reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
