from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_cpu_07_separate_time_interval_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_cpu_07_separate_time_interval_QNX"
    REQ_ID = ["/item/5829173"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that time interval are separately specified for system, core"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        pass

    def test_tca_sysmon_cpu_07_separate_time_interval_QNX(self):

        self.startTestStep("get all time interval variables from the config file")
        system_variable = self.qnx_time_interval_mapping[self.CPU_system_context_id]
        logger.info(f"system variable = {system_variable}")
        self.time_interval_system = self.get_time_interval(contextID=self.CPU_system_context_id)
        logger.info(f"Time interval = {self.time_interval_system}")
        self.expectTrue(self.time_interval_system != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        core_variable = self.qnx_time_interval_mapping[self.CPU_core_context_id]
        logger.info(f"core variable = {core_variable}")
        self.time_interval_core = self.get_time_interval(contextID=self.CPU_core_context_id)
        logger.info(f"Time interval = {self.time_interval_core}")
        self.expectTrue(self.time_interval_core != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        self.assertTrue(system_variable == core_variable, Severity.BLOCKER, "Check that the variables are different")

    def tearDown(self):
        pass
