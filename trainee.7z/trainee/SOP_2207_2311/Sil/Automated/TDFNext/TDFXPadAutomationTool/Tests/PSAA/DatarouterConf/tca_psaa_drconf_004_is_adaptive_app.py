from Tests.PSAA.DatarouterConf.testfixture_PSAA_DatarouterConf import *


class tca_psaa_drconf_004_is_adaptive_app(testfixture_PSAA_DatarouterConf):
    TEST_ID = "PSAA\tca_psaa_drconf_004_is_adaptive_app"
    REQ_ID = ["/item/1019008"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check Datarouter conf is adaptive application"
    STATUS = "Ready"
    OS = ['LINUX','QNX']

    def setUp(self):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls /opt | grep -c '{self.DATA_ROUTER_CONF_APP_NAME}'", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER, "Check DR configurator is under /opt")
        self.dlt_manager.apply_filter(appId=self.EM_APP_ID)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_psaa_drconf_004_is_adaptive_app(self):
        self.startTestStep("Reset Ecu")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.restart()
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUs are correctly reset")
        self.startTestStep("Get dlt message related to the start of Datarouter conf by Execution manager")
        is_adaptive, message = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID,
                                                                    searchMsgArray=self.EM_START_DatarouterConf_MESSAGES)
        self.assertTrue(is_adaptive > 0, Severity.BLOCKER, "Check DR configurator is adaptive application")
        self.startTestStep("Check Datarouter conf is running")
        app_is_running = self.check_application_is_started(app_name=self.DATA_ROUTER_CONF_APP_NAME)
        self.expectTrue(app_is_running, Severity.MAJOR, "Check DR configurator is started in Machine State Running")
        self.startTestStep("Check Datarouter conf exec_config.json exists")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.dconf_config_path} | grep -c '{self.EXEC_CONFIG_FILE_NAME}'", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Check DR configurator contain a valid manifest.json")

    def tearDown(self):
        self.dlt_manager.stop_monitoring()
