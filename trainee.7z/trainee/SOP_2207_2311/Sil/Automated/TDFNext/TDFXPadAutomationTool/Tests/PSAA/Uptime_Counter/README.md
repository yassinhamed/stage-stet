# Uptime_counter

**The uptime_counter application does the below functionalities:**

- Detect each unwanted reset and accumulate a persistently stored counter of all unwanted resets.
- Count system uptime and accumulate a persistently stored uptime counter in milliseconds.
- Count kilometers passed and accumulate a persistently stored kilometer counter in meters.
- All the above counters shall be reset to 0 upon software flash.
- All the above counters shall be reset to 0 via a diagnostic job.
- All the above counters shall be written to persistent key value storage i.e./persistent/uptime_counter/key_value_storage only in ecu machine state is in *Running*

**Unwanted reset:**

- Unwanted reset is detected by incrementing the persistently stored accumulated counter value by one when the ecu machine state is in Running.
- Unwanted reset persistently stored accumulate counter value is decremented by one when the lifecycle manager triggers shutdown request.
- In case of kernel crash unwanted reset persistently stored accumulate counter value will not be decremented by one as there will be no shutdown request trigger from the lifecycle manager. This is the indication for kernel crash as unwanted reset value will be incremented value by one on next boot up.

**System uptime:**

- System uptime persistently stored  accumulated counter value is written to persistent storage for every 10 secs when the ecu machine state is in Running.
- System uptime is logged via non-verbose logging (TRACE) every 10 secs when the ecu machine state is in Running.

**Reset the counters on clear diagnostic job request:**

All counters are reset to 0 on clear diagnostic job request i.e. 0x2E434A01 or 0x2E434A00.

**Reset statistics data on reset statistics diagnostic job request:**

- All counters values are returned on reset statistics diagnostic job request i.e. 0x2E434A.
- Counters values are read from the memory when the ecu machine state is in *Running*.
- Counters values are read from the persistent key value storage i.e./persistent/uptime_counter/key_value_storage. when ecu machine state is not in *Running*

**kilometers passed:**

- Meter driven persistently stored accumulated counter value in *meters* is obtained from the MileageSupreme service.
- *meters* obtained from the MileageSupreme service is written to storage when the previous value is not equal to current value.
