from Tests.PSAA.Param_Server.testfixture_PSAA_param_server import *


class tca_ParamS_031_check_param_names_in_config_file(testfixture_PSAA_param_server):

    TEST_ID = "ParamServer\ttca_ParamS_031_check_param_names_in_config_file"
    REQ_ID = ["/item/727604"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    field_depends_on_coding = None

    def setUp(self):
        pass

    def test_check_param_names_in_config_file(self):
        result = self.check_all_param_names_in_config_file_are_valid()

        self.assertTrue(result, Severity.BLOCKER, "Check that all parameter names in default_values.json are correct")

    def tearDown(self):
        pass
