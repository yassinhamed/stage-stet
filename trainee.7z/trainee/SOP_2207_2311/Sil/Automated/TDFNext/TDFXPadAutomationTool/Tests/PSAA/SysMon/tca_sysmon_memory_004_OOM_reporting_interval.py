from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_004_OOM_reporting_interval(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_004_OOM_reporting_interval"
    REQ_ID = ["/item/5979690"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that OOM time interval is less or equal MEMS time interval"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval_mems = self.get_time_interval(contextID=self.memory_process_usage_context_id + "total")
        logger.info(f"Time interval = {self.time_interval_mems}")

        self.setPrecondition("Get logging time interval")
        self.time_interval_oom = self.get_time_interval(contextID=self.cgroup_oom_report_context_id)
        logger.info(f"Time interval = {self.time_interval_oom}")

    def test_tca_sysmon_memory_004_OOM_reporting_interval(self):
        self.assertTrue( self.time_interval_oom <= self.time_interval_mems, Severity.MAJOR, "Check that OOM time interval <= MEMS time interval")

    def tearDown(self):
        pass
