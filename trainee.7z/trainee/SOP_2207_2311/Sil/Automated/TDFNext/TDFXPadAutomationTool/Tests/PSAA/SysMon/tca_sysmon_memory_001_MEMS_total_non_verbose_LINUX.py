from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_001_MEMS_total_non_verbose_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_001_MEMS_total_non_verbose_LINUX"
    REQ_ID = ["/item/5904829"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports total RAM consumption in non-verbose mode"
    OS = ['LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get sysmon PID")
        self.assertTrue(True, Severity.MAJOR, "Check that sysmon is running (has PID)")
        self.setPrecondition("Start DLT monitoring")

    def test_tca_sysmon_memory_001_MEMS_total_non_verbose_LINUX(self):
        self.startTestStep("Wait time interval  * 2")
        self.startTestStep("Get DLT EMEMS messages of total RAM consumption")
        self.assertTrue(True, Severity.MAJOR, "Check that DLT EMMC of total RAM consumption messages are available")
        self.expectTrue(True, Severity.MAJOR, "Check that dlt messages contain all required statistics")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
