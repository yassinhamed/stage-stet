from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *


class tca_PSAA_UptimeCounter_MeterDrivenInMeters(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_MeterDrivenInMeters"
    REQ_ID = ["/item/3316275"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check Meters driven counter existence"
    OS = ["QNX", "LINUX"]
    STATUS = "Ready"

    def setUp(self):
        pass

    def test_tca_PSAA_UptimeCounter_MeterDrivenInMeters(self):

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")

        file_contents = grep_kvs_file["stdout"].strip()
        self.assertTrue(self.MeterDrivenCounter in file_contents , Severity.BLOCKER, f"Check {self.MeterDrivenCounter} existence")

    def tearDown(self):

        pass
