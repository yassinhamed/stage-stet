from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_013_storage_cleanUp_02(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_013_storage_cleanUp_02"
    REQ_ID = ["/item/2593168", "/item/2593376"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check core dumps cleanup when it's over 50%"
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        pass

    def test_tca_psaa_Chandler_013_storage_cleanUp_02(self):
        # new test
        # first file
        self.startTestStep("Create coredumps files under persistent with size 52428800")
        returnValue = self.ssh_manager.executeCommandInTarget(command="fallocate -l 52428800 /persistent/coredumps/core.50000.test.888.gz", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        self.startTestStep("Get coredumps files")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}", ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        logger.info("########## ls -lh returned : " + str(returnValue["stdout"].strip()) + "##########")
        # second file
        self.startTestStep("Create coredumps files under persistent with size 52428800")
        returnValue = self.ssh_manager.executeCommandInTarget(command="fallocate -l 52428800 /persistent/coredumps/core.60000.test.888.gz", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        self.startTestStep("Get coredumps files")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}", ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        logger.info("########## ls -lh returned : " + str(returnValue["stdout"].strip()) + "##########")
        # third file
        self.startTestStep("Create coredumps files under persistent with size 52428800")
        returnValue = self.ssh_manager.executeCommandInTarget(command="fallocate -l 52428800 /persistent/coredumps/core.70000.test.888.gz", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        self.startTestStep("Get coredumps files")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}", ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        logger.info("########## ls returned : " + str(returnValue["stdout"].strip()) + "##########")
        self.sleep_for(5000)
        # check files
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}", ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        dumps_list = returnValue["stdout"].splitlines()
        logger.info("Number of core dumps" + str(len(dumps_list)))
        self.expectTrue(len(dumps_list) == 4, Severity.BLOCKER,
                        "Checking that coredumps files were created properly.")
        self.expectTrue("core.50000.test.888.gz" not in dumps_list, Severity.BLOCKER,
                        "Checking that coredumps files were created properly.")
        # -----

    def tearDown(self):
        pass