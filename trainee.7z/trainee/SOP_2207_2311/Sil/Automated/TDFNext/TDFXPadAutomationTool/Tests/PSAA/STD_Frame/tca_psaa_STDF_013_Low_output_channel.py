from Tests.PSAA.STD_Frame.testfixture_PSAA_STDFrame import *


class tca_psaa_STDF_013_Low_output_channel(testfixture_PSAA_STDFrame):
    TEST_ID = "PSAA\tca_psaa_STDF_013_Low_output_channel"
    REQ_ID = ["/item/5694464"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "22-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check non verbose dlt messages are logged over low channel port"
    OS = ['LINUX','QNX']
    STATUS = "Ready"

    def setUp(self):
        self.ssh_manager.downloadFileFromTarget(self.Log_channels_file_name, self.datarouter_Config_file_path,
                                                OutputPathManager.get_test_case_path())
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_HWVersion)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SWVersion1)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SWVersion2)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SWVersion3)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SWVersion4)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SWVersion5)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SWVersion6)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SWVersion7)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SWVersion8)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SWVersion9)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SWVersion10)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SerialNumber)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_VehicleId)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_CurrentEngMode)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_InterfaceVersion)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_CurrentMileage)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_timesync)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_STDF_013_Low_output_channel(self):
        lowSrcPort = self.json_manager.findNodeFromJsonFile(filePath=self.datarouter_Config_file_path+self.Log_channels_file_name,
                                                            nodePath=self.Low_channel_port_node,
                                                            use_cache=False, delete_cache=True, upload_file=False)
        lowDstPort = self.json_manager.findNodeFromJsonFile(filePath=self.datarouter_Config_file_path+self.Log_channels_file_name,
                                                            nodePath=self.Low_channel_port_node,
                                                            use_cache=False, delete_cache=True, upload_file=False)
        highSrcPort = self.json_manager.findNodeFromJsonFile(filePath=self.datarouter_Config_file_path+self.Log_channels_file_name,
                                                            nodePath=self.High_channel_port_node,
                                                            use_cache=False, delete_cache=True, upload_file=False)
        highDstPort = self.json_manager.findNodeFromJsonFile(filePath=self.datarouter_Config_file_path+self.Log_channels_file_name,
                                                            nodePath=self.High_channel_port_node,
                                                            use_cache=False, delete_cache=True, upload_file=False)
        logger.info(f"lowSrcPort  : {lowSrcPort}")
        logger.info(f"lowDstPort  : {lowDstPort}")
        logger.info(f"highSrcPort : {highSrcPort}")
        logger.info(f"highDstPort : {highDstPort}")
        self.sleep_for(self.wait_for_STDF_dlt_message)
        message_count, message = self.dlt_manager.get_messages(srcPort=int(lowSrcPort), dstPort=int(lowDstPort))
        self.assertTrue(message_count > 0, Severity.BLOCKER, f"Check the STDF channelAssignments and the ports are correct, massages count: {message_count}")
        message_count, message = self.dlt_manager.get_messages(srcPort=int(highSrcPort), dstPort=int(highDstPort))
        self.assertTrue(message_count == 0, Severity.BLOCKER, f"Check the STDF channelAssignments and the ports are correct, massages count: {message_count}")

    def tearDown(self):
        pass
