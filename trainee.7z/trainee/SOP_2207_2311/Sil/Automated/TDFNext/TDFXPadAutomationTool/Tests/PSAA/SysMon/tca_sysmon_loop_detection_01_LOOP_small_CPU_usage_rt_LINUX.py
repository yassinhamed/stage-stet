from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_loop_detection_01_LOOP_small_CPU_usage_rt_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_loop_detection_01_LOOP_small_CPU_usage_rt_LINUX"
    REQ_ID = ["/item/5911101", "/item/5979602"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon does not report real time inifinte loop that not exceed the configured CPU threshold"
    OS = ['LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.loop_detection_rt_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.Search_msg_array = self.statistic_data["LOOP"]["RT"]["Search_msg_array"]
        logger.info(f"Search message array = {self.Search_msg_array}")
        self.assertTrue(self.Search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")

    def test_tca_sysmon_loop_detection_01_LOOP_small_CPU_usage_rt_LINUX(self):
        self.startTestStep("Get configured CPU threshold")
        cpu_threshold = self.get_process_cpu_usage_limit(SearchText="process_cpu_usage_limit")
        logger.info(f"Cpu threshold = {cpu_threshold} is the cpu usage limit")
        self.expectTrue(cpu_threshold != self.INVALID_VALUE, Severity.BLOCKER, "Check that configured CPU threshold was successfully retrieved")
        self.expectTrue(cpu_threshold == 0.1, Severity.MAJOR, "Check that configured CPU threshold is equal to 0.1")

        self.startTestStep("Set big CPU threshold")
        cpu_threshold_is_set = self.ssh_manager.executeCommandInTarget(command=f"sed 's/cpu_usage_limit_logging=0.1/cpu_usage_limit_logging=99.99/g' /opt/sysmon/etc/monitor.conf", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(cpu_threshold_is_set["exec_recv"] == 0, Severity.MAJOR, "Check cpu_threshold set command is executed")

        self.startTestStep("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")

        self.startTestStep("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.loop_detection_rt_context_id)

        self.dlt_manager.clear_all_dlt_messages()

        self.startTestStep("Execute yes command to made NRT loop")
        command_is_executed = self.ssh_manager.executeCommandInTarget(command=f"yes > /dev/null &", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(command_is_executed["exec_recv"] == 0, Severity.MAJOR, "Check that yes command is executed")

        command_is_running = self.ssh_manager.executeCommandInTarget(command="ps axw | grep yes", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(command_is_running["stdout"] != "", Severity.MAJOR, "Check that yes command is running")

        self.startTestStep("chrt -r -p 1 yes")
        real_time_change = self.ssh_manager.executeCommandInTarget(command="chrt -r -p 1 $(pidof yes)", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(real_time_change['exec_recv'] == 0, Severity.MAJOR, "change yes to real time process")

        command_is_running = self.ssh_manager.executeCommandInTarget(command="ps axw | grep yes", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(command_is_running["stdout"] != "", Severity.MAJOR, "Check that yes command is running")

        self.sleep_for(self.wait_RT_precess_report_ms)

        self.dlt_manager.start_monitoring("SRR-DLT")

        self.startTestStep("Wait the configured time for loop detection * 2")
        self.sleep_for(self.time_interval * 2 * 1000)

        self.startTestStep("Get LOOP  DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.Search_msg_array)
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(message_count == 0, Severity.MAJOR, "Check that no DLT message of LOOP exist")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()

        self.setPostcondition("Revert config file")
        cpu_threshold_is_set = self.ssh_manager.executeCommandInTarget(command=f"sed 's/cpu_usage_limit_logging=99.99/cpu_usage_limit_logging=0.1/g' /opt/sysmon/etc/monitor.conf", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(cpu_threshold_is_set["exec_recv"] == 0, Severity.MAJOR, "Check cpu_threshold set command is executed")

        self.setPostcondition("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
