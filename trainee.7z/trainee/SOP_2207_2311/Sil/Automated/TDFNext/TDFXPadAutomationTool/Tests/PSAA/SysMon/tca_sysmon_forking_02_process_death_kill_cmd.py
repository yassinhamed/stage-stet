from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_forking_02_process_death_kill_cmd(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_forking_02_process_death_kill_cmd"
    REQ_ID = ["/item/5833129"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon report process death using kill command"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.search_msg_array = self.statistic_data["PMON"]["termination_ets"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.process_forking_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_forking_02_process_death_kill_cmd(self):
        self.startTestStep("Get pid of the application to be killed")
        ETS_pid = self.get_process_id(app_name=self.ETS_APP_NAME)
        self.assertTrue(ETS_pid != -1, Severity.MAJOR, "Check the application is running")

        self.startTestStep("Execute cmd kill application")
        application_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal="SIGSEGV")
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check the kill command is executed")

        self.sleep_for(5000)

        self.startTestStep("Check application is killed")
        ETS_still_running = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.assertTrue(not ETS_still_running, Severity.MAJOR, "Check the application is killed")

        self.startTestStep("Wait for DLT (3 seconds)")
        self.sleep_for(3000)

        self.startTestStep("Get PMON DLT messages that contains process death")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that the terminated apps death was reported")

        process_pid = self.get_statistic_value(message=messages[0], statistic_path="PMON.termination_ets.Statistics.pid_ets")
        logger.info(f"dlt pid ({process_pid}) must be equal to ps command pid ({ETS_pid})")
        self.assertTrue(int(process_pid) == int(ETS_pid), Severity.MAJOR, "Check that killed process was reported with its PID")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
