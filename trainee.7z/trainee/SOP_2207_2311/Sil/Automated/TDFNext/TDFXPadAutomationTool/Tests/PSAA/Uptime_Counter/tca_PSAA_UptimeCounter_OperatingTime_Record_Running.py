from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter_ProxyApp import *

class tca_PSAA_UptimeCounter_OperatingTime_Record_Running(testfixture_PSAA_UptimeCounter_ProxyApp):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_OperatingTime_Record_Running"
    REQ_ID = ["/item/6233411"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check system operating time counter is updated in RUNNING state"
    STATUS = "Ready"
    OS = ["QNX", "LINUX"]

    def setUp(self):

        self.setPrecondition("Create backup of exec_config_file")
        self.create_uptime_counter_exec_config_backup()

        self.setPrecondition("Changing uptime_counter cyclicity under exec_config file to 10s")
        self.change_cyclicity(new_cyclicity=self.Cyclicity_10s_MS)

        self.setPrecondition("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        self.setPrecondition("Check Ecus")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUS are correctly reset")

        self.setPrecondition("Get cyclicity from exec_config file")
        cyclicity = self.get_cyclicity_from_exec_config()
        logger.info(f"cyclicity_value: {cyclicity}")
        self.assertTrue(cyclicity == self.Cyclicity_10s_MS, Severity.MAJOR, "Checking cyclicity is successfully changed")

        self.setPrecondition("Setting machine state manager")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.INTEG_LAYER.value)
        result = self.proxy_app_manager.INT_LAY_comm.machine_state_manager_configure()
        self.assertTrue(result == intcActMgrExecResult.SUCCESS.value, Severity.MAJOR, "Check configuration")

    def test_tca_PSAA_UptimeCounter_OperatingTime_Record_Running(self):

        self.startTestStep("Setting machine state RUNNING")
        result = self.proxy_app_manager.INT_LAY_comm.set_new_state(newMachineState=intcMachineState.RUNNING.value,timeoutDuration=self.SET_NEW_MACHINE_STATE_MS)
        self.assertTrue(result == intcActMgrExecResult.SUCCESS.value, Severity.MAJOR, "Check RUNNING state is set")

        self.startTestStep("Getting current machine state")
        result, currentMachineState = self.proxy_app_manager.INT_LAY_comm.get_current_state(timeoutDuration=self.SET_NEW_MACHINE_STATE_MS)
        self.assertTrue(result == intcActMgrExecResult.SUCCESS.value, Severity.MAJOR,"Check that machine state manager is running")
        self.assertTrue(currentMachineState == intcMachineState.RUNNING.value, Severity.MAJOR,"Check that state is RUNNING")

        self.startTestStep("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.startTestStep("Getting OperatingTime counter value from kvs")
        First_OperatingTime = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.OperatingTime_counter)
        logger.info(f"First_OperatingTime_value: {First_OperatingTime}")

        self.startTestStep("waiting UptimeCounter update cyclicity")
        self.sleep_for(1.5*self.Wait_for_counters_incrementation_MS)


        self.startTestStep("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.startTestStep("Getting OperatingTime counter value from kvs")
        Second_OperatingTime = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.OperatingTime_counter)
        logger.info(f"Second_OperatingTime_value: {Second_OperatingTime}")

        self.assertTrue(First_OperatingTime < Second_OperatingTime, Severity.BLOCKER, "Checking OperatingTime value is updated")

    def tearDown(self):

        self.setPostcondition("Reverting uptime_counter exec_config file ")
        self.set_default_uptime_counter_exec_config()

        self.setPostcondition("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.setPostcondition("Check uptime_counter exec_config file is reverted")
        cyclicity = self.get_cyclicity_from_exec_config()
        logger.info(f"cyclicity_value: {cyclicity}")
        self.expectTrue(cyclicity == self.Cyclicity_60m_MS, Severity.MAJOR,"Checking cyclicity is successfully reverted")

