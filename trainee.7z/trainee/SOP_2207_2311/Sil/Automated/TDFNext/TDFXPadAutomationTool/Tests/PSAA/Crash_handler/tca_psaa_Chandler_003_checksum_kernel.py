from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_003_checksum_kernel(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_003_checksum_kernel"
    REQ_ID = ["/item/2593168"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps of kernel pannic are created properly and checksum file contains coredumps files names"
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        pass

    def test_tca_psaa_Chandler_003_checksum_kernel(self):
        self.startTestStep("Perform Kernel Panic")
        self.ssh_manager.executeCommandInTargetNoWait(command=self.kernel_panic_command, timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                      ip_address=self.PP_IP)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.startTestStep("get kernel coredumps names")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"ls -la {self.CoreDumps_Path}/kernel | grep -c kdump.vmcore",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Checking that the coredumps were generated")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.startTestStep("Check checksum exist")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"ls -la {self.CoreDumps_Path} | grep -c checksum",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Checking that the coredumps were generated")
        self.startTestStep("list coredumps in checksum")
        result = self.ssh_manager.executeCommandInTarget(command=f"cat {self.CoreDumps_Path}/checksum | grep kernel",
                                                         timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(result["exec_recv"] == 0, Severity.MAJOR,
                        "Checking that coredump is listed in checksum file {0}".format(result["stdout"]))
        checksum_log = len(result["stdout"].splitlines())
        self.expectTrue(checksum_log == 1, Severity.BLOCKER,
                        "Checking that coredump files are listed correctly in checksum :\n {0}".format(
                            returnValue["stdout"].splitlines()))

        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls -la {self.CoreDumps_Path}/kernel | grep -c kdump.vmcore", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER, "Checking that the coredumps were generated")

    def tearDown(self):
        result = self.ssh_manager.downloadFileFromTarget("kdump.vmcore", f"{self.CoreDumps_Path}/kernel",
                                                         OutputPathManager.get_test_case_path())
        self.expectTrue(result, "Checking that the Kernel coredumps were copied")
