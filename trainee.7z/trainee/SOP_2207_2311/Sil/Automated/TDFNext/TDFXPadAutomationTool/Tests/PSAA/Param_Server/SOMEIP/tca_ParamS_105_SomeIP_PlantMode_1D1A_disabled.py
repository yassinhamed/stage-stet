from Tests.PSAA.Param_Server.testfixture_PSAA_param_server import *


class tca_ParamS_105_SomeIP_PlantMode_1D1A_disabled(testfixture_PSAA_param_server):

    TEST_ID = "ParamServer\tca_ParamS_105_SomeIP_PlantMode_1D1A_disabled"
    REQ_ID = ["/item/53169", "/item/144129", "/item/144130", "/item/144136"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    field_depends_on_coding = None

    def setUp(self):
        self.ecu_uid = self.sfa_manager.get_ecu_uid(target=self.PP_DIAG_ADR)
        self.diag_manager.start()
        self.sfa_manager.set_up(target_address=self.PP_DIAG_ADR)

    def test_SomeIP_PlantMode_1D1A_disabled(self):

        resp = self.sfa_manager.safe_set_to_plant_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(resp, Severity.BLOCKER, "check the return code of the switch to Plant mode")
        mode = self.sfa_manager.sfa_get_ecu_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(mode == EcuMode.Plant.value, Severity.BLOCKER, 'Check that the perf. controller is in Plant mode')

        res = self.sfa_manager.sfa_clear_feature(target=self.PP_DIAG_ADR, feature_id=self.SFA_ID)
        self.expectTrue(res, Severity.BLOCKER, "check the return code of the disabling of 1D1A token in the perf. controller")
        self.sleep_for(self.TOKEN_STATUS_UPDATE_TIMEOUT_MS)
        feature_status = self.sfa_manager.sfa_get_status(self.PP_DIAG_ADR, self.SFA_ID)
        self.expectTrue(feature_status != Feature_Status.Enabled.value, Severity.BLOCKER, f"Check that the 1D1A token is not enabled, token status = {feature_status}")

        sd_filter = [{"srv_id": self.AdpParameters_service_ID, "inst_id": self.AdpParameters_instances[self.PP_NAME], "type": EntryType.OfferService}]
        self.someip_controller.start_check_sd(sd_filter)
        self.sleep_for(self.OFFER_SERVICE_TIMEOUT_MS)
        self.expectTrue(len(self.someip_controller.get_entries_found()) == 0, Severity.BLOCKER,
                        f"Check that PP is not offering SRV_ID : {self.AdpParameters_service_ID} when PP is in Plant mode and 1D1A token is not installed")
        self.someip_controller.stop_check_sd()

    def tearDown(self):
        resp = self.sfa_manager.safe_set_to_engineering_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(resp, Severity.BLOCKER, "check the return code of the switch to Eng mode")
        mode = self.sfa_manager.sfa_get_ecu_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(mode == EcuMode.Engineering.value, Severity.BLOCKER, 'Check that the perf. controller is in Eng mode')

        res = self.sfa_manager.set_secure_feature(target=self.PP_DIAG_ADR, ecu_uid=self.ecu_uid, feature_id=self.SFA_ID,
                                                  result_dir=OutputPathManager.get_report_path(), feature_spec_fields=self.sfa_manager.generate_ssh_key_payload())
        self.expectTrue(res, Severity.BLOCKER, "check that 1D1A token was enabled successfully")
        self.sleep_for(self.TOKEN_STATUS_UPDATE_TIMEOUT_MS)
        feature_status = self.sfa_manager.sfa_get_status(self.PP_DIAG_ADR, self.SFA_ID)
        self.expectTrue(feature_status == Feature_Status.Enabled.value, Severity.BLOCKER, f"check that 1D1A is enabled, token status = {feature_status}")

        self.diag_manager.stop()
