from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_CrashHandler(testfixture_PSAA):
    Default_Context_Id = "DFLT"
    COREDUMPS_GENERATION_TIMEOUT_MS = 100000
    ERROR_GENERATION_TIMEOUT = 120000
    DTC_SET_TIMEOUT_MS = 5000
    DLT_START_MONITORING_TIMEOUT = 2000
    Number_Of_Coredumps_Files = 6
    Number_Of_Coredumps_Files_For_Datarouter_Kill = 5 # log file created by datarouter, when it is killed no log file created
    Number_Of_Coredumps_Files_For_Killing_Two_Apps = 10
    Number_Of_Files_Names_In_Checksum = 4
    Number_Of_Files_Names_In_Checksum_For_Datarouter_Kill = 3
    default_dumper_timeout = 30000

    def setUp(self):
        feature_status = self.sfa_manager.sfa_get_status(self.PP_DIAG_ADR, feature_id=self.SFA_ID)
        if feature_status == Feature_Status.Disabled or feature_status == Feature_Status.IntialDisabled:
            self.ecu_uid = self.sfa_manager.get_ecu_uid(target=self.PP_DIAG_ADR, use_cache=False)
            self.sfa_manager.start_sfa_manager()
            self.tokensPath = self.sfa_manager.generate_tokens(ecu_uid=self.ecu_uid)
            self.sfa_manager.configure_sfa_manager(target=self.PP_DIAG_ADR, pathToTokens=self.tokensPath)
            res = self.sfa_manager.set_secure_feature(target=self.PP_DIAG_ADR, ecu_uid=self.ecu_uid, feature_id=self.SFA_ID, result_dir=OutputPathManager.get_report_path(), feature_spec_fields=self.sfa_manager.generate_ssh_key_payload())
            self.expectTrue(res, Severity.BLOCKER, "Checking that SFA Debug token is Enabled")
            self.sfa_manager.stop_sfa_manager()
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.restart()
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/", output_folder=path.join(OutputPathManager.get_test_case_path(), "coredumps_setup"), check_empty=False, ip_address=self.PP_IP, ignored_files=["currentswversion", "tmp"])
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        self.diag_manager.restart()

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA setUpclsss")
        cls.ssh_manager.executeCommandInTarget("ls /opt/crash_handler/bin")
        cls.ssh_manager.executeCommandInTarget("ls /opt/crash_handler/etc")

        if cls.PP_NAME == "mPAD_Performance":
            cls.INDEX = 'pp_taf'
        elif cls.PP_NAME == "mPAD_Performance_AddOn":
            cls.INDEX = 'pp_cp_addon'
        elif cls.PP_NAME == "mPAD_Performance_High":
            cls.INDEX = 'pp_cp_plus'

        cls.coredump_checker = CoredumpChecker()
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/", output_folder=path.join(OutputPathManager.get_tests_group_path(), "coredumps_setupclass"), check_empty=False, ip_address=cls.PP_IP, ignored_files=["currentswversion", "tmp"])

    def tearDown(self):
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/", output_folder=path.join(OutputPathManager.get_test_case_path(), "coredumps_teardown"), check_empty=False, ip_address=self.PP_IP, ignored_files=["currentswversion", "tmp"])
        self.diag_manager.start()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.restart()
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA tearDownclsss")

    def download_core_dumps_by_names(self, dumps_list):
        folder_name = f"Downloaded_core_dumps_files_{datetime.datetime.now().strftime('%d%m%Y_%H%M%S')}"
        for line in dumps_list:
            if "tmp" in line:
                continue
            else:
                logger.info(line)
                result = self.ssh_manager.downloadFileFromTarget("{0}".format(line.strip()), self.CoreDumps_Path, path.join(OutputPathManager.get_test_case_path(), folder_name))
                self.expectTrue(result, "Checking that Coredumps copy is done properly")

    def convert_storage_size(self, Size, pourcentage):
        if Size[-1] == "M":
            used_storage_B = round(float(Size.replace('M', ''))) * 1024 ** 2
        else:
            used_storage_B = round(float(Size.replace('K', ''))) * 1024
        total_storage = 100 * 1024 * 1024
        target = int(total_storage * pourcentage - used_storage_B)
        return target

    def get_date(self):
        returnValue = self.ssh_manager.executeCommandInTarget(command="date +%s", ip_address=self.PP_IP)
        time = returnValue["stdout"].strip()
        return time

    def restart_crash_handler_with_params(self, coredumps_storage_quota_mb="0", storage_cleanup_percentage="0"):
        application_is_killed = self.kill_application(app_name=self.CRASH_HANDLER_APP_NAME, signal="SIGABRT", option="-v crash_reporter")
        if not application_is_killed:
            logger.error("the kill command is not executed")
            return False
        crash_handler_starting = self.ssh_manager.executeCommandInTarget(command=f"export AMSR_DISABLE_INTEGRITY_CHECK=1 && cd /opt/crash_handler/ && ./bin/crash_handler --coredumps_storage_quota_mb {coredumps_storage_quota_mb} --storage_cleanup_percentage {storage_cleanup_percentage} &", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if crash_handler_starting["exec_recv"] == 0:
            logger.info("crash handler command is executed")
            return True
        else:
            logger.error("crash handler command isn't executed")
            return False

    def parse_crash_handler_commandline_parameters(self):
        crash_handler = self.ssh_manager.executeCommandInTarget(command=f"ps -A -o pid,args | grep crash_handler | grep -v grep | grep -v crash_reporter", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if crash_handler["stdout"] != "":
            pid = crash_handler["stdout"].split(" ./bin/crash_handler")[0].strip()
            if "--coredumps_storage_quota_mb " in crash_handler["stdout"]:
                quota = crash_handler["stdout"].split("--coredumps_storage_quota_mb ")[1].split(" ")[0]
            else:
                quota = None
            if "--storage_cleanup_percentage " in crash_handler["stdout"]:
                percentage = crash_handler["stdout"].split("--storage_cleanup_percentage ")[1].split(" ")[0].strip()
            else:
                percentage = None
            logger.info(f"pid value:  {pid}")
            logger.info(f"quota value:  {quota}")
            logger.info(f"percentage value:  {percentage}")
            parameters = {
                "pid": pid,
                "quota": quota,
                "percentage": percentage
            }
            return parameters
        else:
            logger.info("Crash handler is not running")
            return None

    def remove_old_coredumps(self):
        Old_coredumps_before_the_remove = self.ssh_manager.executeCommandInTarget(command=f"ls /persistent/coredumps/", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        logger.info(f"Old coredumps before the remove: {Old_coredumps_before_the_remove['stdout']}")
        dumps_list = Old_coredumps_before_the_remove["stdout"].splitlines()
        for coredump in dumps_list:
            if len(dumps_list) == 0:
                break
            if coredump == "currentswversion" or coredump == "tmp":
                continue
            else:
                self.ssh_manager.executeCommandInTarget(command=f"rm -rf /persistent/coredumps/{coredump}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        Old_coredumps_after_the_remove = self.ssh_manager.executeCommandInTarget(command=f"ls /persistent/coredumps/", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        logger.info(f"Old coredumps after the remove: {Old_coredumps_after_the_remove['stdout']}")

        if "tmp" in Old_coredumps_after_the_remove['stdout']:
            tmp_Old_coredumps_before_the_remove = self.ssh_manager.executeCommandInTarget(command=f"ls /persistent/coredumps/tmp/", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
            logger.info(f"Old coredumps before the remove in tmp: {tmp_Old_coredumps_before_the_remove['stdout']}")
            dumps_list = tmp_Old_coredumps_before_the_remove["stdout"].splitlines()
            for coredump in dumps_list:
                if len(dumps_list) == 0:
                    break
                else:
                    self.ssh_manager.executeCommandInTarget(command=f"rm -rf /persistent/coredumps/tmp/{coredump}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
            tmp_Old_coredumps_after_the_remove = self.ssh_manager.executeCommandInTarget(command=f"ls /persistent/coredumps/tmp/", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
            logger.info(f"Old coredumps after the remove in tmp: {tmp_Old_coredumps_after_the_remove['stdout']}")

            if (Old_coredumps_after_the_remove['stdout'] == "currentswversion\ntmp\n" or Old_coredumps_after_the_remove['stdout'] == "currentswversion\n") and tmp_Old_coredumps_after_the_remove["stdout"] == "":
                return True
            else:
                return False
        else:
            if Old_coredumps_after_the_remove['stdout'] == "currentswversion\ntmp\n" or Old_coredumps_after_the_remove['stdout'] == "currentswversion\n":
                return True
            else:
                return False

    def context_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'context.*.txt'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of context_files" + str(len(dumps_list)))
            context_files = returnValue["stdout"].strip().split("\n")
            for context_file in context_files:
                app_name_in_context_file = context_file.split('.')[2]
                if app_name_in_context_file == app_name:
                    return True
                else:
                    continue
            return False

    def core_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'core.*.gz'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of core_files" + str(len(dumps_list)))
            core_files = returnValue["stdout"].strip().split("\n")
            for core_file in core_files:
                app_name_in_core_file = core_file.split('.')[2]
                if app_name_in_core_file == app_name:
                    return True
                else:
                    continue
            return False

    def logs_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'logs.*.gz'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of logs_files" + str(len(dumps_list)))
            logs_files = returnValue["stdout"].strip().split("\n")
            for logs_file in logs_files:
                app_name_in_logs_file = logs_file.split('.')[2]
                if app_name_in_logs_file == app_name:
                    return True
                else:
                    continue
            return False

    def stacktrace_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'stacktrace.*.txt'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of stacktrace_files" + str(len(dumps_list)))
            stacktrace_files = returnValue["stdout"].strip().split("\n")
            for stacktrace_file in stacktrace_files:
                app_name_in_stacktrace_file = stacktrace_file.split('.')[2]
                if app_name_in_stacktrace_file == app_name:
                    return True
                else:
                    continue
            return False

    def checksum_file_check(self, app_name):
        List_of_files_related_to_killed_applictaion = []
        Files_exists = False
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"cat {self.CoreDumps_Path}/checksum | grep {app_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'cat' command didn't executed successfully")
            return Files_exists
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of core dumps in checksum" + str(len(dumps_list)))
            checksum_files = returnValue["stdout"].strip().split("\n")
            # Get files related to killed application
            for checksum_file in checksum_files:
                app_name_in_core_file = checksum_file.split('.')[2]
                if app_name_in_core_file == app_name:
                    logger.info(f"C: {checksum_file}")
                    List_of_files_related_to_killed_applictaion.append(checksum_file)
                else:
                    continue
            # Check all files exists
            joined_str = "\t".join(List_of_files_related_to_killed_applictaion)
            if self.os_name == "QNX" and ("context" in joined_str) and ("core" in joined_str) and len(List_of_files_related_to_killed_applictaion) == 2:
                Files_exists = True
            if self.os_name == "Linux" and ("context" in joined_str) and ("core" in joined_str) and ("logs" in joined_str) and ("stacktrace" in joined_str) and len(List_of_files_related_to_killed_applictaion) >= 4:
                Files_exists = True
            return Files_exists

    def check_coredumps(self, app_name):
        Coredumps_created = False
        if self.os_name == "QNX":
            # context file check
            app_name_in_context_file = self.context_file_check(app_name=app_name)
            # core file check
            app_name_in_core_file = self.core_file_check(app_name=app_name)
            if app_name_in_context_file and app_name_in_core_file:
                Coredumps_created = True
        else:
            # context file check
            app_name_in_context_file = self.context_file_check(app_name=app_name)
            # core file check
            app_name_in_core_file = self.core_file_check(app_name=app_name)
            # logs file check
            app_name_in_logs_file = self.logs_file_check(app_name=app_name)
            # stacktrace file check
            app_name_in_stacktrace_file = self.stacktrace_file_check(app_name=app_name)
            if app_name_in_context_file and app_name_in_core_file and app_name_in_logs_file and app_name_in_stacktrace_file:
                Coredumps_created = True
        return Coredumps_created

    def check_no_coredumps_exists(self, coredumps):
        Coredumps_exists = False
        if self.os_name == "QNX":
            for coredump in coredumps:
                if "currentswversion" in coredump or "tmp" in coredump:
                    Coredumps_exists = True
                    continue
                else:
                    Coredumps_exists = False
                    return Coredumps_exists
        else:
            for coredump in coredumps:
                if "currentswversion" in coredump:
                    Coredumps_exists = True
                    continue
                else:
                    Coredumps_exists = False
                    return Coredumps_exists
        return Coredumps_exists
