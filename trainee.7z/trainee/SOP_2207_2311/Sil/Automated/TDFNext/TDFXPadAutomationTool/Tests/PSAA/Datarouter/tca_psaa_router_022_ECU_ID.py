from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_psaa_router_022_ECU_ID(testfixture_PSAA_Datarouter):

    TEST_ID = "PSAA\tca_psaa_router_022_ECU_ID"
    REQ_ID = ["/item/6453823"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check ECUID in the DLT Standard header according to the deployed software variant"
    STATUS = "Ready"
    OS = ['LINUX','QNX']


    def setUp(self):
        self.setPrecondition("Apply DLT filter with PP ECUID according to the deployed software variant")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.setPrecondition("Start monitoring")
        self.dlt_manager.start_monitoring()

    def test_tca_psaa_router_022_ECU_ID(self):
        self.startTestStep("Get DLT messages")
        self.sleep_for(self.WAIT_FOR_DLT_LOG_MS)
        self.startTestStep("Check ecuID according to the deployed software variant")
        msg_count, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID)
        self.expectTrue(msg_count > 0, Severity.BLOCKER, "Checking the ecuID according to the deployed software variant")

    def tearDown(self):
        self.setPostcondition("Clear all filters")
        self.dlt_manager.clear_all_filters()
        self.setPostcondition("Stop monitoring")
        self.dlt_manager.stop_monitoring()
