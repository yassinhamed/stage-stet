from Tests.PSAA.Resource_Manager.testfixture_PSAA_RM import *


class tca_mmr_read_ACL_exposed_files(testfixture_PSAA_RM):

    TEST_ID = "PSAA\Ressource_Manager\tca_mmr_read_ACL_exposed_files"
    REQ_ID = ['/item/5279968']
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    PRIORITY = "Critical"
    DESCRIPTION = "Check that the resource managers shall only set read ACL bit of the exposed files"
    STATUS = "Ready"
    OS = ['QNX']


    def setUp(self):
        pass

    def test_tca_mmr_read_ACL_exposed_files(self):

        result = self.ssh_manager.executeCommandInTarget(command=f'ls -la dev/bar/cmd',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('r--r--r--' in result['stdout'], Severity.MAJOR,"Check read bit of dev/bar/cmd ")

        result = self.ssh_manager.executeCommandInTarget(command=f'ls -la dev/bar/glreg_errpinctrl',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('r--r--r--' in result['stdout'], Severity.MAJOR, "Check read bit of dev/bar/glreg_errpinctrl ")

        result = self.ssh_manager.executeCommandInTarget(command=f'ls -la /dev/bar/glreg_gerrmsk',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('r--r--r--' in result['stdout'], Severity.MAJOR, "Check read bit of /dev/bar/glreg_gerrmsk ")

        result = self.ssh_manager.executeCommandInTarget(command=f'ls -la /dev/bar/glreg_gsysevtmsk',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('r--r--r--' in result['stdout'], Severity.MAJOR, "Check read bit of /dev/bar/glreg_gsysevtmsk ")

        result = self.ssh_manager.executeCommandInTarget(command=f'ls -la /dev/mmr/mchbar',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('r--r--r--' in result['stdout'], Severity.MAJOR, "Check read bit of /dev/mmr/mchbar ")

        result = self.ssh_manager.executeCommandInTarget(command=f'ls -la /dev/mmr/pwrmbase',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('r--r--r--' in result['stdout'], Severity.MAJOR, "Check read bit of /dev/mmr/pwrmbase ")

        result = self.ssh_manager.executeCommandInTarget(command=f'ls -la /dev/mmr/sbreg/10',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('r--r--r--' in result['stdout'], Severity.MAJOR, "Check read bit of /dev/mmr/sbreg/10 ")

        result = self.ssh_manager.executeCommandInTarget(command=f'ls -la /dev/mmr/sbreg/12',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('r--r--r--' in result['stdout'], Severity.MAJOR, "Check read bit of /dev/mmr/sbreg/12 ")

        result = self.ssh_manager.executeCommandInTarget(command=f'ls -la /dev/mmr/sbreg/10',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('r--r--r--' in result['stdout'], Severity.MAJOR, "Check read bit of /dev/mmr/sbreg/c2 ")

        result = self.ssh_manager.executeCommandInTarget(command=f'ls -la /dev/mmr/sbreg/10',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('r--r--r--' in result['stdout'], Severity.MAJOR, "Check read bit of /dev/mmr/sbreg/c5 ")

    def tearDown(self):
        pass
