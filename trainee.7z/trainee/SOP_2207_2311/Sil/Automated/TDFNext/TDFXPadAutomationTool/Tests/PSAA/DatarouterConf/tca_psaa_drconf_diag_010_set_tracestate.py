from Tests.PSAA.DatarouterConf.testfixture_PSAA_DatarouterConf import *


class tca_psaa_drconf_diag_010_set_tracestate(testfixture_PSAA_DatarouterConf):

    TEST_ID = "PSAA\tca_psaa_drconf_diag_010_set_tracestate"
    REQ_ID = ["/item/853028"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check the diag responsible on activates/deactivates the tracing in the DLT subsystem of the ECU"
    STATUS = "Ready"
    OS = ['LINUX','QNX']


    def setUp(self):
        grep_DConf = self.check_application_is_started(app_name=self.DATA_ROUTER_CONF_APP_NAME)
        self.expectTrue(grep_DConf, Severity.MAJOR, "Check The application was started")

        self.diag_manager.start()

    def test_tca_psaa_drconf_diag_010_set_tracestate(self):
        self.startTestStep("Set trace state using diag")
        res = self.diag_manager.syn_send(0xF4, self.PP_DIAG_ADR,
                                         self.STEUERN_DLT_SET_TRACESTATE)

        self.expectTrue(res == DiagResult.positive, Severity.BLOCKER, "Check the response of the diag")

    def tearDown(self):
        self.diag_manager.stop()
