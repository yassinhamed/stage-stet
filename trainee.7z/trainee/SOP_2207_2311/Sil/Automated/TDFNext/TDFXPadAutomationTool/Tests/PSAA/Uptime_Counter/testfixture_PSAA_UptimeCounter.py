from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_UptimeCounter(testfixture_PSAA):
    STATUS_UNGEWOLLTE_RESETS_STATISTIKEN = [0x22, 0x43, 0x4a]
    STEUERN_LOESCHEN_UNGEWOLLTE_RESETS_STATISTIKEN = [0x2e, 0x43, 0x4a, 0x00]
    uptimecounter_kvs_path = '/persistent/uptime_counter'
    UptimeCounter_exec_config_file_path = '/opt/uptime_counter/etc/exec_config.json'
    kvs_name = 'key_value_storage'
    MeterDrivenCounter = "MeterDrivenInMeters"
    MeterDrivenOnLastReset = "MeterDrivenOnLastReset"
    UpTimeCounter = "UpTimeInMilliSeconds"
    OperatingTime_counter = "OperatingTimeInMilliseconds"
    CP60_Uptime_counter = "CP60UptimeInMilliSeconds"
    StartupCycles_counter = "NumOperationStartupCycles"
    Unexpected_reset_counter = "NumOfUnexpectedResets"

    AD_Ready_AUS_FUNCTIONAL_PARTIAL_NETWORK = 0x19be7d

    Cyclicity_60m_MS = "3600000"
    Cyclicity_10s_MS = "10000"

    Cyclicity_30s_MS = 30000
    Wait_for_counters_incrementation_MS = 10000

    Zero_unexpected_resets = 1
    Counters_Zero_Number_of_unwanted_resets = 0
    Counters_Zero_Total_accumulated_uptime_in_milliseconds = 60000
    Counters_Zero_Total_accumulated_meters_driven = 0
    Counters_Zero_Total_accumulated_uptime_in_milliseconds_when_HAF_READY_was_available = 0

    Payload_parse_dict = {
        "Number_of_unwanted_resets" : -1,
        "Total_accumulated_uptime_in milliseconds" : -1,
        "Total_accumulated_meters_driven" : -1 ,
        "Total_accumulated_uptime_in_milliseconds_when_HAF_READY_was_available" : -1
    }

    initial_mileage = 0x100
    initial_mileage_decimal_value = 256

    New_mileage = 0x200
    New_mileage_decimal_value = 512
    
    
    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_UptimeCounter setUpclsss")
        cls.ssh_manager.executeCommandInTarget("ls /opt/uptime_counter/bin")
        cls.ssh_manager.executeCommandInTarget("ls /opt/uptime_counter/etc")

        grep_file_exist = cls.ssh_manager.executeCommandInTarget(command=f"ls {cls.uptimecounter_kvs_path} |grep {cls.kvs_name}", timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
        cls.assertTrue(cls.kvs_name in grep_file_exist["stdout"], Severity.MAJOR, f"check key_value_storage is not present under {cls.uptimecounter_kvs_path}")
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_tests_group_path(),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_UptimeCounter tearDownclsss")

    def setUp(self):
        grep_uptime_counter = self.check_application_is_started(app_name=self.UPTIME_COUNTER_APP_NAME)
        self.assertTrue(grep_uptime_counter, Severity.MAJOR, "Check The application was started")

    def tearDown(self):
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_test_case_path(), check_empty=False,ip_address=self.PP_IP,ignored_files=["currentswversion", "tmp"])

    def Convert_to_dec(self,counters_values):
        dec = int(' '.join(counters_values).replace(' ', ''), 16)
        return dec

    def get_Counter_values(self, stdout_kvs, counter_name):
        values = stdout_kvs.strip().split(counter_name)[1].split("}")[0].split(",\"data\":")[1]
        return values

    def payload_to_dic(self, payload):
        list_of_counters = payload.split('43 4a')[1].split(' ')
        self.Payload_parse_dict["Number_of_unwanted_resets"] = self.Convert_to_dec(list_of_counters[1:3])
        self.Payload_parse_dict["Total_accumulated_uptime_in milliseconds"] = self.Convert_to_dec(list_of_counters[3:8])
        self.Payload_parse_dict["Total_accumulated_meters_driven"] = self.Convert_to_dec(list_of_counters[8:12])
        self.Payload_parse_dict["Total_accumulated_uptime_in_milliseconds_when_HAF_READY_was_available"] = self.Convert_to_dec(list_of_counters[12:17])
        return self.Payload_parse_dict

    def get_values_list(self,counter_name):
        i = 0
        values_list = []
        while i<30 :
            grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}",
                                                                    timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
            value = grep_kvs_file["stdout"].strip().split(counter_name)[1].split("}")[0].split(",\"data\":")[1]
            values_list.append(int(value))
            self.sleep_for(1000)
            i = i+1
        return values_list

    def get_delta_time_list(self,values_list):
        delta_time_list = []
        indexes_list = []
        for i in range(len(values_list) - 1):
            if values_list[i] != values_list[i + 1]:
                indexes_list.append(values_list.index(values_list[i + 1]))
        for i in range(len(indexes_list)-1):
            delta_time = indexes_list[i + 1] - indexes_list[i]
            delta_time_list.append(delta_time)
        return delta_time_list


    def check_delta_time(self,delta_time_list,cyclicity):
        min_value = (int(cyclicity) - 0.1 * int(cyclicity)) / 1000 - 3  # 3 is tolerance due to infra Apis
        max_value = (int(cyclicity) + 0.1 * int(cyclicity)) / 1000

        for delta_time in delta_time_list:
            if not (min_value <= delta_time <= max_value):
                return False

        return True


    def create_uptime_counter_exec_config_backup(cls):
        returnValue = cls.ssh_manager.executeCommandInTarget(
            command="cp /opt/uptime_counter/etc/exec_config.json /opt/uptime_counter/etc/exec_config_backup.json", ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        return returnValue['exec_recv'] == 0

    def set_default_uptime_counter_exec_config(cls):
        grep_backup_file = cls.ssh_manager.executeCommandInTarget(command="ls /opt/uptime_counter/etc/ | grep 'exec_config_backup.json'",ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        if not ('exec_config_backup.json' in grep_backup_file["stdout"]):
            return grep_backup_file['exec_recv'] == 0

        returnValue = cls.ssh_manager.executeCommandInTarget(command="rm /opt/uptime_counter/etc/exec_config.json && mv /opt/uptime_counter/etc/exec_config_backup.json /opt/uptime_counter/etc/exec_config.json",
                                                             ip_address=cls.PP_IP, timeout=cls.SSH_CONNECTION_TIMEOUT_MS)
        return returnValue['exec_recv'] == 0


    def get_cyclicity_from_exec_config(cls):
        cyclicity = cls.json_manager.findNodeFromJsonFile(filePath="/opt/uptime_counter/etc/exec_config.json",nodePath="processes[0].startupConfigs[0].options[1]",
                                                            use_cache=False, delete_cache=True)
        return cyclicity


    def change_cyclicity(cls,new_cyclicity):
        cls.json_manager.updateNodeIntoJsonFile(filePath="/opt/uptime_counter/etc/exec_config.json",nodePath="processes[0].startupConfigs[0].options[1]",
                                                 value=new_cyclicity,use_cache=False, delete_cache=True, upload_file=True)

