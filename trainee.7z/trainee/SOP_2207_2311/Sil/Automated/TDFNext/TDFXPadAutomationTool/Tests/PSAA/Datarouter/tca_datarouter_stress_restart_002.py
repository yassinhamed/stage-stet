from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_datarouter_stress_restart_002(testfixture_PSAA_Datarouter):

    TEST_ID = "Datarouter\tca_datarouter_stress_restart_002"
    REQ_ID = ["/item/1573713", "/item/145159"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        pass

    def test_tca_datarouter_stress_restart_002(self):
        i = 1
        while i < 10:
            self.startTestStep("Get the PID of datarouter")
            datarouter_pid_initial = self.get_process_id(app_name=self.DATA_ROUTER_APP_NAME, exclude=True, exclude_app_name="conf")

            logger.info("###########datarouter_pid_initial############")
            logger.info(str(datarouter_pid_initial))
            logger.info("#######################")
            self.assertTrue(datarouter_pid_initial != -1, Severity.BLOCKER, "Checking that the pid of datarouter is returned successfully")

            self.startTestStep("Kill datarouter")
            datarouter_is_killed = self.kill_application(app_name=self.DATA_ROUTER_APP_NAME,signal=self.killall_options["SIGABRT"])
            self.expectTrue(datarouter_is_killed, Severity.MAJOR, "Checking that datarouter is killed")

            self.sleep_for(self.KILL_TIMEOUT_MS)

            self.startTestStep("Get the PID of datarouter")
            datarouter_pid_post_kill = self.get_process_id(app_name=self.DATA_ROUTER_APP_NAME, exclude=True, exclude_app_name="conf")

            logger.info("###########datarouter_pid_post_kill############")
            logger.info(str(datarouter_pid_post_kill))
            logger.info("#######################")

            self.assertTrue(datarouter_pid_post_kill != -1, Severity.BLOCKER, "Checking that the pid of datarouter is returned successfully")
            self.assertTrue(datarouter_pid_post_kill > datarouter_pid_initial, Severity.BLOCKER, "Checking that the new pid is bigger then old pid.")

            i += 1

    def tearDown(self):
        pass
