from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_011_check_time_crash(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_011_check_time_crash"
    REQ_ID = ["/item/1736864","/item/1736931"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check the crash time in coredumps file"
    STATUS = "Ready"
    OS = ['LINUX']



    def setUp(self):
        pass

    def test_tca_psaa_dumper_011_check_time_crash(self):

        self.startTestStep("Kill application ETS")
        ets_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(ets_is_killed, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

        self.startTestStep("Check application is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is not running")

        self.startTestStep("check coredumps created")
        coredumps_created = self.check_coredumps(self.ETS_APP_NAME)
        self.assertTrue(coredumps_created,Severity.BLOCKER,"Checking that coredumps files were created properly.")

        self.startTestStep("Get context files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'context.*.txt'", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Check 'ls | grep' command is executed")
        context_files = returnValue["stdout"].strip().split("\n")
        dump_file = context_files[0].split('.')

        self.startTestStep("Get system time from context")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"cat {self.CoreDumps_Path}/context.* |  grep 'system time'", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Check the existance of the result")
        time_c=returnValue["stdout"].split('(')[2].split(' ')[3]
        time_crash=round(round(float(time_c.split('.')[0]), 1))

        self.expectTrue(int(dump_file[1]) < time_crash + 5 or int(dump_file[1]) > time_crash - 5, Severity.MAJOR, f"Check time of crash from file name {dump_file[1]} is equal to the time crash inside the file {time_crash}")

    def tearDown(self):
        pass
