from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_network_06_NETP_IP_statistics(testfixture_PSAA_SysMon):
    TEST_ID = "PSAA/SysMon/tca_sysmon_network_06_NETP_IP_statistics"
    REQ_ID = ["/item/5909511"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that the NETP IP reports contains all required statistics"
    OS = ['LINUX', 'QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.network_protocols_statistics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["Network"]["TCP"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.network_protocols_statistics_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_network_06_NETP_IP_statistics(self):
        self.startTestStep("Wait cycle of NETP * 2")
        self.sleep_for(self.time_interval * 2)
        self.startTestStep("Get NETS DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that NETP DLT messages are available")

        self.startTestStep("Get in_receives value")
        in_receives = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.in_receives")
        self.expectTrue(in_receives != self.INVALID_VALUE, Severity.MAJOR, "Check that in_receives is reported")

        self.startTestStep("Get in_hdr_errors value")
        in_hdr_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.in_hdr_errors")
        self.expectTrue(in_hdr_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that in_hdr_errors is reported")

        self.startTestStep("Get in_discards value")
        in_discards = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.in_discards")
        self.expectTrue(in_discards != self.INVALID_VALUE, Severity.MAJOR, "Check that in_discards is reported")

        self.startTestStep("Get in_delivers value")
        in_delivers = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.in_delivers")
        self.expectTrue(in_delivers != self.INVALID_VALUE, Severity.MAJOR, "Check that in_delivers is reported")

        self.startTestStep("Get out_requests value")
        out_requests = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.out_requests")
        self.expectTrue(out_requests != self.INVALID_VALUE, Severity.MAJOR, "Check that out_requests is reported")

        self.startTestStep("Get out_discards value")
        out_discards = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.out_discards")
        self.expectTrue(out_discards != self.INVALID_VALUE, Severity.MAJOR, "Check that out_discards is reported")

        self.startTestStep("Get out_no_routes value")
        out_no_routes = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.out_no_routes")
        self.expectTrue(out_no_routes != self.INVALID_VALUE, Severity.MAJOR, "Check that out_no_routes is reported")

        self.startTestStep("Get reasm_oks value")
        reasm_oks = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.reasm_oks")
        self.expectTrue(reasm_oks != self.INVALID_VALUE, Severity.MAJOR, "Check that reasm_oks is reported")

        self.startTestStep("Get frag_oks value")
        frag_oks = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.frag_oks")
        self.expectTrue(frag_oks != self.INVALID_VALUE, Severity.MAJOR, "Check that frag_oks is reported")

        self.startTestStep("Get frag_fails value")
        frag_fails = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.frag_fails")
        self.expectTrue(frag_fails != self.INVALID_VALUE, Severity.MAJOR, "Check that frag_fails is reported")

        self.startTestStep("Get frag_creates value")
        frag_creates = self.get_statistic_value(message=messages[0], statistic_path="Network.IP.Statistics.frag_creates")
        self.expectTrue(frag_creates != self.INVALID_VALUE, Severity.MAJOR, "Check that frag_creates is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
