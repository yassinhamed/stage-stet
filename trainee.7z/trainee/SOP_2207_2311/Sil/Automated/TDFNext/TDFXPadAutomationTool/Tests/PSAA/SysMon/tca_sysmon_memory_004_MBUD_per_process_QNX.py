from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_004_MBUD_per_process_QNX(testfixture_PSAA_SysMon):
    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_004_MBUD_per_process_QNX"
    REQ_ID = ["/item/6343130"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon is reporting RAM comsumption per process"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.budget_report_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array_part1 = self.statistic_data["Memory"]["mbud_per_process1_qnx"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array_part1}")
        self.assertTrue(self.search_msg_array_part1 is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.search_msg_array_part2 = self.statistic_data["Memory"]["mbud_per_process2_qnx"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array_part2}")
        self.assertTrue(self.search_msg_array_part2 is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.budget_report_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_memory_004_MBUD_per_process_QNX(self):
        self.startTestStep("Wait cycle * 2")
        self.sleep_for(self.time_interval * 2)
        
        self.startTestStep("Get MBUD perprocess1 DLT messages")
        message_count1, messages1 = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array_part1)
        self.assertTrue(message_count1 > 0, Severity.MAJOR, "Check that MBUD perprocess1 DLT messages are available")

        self.startTestStep("Get rss value")
        rss = self.get_statistic_value(message=messages1[0], statistic_path="Memory.mbud_per_process1_qnx.Statistics.rss")
        self.expectTrue(rss != self.INVALID_VALUE, Severity.MAJOR, "Check that rss is reported")

        self.startTestStep("Get uss value")
        uss = self.get_statistic_value(message=messages1[0], statistic_path="Memory.mbud_per_process1_qnx.Statistics.uss")
        self.expectTrue(uss != self.INVALID_VALUE, Severity.MAJOR, "Check that uss is reported")

        self.startTestStep("Get shm value")
        shm = self.get_statistic_value(message=messages1[0], statistic_path="Memory.mbud_per_process1_qnx.Statistics.shm")
        self.expectTrue(shm != self.INVALID_VALUE, Severity.MAJOR, "Check that shm is reported")

        self.startTestStep("Get MBUD perprocess2 DLT messages")
        message_count2, messages2 = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array_part2)
        self.assertTrue(message_count2 > 0, Severity.MAJOR, "Check that MBUD total2 DLT messages are available")
        
        self.startTestStep("Get vmsize value")
        vmsize = self.get_statistic_value(message=messages2[0], statistic_path="Memory.mbud_per_process2_qnx.Statistics.vmSize")
        self.expectTrue(vmsize != self.INVALID_VALUE, Severity.MAJOR, "Check that vmsize is reported")


    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
