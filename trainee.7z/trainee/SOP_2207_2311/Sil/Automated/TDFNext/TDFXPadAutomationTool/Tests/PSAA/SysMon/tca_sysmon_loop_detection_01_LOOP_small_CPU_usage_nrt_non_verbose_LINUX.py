from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_loop_detection_01_LOOP_small_CPU_usage_nrt_non_verbose_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_loop_detection_01_LOOP_small_CPU_usage_nrt_non_verbose_LINUX"
    REQ_ID = ["/item/5911101", "/item/5979602"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon does not report non real time inifinte loop that not exceed the configured CPU threshold in non-verbose mode"
    OS = ['LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Upload infinite binary under /persistent")
        self.setPrecondition("Add execute permission to infinite binary")
        self.setPrecondition("ls -la /persistent | grep infinite")
        self.assertTrue(True, Severity.MAJOR, "Check that binary exist under /persistent and has execute permission")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        # TODO add message id
        self.dlt_manager.apply_filter(messageId="")
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_loop_detection_01_LOOP_small_CPU_usage_nrt_non_verbose_LINUX(self):
        # TODO add message short name
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name="", sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Get configured CPU threshold")
        self.assertTrue(True, Severity.MAJOR, "Check that configured threshold is retrieved")
        self.startTestStep("Set big CPU threshold")
        self.startTestStep("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.startTestStep("Execute infinite binary using cd /persistent && ./infinite  with one thread and big wait time to decrease cpu usage")
        self.startTestStep("Wait the configured time for loop detection * 2")
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get LOOP non-verbose DLT messages")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(True, Severity.MAJOR, "Check that no DLT message for inifinite binary exist")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.setPostcondition("Revert config file")
        self.setPostcondition("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
