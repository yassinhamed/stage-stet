from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_loop_detection_01_LOOP_big_CPU_usage_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_loop_detection_01_LOOP_big_CPU_usage_QNX"
    REQ_ID = ["/item/5910322"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports inifinte loop that exceed the configured CPU threshold"
    OS = ['QNX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.loop_detection_rt_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.Search_msg_array = self.statistic_data["LOOP"]["RT"]["Search_msg_array"]
        logger.info(f"Search message array = {self.Search_msg_array}")
        self.assertTrue(self.Search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.loop_detection_rt_context_id)

    def test_tca_sysmon_loop_detection_01_LOOP_big_CPU_usage_QNX(self):
        self.startTestStep("Execute yes command to made RT loop")
        command_is_executed = self.ssh_manager.executeCommandInTargetNoWait(command=f"while true; do echo yes > /dev/null; done &", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        #self.expectTrue(command_is_executed["exec_recv"] == 0, Severity.MAJOR, "Check that yes command is executed")

        self.startTestStep("Wait the configured time for loop detection * 2")
        self.sleep_for(self.time_interval * 2)
        self.startTestStep("Get LOOP DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.Search_msg_array)
        logger.info(f"dlt messages: {messages}")
        self.expectTrue(message_count > 0, Severity.MAJOR, "Check that DLT message of LOOP exist")
        self.expectTrue(True, Severity.MAJOR, "Check that DLT message are reported for thread of infinite process")
        self.expectTrue(True, Severity.MAJOR, "Check thatDLT message contains thread name")
        self.expectTrue(True, Severity.MAJOR, "Check thatDLT message contains used CPU time")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.setPostcondition("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.setPostcondition("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
