from Tests.PSAA.Resource_Manager.testfixture_PSAA_RM import *


class tca_mmr_root_file_system(testfixture_PSAA_RM):

    TEST_ID = "PSAA\tca_mmr_root_file_system"
    REQ_ID = ["/item/5280160"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check MMR resource manager is deployed to the root file system /opt"
    OS = ["QNX"]
    STATUS = "Ready"

    def setUp(self):
        pass

    def test_tca_mmr_root_file_system(self):

        check_root_file_system_command = "ls /opt | grep mmr_reader"
        check_root_file_system = self.ssh_manager.executeCommandInTarget(command=check_root_file_system_command,timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(check_root_file_system["stdout"].strip() != "", Severity.BLOCKER,"Check MMR resource manager is deployed to the root file sysytem /opt")

    def tearDown(self):

        pass
