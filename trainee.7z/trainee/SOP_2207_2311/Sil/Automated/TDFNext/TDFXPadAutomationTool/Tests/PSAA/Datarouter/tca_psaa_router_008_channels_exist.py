from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_psaa_router_008_channels_exist(testfixture_PSAA_Datarouter):

    TEST_ID = "PSAA\tca_psaa_router_008"
    REQ_ID = ["/item/1573751", "/item/145159"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX','QNX']

    def setUp(self):
        self.setPrecondition("Checking log-channels.json file exist under datarouter")
        returnValue = self.ssh_manager.executeCommandInTarget(command=r"ls /opt/{0}/etc | grep -c 'log-channels.json'".format(self.DATA_ROUTER_APP_NAME), timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", "Checking that DataRouter contains a log-channels.json file")

    def test_datarouter_channels_exist(self):
        self.startTestStep("Get the channels from log-channels.json")
        channels = self.json_manager.getInfoFromJsonFile(filePath=self.channels_file_path, valuePath="channels", use_cache=False, delete_cache=False)
        self.assertTrue(channels, Severity.BLOCKER, "Checking that log-channels.json file contains a valid channels")

        self.assertTrue("LOW" in channels, Severity.BLOCKER, "Checking that log-channels.json file contains a valid channels")
        self.expectTrue("channelThreshold" in channels["LOW"], Severity.BLOCKER, "Checking that LOW channel contains a valid channelThreshold")
        self.expectTrue("dstAddress" in channels["LOW"], Severity.BLOCKER, "Checking that LOW channel contains a valid dstAddress")
        self.expectTrue("dstPort" in channels["LOW"], Severity.BLOCKER, "Checking that LOW channel contains a valid dstPort")
        self.expectTrue("ecu" in channels["LOW"], Severity.BLOCKER, "Checking that LOW channel contains a valid ecu")
        self.expectTrue("port" in channels["LOW"], Severity.BLOCKER, "Checking that LOW channel contains a valid port")

        self.assertTrue("HIGH" in channels, Severity.BLOCKER, "Checking that log-channels.json contains a valid channels")
        self.expectTrue("channelThreshold" in channels["HIGH"], Severity.BLOCKER, "Checking that LOW channel contains a valid channelThreshold")
        self.expectTrue("dstAddress" in channels["HIGH"], Severity.BLOCKER, "Checking that LOW channel contains a valid dstAddress")
        self.expectTrue("dstPort" in channels["HIGH"], Severity.BLOCKER, "Checking that LOW channel contains a valid dstPort")
        self.expectTrue("ecu" in channels["HIGH"], Severity.BLOCKER, "Checking that LOW channel contains a valid ecu")
        self.expectTrue("port" in channels["HIGH"], Severity.BLOCKER, "Checking that LOW channel contains a valid port")

    def tearDown(self):
        pass
