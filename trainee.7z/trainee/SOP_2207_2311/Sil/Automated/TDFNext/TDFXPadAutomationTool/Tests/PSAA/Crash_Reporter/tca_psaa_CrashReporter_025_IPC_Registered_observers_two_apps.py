from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter_With_Proxy_App import *


class tca_psaa_CrashReporter_025_IPC_Registered_observers_two_apps(testfixture_PSAA_Crash_Reporter_With_Proxy_App):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_025_IPC_Registered_observers_two_apps"
    REQ_ID = ["/item/6566027"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check IPC coredump notification of two apps kill is sent to registered observers"
    STATUS = "Obsolete"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Clear old core dumps")
        self.expectTrue(True, Severity.MAJOR, "Check the remove of old coredumps is done")
        self.setPrecondition("Check crash reporter is running")
        self.expectTrue(True, Severity.MAJOR, "Check that crash reporter is running")
        self.setPrecondition("Import proxy app library")

    def test_tca_psaa_CrashReporter_025_IPC_Registered_observers_two_apps(self):
        self.startTestStep("Subscribe to IPC event using proxy app")
        self.startTestStep("Get pid of the first application to be killed")
        self.assertTrue(True, Severity.MAJOR, "Check the first application is running")
        self.startTestStep("Kill first application")
        self.expectTrue(True, Severity.MAJOR, "Check the kill command is executed")
        self.startTestStep("Get pid of the second application to be killed")
        self.assertTrue(True, Severity.MAJOR, "Check the second application is running")
        self.startTestStep("Kill second application")
        self.expectTrue(True, Severity.MAJOR, "Check the kill command is executed")
        self.startTestStep("Wait for coredumps creation")
        self.startTestStep("Check first application is killed")
        self.assertTrue(True, Severity.MAJOR, "Check the first application is killed")
        self.startTestStep("Check second application is killed")
        self.assertTrue(True, Severity.MAJOR, "Check the second application is killed")
        self.startTestStep("Get coredumps names using ls command")
        self.expectTrue(True, Severity.MAJOR, "Check the context file of first app is created successfully under /persistent/coredumps")
        self.expectTrue(True, Severity.MAJOR, "Check the core file of first app is created successfully under /persistent/coredumps")
        self.expectTrue(True, Severity.MAJOR, "Check the context file of second app is created successfully under /persistent/coredumps")
        self.expectTrue(True, Severity.MAJOR, "Check the core file is of second app created successfully under /persistent/coredumps")
        self.startTestStep("Get IPC coredump notification")
        self.assertTrue(True, Severity.MAJOR, "Check IPC coredump notifications of two apps are sent")
        self.assertTrue(True, Severity.MAJOR, "Check IPC coredump notifications of two apps contains the PID of the crashed process")

    def tearDown(self):
        self.setPostcondition("Remove proxy app library")
        self.setPostcondition("Reset ECU")
