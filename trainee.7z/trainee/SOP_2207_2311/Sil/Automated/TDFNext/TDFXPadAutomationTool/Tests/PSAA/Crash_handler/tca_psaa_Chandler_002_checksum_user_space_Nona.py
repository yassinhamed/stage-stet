from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_002_checksum_user_space_Nona(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_002_checksum_user_space_Nona"
    REQ_ID = ["/item/2593168"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps of non adaptive app are created properly and checksum file contains coredumps files names and check coredumps format"
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    default_check_empty = False

    def setUp(self):
        pass

    def test_tca_psaa_Chandler_002_checksum_user_space_Nona(self):
        self.startTestStep("Get pid of the application to be killed")
        XPC_pid = self.get_process_id(app_name=self.XPC_APP_NAME)
        self.assertTrue(XPC_pid != -1, Severity.MAJOR, "Check the application is running")
        self.startTestStep("kill XPC app")
        application_is_killed = self.kill_application(app_name=self.XPC_APP_NAME, signal=self.killall_options["SIGABRT"])
        self.assertTrue(application_is_killed, Severity.MAJOR, "Checking that Linux command executed successfully")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.startTestStep("Get coredumps files names")
        self.assertTrue(self.check_coredumps(app_name=self.XPC_APP_NAME), Severity.BLOCKER, f"Checking that coredumps files were created properly and coredumps format is right")
        self.startTestStep("check XPC exist in checksum file")
        self.assertTrue(self.checksum_file_check(app_name=self.XPC_APP_NAME), Severity.BLOCKER, f"Checking that coredump files are listed correctly in checksum")

    def tearDown(self):
        self.setPostcondition("Reset safety")
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_MS)
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)
