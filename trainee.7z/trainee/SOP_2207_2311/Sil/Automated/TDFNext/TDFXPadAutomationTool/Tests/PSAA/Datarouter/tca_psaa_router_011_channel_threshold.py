from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter_ProxyApp import *


class tca_psaa_router_011_channel_threshold(testfixture_PSAA_Datarouter_ProxyApp):

    TEST_ID = "PSAA\tca_psaa_router_011_channel_threshold"
    REQ_ID = ["/item/1573751", "/item/1573764", "/item/1633236", "/item/1633238", "/item/145159"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX','QNX']

    
    def setUp(self):
        self.setPrecondition("Set channelThreshold in log-channels.json file")
        exitCode = self.json_manager.setInfoToJsonFile(filePath=self.log_channels_file_path+self.log_channels_file, valuePath="channels.HIGH.channelThreshold", value="kInfo")
        self.setPrecondition("Set the log manifest")
        exitCode, json_is_changed, message = self.proxy_app_settings.set_logging_manifest(logLevel=self.Log_levels["verbose"], logMode=self.Log_modes["remote"])
        self.assertTrue(exitCode, Severity.BLOCKER, "Check the log manifest is set")

        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECU_status = self.check_ECUs()
        self.expectTrue(ECU_status, Severity.BLOCKER, "Checking that ECU status is OK")

        exitCode, message = self.proxy_app_settings.check_logging_manifest(logLevel=self.Log_levels["verbose"], logMode=self.Log_modes["remote"])
        self.assertTrue(exitCode, Severity.BLOCKER, "Check the log manifest is set")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.ARA_LOG.value)
        self.setPrecondition("Create logger with context id CTX1")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.CREATE_LOGGER, contextId=self.set_contextId_CTX1, ctxDescription="Log CTX1")
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the creation of logger")

        self.dlt_manager.apply_filter(appId=self.PROXY_APP_APP_ID)
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_datarouter_channel_threshold(self):
        self.startTestStep("Append log messages with log level debug")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.APPEND_LOG, argType=araLogType.LOG_ARGS_TYPE_STRING, argVal=self.set_argVal_debug_011)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the append of the message")
        self.startTestStep("Log the message")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.LOG_DEBUG, contextId=self.set_contextId_CTX1)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the log of the message")
        self.startTestStep("Append log messages with log level info")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.APPEND_LOG, argType=araLogType.LOG_ARGS_TYPE_STRING, argVal=self.set_argVal_info_011)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the append of the message")
        self.startTestStep("Log the message")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.LOG_INFO, contextId=self.set_contextId_CTX1)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the log of the message")

        self.startTestStep("wait for Logging")
        self.sleep_for(self.wait_for_dlt_log)

        self.startTestStep("Get DLT message related to log level debug")
        messages_count, messages_array = self.dlt_manager.wait_for_message(ecuId=self.PP_ECUID, contextId=self.set_contextId_CTX1, search_message=self.set_argVal_debug_011, timeout=10)
        self.expectTrue(messages_count == 0, Severity.BLOCKER, "Check messages are not logged")
        logger.info("Messages Count = " + str(messages_count))
        self.startTestStep("Get DLT message related to log level info")
        messages_count, messages_array = self.dlt_manager.wait_for_message(ecuId=self.PP_ECUID, contextId=self.set_contextId_CTX1, search_message=self.set_argVal_info_011, timeout=30)
        self.expectTrue(messages_count == 1, Severity.BLOCKER, "Check messages are logged")
        logger.info("Messages Count = " + str(messages_count))
        for message in messages_array:
            self.assertTrue(message.get("extendedHeader").get("MessageTypeInfo") == dltLogLevel.DLT_LOG_INFO.value, Severity.BLOCKER, "Checking the MessageTypeInfo")
            logger.info("Current MessageTypeInfo = " + str(message.get("extendedHeader").get("MessageTypeInfo")))

    def tearDown(self):
        pass
