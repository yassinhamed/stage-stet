from Tests.PSAA.testfixture_PSAA import *
from TDFNextApi.time import xtime

class testfixture_PSAA_SysMon(testfixture_PSAA):

    """
    message short name = message id
    bmw_platform_sysmon_cpu_CoreMetrics = 74
    bmw_platform_sysmon_cpu_ProcessMetrics = 75
    bmw_platform_sysmon_cpu_SystemMetrics = 76
    bmw_platform_sysmon_memory_PagesTotalMetrics = 77
    bmw_platform_sysmon_memory_ProcessPageTotal = 78
    bmw_platform_sysmon_memory_ProcessTotalMetrics = 79
    bmw_platform_sysmon_memory_SystemTotalMetrics = 80
    bmw_platform_sysmon_netprotocol_TcpProtocolInfo = 82
    bmw_platform_sysmon_netprotocol_UdpProtocolInfo = 83
    bmw_platform_sysmon_netprotocol_IpProtocolInfo = 84
    bmw_platform_sysmon_netprotocol_IcmpProtocolInfo = 85
    bmw_platform_sysmon_netstat_NetAdapterStatInfo = 86
    bmw_platform_sysmon_netstat_NetSoftStatInfo = 87
    bmw_platform_sysmon_temperature_TemperatureCpuCore = 114
    bmw_platform_sysmon_blkInfoData_t_blkDevice_t = 8650831
    bmw_platform_sysmon_blkInfoData_t_fsStats_t = 8650832
    bmw_platform_sysmon_blkInfoData_t = 8650833
    bmw_platform_sysmon_cpuData_coreData = 8650834
    bmw_platform_sysmon_cpuData_threadData = 8650835
    bmw_platform_sysmon_cpuData = 8650836
    bmw_platform_sysmon_domainInstData_t_csvProcRss_t = 8650837
    bmw_platform_sysmon_domainInstData_t_negativeCpu_t = 8650838
    bmw_platform_sysmon_domainInstData_t_domainPerformance_t = 8650839
    bmw_platform_sysmon_domainInstData_t = 8650840
    bmw_platform_sysmon_emmcData_t = 8650841
    bmw_platform_sysmon_eyeqTempStatus = 8650842
    bmw_platform_sysmon_memBudgetData_t_rssMemory_t = 8650843
    bmw_platform_sysmon_memBudgetData_t_shm_seg_id = 8650844
    bmw_platform_sysmon_memBudgetData_t = 8650845
    bmw_platform_sysmon_memCGroupData_t_memInfoStr_t = 8650846
    bmw_platform_sysmon_memCGroupData_t_memCGroup_t = 8650847
    bmw_platform_sysmon_memCGroupData_t = 8650848
    bmw_platform_sysmon_memInfoData_t_memAllocInfo_t = 8650849
    bmw_platform_sysmon_memInfoData_t = 8650850
    bmw_platform_sysmon_memInterfaceData_t = 8650851
    bmw_platform_sysmon_netLinkData_t_netLinkPid_t = 8650852
    bmw_platform_sysmon_netLinkData_t = 8650853
    bmw_platform_sysmon_netStatData_t_adapterStat_t = 8650854
    bmw_platform_sysmon_netStatData_t = 8650855
    bmw_platform_sysmon_netStatProcInst_t_procNetStats_t = 8650856
    bmw_platform_sysmon_netStatProcInst_t = 8650857
    bmw_platform_sysmon_singleSoftIrqData_t = 8650858
    bmw_platform_sysmon_softIrqsData_t = 8650859
    bmw_platform_sysmon_emmclib_EmmcData = 8650860
    bmw_platform_sysmon_process_ProcessCreationMetrics = 119
    bmw_platform_sysmon_process_ProcessDeathMetrics = 120
    """

    non_verbose_message_id_of_CPUS_1 = 8650835
    non_verbose_message_id_of_NETS_1 = 8650854
    non_verbose_message_id_of_THRD = 8650852
    non_verbose_message_id_of_IRQS = 8650858

    non_verbose_message_id_of_HLT = 122
    non_verbose_message_id_of_BLK_IO = 8650831
    non_verbose_message_id_of_BLK_FS = 8650832
    non_verbose_message_id_of_NETS_2 = 86
    non_verbose_message_id_of_NETP_TCP = 82
    non_verbose_message_id_of_NETP_UDP = 83
    non_verbose_message_id_of_NETP_IP = 84
    non_verbose_message_id_of_NETP_ICMP = 85
    non_verbose_message_id_of_CPUC = 74
    non_verbose_message_id_of_CPUP = 75
    non_verbose_message_id_of_CPUS = 76
    non_verbose_message_id_of_LLED = 114
    non_verbose_message_id_of_PMON_creation = 119
    non_verbose_message_id_of_PMON_death = 120
    non_verbose_message_id_of_MBUD_totals = 77
    non_verbose_message_id_of_MBUD_per_process = 78
    non_verbose_message_id_of_MEMS_per_process = 79
    non_verbose_message_id_of_MEMS_totals = 80
    non_verbose_message_id_of_EMMC_erase_count_samsung = 126
    non_verbose_message_id_of_EMMC_erase_count_micron = 125


    wait_for_iotd_message_MS = 60000


    non_verbose_message_short_name_of_CPUS_1 = "bmw_platform_sysmon_cpuData_threadData"
    non_verbose_message_short_name_of_MBUD = "bmw_platform_sysmon_memBudgetData_t_shm_seg_id"
    non_verbose_message_short_name_of_NETS_1 = "bmw_platform_sysmon_netStatData_t_adapterStat_t"
    non_verbose_message_short_name_of_THRD = "bmw_platform_sysmon_netLinkData_t_netLinkPid_t"
    non_verbose_message_short_name_of_IRQS = "bmw_platform_sysmon_singleSoftIrqData_t"
    non_verbose_message_short_name_of_HLT = "bmw_platform_sysmon_version_VersionInfo"
    non_verbose_message_short_name_of_BLK_IO = "bmw_platform_sysmon_blkInfoData_t_blkDevice_t"
    non_verbose_message_short_name_of_BLK_FS = "bmw_platform_sysmon_blkInfoData_t_fsStats_t"
    non_verbose_message_short_name_of_NETS_2 = "bmw_platform_sysmon_netstat_NetAdapterStatInfo"
    non_verbose_message_short_name_of_NETP_TCP = "bmw_platform_sysmon_netprotocol_TcpProtocolInfo"
    non_verbose_message_short_name_of_NETP_UDP = "bmw_platform_sysmon_netprotocol_UdpProtocolInfo"
    non_verbose_message_short_name_of_NETP_IP = "bmw_platform_sysmon_netprotocol_IpProtocolInfo"
    non_verbose_message_short_name_of_NETP_ICMP = "bmw_platform_sysmon_netprotocol_IcmpProtocolInfo"
    non_verbose_message_short_name_of_CPUC = "bmw_platform_sysmon_cpu_CoreMetrics"
    non_verbose_message_short_name_of_CPUP = "bmw_platform_sysmon_cpu_ProcessMetrics"
    non_verbose_message_short_name_of_CPUS = "bmw_platform_sysmon_cpu_SystemMetrics"
    non_verbose_message_short_name_of_LLED = "bmw_platform_sysmon_temperature_TemperatureCpuCore"
    non_verbose_message_short_name_of_PMON_creation = "bmw_platform_sysmon_process_ProcessCreationMetrics"
    non_verbose_message_short_name_of_PMON_death = "bmw_platform_sysmon_process_ProcessDeathMetrics"
    non_verbose_message_short_name_of_MBUD_totals = "bmw_platform_sysmon_memory_PagesTotalMetrics"
    non_verbose_message_short_name_of_MBUD_per_process = "bmw_platform_sysmon_memory_ProcessPageTotal"
    non_verbose_message_short_name_of_MEMS_totals = "bmw_platform_sysmon_memory_SystemTotalMetrics"
    non_verbose_message_short_name_of_MEMS_per_process = "bmw_platform_sysmon_memory_ProcessTotalMetrics"
    non_verbose_message_short_name_of_EMMC_erase_count_samsung = "bmw_platform_sysmon_emmclib_SamsungEraseCountMetrics"
    non_verbose_message_short_name_of_EMMC_erase_count_micron = "bmw::platform::sysmon::emmclib::MicronEraseCountMetrics"


    eth0_interface = "eth0"
    vlan_interface = "eth0.73"

    IOTD_threshold = 10

    #network
    network_statistic_context_id = "NETS"
    network_protocols_statistics_context_id = "NETP"
    #disk
    emmc_health_report_context_id = "EMMC"
    blk_context_id = "BLK"
    thread_io_statistics_context_id = "IOTD"
    #margin
    DDR_margin_context_id = "DDR"
    #scheduling delay (linux)
    real_time_scheduling_delay_context_id = "SDRT"
    non_real_time_scheduling_delay_context_id = "SCHD"
    #domain reporting (linux)
    domain_reporting_memory_context_id = "DOMM"
    domain_reporting_cpu_context_id = "DOMC"
    #version
    version_context_id = "HLT"
    #CPU
    CPU_system_context_id = "CPUS"
    IOWAIT_system_context_id = "CPUS"
    CPU_core_context_id = "CPUC"
    IOWAIT_core_context_id = "CPUC"
    process_cpu_usage_context_id = "CPUP"
    thread_cpu_usage_context_id = "CPUT"
    loop_detection_rt_context_id = "LOOP"
    loop_detection_nrt_context_id = "LOOP"
    #forking
    process_forking_context_id = "PMON"
    thread_forking_context_id = "THRD"

    #memory
    memory_total_usage_context_id = "MEMS"
    memory_process_usage_context_id = "MEMS"
    budget_report_context_id = "MBUD"
    cgroup_report_context_id = "MCGT"
    cgroup_oom_report_context_id = "OOM"
    #inerrupts
    softirqs_context_id = "IRQS"
    hardware_irqs_context_id = "IRQH"

    Low_level_error_diagnostics_context_id = "LLED"

    ecc_error_dlt_msg = "New ECC error"

    #sysmon file names
    sysmon_config_file_name = "sysmon_config.json"
    hw_reg_file_name = "hw_reg.json"
    asil_app_file_name = "asil_apps.conf"

    #sysmon error messages
    sysmon_config_invalid_file_error_message = ["Can't find root json object in", "sysmon_config.json"]
    hw_reg_error_message = ["Failed to load a configuration file", "hw_reg.json"]
    asil_app_error_message = ["TODO"]

    sysmon_etc_path = "/opt/sysmon/etc/"

    qnx_time_interval_mapping = {
        network_statistic_context_id: "NETWORK.statistics_interval.value_ms",
        network_protocols_statistics_context_id: "NETWORK.protocols_statistics_interval.value_ms",
        blk_context_id: "DISK.disk_usage_interval.value_ms",
        emmc_health_report_context_id: "DISK.emmc_health_report_interval.value_ms",
        CPU_system_context_id: "CPU.report_interval.value_ms",
        CPU_core_context_id: "CPU.report_interval.value_ms",
        process_cpu_usage_context_id: "CPU.report_interval.value_ms",
        thread_cpu_usage_context_id: "CPU.report_interval.value_ms",
        loop_detection_rt_context_id: "CPU.loop_track_rt_interval.value_ms",
        loop_detection_nrt_context_id: "CPU.loop_track_nrt_interval.value_ms",
        memory_total_usage_context_id + "total": "MEMORY.usage_interval.value_ms",
        memory_process_usage_context_id + "process": "MEMORY.process_memory_usage_interval.value_ms",
        budget_report_context_id: "MEMORY.budget_report_interval.value_ms",
        cgroup_report_context_id: "MEMORY.cgroup_report_interval.value_ms",
        cgroup_oom_report_context_id: "MEMORY.cgroup_oom_report_interval.value_ms",
        cgroup_oom_report_context_id + "limit": "MEMORY.ram_available_oom_trigger.value_pct",
        version_context_id: "GENERAL.version_hash_interval.value_ms",
        softirqs_context_id: "IRQ.softirqs_interval.value_ms",
        hardware_irqs_context_id: "IRQ.hardware_irqs_interval.value_ms",
        Low_level_error_diagnostics_context_id: "LOW-LEVEL-ERROR-DIAGNOSTICS.report_interval.value_ms",
        "process_cpu_usage_limit": "CPU.usage_limit.value_pct"
    }

    linux_time_interval_mapping = {
        network_statistic_context_id: "network_statistic_output_ms",
        network_protocols_statistics_context_id: "network_protocols_statistics_output_ms",
        blk_context_id: "disk_usage_output_ms",
        emmc_health_report_context_id: "emmc_health_report_ms",
        CPU_system_context_id: "cpu_usage_output_ms",
        CPU_core_context_id: "cpu_usage_output_ms",
        process_cpu_usage_context_id: "cpu_usage_output_ms",
        thread_cpu_usage_context_id: "cpu_usage_output_ms",
        IOWAIT_system_context_id: "cpu_usage_output_ms",
        IOWAIT_core_context_id: "cpu_usage_output_ms",
        memory_total_usage_context_id + "total": "ram_usage_output_ms",
        memory_process_usage_context_id + "process": "process_memory_usage_output_ms",
        budget_report_context_id: "mem_budget_interval_ms",
        loop_detection_nrt_context_id: "cpu_loop_track_nrt_interval_sec",
        loop_detection_rt_context_id: "cpu_loop_track_rt_interval_sec",
        cgroup_oom_report_context_id: "mem_cgroup_oom_interval_ms",
        cgroup_oom_report_context_id + "limit": "memavailable_pct",
        softirqs_context_id: "softirqs_output_ms",
        hardware_irqs_context_id: "hardware_irqs_output_ms",
        version_context_id: "git_hash_output_ms",
        Low_level_error_diagnostics_context_id: "low_level_error_diagnostic_output_ms",
        "process_cpu_usage_limit": "cpu_usage_limit_logging",
        domain_reporting_cpu_context_id: "domain_cpu_usage_output_ms",
        domain_reporting_memory_context_id: "domain_cpu_usage_output_ms"
    }

    wait_for_scheduling_delay_reports_ms = 30000
    wait_for_process_reports_ms = 120000
    wait_for_oom_reports_ms = 200000
    wait_RT_precess_report_ms = 5000
    wait_for_forking_non_verbose_message_ms = 10000
    wait_for_budget_report_non_verbose_message_ms = 10000
    wait_for_memory_usage_non_verbose_message_ms = 10000

    diag_to_set_halt_state = [0x31, 0x01, 0xF0, 0x86, 0x00]
    diag_to_set_continue_state = [0x31, 0x01, 0xF0, 0x86, 0x01]

    execution_manager_process_path = "/sbin/execution_manager"
    execution_manager_with_first_option = "execution_manager -a"
    someipd_posix_process_name = "someipd_posix"

    scheduling_delay_non_rt_threshold = "sched_delay_non_rt_thread_cutoff_ms"
    scheduling_delay_rt_threshold = "sched_delay_rt_thread_cutoff_ms"

    valid_reserved_blocks_status = [
        "Normal",
        "Consumed 80% of reserved blocks",
        "Consumed 90% of reserved blocks"
    ]

    valid_DDR_levels = [
        "Normal",
        "Warning",
        "Failure"
    ]

    statistic_data = {
        "Network": {
            "General": {
                "ContextID": network_statistic_context_id,
                "Search_msg_array": ["Adapter", "RX", "TX"],
                "Statistics": {
                    "RX Total number of bytes": r"bytes: (.*) \(.*TX",
                    "TX Total number of bytes": r"TX.*bytes: (.*) \(",
                    "RX Bandwidth": r"\((.*) Mbps\).*TX",
                    "TX Bandwidth": r"TX.*\((.*) Mbps\)",
                    "RX Total number of packets": r"packets: (.*) errs:.*TX",
                    "TX Total number of packets": r"TX.*packets: (.*) errs:",
                    "RX Total number of errors": r"errs: (.*) drop:.*TX",
                    "TX Total number of errors": r"TX.*errs: (.*) drop:",
                    "RX Number of dropped packets": r"drop: (.*) fifo:.*TX",
                    "TX Number of dropped packets": r"TX.*drop: (.*) fifo:",
                    "RX Number of aggregated packet framing errors": r"frame: (.*) compressed:.*TX",
                    "RX Number of multicast packets": r"multicast: (.*) TX",
                    "TX Number of multicast packets": r"TX.*multicast: (.*)$",
                    "TX Number of collision errors detected on the interface": r"TX.*colls: (.*) carrier:",
                    "TX Number of aggregated carrier errors": r"TX.*carrier: (.*) compressed:",
                    "RX Number of FIFO": r"fifo: (.*) frame:.*TX",
                    "TX Number of FIFO": r"TX.*fifo: (.*) colls:"
                }
            },
            "TCP": {
                "ContextID": network_protocols_statistics_context_id,
                "Search_msg_array": ["Ip", "Tcp", "Udp", "Icmp"],
                "Statistics": {
                    "cur_estab": r"Tcp:.*?(?:CurrEstab: )(\d+)(?:$|\D)",
                    "in_csum_errors":  r"Tcp:.*?(?:InCsumErrors: )(\d+)(?:$|\D)"
                }
            },
            "UDP": {
                "ContextID": network_protocols_statistics_context_id,
                "Search_msg_array": ["Ip", "Tcp", "Udp", "Icmp"],
                "Statistics": {
                    "in_datagrams": r"Udp:.*?(?:InDatagrams: )(\d+)(?:$|\D)",
                    "no_ports": r"Udp:.*?(?:NoPorts: )(\d+)(?:$|\D)",
                    "in_errors": r"Udp:.*?(?:InErrors: )(\d+)(?:$|\D)",
                    "out_datagrams": r"Udp:.*?(?:OutDatagrams: )(\d+)(?:$|\D)",
                    "rcv_buf_errors": r"Udp:.*?(?:RcvbufErrors: )(\d+)(?:$|\D)",
                    "in_csum_errors": r"Udp:.*?(?:InCsumErrors: )(\d+)(?:$|\D)",
                    "ignored_multi": r"Udp:.*?(?:IgnoredMulti: )(\d+)(?:$|\D)",
                    "snd_buf_errors": r"Udp:.*?(?:SndbufErrors: )(\d+)(?:$|\D)"
                }
            },
            "ICMP": {
                "ContextID": network_protocols_statistics_context_id,
                "Search_msg_array": ["Ip", "Tcp", "Udp", "Icmp"],
                "Statistics": {
                    "in_msgs": r"Icmp:.*?(?:InMsgs: )(\d+)(?:$|\D)",
                    "in_errors": r"Icmp:.*?(?:InErrors: )(\d+)(?:$|\D)",
                    "in_csum_errors": r"Icmp:.*?(?:InCsumErrors: )(\d+)(?:$|\D)",
                    "in_dest_unreachs": r"Icmp:.*?(?:InDestUnreachs: )(\d+)(?:$|\D)",
                    "in_time_exds": r"Icmp:.*?(?:InTimeExcds: )(\d+)(?:$|\D)",
                    "in_param_probs": r"Icmp:.*?(?:InParmProbs: )(\d+)(?:$|\D)",
                    "in_redirects": r"Icmp:.*?(?:InRedirects: )(\d+)(?:$|\D)",
                    "in_echos": r"Icmp:.*?(?:InEchos: )(\d+)(?:$|\D)",
                    "in_echo_reps": r"Icmp:.*?(?:InEchoReps: )(\d+)(?:$|\D)",
                    "in_addr_masks": r"Icmp:.*?(?:InAddrMasks: )(\d+)(?:$|\D)",
                    "out_msgs": r"Icmp:.*?(?:OutMsgs: )(\d+)(?:$|\D)",
                    "out_dest_unreachs": r"Icmp:.*?(?:OutDestUnreachs: )(\d+)(?:$|\D)",
                    "out_echos": r"Icmp:.*?(?:OutEchos: )(\d+)(?:$|\D)",
                    "out_echo_reps": r"Icmp:.*?(?:OutEchoReps: )(\d+)(?:$|\D)",
                    "out_errors": r"Icmp:.*?(?:OutErrors: )(\d+)(?:$|\D)"
                }
            },
            "IP": {
                "ContextID": network_protocols_statistics_context_id,
                "Search_msg_array": ["Ip", "Tcp", "Udp", "Icmp"],
                "Statistics": {
                    "in_receives": r"Ip:.*?(?:InReceives: )(\d+)(?:$|\D)",
                    "in_hdr_errors": r"Ip:.*?(?:InHdrErrors: )(\d+)(?:$|\D)",
                    "in_discards": r"Ip:.*?(?:InDiscards: )(\d+)(?:$|\D)",
                    "in_delivers": r"Ip:.*?(?:InDelivers: )(\d+)(?:$|\D)",
                    "out_requests": r"Ip:.*?(?:OutRequests: )(\d+)(?:$|\D)",
                    "out_discards": r"Ip:.*?(?:OutDiscards: )(\d+)(?:$|\D)",
                    "out_no_routes": r"Ip:.*?(?:OutNoRoutes: )(\d+)(?:$|\D)",
                    "reasm_oks": r"Ip:.*?(?:ReasmOKs: )(\d+)(?:$|\D)",
                    "frag_oks": r"Ip:.*?(?:FragOKs: )(\d+)(?:$|\D)",
                    "frag_fails": r"Ip:.*?(?:FragFails: )(\d+)(?:$|\D)",
                    "frag_creates": r"Ip:.*?(?:FragCreates: )(\d+)(?:$|\D)"
            }
        }
        },
        "EMMC": {
            "IO statistics LINUX": {
                "ContextID": emmc_health_report_context_id,
                "Search_msg_array": ["eMMC IO statistics:"],
                "Statistics": {
                    "READ_IOS": r"READ_IOS: *(\d+)(?: *|$)",
                    "READ_MERGES": r"READ_MERGES: *(\d+)(?: *|$)",
                    "READ_SECTORS": r"READ_SECTORS: *(\d+)(?: *|$)",
                    "READ_TICKS": r"READ_TICKS: *(\d+)(?: *|$)",
                    "WRITE_IOS": r"WRITE_IOS: *(\d+)(?: *|$)",
                    "WRITE_MERGES": r"WRITE_MERGES: *(\d+)(?: *|$)",
                    "WRITE_SECTORS": r"WRITE_SECTORS: *(\d+)(?: *|$)",
                    "WRITE_TICKS": r"WRITE_TICKS: *(\d+)(?: *|$)",
                    "IN_FLIGTH": r"IN_FLIGTH: *(\d+)(?: *|$)",
                    "IO_TICKTS": r"IO_TICKTS: *(\d+)(?: *|$)",
                    "TIME_IN_QUEUE": r"TIME_IN_QUEUE: *(\d+)(?: *|$)",
                    "DISCARD_IOS": r"DISCARD_IOS: *(\d+)(?: *|$)",
                    "DISCARD_MERGES": r"DISCARD_MERGES: *(\d+)(?: *|$)",
                    "DISCARD_SECTORS": r"DISCARD_SECTORS: *(\d+)(?: *|$)",
                    "DISCARD_TICKS": r"DISCARD_TICKS: *(\d+)(?: *|$)"
                }
            },
            "IO statistics QNX": {
                "ContextID": emmc_health_report_context_id,
                "Search_msg_array": ["eMMC IO statistics:"],
                "Statistics": {
                    "READ_SECTORS": r"READ_SECTORS: *(\d+)(?: *|$)",
                    "WRITE_SECTORS": r"WRITE_SECTORS: *(\d+)(?: *|$)",
                    "TRIM_SECTORS": r"TRIM_SECTORS: *(\d+)(?: *|$)",
                    "ERASE_SECTORS": r"ERASE_SECTORS: *(\d+)(?: *|$)",
                    "DISCARD_SECTORS": r"DISCARD_SECTORS: *(\d+)(?: *|$)"
                }
            },
            "Bad Blocks": {
                "ContextID": emmc_health_report_context_id,
                "Search_msg_array": ["Bad blocks"],
                "Statistics": {
                    "INITIAL_BAD_BLOCKS": r"INITIAL_BAD_BLOCKS: *([xabcdef0-9]+)(?: *|$)",
                    "RUNTIME_BAD_BLOCKS": r"RUNTIME_BAD_BLOCKS: *([xabcdef0-9]+)(?: *|$)",
                    "REMAIN_SPR_BLOCKS": r"REMAIN_SPR_BLOCKS: *([xabcdef0-9]+)(?: *|$)",
                    "BAD_BLOCK_RATIO": r"ratio: *(\d+)(?: *%)"
                }
            },
            "Erase Count": {
                "ContextID": emmc_health_report_context_id,
                "Search_msg_array": ["Erase count:"],
                "Statistics": {
                    "MIN_BLOCK_ERASE": r"MIN_BLOCK_ERASE: *([xabcdef0-9]+)(?: *|$)",
                    "MAX_BLOCK_ERASE": r"MAX_BLOCK_ERASE: *([xabcdef0-9]+)(?: *|$)",
                    "AVG_BLOCK_ERASE": r"AVG_BLOCK_ERASE: *([xabcdef0-9]+)(?: *|$)",
                    "MIN_BLOCK_ERASE_SLC": r"Min. cycle_SLC: *([.0-9]+)(?:\,| *|$)",
                    "MAX_BLOCK_ERASE_SLC": r"Max. cycle_SLC: *([.0-9]+)(?:\,| *|$)",
                    "AVG_BLOCK_ERASE_SLC": r"Avg. cycle_SLC: *([.0-9]+)(?:\,| *|$)",
                    "MIN_BLOCK_ERASE_MLC": r"Min. cycle_MLC: *([.0-9]+)(?:\,| *|$)",
                    "MAX_BLOCK_ERASE_MLC": r"Max. cycle_MLC: *([.0-9]+)(?:\,| *|$)",
                    "AVG_BLOCK_ERASE_MLC": r"Avg. cycle_MLC: *([.0-9]+)(?:\,| *|$)"
                }
            },
            "ECSD": {
                "ContextID": emmc_health_report_context_id,
                "Search_msg_array": ["ECSD Register:"]
            },
            "eMMC Health": {
                "ContextID": emmc_health_report_context_id,
                "Search_msg_array": ["eMMC Health:"],
                "Statistics": {
                    "FIRMWARE_VERSION": r"FIRMWARE_VERSION: *([xabcdef0-9]+)(?:\,| *|$)",
                    "SEC_COUNT": r"SEC_COUNT: *([xabcdef0-9]+)(?:\,| *|$)",
                    "PRE_EOL_INFO": r"PRE_EOL_INFO: *([xabcdef0-9]+)(?:\,| *|$)",
                    "DEVICE_LIFE_EST_SLC": r"DEVICE_LIFE_EST_TYP_A: *([xabcdef0-9]+)(?:\,| *|$)",
                    "DEVICE_LIFE_EST_MLC": r"DEVICE_LIFE_EST_TYP_B: *([xabcdef0-9]+)(?:\,| *|$)",
                }
            },
            "Reserved Blocks": {
                "ContextID": emmc_health_report_context_id,
                "Search_msg_array": ["Reserved blocks:"],
                "Statistics": {
                    "Status": r"Reserved blocks: *(.*)\. SLC areas"
                }
            },
            "Used lifetime": {
                "ContextID": emmc_health_report_context_id,
                "Search_msg_array": ["SLC areas:", "MLC areas:"],
                "Statistics": {
                    "SLC_USED_LIFETIME": r"SLC areas: *(.*)\. MLC areas",
                    "MLC_USED_LIFETIME": r"MLC areas: *(.*)\.$"
                }
            }
        },
        "CPU": {
            "online Cores": {
                "ContextID": CPU_system_context_id,
                "Search_msg_array": ["active_cores"],
                "Statistics": {
                    "online_cores": r"'active_cores': (\d),",
                }
            },
            "Overall": {
                "ContextID": CPU_system_context_id,
                "Search_msg_array": ["CPU usage (overall)"],
                "Statistics": {
                    "in_interval": r"in interval: ([0-9\.]+)%",
                    "since_boot": r"since boot: ([0-9\.]+)%",
                    "iowait": r"iowait: ([0-9\.]+)%"
                }
            },
            "Cores": {
                "ContextID": CPU_core_context_id,
                "Search_msg_array": ["CPU usage (core"],
                "Statistics": {
                    "in_interval": r"in interval: ([0-9\.]+)%",
                    "since_boot": r"since boot: ([0-9\.]+)%",
                    "iowait": r"iowait: ([0-9\.]+)%"
                }
            },
            "Process": {
                "ContextID": process_cpu_usage_context_id,
                "Search_msg_array": ["CPU consumed by process"],
                "Statistics": {
                    "consumed_percentage": r"([(\d).]+)% CPU consumed",
                    "process_name": r'by process (\w+) \("',
                    "process_path_and_args": r'\("(\w+)"\)',
                    "pid": r"pid: (\d+)"
                }
            },
            "Thread": {
                "ContextID": thread_cpu_usage_context_id,
                "Search_msg_array": ["CPU consumed by thread"],
                "Statistics": {
                    "consumed_percentage": r"",
                    "thread_name": r"",
                    "tid": r""
                }
            }
        },
        "Domain": {
            "cpu": {
                "ContextID": domain_reporting_cpu_context_id,
                "Search_msg_array": ["Domain", "consumed"],
                "Statistics": {
                    "domain": r"Domain \"(.*)\"",
                    "usage": r" (\d+)%"
                }
            },
            "memory": {
                "ContextID": domain_reporting_memory_context_id,
                "Search_msg_array": ["RSS memory used by domain"],
                "Statistics": {
                    "domain": r"domain \"(.*)\"",
                    "usage": r": (\d+) [A-Za-z]"
                }
            }
        },
        "DDR": {
            "Margin": {
                "ContextID": DDR_margin_context_id,
                "Search_msg_array": ["DDR RAM margins:"],
                "Statistics": {
                    "level": r"margins: (.*) level\.",
                    "RxPdq": r"RxPdq: ([0-9:-]+)\.",
                    "RxVref": r"RxVref: ([0-9:-]+)\.",
                    "TxPdq": r"Txdq: ([0-9:-]+)\.",
                    "TxVref": r"TxVref: ([0-9:-]+)\."
                }
            }
        },
        "BLK": {
            "IO": {
                "ContextID": blk_context_id,
                "Search_msg_array_read": ["Read IOs"],
                "Search_msg_array_write": ["Write IO"],
                "Statistics": {
                    "read_processed": r"Read IOs processed: (\d+)?(?:\D)",
                    "read_merged": r"rrqm: (\d+)?(?:\D).*Write IO",
                    "read_sectors": r"(unknowN)",
                    "read_wait_time": r"waittime: (\d+)?(?:\D).*Write IO",
                    "write_processed": r"Write IO: (\d+)?(?:\D)",
                    "write_merged": r"Write IO.*wrqm: (\d+)?(?:\D)",
                    "write_sectors": r"(unknowN)",
                    "write_wait_time": r"Write IO.*waittime: (\d+)?(?:\D)",
                    "requests": r"(unknowN)",
                    "total_time_active": r"(unknowN)",
                    "total_time_wait_time": r"total wait: (\d+)?(?:\D)",
                }
            },
            "Filesystem": {
                "ContextID": blk_context_id,
                "Search_msg_array": ["Filesystem:"],
                "Statistics": {
                    "filesystem": r"Filesystem: ([a-z/]+)",
                    "type": r"Type: ([a-z]+)",
                    "path": r"Mounted on: ([a-z/]+)",
                    "overall_size": r"Size: ([0-9\.]+ [A-Z]+)",
                    "available_size": r"Available: ([0-9\.]+ [A-Z]+)",
                    "used_space": r"Used: ([0-9\.]+%)"
                }
            }
        },
        "block_delay": {
            "IOTD": {
                "ContextID": thread_io_statistics_context_id,
                "Search_msg_array": ["ms block delay for thread"],
                "Statistics": {
                    "delay": r"(\d+) ms"
                }
            }

        },
        "Scheduling": {
            "real_time": {
                "ContextID": real_time_scheduling_delay_context_id,
                "Search_msg_array": ["scheduling delay", "for rt thread"],
                "Statistics": {
                    "scheduling_delay": r"^(\d+) ms total scheduling delay",
                    "number_of_times": r"ms for scheduling (\d+) number",
                    "in_interval": r"in interval (\d+) ms for scheduling",
                    "thread_name": r"thread (.*) \(tid",
                    "parent_PID": r"in parent pid (\d+) ",
                    "parent_process_name": r'pid \d+ ["|\(](.*)["|\)]'
                }
            },
            "non_real_time": {
                "ContextID": non_real_time_scheduling_delay_context_id,
                "Search_msg_array": ["scheduling delay", "for non-rt thread"],
                "Statistics": {
                    "scheduling_delay": r"^(\d+) ms total scheduling delay",
                    "number_of_times": r"ms for scheduling (\d+) number",
                    "in_interval": r"in interval (\d+) ms for scheduling",
                    "thread_name": r"thread (.*) \(tid",
                    "parent_PID": r"in parent pid (\d+) ",
                    "parent_process_name": r'pid \d+ ["|\(](.*)["|\)]'
                }
            }
        },
        "PMON": {
            "creation": {
                "ContextID": process_forking_context_id,
                "Search_msg_array": ["New process", "with pid", "created"],
                "Statistics": {
                    "process_name": r'New process "([\w -]+)" with pid ',
                    "pid": r"with pid (\d+) created"
                }
            },
            "termination": {
                "ContextID": process_forking_context_id,
                "Search_msg_array": ["Process", "with pid", "terminated"],
                "Statistics": {
                    "process_name": r'Process "([\w -/]+)" with pid ',
                    "pid": r"with pid (\d+) terminated"
                }
            },
            "termination_ets": {
                "ContextID": process_forking_context_id,
                "Search_msg_array": ["Process", "with pid", "terminated", "ets"],
                "Statistics": {
                    "pid_ets": r'Process "ets" with pid (\d+) terminated'
                }
            }
        },
        "LOOP": {
            "NRT": {
                "ContextID": loop_detection_nrt_context_id,
                "Search_msg_array": ["Following NRT thread spent"],
                "Statistics": {
                    "thread_name": r"Following NRT thread .+on CPU: (\w+) \(tid",
                    "used_CPU_time": r"Actual CPU-Time used: (\d+)us"
                }
            },
            "RT": {
                "ContextID": loop_detection_rt_context_id,
                "Search_msg_array": ["Following", "RT", "thread", "spent"],
                "Statistics": {
                    "thread_name": r"Following RT thread .+on CPU: (\w+) \(tid",
                    "used_CPU_time": r"Actual CPU-Time used: (\d+)us"
                }
            }
        },
        "Memory": {
            "mems_total": {
                "ContextID": memory_total_usage_context_id,
                "Search_msg_array": ["MemTotal:", "MemAvailable:"],
                "Statistics": {
                    "total_memory": r"MemTotal: (\d+) [kKBi]+",
                    "free_memory": r"FreeMemory: (\d+) [kKBi]+",
                    "available_memory": r"MemAvailable: (\d+) [kKBi]+",
                    "shared_memory": r"Shmem: (\d+) [kKBi]+",
                    "buffered_memory": r"Buffers: (\d+) [kKBi]+",
                    "cached_memory": r"Cached: (\d+) [kKBi]+"
                }
            },
            "mems_per_process_linux": {
                "ContextID": memory_process_usage_context_id,
                "Search_msg_array": ["RSS:", "USS:"],
                "Statistics": {
                    "rss": r"RSS: (-1|\d+) MB",
                    "pss": r"PSS: (-1|\d+) MB",
                    "uss": r"USS: (-1|\d+) MB",
                    "vm": r"VM: (-1|\d+) MB",
                    "process_name": r"for process (.*)\("
                }
            },
            "mbud_per_process_linux_1": {
                "ContextID": budget_report_context_id,
                "Search_msg_array": ["for process", "vmSize"],
                "Statistics": {
                    "vmsize": r"vmSize of (-1|\d+) MB",
                    "process_name": r"for process (.*)\("
                }
            },
            "mbud_per_process_linux_2": {
                "ContextID": budget_report_context_id,
                "Search_msg_array": ["RSS:", "USS:","for process"],
                "Statistics": {
                    "rss": r"RSS: (-1|\d+) MB",
                    "pss": r"PSS: (-1|\d+) MB",
                    "uss": r"USS: (-1|\d+) MB",
                    "process_name": r"for process (.*)\("
                }
            },
            "mems_per_process_stack": {
                "ContextID": memory_process_usage_context_id,
                "Search_msg_array": ["Process stack memory usage:"],
            },
            "mems_per_process_heap": {
                "ContextID": memory_process_usage_context_id,
                "Search_msg_array": ["Process heap memory usage:"],
            },
            "mems_per_process_vvar": {
                "ContextID": memory_process_usage_context_id,
                "Search_msg_array": ["Process vvar memory usage:"],
            },
            "mems_per_process_vdso": {
                "ContextID": memory_process_usage_context_id,
                "Search_msg_array": ["Process vdso memory usage:"],
            },
            "mbud_total1_linux": {
                "ContextID": budget_report_context_id,
                "Search_msg_array": ["Total for all processes calculated"],
                "Statistics": {
                    "rss": r"RSS: (\d+)",
                    "pss": r"PSS: (\d+)",
                    "uss": r"USS: (\d+)",
                    "vm": r"VM: (\d+)"
                }
            },
            "mbud_total1_qnx": {
                "ContextID": budget_report_context_id,
                "Search_msg_array": ["Accumulated memory usage of all processes"],
                "Statistics": {
                    "uss": r"USS: (\d+)",
                }
            },
            "mbud_total2_linux": {
                "ContextID": budget_report_context_id,
                "Search_msg_array": ["total:", "free:", "available:"],
                "Statistics": {
                    "total": r"total: (\d+)",
                    "free": r"free: (\d+)",
                    "available": r"available: (\d+)",
                    "active_anon": r"active\(anon\): (\d+)",
                    "inactive_anaon": r"inactive\(anon\): (\d+)",
                    "active_file": r"active\(file\): (\d+)",
                    "inactive_file": r"inactive\(file\): (\d+)",
                    "mapped": r"mapped: (\d+)",
                    "shmem": r"shared: (\d+)",
                    "sreclaimable": r"sreclaimable: (\d+)",
                    "sunreclaim": r"sunreclaim: (\d+)",
                    "pagetables": r"pagecache: (\d+)",
                    "kernelstack": r"kernel: (\d+)"
                }
            },
            "mbud_total2_qnx": {
                "ContextID": budget_report_context_id,
                "Search_msg_array": ["Total:", "Free:", "Available:"],
                "Statistics": {
                    "total": r"Total: (\d+)",
                    "free": r"Free: (\d+)",
                    "available": r"Available: (\d+)",
                    "shmem": r"Shared: (\d+)"
                }
            },
            # RSS: 3 MB PSS: -1 MB USS: 1 MB SHM: 1 MB
            "mbud_per_process1_qnx": {
                "ContextID": budget_report_context_id,
                "Search_msg_array": ["RSS","USS:","SHM:","for process"],
                "Statistics": {
                    "rss": r"RSS: (\d+)",
                    "uss": r"USS: (\d+)",
                    "shm": r"SHM: (\d+)",
                }
            },
            "mbud_per_process2_qnx": {
                "ContextID": budget_report_context_id,
                "Search_msg_array": ["for process","vmSize"],
                "Statistics": {
                    "vmSize": r"vmSize of (\d+)",
                }
            },
            "oom_memory_change": {
                "ContextID": cgroup_oom_report_context_id,
                "Search_msg_array": ["MemAvailable changed by"],
                "Statistics": {
                    "change_in_percent": r"changed by ([0-9.]+)%",
                    "old_value": r"Old value: (\d+)",
                    "new_value": r"new value: (\d+)"
                }
            }
        },
        "IRQ": {
            "SW": {
                "ContextID": softirqs_context_id,
                "Search_msg_array": ["softIRQ/sec"],
                "Statistics": {
                    "name": r"^([A-Z_a-z]+):",
                    "sum": r"Sum: (\d+) ",
                    "irq_sec": r"([0-9.]+) softIRQ\/sec",
                    "cpu_1": r"CPU 1: (\d+)",
                    "cpu_2": r"CPU 2: (\d+)",
                    "cpu_3": r"CPU 3: (\d+)",
                    "cpu_4": r"CPU 4: (\d+)"
                }
            },
            "HW": {
                "ContextID": hardware_irqs_context_id,
                "Search_msg_array": ["eth0:", "mmc0:"],
                "Statistics": {
                    "eth0": r"eth0: (\d+)",
                    "mmc0": r"mmc0: (\d+)",
                    "rtc0": r"rtc0: (\d+)",
                    "timer": r"timer: (\d+)",
                    "ttyS0": r"ttyS0: (\d+)",
                    "ttyS2": r"ttyS2: (\d+)",
                    "CAL": r"CAL: (\d+)",
                    "IWI": r"IWI: (\d+)",
                    "LOC": r"LOC: (\d+)",
                    "MCP": r"MCP: (\d+)",
                    "NMI": r"NMI: (\d+)",
                    "PMI": r"PMI: (\d+)",
                    "RES": r"RES: (\d+)",
                    "TLB": r"TLB: (\d+)",
                    "Order": "eth0: (\d+) mmc0: (\d+) rtc0: (\d+) timer: (\d+) ttyS0: (\d+) ttyS2: (\d+) CAL: (\d+) IWI: (\d+) LOC: (\d+) MCP: (\d+) NMI: (\d+) PMI: (\d+) RES: (\d+) TLB: (\d+)"
                }
            }
        },
        "LLED": {
            "temperature": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["Temperature:"],
                "Statistics": {
                    "core0": r"Core 0: (\d+)",
                    "core1": r"Core 1: (\d+)",
                    "core2": r"Core 2: (\d+)",
                    "core3": r"Core 3: (\d+)",
                }
            },
            "MEC": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["Memory Execution Cluster", "New error"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"decimal value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            },
            "PMC": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["ME Uncorrectable Error Status"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"decimal value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            },
            "BIU": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["Bus Interface Unit", "MCERR happened"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"hex value: (missing)",
                    "hex_value": r"Whole register content: (0[x|X][0-9abcdefABCDEF]+)"
                }
            },
            "FEC": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["Forward Error Correction", "New ECC error"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"hex value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            },
            "IE": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["IE uncorrectable Error"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"hex value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            },
            "RAM": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["L2 cache", "New ECC error"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"hex value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            },
            "PMU": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["Performance Monitoring Units", "New error"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"hex value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            },
            "RESET_CAUSE": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["Reset caused by"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"hex value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            },
            "SYS_AGENT": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["System Agent (MC4)", "New error"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"hex value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            },
            "A_UNIT": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["AT translated illegal device"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"hex value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            },
            "B_UNIT": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["Bram Write Parity Error"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"hex value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            },
            "THERMAL": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": ["Temperature threshold 1", "exceeded"],
                "Statistics": {
                    "core": r"Core (\d)",
                    "dec_value": r"hex value: (missing)",
                    "hex_value": r"hex value: (missing)"
                }
            }
        },
        "THRD": {
            "THREAD": {
                "ContextID": thread_forking_context_id,
                "Search_msg_array": ["Fork process"],
                "Statistics": {
                    "TID": r"Fork process pid (\d+)",
                    "PID": r"in parent (\d+)"
                }
            }
        },
        "HLT": {
            "version": {
                "ContextID": version_context_id,
                "Search_msg_array": ["Git hash:", "swName:", "swVersion:"],
                "Statistics": {
                    "Git_hash": r"Git hash: ([\w\d]+),",
                    "swName": r", swName: ([\w\d]+),",
                    "swVersion": r", swVersion: ([\w\d.]+)"
                }
            }
        }
    }

    non_verbose_statistic_data = {
        "Network": {
            "General": {
                "ContextID": network_statistic_context_id,
                "Search_msg_array": ["Adapter", "RX", "TX"],
                "Statistics": {
                    "RX Total number of bytes": r"NetAdapter.*?(?:rx_bytes= )(\d+)(?:$|\D)",
                    "TX Total number of bytes": r"NetAdapter.*?(?:tx_bytes= )(\d+)(?:$|\D)",
                    "RX Bandwidth": r"NetAdapter.*?(?:rx_elapsed_mbits_p_sec= )(\d+)(?:$|\D) \((.*) Mbps\).*TX",
                    "TX Bandwidth": r"NetAdapter.*?(?:tx_elapsed_mbits_p_sec= )(\d+)(?:$|\D) TX.*\((.*) Mbps\)",
                    "RX Total number of packets": r"NetAdapter.*?(?:rx_packets= )(\d+)(?:$|\D) packets: (.*) errs:.*TX",
                    "TX Total number of packets": r"NetAdapter.*?(?:tx_packets= )(\d+)(?:$|\D) TX.*packets: (.*) errs:",
                    "RX Total number of errors": r"NetAdapter.*?(?:rx_errs= )(\d+)(?:$|\D) errs: (.*) drop:.*TX",
                    "TX Total number of errors": r"NetAdapter.*?(?:tx_errs= )(\d+)(?:$|\D) TX.*errs: (.*) drop:",
                    "RX Number of dropped packets": r"NetAdapter.*?(?:rx_drop= )(\d+)(?:$|\D) drop: (.*) fifo:.*TX",
                    "TX Number of dropped packets": r"NetAdapter.*?(?:tx_drop= )(\d+)(?:$|\D) TX.*drop: (.*) fifo:",
                    "RX Number of aggregated packet framing errors": r"NetAdapter.*?(?:rx_frame= )(\d+)(?:$|\D) frame: (.*) compressed:.*TX",
                    "RX Number of multicast packets": r"NetAdapter.*?(?:multicast= )(\d+)(?:$|\D) multicast: (.*) TX",
                    "TX Number of multicast packets": r"NetAdapter.*?(?:multicast= )(\d+)(?:$|\D) TX.*multicast: (.*)$",
                    "TX Number of collision errors detected on the interface": r"NetAdapter.*?(?:tx_colls= )(\d+)(?:$|\D) TX.*colls: (.*) carrier:",
                    "TX Number of aggregated carrier errors": r"NetAdapter.*?(?:tx_carrier= )(\d+)(?:$|\D) TX.*carrier: (.*) compressed:",
                    "RX Number of FIFO": r"NetAdapter.*?(?:rx_fifo= )(\d+)(?:$|\D) fifo: (.*) frame:.*TX",
                    "TX Number of FIFO": r"NetAdapter.*?(?:tx_fifo= )(\d+)(?:$|\D) TX.*fifo: (.*) colls:"
                }
            },
            "TCP": {
                "ContextID": network_protocols_statistics_context_id,
                "Search_msg_array": ["Ip", "Tcp", "Udp", "Icmp"],
                "Statistics": {
                    "cur_estab": r"Tcp.*?(?:established_connections= )(\d+)(?:$|\D)",
                    "in_csum_errors": r"Tcp.*?(?:in_check_sum_errors= )(\d+)(?:$|\D)"
                }
            },
            "UDP": {
                "ContextID": network_protocols_statistics_context_id,
                "Search_msg_array": ["Ip", "Tcp", "Udp", "Icmp"],
                "Statistics": {
                    "in_datagrams": r"Udp.*?(?:in_datagrams= )(\d+)(?:$|\D)",
                    "no_ports": r"Udp.*?(?:no_ports= )(\d+)(?:$|\D)",
                    "in_errors": r"Udp.*?(?:in_errors= )(\d+)(?:$|\D)",
                    "out_datagrams": r"Udp.*?(?:out_datagrams= )(\d+)(?:$|\D)",
                    "rcv_buf_errors": r"Udp.*?(?:rcv_buf_errors= )(\d+)(?:$|\D)",
                    "in_csum_errors": r"Udp.*?(?:snd_buf_errors= )(\d+)(?:$|\D)",
                    "ignored_multi": r"Udp.*?(?:in_check_sum_errors= )(\d+)(?:$|\D)",
                    "snd_buf_errors": r"Udp.*?(?:ignored_multi= )(\d+)(?:$|\D)"
                }
            },
            "ICMP": {
                "ContextID": network_protocols_statistics_context_id,
                "Search_msg_array": ["Ip", "Tcp", "Udp", "Icmp"],
                "Statistics": {
                    "in_msgs": r"Icmp.*?(?:in_msgs= )(\d+)(?:$|\D)",
                    "in_errors": r"Icmp.*?(?:in_errors= )(\d+)(?:$|\D)",
                    "in_csum_errors": r"Icmp.*?(?:in_check_sum_errors= )(\d+)(?:$|\D)",
                    "in_dest_unreachs": r"Icmp.*?(?:in_dest_unreachs= )(\d+)(?:$|\D)",
                    "in_time_exds": r"Icmp.*?(?:in_time_exds= )(\d+)(?:$|\D)",
                    "in_param_probs": r"Icmp.*?(?:in_param_probs= )(\d+)(?:$|\D)",
                    "in_redirects": r"Icmp.*?(?:in_redirects= )(\d+)(?:$|\D)",
                    "in_echos": r"Icmp.*?(?:in_echos= )(\d+)(?:$|\D)",
                    "in_echo_reps": r"Icmp.*?(?:in_echo_reps= )(\d+)(?:$|\D)",
                    "in_addr_masks": r"Icmp.*?(?:in_addr_masks= )(\d+)(?:$|\D)",
                    "out_msgs": r"Icmp.*?(?:out_msgs= )(\d+)(?:$|\D)",
                    "out_dest_unreachs": r"Icmp.*?(?:out_errors= )(\d+)(?:$|\D)",
                    "out_echos": r"Icmp.*?(?:out_dest_unreachs= )(\d+)(?:$|\D)",
                    "out_echo_reps": r"Icmp.*?(?:out_echos= )(\d+)(?:$|\D)",
                    "out_errors": r"Icmp.*?(?:out_echo_reps= )(\d+)(?:$|\D)"
                }
            },
            "IP": {
                "ContextID": network_protocols_statistics_context_id,
                "Search_msg_array": ["Ip", "Tcp", "Udp", "Icmp"],
                "Statistics": {
                    "in_receives": r"Ip.*?(?:in_receives= )(\d+)(?:$|\D)",
                    "in_hdr_errors": r"Ip.*?(?:in_hdr_errors= )(\d+)(?:$|\D)",
                    "in_discards": r"Ip.*?(?:in_discards= )(\d+)(?:$|\D)",
                    "in_delivers": r"Ip.*?(?:in_delivers= )(\d+)(?:$|\D)",
                    "out_requests": r"Ip.*?(?:out_requests= )(\d+)(?:$|\D)",
                    "out_discards": r"Ip.*?(?:out_discards= )(\d+)(?:$|\D)",
                    "out_no_routes": r"Ip.*?(?:out_no_routes= )(\d+)(?:$|\D)",
                    "reasm_oks": r"Ip.*?(?:reasm_oks= )(\d+)(?:$|\D)",
                    "frag_oks": r"Ip.*?(?:frag_oks= )(\d+)(?:$|\D)",
                    "frag_fails": r"Ip.*?(?:frag_fails= )(\d+)(?:$|\D)",
                    "frag_creates": r"Ip.*?(?:frag_creates= )(\d+)(?:$|\D)"
                }
            }
        },
        "CPU": {
            "online_Cores": {
                "ContextID": CPU_system_context_id,
                "Search_msg_array": ["online cores"],
                "Statistics": {
                    "online_cores": r"cpu_SystemMetrics.*?(?:active_cores= )(\d+)(?:$|\D)",
                }
            },
            "Overall": {
                "ContextID": CPU_system_context_id,
                "Search_msg_array": ["CPU usage (overall)"],
                "Statistics": {
                    "in_interval": r"cpu_SystemMetrics.*?(?:average_load= )(\d+)(?:$|\D)",
                    "since_boot": r"cpu_SystemMetrics.*?(?:average_load_since_boot= )(\d+)(?:$|\D)",
                    "iowait": r"cpu_SystemMetrics.*?(?:average_iowait= )(\d+)(?:$|\D)"
                }
            },
            "Cores": {
                "ContextID": CPU_core_context_id,
                "Search_msg_array": ["CPU usage (core"],
                "Statistics": {
                    "in_interval": r"cpu_CoreMetrics.*?(?:load= )(\d+)(?:$|\D)",
                    "since_boot": r"cpu_CoreMetrics.*?(?:load_since_boot= )(\d+)(?:$|\D)",
                    "iowait": r"cpu_CoreMetrics.*?(?:iowait= )(\d+)(?:$|\D)"
                }
            }
        },
        "BLK": {
            "IO": {
                "ContextID": blk_context_id,
                "Search_msg_array": ["blkInfoData"],
                "Statistics": {
                    "rioDiff": r"rioDiff= (\d+)?(?:\D).*rmDiff",
                    "rmDiff": r"rmDiff= (\d+)?(?:\D).*rsDiff",
                    "rsDiff": r"rsDiff= (\d+)?(?:\D).*rtDiff",
                    "rtDiff": r"rtDiff= (\d+)?(?:\D).*wioDiff",
                    "wioDiff": r"wioDiff= (\d+)?(?:\D).*wmDiff",
                    "wmDiff": r"wmDiff= (\d+)?(?:\D).*wsDiff",
                    "wsDiff": r"wsDiff= (\d+)?(?:\D).*wtDiff",
                    "wtDiff": r"wtDiff= (\d+)?(?:\D).*totwaititmeDiff",
                    "totwaititmeDiff": r"totwaititmeDiff= (\d+)?(?:\D).*readkB",
                    "readkB": r"readkB= (\d+)?(?:\D).*writekB",
                    "writekB": r"writekB= (\d+)",
                }
            },
            "Filesystem": {
                "ContextID": blk_context_id,
                "Search_msg_array": [""],
                "Statistics": {
                    "filesystem": r"",
                    "type": r"",
                    "path": r"",
                    "overall_size": r"",
                    "available_size": r"",
                    "used_space": r""
                }
            }
        },
        "LLED": {
            "temperature": {
                "ContextID": Low_level_error_diagnostics_context_id,
                "Search_msg_array": [],
                "Statistics": {
                    "core0": r"temperature.*?(?:core= 0 temperature= )(\d+)(?:$|\D)",
                    "core1": r"temperature.*?(?:core= 1 temperature= )(\d+)(?:$|\D)",
                    "core2": r"temperature.*?(?:core= 2 temperature= )(\d+)(?:$|\D)",
                    "core3": r"temperature.*?(?:core= 3 temperature= )(\d+)(?:$|\D)",
                }
            }
        },
    }

    destination_path_msr = "/opt/Technica/msr"
    destination_path_msr_etc = "/opt/Technica/msr/etc"
    executable_msr_files = "chmod +x /opt/Technica/msr/msr_reader_app /opt/Technica/msr/msr_writer_app"
    msr_writer_app = "msr_writer_app"
    msr_reader_app = "msr_reader_app"

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_SysMon setUpclsss")
        cls.ssh_manager.executeCommandInTarget("ls /opt/sysmon/bin")
        cls.ssh_manager.executeCommandInTarget("ls /opt/sysmon/etc")
        if cls.os_name.lower() == "qnx":
            cls.vlan_interface = "vlan0"

        if cls.os_name.lower() == "qnx":
            executable_msr_files = "chmod +x /opt/Technica/msr/msr_reader_app_qnx /opt/Technica/msr/msr_writer_app_qnx"
            msr_writer_app = "msr_writer_app_qnx"
            msr_reader_app = "msr_reader_app_qnx"

        cls.eMMC_manufacturer = "UNKNOWN"
        if cls.os_name.lower() == "qnx":
            returnValue = cls.ssh_manager.executeCommandInTarget(command="slog2info | grep \"MID 0x\" | awk '{print $8}' | sed 's/,//g'", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            if returnValue["stdout"].strip() == "0x13":
                cls.eMMC_manufacturer = "MICRON"
            elif returnValue["stdout"].strip() == "0x15":
                cls.eMMC_manufacturer = "SAMSUNG"
        else:
            returnValue = cls.ssh_manager.executeCommandInTarget(command="cat /sys/block/mmcblk0/device/manfid", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            if returnValue["stdout"].strip() == "0x000013":
                cls.eMMC_manufacturer = "MICRON"
            elif returnValue["stdout"].strip() == "0x000015":
                cls.eMMC_manufacturer = "SAMSUNG"

        logger.debug(f"eMMC manufacturer is {cls.eMMC_manufacturer}")

        cls.number_of_cores = cls.get_number_of_cores()

        cls.ssh_manager.downloadFileFromTarget(source_file="hw_reg.json", source_path="/opt/sysmon/etc/", destination_path=OutputPathManager.get_tests_group_path())
        cls.ssh_manager.downloadFileFromTarget(source_file="exec_config.json", source_path="/opt/sysmon/etc/", destination_path=OutputPathManager.get_tests_group_path())
        cls.ssh_manager.downloadFileFromTarget(source_file="logging.json", source_path="/opt/sysmon/etc/", destination_path=OutputPathManager.get_tests_group_path())
        cls.ssh_manager.downloadFileFromTarget(source_file="domainlist.json", source_path="/opt/sysmon/etc/", destination_path=OutputPathManager.get_tests_group_path())
        cls.ssh_manager.downloadFileFromTarget(source_file="monitor.conf", source_path="/opt/sysmon/etc/", destination_path=OutputPathManager.get_tests_group_path())
        cls.ssh_manager.downloadFileFromTarget(source_file="process_monitor.conf", source_path="/opt/sysmon/etc/", destination_path=OutputPathManager.get_tests_group_path())
        if cls.os_name.lower() == "qnx":
            cls.ssh_manager.downloadFileFromTarget(source_file="sysmon_config.json", source_path="/opt/sysmon/etc/", destination_path=OutputPathManager.get_tests_group_path())
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/", output_folder=OutputPathManager.get_tests_group_path(), check_empty=False, ip_address=cls.PP_IP, ignored_files=["currentswversion", "tmp"])

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_SysMon tearDownclsss")

    def setUp(self):
        self.setPrecondition("Find sysmon PID")
        sysmon_is_running = self.check_application_is_started(app_name=self.SYSMON_APP_NAME)
        self.assertTrue(sysmon_is_running, Severity.MAJOR, "Check sysmon application is running")

    def tearDown(self):
        pass

    @classmethod
    def get_reported_cpu_cores(cls, messages):
        cores = []
        pattern = r"\(core (\d)\)"
        for message in messages:
            match = re.search(pattern, message['payload'])
            if match:
                core_nr = int(match.group(1))
                if core_nr not in cores:
                    cores.append(core_nr)
        return sorted(cores)

    @classmethod
    def get_partitions_info(cls):
        partitions_info = []
        all_filesystems = []
        if cls.os_name.lower() == "linux":
            returnValue = cls.ssh_manager.executeCommandInTarget(command="df -T", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        else:
            returnValue = cls.ssh_manager.executeCommandInTarget(command="df -n", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        partitions_output = returnValue['stdout'].strip()
        if len(partitions_output) == 0:
            logger.error("Empty output")
            return -1, -1
        partitions = partitions_output.splitlines()
        if not (len(partitions) > 1):
            logger.error("No partitions")
            return -1, -1
        headers = partitions[0]
        filesystem_start_index = headers.find("Filesystem")
        logger.debug(f"Filesystem header starts at {filesystem_start_index}")
        type_start_index = headers.find("Type")
        logger.debug(f"Type header starts at {type_start_index}")
        mounted_on_start_index = headers.find("Mounted on")
        logger.debug(f"Mounted on header starts at {mounted_on_start_index}")
        current_partition = {"filesystem": None, "type": None, "mounted on": None}
        for partition in partitions[1:]:
            if len(partition) < max([filesystem_start_index, type_start_index, mounted_on_start_index]):
                current_partition["filesystem"] = partition[filesystem_start_index:].split(" ")[0]
                continue
            elif partition.startswith(" "):
                current_partition["type"] = partition[type_start_index:].split(" ")[0]
                current_partition["mounted on"] = partition[mounted_on_start_index:].split(" ")[0]
            else:
                current_partition["filesystem"] = partition[filesystem_start_index:].split(" ")[0]
                current_partition["type"] = partition[type_start_index:].split(" ")[0]
                current_partition["mounted on"] = partition[mounted_on_start_index:].split(" ")[0]
            partitions_info.append(current_partition)
            all_filesystems.append(current_partition["filesystem"])
            current_partition = {"filesystem": None, "type": None, "mounted on": None}
        logger.debug(f"all partitions info:\n{json.dumps(partitions_info, indent=4)}")
        return all_filesystems, partitions_info

    @classmethod
    def get_domain_list(cls):
        cls.ssh_manager.downloadFileFromTarget(source_file="domainlist.json", source_path="/opt/sysmon/etc", destination_path=OutputPathManager.get_test_case_path())
        with io.open(path.join(OutputPathManager.get_test_case_path(), "domainlist.json")) as fl:
            domainlist_dict = json.load(fl)
        domainlist = []
        for entry in domainlist_dict["processes"]:
            if entry["domain_name"] not in domainlist:
                domainlist.append(entry["domain_name"])
        logger.info(f"domain list\n{domainlist}")
        return domainlist

    @classmethod
    def get_reported_domains(cls, messages, reported_caracteristic):
        reported_domains = []
        reported_usage = []
        for msg in messages:
            domain = cls.get_statistic_value(message=msg, statistic_path=f"Domain.{reported_caracteristic}.Statistics.domain")
            usage = cls.get_statistic_value(message=msg, statistic_path=f"Domain.{reported_caracteristic}.Statistics.usage")
            if domain not in reported_domains:
                reported_domains.append(domain)
                reported_usage.append(usage)
        logger.info(f"reported domains \n{reported_domains}")
        return reported_domains, reported_usage

    @classmethod
    def check_if_all_partitions_are_reported(cls, messages, partitions):
        reported_partitions = []
        timestamp = messages[-1]["timestamp"].split(".")[0]
        logger.debug(f"select all DLT messages with timestamp = {timestamp}")
        selected_payloads = []
        for message in messages:
            if message['timestamp'].split(".")[0] == timestamp:
                selected_payloads.append(message['payload'])
        logger.debug(f"selected DLT messages:\n{selected_payloads}")
        if len(selected_payloads) == 0:
            logger.error("0 selected DLT messages")
            return False
        for payload in selected_payloads:
            logger.debug(f"Search pattern \"Filesystem: ([a-z0-9/]+)\" in \"{payload}\"")
            match = re.search("Filesystem: ([a-z0-9/]+)", payload)
            if match:
                fs = match.group(1)
                reported_partitions.append(fs)
            else:
                logger.error(f"could not get Filesystem from payload")
                return False

        logger.info(f"reported partitions are\n{reported_partitions}")

        logger.info("check that count of reported partitions is equal to the number of partitions got using df command")
        if not (len(reported_partitions) == len(partitions)):
            logger.error("Check failed")
            return False

        logger.info("check that all partitons are reported")
        all_reported = True
        for partition in partitions:
            if partition not in reported_partitions:
                logger.error(f"{partition} not in df output list")
                all_reported = False
        for partition in reported_partitions:
            if partition not in partitions:
                logger.error(f"{partition} not in reported list")
                all_reported = False

        return all_reported

    @classmethod
    def get_overall_cpu_from_core_cpu(cls, messages, statistic_path):
        timestamp = 0
        last_messages = []
        for message in messages:
            if int(message['timestamp'].split(".")[0]) > timestamp:
                timestamp = int(message['timestamp'].split(".")[0])

        for message in messages:
            if int(message['timestamp'].split(".")[0]) == timestamp:
                last_messages.append(message)
        logger.debug(f"last cores CPU DLT messages =\n{last_messages}")

        if cls.number_of_cores != len(last_messages):
            logger.error(f"Nr of Core CPU reports is not equal to nr of cores")
            return -1

        all_cpu = 0.0

        for message in last_messages:
            core_perc = cls.get_statistic_value(message=message, statistic_path=statistic_path)
            if core_perc != -1:
                all_cpu += float(core_perc)
            else:
                logger.error("could not retrieve core cpu interval")
                return -1

        return all_cpu/cls.number_of_cores

    @classmethod
    def get_time_interval(cls, contextID):
        if cls.os_name.lower() == "linux":
            return cls.get_time_interval_linux(contextID=contextID)
        else:
            return cls.get_time_interval_qnx(contextID=contextID)

    @classmethod
    def get_time_interval_linux(cls, contextID):
        try:
            variable = cls.linux_time_interval_mapping[contextID]
            with io.open(path.join(OutputPathManager.get_tests_group_path(), "monitor.conf")) as dv:
                content = dv.read()
                pattern = fr"{variable}=(\d+)"
                match = re.search(pattern, content)
                if match:
                    return int(match.group(1))
                else:
                    logger.error(f"Variable for {contextID} not found in the config file")
                    return -1
        except:
            logger.error(f"Variable for {contextID} is not defined")
            return -1


    @classmethod
    def get_config_value_linux(cls, config_name):

        try:
            with io.open(path.join(OutputPathManager.get_tests_group_path(), "monitor.conf")) as dv:
                content = dv.read()
                pattern = fr"{config_name}=(\d+)"
                match = re.search(pattern, content)
                if match:
                    return int(match.group(1))
                else:
                    logger.error(f"Value of {config_name} not found in the config file")
                    return None
        except:
            logger.error(f"Error while getting value of {config_name}")
            return None

    @classmethod
    def get_config_value_qnx(cls, config_path):
        try:
            with io.open(path.join(OutputPathManager.get_tests_group_path(), "sysmon_config.json")) as dv:
                config_value = json.load(dv)
                keys = config_path.split(".")
                for key in keys:
                    config_value = config_value[key]

            return config_value
        except:
            logger.error(f"{traceback.format_exc()}")
            logger.error(f"variable for {config_path} is not defined")
            return -1

    @classmethod
    def get_time_interval_qnx(cls, contextID):
        try:
            with io.open(path.join(OutputPathManager.get_tests_group_path(), "sysmon_config.json")) as dv:
                time_interval = json.load(dv)
                keys = cls.qnx_time_interval_mapping[contextID].split(".")
                for key in keys:
                    time_interval = time_interval[key]

            return int(time_interval)
        except:
            logger.error(f"{traceback.format_exc()}")
            logger.error(f"variable for {contextID} is not defined")
            return -1

    @classmethod
    def get_reported_interfaces(cls, messages):
        interfaces = []
        pattern = "^Adapter *(.*): RX:"
        for message in messages:
            match = re.search(pattern, message["payload"])
            if match:
                interface = match.group(1)
                if interface not in interfaces:
                    interfaces.append(interface)

        return interfaces

    @classmethod
    def get_statistic_value(cls, message, statistic_path):
        logger.debug(f"Get value for {statistic_path}")
        payload = message["payload"].strip()
        logger.debug(f"payload = '{payload}'")
        pattern = cls.statistic_data
        for key in statistic_path.split("."):
            pattern = pattern[key]
        logger.debug(f"pattern = '{pattern}'")
        match = re.search(pattern, payload)
        if match:
            logger.info(f"value = {match.group(1)}")
            return match.group(1)
        else:
            logger.warn(f"could not get value")
            return -1

    @classmethod
    def get_wearout_error_injection_DIAG_payload(cls, SLC_MIN, SLC_MAX, MLC_MIN, MLC_MAX, PRE_EOL):
        DIAG_JOB = cls.STEUERN_EMMC_WEAROUT_ERROR_INJECTION[:]
        DIAG_JOB.append(SLC_MIN)
        DIAG_JOB.append(SLC_MAX)
        DIAG_JOB.append(MLC_MIN)
        DIAG_JOB.append(MLC_MAX)
        DIAG_JOB.append(PRE_EOL)
        return DIAG_JOB

    @classmethod
    def check_reported_delays(cls, messages, threshold):
        reported_delays = []
        for message in messages:
            delay = cls.get_statistic_value(message=message, statistic_path="Scheduling.non_real_time.Statistics.scheduling_delay")
            logger.debug(f"Got delay {delay} for message {message['payload']}")
            reported_delays.append(delay)

        delays_are_correct = True
        for delay in reported_delays:
            if delay == -1:
                logger.error("invalid delay")
                delays_are_correct = False
            elif int(delay) < threshold:
                logger.error("Delay less than threshold")
                delays_are_correct = False

        return delays_are_correct

    @classmethod
    def check_report_with_full_path(cls, messages):
        with_full_path = False
        for message in messages:
            if cls.someipd_posix_process_name in message['payload']:
                logger.error(f"full path found in message {message}")
                with_full_path = True
        return with_full_path


    @classmethod
    def check_report_without_options(cls, messages):
        without_full_path = False
        for message in messages:
            if cls.execution_manager_with_first_option in message['payload']:
                logger.error(f"full path found in message {message}")
                without_full_path = True
        return without_full_path

    @classmethod
    def check_report_BLK_required_statistics_IO(cls, messages):
        statistics_exists = False
        for message in messages:
            rioDiff = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.rioDiff")
            rmDiff = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.rmDiff")
            rsDiff = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.rsDiff")
            rtDiff = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.rtDiff")
            wioDiff = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.wioDiff")
            wmDiff = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.wmDiff")
            wsDiff = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.wsDiff")
            wtDiff = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.wtDiff")
            totwaititmeDiff = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.totwaititmeDiff")
            readkB = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.readkB")
            writekB = cls.get_statistic_value(message=message, statistic_path="BLK.IO.Statistics.writekB")
            if (rioDiff != -1) and (rmDiff != -1) and (rsDiff != -1) and (rtDiff != -1) and (wioDiff != -1) and (wmDiff != -1) and (wsDiff != -1) and (wtDiff != -1) and (totwaititmeDiff != -1) and (readkB != -1) and (writekB != -1):
                logger.debug(f"All statistics exists in message {message['payload']}")
                statistics_exists = True
            else:
                logger.debug(f"Some statistics does not exists in message {message['payload']}")
                statistics_exists = False
                return statistics_exists
        return statistics_exists

    @classmethod
    def check_report_CPUS_online_cores(cls, messages):
        online_cores_exists = False
        for message in messages:
            online_cores = cls.get_statistic_value(message=message, statistic_path="CPU.online_Cores.Statistics.online_cores")
            if (online_cores != -1):
                logger.debug(f"Online cores exists in message {message['payload']}")
                if (cls.PP_NAME == "mPAD_Performance_2C" and online_cores != 2) or (cls.PP_NAME == "mPAD_Performance_4C" and online_cores != 4):
                    online_cores_exists = True
                else:
                    logger.debug(f"Wrong online cores number in message {message['payload']}")
                    online_cores_exists = False
                    return online_cores_exists
            else:
                logger.debug(f"Online cores does not exists in message {message['payload']}")
                online_cores_exists = False
                return online_cores_exists
        return online_cores_exists

    @classmethod
    def check_process_cpu_usage_more_than_usage_limit(cls, messages, cpu_threshold):
        process_cpu_usage_more_than_usage_limit = False
        for message in messages:
            consumed_percentage = cls.get_statistic_value(message=message, statistic_path="CPU.Process.Statistics.consumed_percentage")
            if float(consumed_percentage) >= cpu_threshold:
                logger.debug(f"Consumed percentage in message {message['payload']} is more than 0.1")
                process_cpu_usage_more_than_usage_limit = True
            else:
                logger.debug(f"Consumed percentage in message {message['payload']} is lower than 0.1")
                process_cpu_usage_more_than_usage_limit = False
                return process_cpu_usage_more_than_usage_limit
        return process_cpu_usage_more_than_usage_limit

    @classmethod
    def check_process_cpu_usage_more_than_usage_limit_non_verbose(cls, dlt_messages, cpu_threshold):
        process_cpu_usage_more_than_usage_limit = False
        for message in dlt_messages:
            load = float(message["payload"]["load"])
            if type(load) == float:
                if load >= cpu_threshold:
                    logger.debug(f"Consumed percentage in message {message['payload']} is more than 0.1")
                    process_cpu_usage_more_than_usage_limit = True
                else:
                    logger.debug(f"Consumed percentage in message {message['payload']} is lower than 0.1")
                    process_cpu_usage_more_than_usage_limit = False
                    return process_cpu_usage_more_than_usage_limit
            else:
                logger.debug(f"Consumed percentage in message {message['payload']} is not retrieved")
                process_cpu_usage_more_than_usage_limit = False
                return process_cpu_usage_more_than_usage_limit
        return process_cpu_usage_more_than_usage_limit

    @classmethod
    def get_process_cpu_usage_limit(cls, SearchText):
        if cls.os_name.lower() == "linux":
            return cls.get_process_cpu_usage_limit_linux(SearchText=SearchText)
        else:
            return cls.get_process_cpu_usage_limit_qnx(SearchText=SearchText)

    @classmethod
    def get_process_cpu_usage_limit_linux(cls, SearchText):
        try:
            variable = cls.linux_time_interval_mapping[SearchText]
            with io.open(path.join(OutputPathManager.get_tests_group_path(), "monitor.conf")) as dv:
                content = dv.read()
                pattern = fr"{variable}=([\d.]+)"
                match = re.search(pattern, content)
                if match:
                    return float(match.group(1))
                else:
                    logger.error(f"Variable for {SearchText} not found in the config file")
                    return -1
        except:
            logger.error(f"Variable for {SearchText} is not defined")
            return -1

    @classmethod
    def get_process_cpu_usage_limit_qnx(cls, SearchText):
        try:
            with io.open(path.join(OutputPathManager.get_tests_group_path(), "sysmon_config.json")) as dv:
                time_interval = json.load(dv)
                keys = cls.qnx_time_interval_mapping[SearchText].split(".")
                for key in keys:
                    time_interval = time_interval[key]

            return float(time_interval)
        except:
            logger.error(f"{traceback.format_exc()}")
            logger.error(f"variable for {SearchText} is not defined")
            return -1

    @classmethod
    def Calculate_Alocate(cls, memTotal, memAvailable, percentage):
        needed_percent = int(memTotal) * percentage / 100
        logger.info(f"needed_percent: {needed_percent}")
        logger.info(f"memTotal: {memTotal}")
        logger.info(f"memAvailable: {memAvailable}")

        pending_Allocate_to_needed_percent = needed_percent - (int(memTotal) - int(memAvailable))
        logger.info(f"needed_percent: {pending_Allocate_to_needed_percent}")
        # return the value to be allocated to result a  RAM overload on bytes
        return int(1000 * pending_Allocate_to_needed_percent)

    def get_real_time_messages(cls, messages):
        for message in messages:
            if "Following RT thread spent" in message["payload"]:
                logger.warn("RT message found")
                return message
            else:
                continue
        logger.warn("RT message not found")
        return -1
    
    @classmethod
    def get_non_verbose_message_by_pid(cls, pid:int, dlt_messages:list):
        for item in dlt_messages:
            message = dict(item)
            if message.get('payload', {}).get('id') == pid:
                return message
        logger.error(f"message for pid {pid} was not captured")
        return None

    def get_cores_tempratures(cls, dlt_messages, number_of_cores):
        cores = []
        logger.info(f"number of cores {number_of_cores}")
        for dlt_message in dlt_messages:
            core = int(dlt_message["payload"]["core"])
            logger.info(f"core {core} is reported")
            cores.append(int(core))
        logger.info(str(cores))
        if number_of_cores == 4:
            logger.info("4 cores")
            return (0 in cores) and (1 in cores) and (2 in cores) and (3 in cores)
        else:
            logger.info("2 cores")
            return (0 in cores) and (1 in cores)

    def list_sysmon_files(self):
        ls = self.ssh_manager.executeCommandInTarget(command=f"ls {self.sysmon_etc_path}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        return ls["stdout"].strip()

    def wait_until(self, somepredicate, timeout, period=0.25, text_check="Launching EM"):
        mustend = time.time() + timeout
        while time.time() < mustend:
            if text_check in self.serial_controller.get_readed_data():
                return True
            time.sleep(period)
        return False

    def check_serial_output(self, text_check):
        return text_check in self.serial_controller.get_readed_data()
