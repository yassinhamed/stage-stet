from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_emmc_erase_count(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_emmc_erase_count"
    REQ_ID = ["/item/5888418", "/item/5888677"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports erase count statistics"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.emmc_health_report_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["EMMC"]["Erase Count"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.assertTrue(self.eMMC_manufacturer != "UNKNOWN", Severity.BLOCKER, "Check that eMMC manufacturer is known")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.emmc_health_report_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_emmc_erase_count(self):
        self.startTestStep("Wait one cycle * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get eMMC Erase count DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that eMMC erase count DLT messages are available")

        if self.eMMC_manufacturer == "MICRON":
            self.startTestStep("Get MIN_BLOCK_ERASE value if eMMC is MICRON")
            MIN_BLOCK_ERASE = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Erase Count.Statistics.MIN_BLOCK_ERASE")
            self.expectTrue(MIN_BLOCK_ERASE != self.INVALID_VALUE, Severity.MAJOR, "Check that MIN_BLOCK_ERASE is reported if eMMC is MICRON")

            self.startTestStep("Get MAX_BLOCK_ERASE value if eMMC is MICRON")
            MAX_BLOCK_ERASE = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Erase Count.Statistics.MAX_BLOCK_ERASE")
            self.expectTrue(MAX_BLOCK_ERASE != self.INVALID_VALUE, Severity.MAJOR, "Check that MAX_BLOCK_ERASE is reported if eMMC is MICRON")

            self.startTestStep("Get AVG_BLOCK_ERASE value if eMMC is MICRON")
            AVG_BLOCK_ERASE = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Erase Count.Statistics.AVG_BLOCK_ERASE")
            self.expectTrue(AVG_BLOCK_ERASE != self.INVALID_VALUE, Severity.MAJOR, "Check that AVG_BLOCK_ERASE is reported if eMMC is MICRON")

        if self.eMMC_manufacturer == "SAMSUNG":
            self.startTestStep("Get MIN_BLOCK_ERASE_SLC value if eMMC is SAMSUNG")
            MIN_BLOCK_ERASE_SLC = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Erase Count.Statistics.MIN_BLOCK_ERASE_SLC")
            self.expectTrue(MIN_BLOCK_ERASE_SLC != self.INVALID_VALUE, Severity.MAJOR, "Check that MIN_BLOCK_ERASE_SLC is reported if eMMC is SAMSUNG")

            self.startTestStep("Get MAX_BLOCK_ERASE_SLC value if eMMC is SAMSUNG")
            MAX_BLOCK_ERASE_SLC = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Erase Count.Statistics.MAX_BLOCK_ERASE_SLC")
            self.expectTrue(MAX_BLOCK_ERASE_SLC != self.INVALID_VALUE, Severity.MAJOR, "Check that MAX_BLOCK_ERASE_SLC is reported if eMMC is SAMSUNG")

            self.startTestStep("Get AVG_BLOCK_ERASE_SLC value if eMMC is SAMSUNG")
            AVG_BLOCK_ERASE_SLC = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Erase Count.Statistics.AVG_BLOCK_ERASE_SLC")
            self.expectTrue(AVG_BLOCK_ERASE_SLC != self.INVALID_VALUE, Severity.MAJOR, "Check that AVG_BLOCK_ERASE_SLC is reported if eMMC is SAMSUNG")

            self.startTestStep("Get MIN_BLOCK_ERASE_MLC value if eMMC is SAMSUNG")
            MIN_BLOCK_ERASE_MLC = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Erase Count.Statistics.MIN_BLOCK_ERASE_MLC")
            self.expectTrue(MIN_BLOCK_ERASE_MLC != self.INVALID_VALUE, Severity.MAJOR, "Check that MIN_BLOCK_ERASE_MLC is reported if eMMC is SAMSUNG")

            self.startTestStep("Get MAX_BLOCK_ERASE_MLC value if eMMC is SAMSUNG")
            MAX_BLOCK_ERASE_MLC = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Erase Count.Statistics.MAX_BLOCK_ERASE_MLC")
            self.expectTrue(MAX_BLOCK_ERASE_MLC != self.INVALID_VALUE, Severity.MAJOR, "Check that MAX_BLOCK_ERASE_MLC is reported if eMMC is SAMSUNG")

            self.startTestStep("Get AVG_BLOCK_ERASE_MLC value if eMMC is SAMSUNG")
            AVG_BLOCK_ERASE_MLC = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Erase Count.Statistics.AVG_BLOCK_ERASE_MLC")
            self.expectTrue(AVG_BLOCK_ERASE_MLC != self.INVALID_VALUE, Severity.MAJOR, "Check that AVG_BLOCK_ERASE_MLC is reported if eMMC is SAMSUNG")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
