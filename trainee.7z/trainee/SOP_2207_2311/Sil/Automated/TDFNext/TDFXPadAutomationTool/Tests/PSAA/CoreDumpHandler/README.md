# Core dump handler

Whenever a user space application crashes due to an unhandled software exception or a kernel crash happened, a coredump file shall be created. Coredump file shall make post-mortem analysis possible. Without it there shall be no possibility to exactly identify where the software exception happend. 

Coredump handler is a Process not an application

Coredump file shall contain 

- stacktrace.time_crash.app_name.app_pid.txt

- core.time_crash.app_name.app_pid.gz

- context.time_crash.app_name.app_pid.txt

- logs.time_crash.app_name.app_pid.dlt.gz
