from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter import *


class tca_psaa_CrashReporter_003_blacklist_file(testfixture_PSAA_Crash_Reporter):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_003_blacklist_file"
    REQ_ID = ["/item/7822001"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check ignorelist.json file path and permissions"
    STATUS = "Ready"
    OS = ['QNX']

    def setUp(self):
        pass

    def test_tca_psaa_CrashReporter_003_blacklist_file(self):
        self.startTestStep("Get ignorelist.json file informations using ls -l")
        ignorelist_file_path = self.ssh_manager.executeCommandInTarget(command=f"ls -l /opt/crash_reporter/etc/ | grep ignorelist.json", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue("ignorelist.json" in ignorelist_file_path["stdout"], Severity.MAJOR, "Check ignorelist.json is under /opt/crash_reporter/etc/")
        self.expectTrue("-r--r--r--" in ignorelist_file_path["stdout"], Severity.BLOCKER, "check ignorelist.json read only mode")

    def tearDown(self):
        self.setPostcondition("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
