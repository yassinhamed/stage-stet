from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_013_check_linked_libs(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_013_check_linked_libs"
    REQ_ID = ["/item/1736864","/item/1736931"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check the linked libraries in coredumps file"
    STATUS = "Ready"
    OS = ['LINUX']

    pid_ets = 0

    def setUp(self):

        self.setPrecondition("Get ETS pid")
        returnValue = self.get_process_id(app_name=self.ETS_APP_NAME)
        self.assertTrue(returnValue != -1, Severity.BLOCKER,
                        f"Check the get pid of {self.ETS_APP_NAME}")
        self.pid_ets = returnValue

    def test_tca_psaa_dumper_013_check_linked_libs(self):

        self.startTestStep("Get the content of /proc/{pid_ets}/maps")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"cat /proc/{self.pid_ets}/maps", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["stdout"].strip() != "", Severity.BLOCKER,
                        "Check stdout is not empty")
        maps=returnValue["stdout"].splitlines()

        self.startTestStep("Kill application ETS")
        ets_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(ets_is_killed, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

        self.startTestStep("Check application is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is not running")

        self.startTestStep("check coredumps created")
        coredumps_created = self.check_coredumps(self.ETS_APP_NAME)
        self.assertTrue(coredumps_created,Severity.BLOCKER,"Checking that coredumps files were created properly.")

        self.startTestStep("Get context files")
        returnValue = self.ssh_manager.executeCommandInTarget(f"cat {self.CoreDumps_Path}/context.*", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Check the existance of the result")
        output=returnValue["stdout"].strip()

        for line in maps:
            self.expectTrue(line in output, Severity.MAJOR, f"Check line : {line} exist in dump file")

    def tearDown(self):
        pass
