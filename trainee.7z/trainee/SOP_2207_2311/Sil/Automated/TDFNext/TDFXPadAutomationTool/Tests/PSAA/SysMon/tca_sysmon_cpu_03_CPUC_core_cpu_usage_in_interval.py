from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_cpu_03_CPUC_core_cpu_usage_in_interval(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_cpu_03_CPUC_core_cpu_usage_in_interval"
    REQ_ID = ["/item/5829101", "/item/142161", "/item/142158"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports the cpu usage in interval for each core"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.assertTrue(self.number_of_cores != self.INVALID_VALUE, Severity.MAJOR, "Check that number of online cores is available")
        self.time_interval = self.get_time_interval(contextID=self.CPU_core_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["CPU"]["Cores"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.CPU_core_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_cpu_03_CPUC_core_cpu_usage_in_interval(self):
        self.startTestStep("Wait one cycle * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get CPU Core DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(contextId=self.CPU_core_context_id, searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that CPU cores DLT messages are available")

        self.startTestStep("Get in_interval value")
        in_interval = self.get_statistic_value(message=messages[0], statistic_path="CPU.Cores.Statistics.in_interval")
        self.expectTrue(in_interval != self.INVALID_VALUE, Severity.MAJOR, "Check that in_interval is reported")

        reported_cores = self.get_reported_cpu_cores(messages=messages)
        self.expectTrue(reported_cores == [x+1 for x in range(self.number_of_cores)], Severity.MAJOR, "Check the overall cpu usage in interval message exist only for all online cores")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
