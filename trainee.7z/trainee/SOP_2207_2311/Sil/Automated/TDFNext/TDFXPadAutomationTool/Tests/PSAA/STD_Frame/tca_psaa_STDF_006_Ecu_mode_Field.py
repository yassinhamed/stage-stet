from Tests.PSAA.STD_Frame.testfixture_PSAA_STDFrame import *


class tca_psaa_STDF_006_Ecu_mode_Field(testfixture_PSAA_STDFrame):

    TEST_ID = "PSAA\tca_psaa_STDF_006_Ecu_mode_Field"
    REQ_ID = ["/item/2175806"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check non verbose message 'Eng_mode_msg_short_name' is logged"
    OS = ['LINUX','QNX']
    STATUS = "Ready"


    def setUp(self):
        self.diag_manager.start()
        self.setPrecondition("Setting the DUT's SFA mode to Field mode.")
        self.sfa_manager.set_up(target_address=self.PP_DIAG_ADR)
        resp = self.sfa_manager.safe_set_to_field_mode(target=self.PP_DIAG_ADR)
        self.assertTrue(resp, Severity.BLOCKER, "Check no error while setting to Field mode.")
        mode = self.sfa_manager.sfa_get_ecu_mode(target=self.PP_DIAG_ADR)
        self.assertTrue(EcuMode.Field.value == mode, Severity.BLOCKER, f'Check current mode. Expected: {EcuMode.Plant.value}, Actual {mode}')
        self.sleep_for(self.sfa_update_delay)
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_CurrentEngMode)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_STDF_006_Ecu_mode_Field(self):
        self.startTestStep("Get non verbose message 'Eng_mode_msg_short_name'")
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.Eng_mode_msg_short_name, sender=self.PP_ECUID,
                                                             filter_attributes=None)
        self.sleep_for(self.wait_for_STDF_dlt_message)
        self.dlt_manager.stop_capturing_non_verbose_message()
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check the non verbose message 'Eng_mode_msg_short_name' was received")
        logger.info(f"DTL message = {dlt_messages[-1]}")
        dlt_msg = dlt_messages[-1]['payload']
        logger.info("[DLT Messages ]:{0}".format(dlt_msg))
        val = hex(dlt_msg['engg'])
        Eng = str(bytearray.fromhex(val.split('x')[1]).decode())
        self.expectTrue(dlt_msg['engg_mode_len'] == 1, Severity.MAJOR,
                        f"Check value of engg_mode_len. Expected: 1, Actual: {dlt_msg['engg_mode_len']}")
        self.expectTrue(Eng == "F", Severity.MAJOR, f"Check engg value. Expected : F, Actual: {Eng}")

    def tearDown(self):
        self.setPostcondition("Setting the DUT's SFA mode to engineering mode.")
        resp = self.sfa_manager.safe_set_to_engineering_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(resp, Severity.BLOCKER, "Check no error while setting to eng mode.")
        mode = self.sfa_manager.sfa_get_ecu_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(EcuMode.Engineering.value == mode, Severity.BLOCKER, f'Check current mode. Expected: {EcuMode.Engineering.value}, Actual {mode}')
        self.sfa_manager.stop_sfa_manager()
        self.diag_manager.stop()
