from Tests.PSAA.Log_Collector.testfixture_PSAA_Log_Collector import *


class tca_PSAA_002_logC_ConfigFile_Removed(testfixture_PSAA_Log_Collector):

    TEST_ID = "PSAA\tca_PSAA_002_logC_ConfigFile_Removed"
    REQ_ID = ["/item/2593628","/item/2593612"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Obsolete"
    OS = ['LINUX']

    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.apply_filter(appId=self.LOG_COLLECTOR_APP_ID, context_ID=self.Configuration_error_context_ID)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_PSAA_002_logC_ConfigFile_Removed(self):
        self.ssh_manager.executeCommandInTarget(command="mount -o remount,rw /",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.startTestStep("Move config file under persistent")
        remove_file = self.ssh_manager.executeCommandInTarget(
            command=f"mv {self.Config_file_path + self.Config_file_name} /persistent/Technica",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(remove_file["exec_recv"] == 0, Severity.MAJOR, "Check file removed")
        self.ssh_manager.executeCommandInTarget(command="mount -o remount,ro /",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.startTestStep("Check the existence of security_events.json")
        check_file = self.ssh_manager.executeCommandInTarget(command=f"ls {self.Config_file_path}",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(check_file["stdout"].strip() != "", Severity.MAJOR, "Check file not exist")
        folder_contents = check_file["stdout"].strip()
        logger.info("folder contents: " + str(folder_contents))
        self.assertTrue(self.Config_file_name not in str(folder_contents), Severity.BLOCKER,
                        "Check security configuration file not exists")
        self.startTestStep("Get DLT messages")
        number, message = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.LOG_COLLECTOR_APP_ID, context_ID=self.Configuration_error_context_ID,
                                                               searchMsgArray=["not", "security", "config"])
        self.assertTrue(number > 0, Severity.BLOCKER, "Check error detected")

    def tearDown(self):
        self.setPostcondition("Revert Config file")
        self.logCollectorRevertConfigFile()
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
