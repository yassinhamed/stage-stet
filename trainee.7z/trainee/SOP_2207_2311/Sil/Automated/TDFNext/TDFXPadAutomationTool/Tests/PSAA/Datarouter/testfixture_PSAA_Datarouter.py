from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_Datarouter(testfixture_PSAA):

    channels_file_path = "/opt/datarouter/etc/log-channels.json"
    wait_for_dlt_message_to_be_sent = 60000

    def setUp(self):
        ECU_status = self.check_ECUs()
        self.assertTrue(ECU_status, Severity.BLOCKER, "Checking that ECU status is OK")
        feature_status = self.sfa_manager.sfa_get_status(self.PP_DIAG_ADR, feature_id=self.SFA_ID)
        if feature_status == Feature_Status.Disabled or feature_status == Feature_Status.IntialDisabled:
            self.ecu_uid = self.sfa_manager.get_ecu_uid(target=self.PP_DIAG_ADR, use_cache=False)
            self.sfa_manager.start_sfa_manager()
            self.tokensPath = self.sfa_manager.generate_tokens(ecu_uid=self.ecu_uid)
            self.sfa_manager.configure_sfa_manager(target=self.PP_DIAG_ADR, pathToTokens=self.tokensPath)
            res = self.sfa_manager.set_secure_feature(target=self.PP_DIAG_ADR,
                                                      ecu_uid=self.ecu_uid,
                                                      feature_id=self.SFA_ID,
                                                      result_dir=OutputPathManager.get_report_path(),
                                                      feature_spec_fields=self.sfa_manager.generate_ssh_key_payload())
            self.expectTrue(res == True, Severity.BLOCKER, "Checking that SFA Debug token is Enabled")
            self.sfa_manager.stop_sfa_manager()

        self.startTestStep("Get the PID of datarouter")
        datarouter_status = self.get_process_id(app_name=self.DATA_ROUTER_APP_NAME, exclude=True, exclude_app_name="conf")
        self.expectTrue(datarouter_status != -1, Severity.BLOCKER,"Checking that datarouter is running")

        datarouterconf_status = self.check_application_is_started(app_name=self.DATA_ROUTER_CONF_APP_NAME)
        self.expectTrue(datarouterconf_status,Severity.MAJOR, "Checking that datarouterconf is running")

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_Datarouter setUpclsss")
        cls.ssh_manager.executeCommandInTarget("ls /opt/datarouter/bin")
        cls.ssh_manager.executeCommandInTarget("ls /opt/datarouter/etc")

        cls.default_check_empty = False
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/", output_folder=path.join(OutputPathManager.get_tests_group_path(),"coredumps_setupclass"),check_empty=True, ip_address=cls.PP_IP)

    def tearDown(self):
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECU_status = self.check_ECUs()
        self.expectTrue(ECU_status, Severity.BLOCKER, "Checking that ECU status is OK")

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_Datarouter tearDownclsss")
        #cls.ssh_manager.removeFileFromTarget(cls.per_log_test_folder, ip_address=cls.PP_IP)

    def RevertConfigFile(self):
        self.ssh_manager.executeCommandInTarget(command=f"cp -f /persistent/Technica/sysmon_logging.json /opt/sysmon/etc/logging.json",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.ssh_manager.executeCommandInTarget(command=f"chmod 644 /opt/sysmon/etc/logging.json",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        result = self.ssh_manager.executeCommandInTarget(command=f'ls -l /opt/sysmon/etc/logging.json',timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue('-rw-r--r--' in result['stdout'], Severity.MAJOR, f"False Permission, Permission = {result['stdout']}")

    def without_extended_header(self, dlt_messages):
        extended_header_not_exist = True
        for dlt_msg in dlt_messages[1]:
            dlt = dlt_msg.keys()
            logger.info("dlt_keys: " + str(dlt))
            if ("extended_header" in dlt):
                extended_header_not_exist = False
        return extended_header_not_exist

