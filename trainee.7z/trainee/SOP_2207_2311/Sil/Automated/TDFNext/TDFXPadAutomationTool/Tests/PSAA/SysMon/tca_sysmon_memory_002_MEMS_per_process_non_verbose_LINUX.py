from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_002_MEMS_per_process_non_verbose_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_002_MEMS_per_process_non_verbose_LINUX"
    REQ_ID = ["/item/5904902"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports total RAM consumption per process in non-verbose mode"
    OS = ['Linux']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get sysmon PID")
        self.assertTrue(True, Severity.MAJOR, "Check that sysmon is running (has PID)")
        self.setPrecondition("Start DLT monitoring")

    def test_tca_sysmon_memory_002_MEMS_per_process_non_verbose_LINUX(self):
        self.startTestStep("Wait time interval  * 2")
        self.startTestStep("Get DLT EMEMS messages of RAM consumption per process")
        self.assertTrue(True, Severity.MAJOR, "Check that DLT EMMC of RAM consumption per process messages are available")
        self.expectTrue(True, Severity.MAJOR, "Check that dlt messages contain all required statistics")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
