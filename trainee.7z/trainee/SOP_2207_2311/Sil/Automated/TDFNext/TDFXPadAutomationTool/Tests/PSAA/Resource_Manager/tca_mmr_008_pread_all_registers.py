from Tests.PSAA.Resource_Manager.testfixture_PSAA_RM import *


class tca_mmr_008_pread_all_registers(testfixture_PSAA_RM):

    TEST_ID = "PSAA\Ressource_Manager\tca_mmr_008_pread_all_registers"
    REQ_ID = ['/item/5280137','/item/5311827']
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    PRIORITY = "Critical"
    DESCRIPTION = "Seeking by lseek(2) shall be allowed but not required on the exposed files"
    STATUS = "Ready"
    OS = ['QNX']


    def setUp(self):
        pass

    def test_tca_mmr_008_pread_all_registers(self):
        self.startTestStep("Get all allowed MMR register from configuration file")
        
        mmr_regs = self.get_registers_based_on_type(self.MMR_JSON_PATH, "MMR")
        mmr_PWRMBASE_offsets, mmr_MCHBAR_offsets, mmr_SBREG_offsets = self.get_bar_offset_list_from_mmr_registers(mmr_regs)
        mmr_PWRMBASE_sizes, mmr_MCHBAR_sizes, mmr_SBREG_sizes = self.get_size_list_from_mmr_registers(mmr_regs)
        
        logger.info(    f"""
        ---------------------------------------------------------
        All gathered info:
        mmr_PWRMBASE_offsets: {mmr_PWRMBASE_offsets}
        mmr_MCHBAR_offsets: {mmr_MCHBAR_offsets}
        mmr_SBREG_offsets: {mmr_SBREG_offsets}

        mmr_PWRMBASE_sizes: {mmr_PWRMBASE_sizes}
        mmr_MCHBAR_sizes: {mmr_MCHBAR_sizes}
        mmr_SBREG_sizes: {mmr_SBREG_sizes}
        ---------------------------------------------------------
                        """)
        self.startTestStep("Read all MMR register pread.")

        logger.info("perform_operation_on_mmr_registers pwrmbase")
        open_exit_code, pread_exit_codes, close_exit_code = self.perform_operation_on_mmr_registers(op_type="PREAD", bar_type="pwrmbase")
        
        self.expectTrue(open_exit_code == 0, Severity.CRITICAL, "Exit code for opening pwrmbase is positive.")
        self.expectTrue(all(code == 0 for code in pread_exit_codes), Severity.CRITICAL, "Exit codes for preading pwrmbase registers are positive.")
        self.expectTrue(close_exit_code == 0, Severity.CRITICAL, "Exit code for closing pwrmbase is positive.")

        logger.info("perform_operation_on_mmr_registers mchbar")
        open_exit_code, pread_exit_codes, close_exit_code = self.perform_operation_on_mmr_registers(op_type="PREAD", bar_type="mchbar")
        
        self.expectTrue(open_exit_code == 0, Severity.CRITICAL, "Exit code for opening mchbar is positive.")
        self.expectTrue(all(code == 0 for code in pread_exit_codes), Severity.CRITICAL, "Exit codes for preading mchbar registers are positive.")
        self.expectTrue(close_exit_code == 0, Severity.CRITICAL, "Exit code for closing mchbar is positive.")

        logger.info("perform_operation_on_mmr_registers sbreg 0x10")
        open_exit_code, pread_exit_codes, close_exit_code = self.perform_operation_on_mmr_registers(op_type="PREAD", bar_type="sbreg", sbreg_bar_port="0x10")
        
        self.expectTrue(open_exit_code == 0, Severity.CRITICAL, "Exit code for opening sbreg 0x10 is positive.")
        self.expectTrue(all(code == 0 for code in pread_exit_codes), Severity.CRITICAL, "Exit codes for preading sbreg 0x10 registers are positive.")
        self.expectTrue(close_exit_code == 0, Severity.CRITICAL, "Exit code for closing sbreg 0x0x10 is positive.")

        logger.info("perform_operation_on_mmr_registers sbreg 0x12")
        open_exit_code, pread_exit_codes, close_exit_code = self.perform_operation_on_mmr_registers(op_type="PREAD", bar_type="sbreg", sbreg_bar_port="0x12")

        self.expectTrue(open_exit_code == 0, Severity.CRITICAL, "Exit code for opening sbreg 0x12 is positive.")
        self.expectTrue(all(code == 0 for code in pread_exit_codes), Severity.CRITICAL, "Exit codes for preading sbreg 0x12 registers are positive.")
        self.expectTrue(close_exit_code == 0, Severity.CRITICAL, "Exit code for closing sbreg 0x12 is positive.")

        logger.info("perform_operation_on_mmr_registers sbreg 0xC2")
        open_exit_code, pread_exit_codes, close_exit_code = self.perform_operation_on_mmr_registers(op_type="PREAD", bar_type="sbreg", sbreg_bar_port="0xC2")

        self.expectTrue(open_exit_code == 0, Severity.CRITICAL, "Exit code for opening sbreg 0xC2 is positive.")
        self.expectTrue(all(code == 0 for code in pread_exit_codes), Severity.CRITICAL, "Exit codes for preading sbreg 0xC2 registers are positive.")
        self.expectTrue(close_exit_code == 0, Severity.CRITICAL, "Exit code for closing sbreg 0xC2 is positive.")

        logger.info("perform_operation_on_mmr_registers sbreg 0xC5")
        open_exit_code, pread_exit_codes, close_exit_code = self.perform_operation_on_mmr_registers(op_type="PREAD", bar_type="sbreg", sbreg_bar_port="0xC5")

        self.expectTrue(open_exit_code == 0, Severity.CRITICAL, "Exit code for opening sbreg 0xC5 is positive.")
        self.expectTrue(all(code == 0 for code in pread_exit_codes), Severity.CRITICAL, "Exit codes for preading sbreg 0xC5 registers are positive.")
        self.expectTrue(close_exit_code == 0, Severity.CRITICAL, "Exit code for closing sbreg 0xC5 is positive.")

    def tearDown(self):
        pass