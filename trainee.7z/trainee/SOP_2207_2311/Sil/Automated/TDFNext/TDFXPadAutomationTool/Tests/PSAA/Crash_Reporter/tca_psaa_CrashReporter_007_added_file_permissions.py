from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter import *


class tca_psaa_CrashReporter_007_added_file_permissions(testfixture_PSAA_Crash_Reporter):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_007_added_file_permissions"
    REQ_ID = ["/item/6159353"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check added files permissions"
    STATUS = "Obsolete"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Clear old core dumps")
        self.setPrecondition("Get dumper process informations using ps -A -o pid,args | grep dumper")
        self.assertTrue(True, Severity.MAJOR, "Check dumper is running")
        self.setPrecondition("Get crash reporter process informations using ps -A -o pid,args | grep crash_reporter")
        self.assertTrue(True, Severity.MAJOR, "Check crash reporter is running")
        self.expectTrue(True, Severity.MAJOR, "Check quota value")
        self.expectTrue(True, Severity.MAJOR, "Check min free space value")

    def test_tca_psaa_CrashReporter_007_added_file_permissions(self):
        self.startTestStep("Add file under /persistent/coredumps")
        self.startTestStep("Get file access permissions using ls -l /persistent/coredumps command")
        self.expectTrue(True, Severity.MAJOR, "Check coredumps files access is -r--r-----")
        self.startTestStep("Add file under /persistent/coredumps/tmp")
        self.startTestStep("Get file access permissions using ls -l /persistent/coredumps/tmp command")
        self.expectTrue(True, Severity.MAJOR, "Check coredumps files access is -r--r-----")

    def tearDown(self):
        self.setPostcondition("Reset ECU")
