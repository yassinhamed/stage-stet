from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_HW_IRQ_01_IRQH_non_verbose_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_HW_IRQ_01_IRQH_non_verbose_LINUX"
    REQ_ID = ["/item/5888650", "/item/5888716", "/item/5888728", "/item/5889454", "/item/5888802"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports HW IRQ statistics in non-verbose mode"
    OS = ['LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        # TODO add message id
        self.dlt_manager.apply_filter(messageId="")
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_HW_IRQ_01_IRQH_non_verbose_LINUX(self):
        # TODO add message short name
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name="", sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait the configured time interval * 4.5")
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get IRGH non-verbose DLT messages")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(True, Severity.MAJOR, "Check that DLT message exits")
        self.expectTrue(True, Severity.MAJOR, "Check that all information are logged in one message (only 4 messages)")
        self.expectTrue(True, Severity.MAJOR, "Check that interrupt names are sorted a alphabetical order (lowercase than uppercase)")
        self.expectTrue(True, Severity.MAJOR, "Check that MIS interrupt is not reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
