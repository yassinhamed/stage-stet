from Tests.PSAA.STD_Frame.testfixture_PSAA_STDFrame import *


class tca_psaa_STDF_001_start_frame(testfixture_PSAA_STDFrame):

    TEST_ID = "PSAA\tca_psaa_STDF_001_start_frame"
    REQ_ID = ["/item/2175806"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check STDF Starting frame verbose dlt message is logged"
    OS = ['LINUX','QNX']
    STATUS = "Ready"

    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appId=self.STDFrame_APP_ID)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_STDF_001_start_frame(self):
        self.startTestStep("Get STDF Starting frame verbose dlt message")
        self.sleep_for(self.wait_for_start_STDF_dlt_message)
        messages_count, messages_array_set = self.dlt_manager.get_messages(searchMsg=self.first_search_msg)
        self.expectTrue(messages_count > 0, Severity.BLOCKER,"Check STDF Starting frame is logged")

    def tearDown(self):
        pass
