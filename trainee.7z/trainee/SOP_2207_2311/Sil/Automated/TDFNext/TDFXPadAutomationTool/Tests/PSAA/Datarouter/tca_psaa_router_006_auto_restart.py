from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_psaa_router_006_auto_restart(testfixture_PSAA_Datarouter):

    TEST_ID = "Datarouter\tca_psaa_router_006_auto_restart"
    REQ_ID = ["/item/1573713", "/item/145159"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX']


    def setUp(self):
        self.setPrecondition("Get the PID of datarouter")
        self.datarouter_pid_initial = self.get_process_id(app_name=self.DATA_ROUTER_APP_NAME, exclude=True, exclude_app_name="conf")

        self.assertTrue(self.datarouter_pid_initial != -1, Severity.BLOCKER, "Checking that the pid of datarouter is returned successfully")

    def test_datarouter_auto_restart(self):
        self.startTestStep("Kill datarouter")
        datarouter_is_killed = self.kill_application(app_name=self.DATA_ROUTER_APP_NAME,signal=self.killall_options["SIGABRT"])
        self.expectTrue(datarouter_is_killed, Severity.MAJOR, "Checking that datarouter is killed")

        self.sleep_for(self.KILL_TIMEOUT_MS)

        self.startTestStep("Get the PID of datarouter")
        self.datarouter_pid_post_kill = self.get_process_id(app_name=self.DATA_ROUTER_APP_NAME, exclude=True, exclude_app_name="conf")
        self.assertTrue(self.datarouter_pid_post_kill > self.datarouter_pid_initial, Severity.BLOCKER, "Checking that new pid is bigger then old pid.")

    def tearDown(self):
        pass
