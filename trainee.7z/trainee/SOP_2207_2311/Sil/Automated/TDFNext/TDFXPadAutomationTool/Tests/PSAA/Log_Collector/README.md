# Log Collector 

**Overview** 

The log collector application is an adaptive application used to collect all the required logs for analysis and security purposes including the journal log, syslog, kernel logs … 

The log collector is a single threaded application which reads all of it is logs from the journal logs 

The application uses a configuration file called the security_events.json file to set the looging and dtc triggering on event. The event is the detection of a message with a specific context_id and matching a regular expression mentioned in the file. 

How does it work ? 

As most of the adaptive applications the log collector has 3 stages initialization, run and shutdown, now let's have a look on the log collector behavior in each stage 

**Initialization:** 

In the initialization stage the log collector does 2 main things: 

- Initialize and clear both of the DTCs (0x022292 and 0x482EA9) used for security issues detection and it additionally initializes the DID used to log the message causes either the DTCs to be set. 

- The log collector loads the security configuration file, checks it syntactically and matches the schema expected by log collector. 

The file can be found under /opt/log_collector/etc/security_events.json and this is an exemple of the configuration: 

https://cc-github.bmwgroup.net/swh/ddad_platform/blob/master/aas/pas/log_collector/etc/security_events.json 

 

**Run** 

Here is most of the work done, let's try to put them in logical steps: 

- The log collector start looping over the journal log message and parse them 

- After parsing the journal message the following information is known: 

  - message payload 

  - message logging context (KMSG, SYSL, AUD and JOUR) 

  - message log severity (Fatal, Error, Warn, Info, Debug and Verbose) 

- The log collector checks if any of the security configuration matches the message, in our current state if no security configuration is configured to set either of the DTCs or even both, there is a permissive regex configuration (*) to match all the messages and has only one action which is logging to dlt, in other word all the messages will be logged to dlt 

- In case of setting a DTC the log collector will fill the log_collector_info Did which hold 128 bytes of the messages caused the setting of the DTC, if the message length is smaller than 128 bytes the rest will be filed with 0xff if it more than 128 bytes the message will be trimmed 

- The security configurations is matched by order and after the first match the rest will be neglected 

**Shutdown** 

The shutdown phase is the simplest just stop offering the services and resets all the used pointers 

**User Guide** 

To use the log collector for security purpose you need to configure your message and the corresponding action in the security configuration file which can be found here: *log_collector/etc/security_events.json* 

**Configuration** 

There are five parameter you need to configure in each security entry: 

- MessageSource: the message source attribute defines where this message is coming from and in the log collector we have 4 different sources: 

  - Kernel message: KMSG 

  - Audit message: AUD 

  - Syslog message: SYSL 

  - Journal message: JOUR 

- MessageRegex: the regex used to match the message, one important note here we are using regex_search which mean if the regex matches any part of the message a match will be count in other word the regex should not match the whole message to count a match 

- SetDTC022292: This is a boolean attribute to set the system_error_with_integrity_check DTC. Values are Yes or No 

- SetDTC482EA9: This is a boolean attribute to set the internal_system_manipulation_detected DTC. values can be Yes or No 

- LogDlt: This is a boolean attribute to relay the message to dlt. Values are Yes or No. 

**Example** 
```
"EventsConfigs": [
      { 
        "MessageSource": "KMSG", 
        "MessageRegex": "device-mapper: verity: [0-9]:[0-9]: (meta){0,1}data block [0-9]+ is  corrupted", 
        "SetDTC022292": "Yes", 
        "SetDTC482EA9": "No", 
        "LogDlt": "Yes" 
      }, 
      { 
        "MessageSource": "KMSG", 
        "MessageRegex": "device-mapper: crypt: dm-5: INTEGRITY AEAD ERROR, sector [0-9]+", 
        "SetDTC022292": "Yes", 
        "SetDTC482EA9": "No", 
        "LogDlt": "Yes" 
      }, 
]
 ```
 

**DLT log** 

Each source of log in the log collector has a separate CtxId, so here is a list of the sources and their Ctxids: 

- Syslog has Ctxid SYSL 

- Kernel message has Ctxid KMSG 

- Audit message has Ctxid AUD 

- Journal has Ctxid JOUR
 

For more info :
https://cc-github.bmwgroup.net/swh/ddad_platform/tree/master/aas/pas/log_collector 

Useful linux command : 

- journalctl –f : get journal logs on real time. 

- journalctl –u [service name] : get logs related to the service name from journal. 

- journalctl –u audit : get audit logs from journal. 

- journalctl –k : get kernal logs from journal. 

- journalctl –t [identifier] : get logs using identifier (e.g. LOGC). 

- logger –t [identifier] “Hello world” : send SYSL log contains “Hello world” message with an identifier. 

- journalctl –n 10 : get last 10 juornal logs. 

- timeout 10s | journalctl –S now : get journal logs in the next 10 seconds. 

- echo “kernel : test : Hello” > /dev/kmsg : add “test : Hello” message in kernel logs. 