from Tests.PSAA.Param_Server.testfixture_PSAA_param_server import *


class tca_ParamS_010_default_value_is_persistent_not_coding(testfixture_PSAA_param_server):

    TEST_ID = "ParamServer\tca_ParamS_010_default_value_is_persistent_not_coding"
    REQ_ID = ["/item/727615", "/item/53147"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    field_depends_on_coding = False

    def setUp(self):
        pass

    def test_default_value_is_persistent_not_coding(self):

        new_parameter_values = self.generate_paresed_payload_newSetValues(field_name=self.tested_field)

        new_payload = self.parsed_payload_to_hex_list(parsed_payload=new_parameter_values, structure=self.field_structure)

        self.someip_controller.send_request("TestEquipmentIntern", service_id=self.AdpParameters_service_ID, instance_id=self.AdpParameters_instances[self.PP_NAME],
                                            method_id=self.someipIds['setterID'], payload=new_payload, interface_version=1, is_TCP=False)

        self.sleep_for(self.SETTER_NOTIF_TIMEOUT_MS)

        someip_notifications = self.get_someip_messages_from_queue(method_id=self.someipIds['notifierID'])
        self.assertTrue(len(someip_notifications) > 0, Severity.BLOCKER, "Check that a notification after the setter request is received")
        self.expectTrue(len(someip_notifications) == 1, Severity.MAJOR, "Check that exactly 1 notification after the setter request is received")

        notification = someip_notifications[-1].payload
        logger.info(f"The payload of the notification = {notification}")

        notification_payload_size = len(notification)
        logger.info(f"The payload size of the received notification = {notification_payload_size}")
        self.assertTrue(notification_payload_size == self.field_size, Severity.BLOCKER, "Check that the payload size of the notification is correct.")

        parsed_notification_payload = self.parse_field_someip_payload(payload=notification, field_structure=self.field_structure)
        logger.info(f"{json.dumps(parsed_notification_payload, indent=4)}")

        self.assertTrue(parsed_notification_payload == new_parameter_values, Severity.BLOCKER, "Check that the parameter Values in the received notification equal the values sent in the Setter request")

        self.someip_manager.reset(ecu="TestEquipmentIntern")

        self.someip_controller.send_request("TestEquipmentIntern", service_id=self.AdpParameters_service_ID, instance_id=self.AdpParameters_instances[self.PP_NAME],
                                            method_id=self.someipIds['getterID'], interface_version=1, is_TCP=False)

        self.sleep_for(self.GETTER_RESPONSE_TIMEOUT_MS)

        someip_response_messages = self.get_someip_messages_from_queue(method_id=self.someipIds['getterID'])

        self.expectTrue(len(someip_response_messages) > 0, Severity.BLOCKER, "Check that a response of the getter request is received")
        self.expectTrue(len(someip_response_messages) == 1, Severity.MAJOR, "Check that exactly 1 response of the getter request is received")

        getter_response = someip_response_messages[-1].payload
        logger.info(f"Response payload of the getter = {getter_response}")

        getter_response_size = len(getter_response)
        logger.info(f"The size of the received Getter response = {getter_response_size}")
        self.assertTrue(getter_response_size == self.field_size, Severity.BLOCKER, "Check that the payload size of the getter response is correct.")

        parsed_getter_response = self.parse_field_someip_payload(payload=getter_response, field_structure=self.field_structure)
        logger.info(f"Parsed Getter response :\n{json.dumps(parsed_getter_response, indent=4)}")

        result = self.compare_2_dicts(parsed_getter_response,  new_parameter_values)
        self.assertTrue(result, Severity.BLOCKER, "Check that the parameter Values in Getter response equals the new paramter values")

        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")

        self.someip_manager.reset(ecu="TestEquipmentIntern")

        self.someip_controller.send_request("TestEquipmentIntern", service_id=self.AdpParameters_service_ID, instance_id=self.AdpParameters_instances[self.PP_NAME],
                                            method_id=self.someipIds['getterID'], interface_version=1, is_TCP=False)

        self.sleep_for(self.GETTER_RESPONSE_TIMEOUT_MS)

        someip_response_messages = self.get_someip_messages_from_queue(method_id=self.someipIds['getterID'])

        self.expectTrue(len(someip_response_messages) > 0, Severity.BLOCKER, "Check that a response of the getter request is received")
        self.expectTrue(len(someip_response_messages) == 1, Severity.MAJOR, "Check that exactly 1 response of the getter request is received")

        getter_response = someip_response_messages[-1].payload
        logger.info(f"Response payload of the getter = {getter_response}")

        getter_response_size = len(getter_response)
        logger.info(f"The size of the received Getter response = {getter_response_size}")
        self.assertTrue(getter_response_size == self.field_size, Severity.BLOCKER, "Check that the payload size of the getter response is correct.")

        parsed_getter_response = self.parse_field_someip_payload(payload=getter_response, field_structure=self.field_structure)
        logger.info(f"Parsed Getter response :\n{json.dumps(parsed_getter_response, indent=4)}")
        logger.info(f"expected result :\n{json.dumps(self.initial_parsed_payload, indent=4)}")

        result = self.compare_2_dicts(parsed_getter_response,  self.initial_parsed_payload)
        self.assertTrue(result, Severity.BLOCKER, "Check that the parameter Values in Getter response after the reset equals the default paramter values")

    def tearDown(self):
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset in TearDown")

