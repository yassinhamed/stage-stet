from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_scheduling_delay_001_non_real_time_thread_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_scheduling_delay_001_non_real_time_thread_LINUX"
    REQ_ID = ["/item/5909649", "/item/5909934"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that  sysmon reports scheduling delay for non-real time threads"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.search_msg_array = self.statistic_data["Scheduling"]["non_real_time"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.non_real_time_scheduling_delay_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_scheduling_delay_001_non_real_time_thread_LINUX(self):
        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.startTestStep("Check ECUs")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUs are Ok after ECU reset")

        self.startTestStep("Wait 30 seconds")
        self.sleep_for(self.wait_for_scheduling_delay_reports_ms)

        self.startTestStep("Get SCHD DLT message")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that SCHD DLT messages are available")

        self.startTestStep("Get sscheduling_delay value")
        scheduling_delay = self.get_statistic_value(message=messages[0], statistic_path="Scheduling.non_real_time.Statistics.scheduling_delay")
        self.expectTrue(scheduling_delay != self.INVALID_VALUE, Severity.MAJOR, "Check that scheduling_delay is reported")

        self.startTestStep("Get number_of_times value")
        number_of_times = self.get_statistic_value(message=messages[0], statistic_path="Scheduling.non_real_time.Statistics.number_of_times")
        self.expectTrue(number_of_times != self.INVALID_VALUE, Severity.MAJOR, "Check that number_of_times is reported")

        self.startTestStep("Get in_interval value")
        in_interval = self.get_statistic_value(message=messages[0], statistic_path="Scheduling.non_real_time.Statistics.in_interval")
        self.expectTrue(in_interval != self.INVALID_VALUE, Severity.MAJOR, "Check that in_interval is reported")

        self.startTestStep("Get thread_name value")
        thread_name = self.get_statistic_value(message=messages[0], statistic_path="Scheduling.non_real_time.Statistics.thread_name")
        self.expectTrue(thread_name != self.INVALID_VALUE, Severity.MAJOR, "Check that thread_name is reported")

        self.startTestStep("Get parent_PID value")
        parent_PID = self.get_statistic_value(message=messages[0], statistic_path="Scheduling.non_real_time.Statistics.parent_PID")
        self.expectTrue(parent_PID != self.INVALID_VALUE, Severity.MAJOR, "Check that parent_PID is reported")

        self.startTestStep("Get parent_process_name value")
        parent_process_name = self.get_statistic_value(message=messages[0], statistic_path="Scheduling.non_real_time.Statistics.parent_process_name")
        self.expectTrue(parent_process_name != self.INVALID_VALUE, Severity.MAJOR, "Check that parent_process_name is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
