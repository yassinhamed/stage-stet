from Tests.PSAA.Param_Server.testfixture_PSAA_param_server import *


class tca_ParamS_030_check_default_values_file(testfixture_PSAA_param_server):

    TEST_ID = "ParamServer\tca_ParamS_030_check_default_values_file"
    REQ_ID = ["/item/727604"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    field_depends_on_coding = None

    def setUp(self):
        pass

    def test_check_default_values_file(self):
        result = self.check__default_values_file_is_valid()

        self.assertTrue(result, Severity.BLOCKER, "Check that structure of the dict in default_values.json is correct")

    def tearDown(self):
        pass
