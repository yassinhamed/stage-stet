from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_running_interval(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_running_interval"
    REQ_ID = ["/item/5906520"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports messages as often as it is configured"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")

        all_intervals = []

        self.time_interval_cpuc = self.get_time_interval(contextID=self.CPU_core_context_id)
        logger.info(f"Time interval = {self.time_interval_cpuc}")
        self.assertTrue(self.time_interval_cpuc != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        all_intervals.append(self.time_interval_cpuc)

        self.time_interval_cpus = self.get_time_interval(contextID=self.CPU_system_context_id)
        logger.info(f"Time interval = {self.time_interval_cpus}")
        self.assertTrue(self.time_interval_cpus != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        all_intervals.append(self.time_interval_cpus)

        self.time_interval_emmc = self.get_time_interval(contextID=self.emmc_health_report_context_id)
        logger.info(f"Time interval = {self.time_interval_emmc}")
        self.assertTrue(self.time_interval_emmc != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        all_intervals.append(self.time_interval_emmc)

        self.time_interval_lled = self.get_time_interval(contextID=self.Low_level_error_diagnostics_context_id)
        logger.info(f"Time interval = {self.time_interval_lled}")
        self.assertTrue(self.time_interval_lled != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        all_intervals.append(self.time_interval_lled)

        self.time_interval_mems = self.get_time_interval(contextID=self.memory_total_usage_context_id + "total")
        logger.info(f"Time interval = {self.time_interval_mems}")
        self.assertTrue(self.time_interval_mems != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        all_intervals.append(self.time_interval_mems)

        self.time_interval_nets = self.get_time_interval(contextID=self.network_statistic_context_id)
        logger.info(f"Time interval = {self.time_interval_nets}")
        self.assertTrue(self.time_interval_nets != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        all_intervals.append(self.time_interval_nets)

        self.time_interval_netp = self.get_time_interval(contextID=self.network_protocols_statistics_context_id)
        logger.info(f"Time interval = {self.time_interval_netp}")
        self.assertTrue(self.time_interval_netp != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        all_intervals.append(self.time_interval_netp)

        self.time_interval_hlt = self.get_time_interval(contextID=self.version_context_id)
        logger.info(f"Time interval = {self.time_interval_hlt}")
        self.assertTrue(self.time_interval_hlt != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        all_intervals.append(self.time_interval_hlt)

        self.setPrecondition("Set sniff time equals the max time interval * 2")
        self.wait_time = max(all_intervals) * 2

        self.max_cpuc_cycles = int(self.wait_time*1.1 / self.time_interval_cpuc) + 1
        logger.info(f"max cpuc: {self.max_cpuc_cycles}")
        self.max_cpus_cycles = int(self.wait_time*1.1 / self.time_interval_cpus) + 1
        logger.info(f"max cpus: {self.max_cpus_cycles}")
        self.max_emmc_cycles = int(self.wait_time*1.1 / self.time_interval_emmc) + 1
        logger.info(f"max emmc: {self.max_emmc_cycles}")
        self.max_lled_cycles = int(self.wait_time*1.1 / self.time_interval_lled) + 1
        logger.info(f"max lled: {self.max_lled_cycles}")
        self.max_mems_cycles = int(self.wait_time*1.1 / self.time_interval_mems) + 1
        logger.info(f"max mems: {self.max_mems_cycles}")
        self.max_nets_cycles = int(self.wait_time*1.1 / self.time_interval_nets) + 1
        logger.info(f"max nets: {self.max_nets_cycles}")
        self.max_netp_cycles = int(self.wait_time*1.1 / self.time_interval_netp) + 1
        logger.info(f"max netp: {self.max_netp_cycles}")
        self.max_hlt_cycles = int(self.wait_time*1.1 / self.time_interval_hlt) + 1
        logger.info(f"max hlt: {self.max_hlt_cycles}")

        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.CPU_core_context_id)
        self.dlt_manager.apply_filter(contextId=self.CPU_system_context_id)
        self.dlt_manager.apply_filter(contextId=self.emmc_health_report_context_id)
        self.dlt_manager.apply_filter(contextId=self.Low_level_error_diagnostics_context_id)
        self.dlt_manager.apply_filter(contextId=self.memory_total_usage_context_id)
        self.dlt_manager.apply_filter(contextId=self.network_statistic_context_id)
        self.dlt_manager.apply_filter(contextId=self.network_protocols_statistics_context_id)
        self.dlt_manager.apply_filter(contextId=self.version_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_running_interval(self):
        self.startTestStep("Wait the max moniring time interval * 2")
        self.sleep_for(self.wait_time)
        self.startTestStep("Get HLT DLT messages")

        self.startTestStep("get all messages")
        message_count, all_messages = self.dlt_manager.get_messages()
        self.dlt_manager.stop_monitoring()
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that MON messages exist")

        self.startTestStep("get CPUC messages")
        messages = [x for x in all_messages if x["contextId"] == self.CPU_core_context_id]
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(len(messages) > 0, Severity.MAJOR, "Check that CPUC messages exist")
        timestamp_list = [x["timestamp"].split(".")[0] for x in messages]
        cycels = len(list(dict.fromkeys(timestamp_list)))
        logger.info(f"cycels of CPUC :{cycels}")
        self.expectTrue(cycels <= self.max_cpuc_cycles, Severity.MAJOR, "Check that CPUC messages are logged as often as configured")

        self.startTestStep("get CPUS messages")
        messages = [x for x in all_messages if x["contextId"] == self.CPU_system_context_id]
        self.assertTrue(len(messages) > 0, Severity.MAJOR, "Check that CPUS messages exist")
        timestamp_list = [x["timestamp"].split(".")[0] for x in messages]
        cycels = len(list(dict.fromkeys(timestamp_list)))
        logger.info(f"cycels of CPUS :{cycels}")
        self.expectTrue(cycels <= self.max_cpus_cycles, Severity.MAJOR, "Check that CPUS messages are logged as often as configured")

        self.startTestStep("get EMMC messages")
        messages = [x for x in all_messages if x["contextId"] == self.emmc_health_report_context_id]
        self.assertTrue(len(messages) > 0, Severity.MAJOR, "Check that EMMC messages exist")
        timestamp_list = [x["timestamp"].split(".")[0] for x in messages]
        cycels = len(list(dict.fromkeys(timestamp_list)))
        logger.info(f"cycels of EMMC :{cycels}")
        self.expectTrue(cycels <= self.max_emmc_cycles, Severity.MAJOR, "Check that EMMC messages are logged as often as configured")

        self.startTestStep("get LLED messages")
        messages = [x for x in all_messages if x["contextId"] == self.Low_level_error_diagnostics_context_id]
        self.assertTrue(len(messages) > 0, Severity.MAJOR, "Check that LLED messages exist")
        timestamp_list = [x["timestamp"].split(".")[0] for x in messages]
        cycels = len(list(dict.fromkeys(timestamp_list)))
        logger.info(f"cycels of LLED :{cycels}")
        self.expectTrue(cycels <= self.max_lled_cycles, Severity.MAJOR, "Check that LLED messages are logged as often as configured")

        self.startTestStep("get MEMS messages")
        messages = [x for x in all_messages if x["contextId"] == self.memory_total_usage_context_id]
        self.assertTrue(len(messages) > 0, Severity.MAJOR, "Check that MEMS messages exist")
        timestamp_list = [x["timestamp"].split(".")[0] for x in messages]
        cycels = len(list(dict.fromkeys(timestamp_list)))
        logger.info(f"cycels of MEMS :{cycels}")
        self.expectTrue(cycels <= self.max_mems_cycles, Severity.MAJOR, "Check that MEMS messages are logged as often as configured")

        self.startTestStep("get NETS messages")
        messages = [x for x in all_messages if x["contextId"] == self.network_statistic_context_id]
        self.assertTrue(len(messages) > 0, Severity.MAJOR, "Check that NETS messages exist")
        timestamp_list = [x["timestamp"].split(".")[0] for x in messages]
        cycels = len(list(dict.fromkeys(timestamp_list)))
        logger.info(f"cycels of NETS :{cycels}")
        self.expectTrue(cycels <= self.max_nets_cycles, Severity.MAJOR, "Check that NETS messages are logged as often as configured")

        self.startTestStep("get NETP messages")
        messages = [x for x in all_messages if x["contextId"] == self.network_protocols_statistics_context_id]
        self.assertTrue(len(messages) > 0, Severity.MAJOR, "Check that NETP messages exist")
        timestamp_list = [x["timestamp"].split(".")[0] for x in messages]
        cycels = len(list(dict.fromkeys(timestamp_list)))
        logger.info(f"cycels of NETP :{cycels}")
        self.expectTrue(cycels <= self.max_netp_cycles, Severity.MAJOR, "Check that NETP messages are logged as often as configured")

        self.startTestStep("get HLT messages")
        messages = [x for x in all_messages if x["contextId"] == self.version_context_id]
        self.assertTrue(len(messages) > 0, Severity.MAJOR, "Check that HLT messages exist")
        timestamp_list = [x["timestamp"].split(".")[0] for x in messages]
        cycels = len(list(dict.fromkeys(timestamp_list)))
        logger.info(f"cycels of HLT :{cycels}")
        self.expectTrue(cycels <= self.max_hlt_cycles, Severity.MAJOR, "Check that HLT messages are logged as often as configured")
        
    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
