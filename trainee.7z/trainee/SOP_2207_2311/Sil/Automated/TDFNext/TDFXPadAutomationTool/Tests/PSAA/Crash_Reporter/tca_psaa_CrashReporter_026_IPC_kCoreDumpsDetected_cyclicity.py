from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter_With_Proxy_App import *


class tca_psaa_CrashReporter_026_IPC_kCoreDumpsDetected_cyclicity(testfixture_PSAA_Crash_Reporter_With_Proxy_App):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_026_IPC_kCoreDumpsDetected_cyclicity"
    REQ_ID = ["/item/6588649", "/item/6588684", "/item/6529388"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check IPC coredump status notification kCoreDumpsDetected cyclicity 1 second"
    STATUS = "Ready"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Clear old core dumps")
        remove_is_done = self.remove_old_coredumps()
        self.expectTrue(remove_is_done, Severity.MAJOR, "Check the remove of old coredumps is done")

        self.setPrecondition("Check crash reporter is running")
        crash_reporter_is_running = self.parse_crash_reporter_commandline_parameters()
        self.expectTrue(crash_reporter_is_running, Severity.MAJOR, "Check that crash reporter is running")

        self.setPrecondition("Import proxy app library")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.FUSA.value)

    def test_tca_psaa_CrashReporter_026_IPC_kCoreDumpsDetected_cyclicity(self):
        self.startTestStep("Subscribe to IPC event using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.subscribe_to_crash_reporter()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_subcriptionState == CrashReporterEventType.SUBSCRIBE.value, Severity.MAJOR, "Check that Crash Reporter is unsubscribed successfully")

        self.startTestStep("Get IPC coredump notification")
        exit_code = self.proxy_app_manager.FUSA_comm.get_crash_reporter_status()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_coreDumpState == CrashReporterCoreDumpStatus.NO_COREDUMP_DETECTED.value, Severity.MAJOR, "Check IPC coredump notification is sent")

        self.startTestStep("Wait for IPC notification to be sent (1s)")
        self.sleep_for(self.WAIT_IPC_notification_MS)

        self.startTestStep("Checking no coredump detected notification of Planning is sent to proxy app")
        message_count, message = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.PROXY_APP_APP_ID, searchMsgArray=self.kNoCoreDumpsDetected_Message_PrApp)
        logger.info(f"Time IPC no coredumps message count: {message_count}")
        self.expectTrue(message_count > 0, Severity.BLOCKER, "Check no coredump notification of Planning is sent to proxy app")

        self.startTestStep("Get timestamp of IPC no coredump from DLT message")
        time_ipc_1 = float(message[0].get("timestamp"))
        logger.info(f"Time IPC no coredumps 1: {time_ipc_1}")
        self.expectTrue(time_ipc_1 > 0, Severity.MAJOR, "Check that Timestamp of IPC no coredump is retrieved")

        self.startTestStep("Get timestamp of IPC no coredump from DLT message")
        time_ipc_2 = float(message[1].get("timestamp"))
        logger.info(f"Time IPC no coredumps 2: {time_ipc_2}")
        self.expectTrue(time_ipc_2 > 0, Severity.MAJOR, "Check that Timestamp of IPC no coredump is retrieved")

        self.startTestStep("Check kNoCoreDumpsDetected IPC coredump notification cyclicity equal to 1 second")
        time_check = time_ipc_1 - time_ipc_2
        logger.info(f"Time difference: {time_check}")
        self.assertTrue(int(time_check) == 1, Severity.MAJOR, "Check that timestamp of MSM termiation is bigger than timestamp of shutdown")

        self.startTestStep("Unsubscribe to IPC event using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.unsubscribe_to_crash_reporter()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_subcriptionState == CrashReporterEventType.UNSUBSCRIBE.value, Severity.MAJOR, "Check that Crash Reporter is unsubscribed successfully")

    def tearDown(self):
        self.setPostcondition("Remove proxy app library")
        self.proxy_app_manager.remove_proxy_app_lib(libName.FUSA.value)
