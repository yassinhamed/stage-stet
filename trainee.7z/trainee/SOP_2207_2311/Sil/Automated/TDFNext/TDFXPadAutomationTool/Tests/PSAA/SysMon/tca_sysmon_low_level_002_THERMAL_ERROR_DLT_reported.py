from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_low_level_002_THERMAL_ERROR_DLT_reported(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_low_level_002_THERMAL_ERROR_DLT_reported"
    REQ_ID = ["/item/5896865", "/item/5889679"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that  sysmon reports THERMAL error in DLT"
    OS = ['QNX', 'LINUX'] # for QNX missing msr_writer binary, should be provided by BMW. Check with Khaled Halleb
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get Read Write privileges.")
        self.setPrecondition("Make new folder Technica under the direction /opt.")
        self.ssh_manager.executeCommandInTarget(command="mkdir /opt", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.ssh_manager.executeCommandInTarget(command="mkdir /opt/Technica", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.setPrecondition("Make new folder Technica under the direction /opt.")
        self.ssh_manager.executeCommandInTarget(command="mkdir /opt/Technica/msr", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.setPrecondition("Make new folder Technica under the direction /opt.")
        self.ssh_manager.executeCommandInTarget(command="mkdir /opt/Technica/msr/etc", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.ssh_manager.uploadFileToTarget(source_path=self.input_folder, source_file="logging-msr.json", destination_path=self.destination_path_msr_etc, ip_address=self.PP_IP)
        self.setPrecondition("Upload the file msr_reader_app under the direction /opt/Technica/msr.")
        self.ssh_manager.uploadFileToTarget(source_path=self.input_folder, source_file=self.msr_reader_app, destination_path=self.destination_path_msr, ip_address=self.PP_IP)
        self.setPrecondition("Upload the file msr_writer_app under the direction /opt/Technica/msr.")
        self.ssh_manager.uploadFileToTarget(source_path=self.input_folder, source_file=self.msr_writer_app, destination_path=self.destination_path_msr, ip_address=self.PP_IP)
        self.setPrecondition("Give the Execution Right the applications msr_reader_app and msr_writer_app .")
        self.ssh_manager.executeCommandInTarget(f"chmod +x /opt/Technica/msr/{self.msr_reader_app} /opt/Technica/msr/{self.msr_writer_app}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)

        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.Low_level_error_diagnostics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["LLED"]["THERMAL"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")

        self.setPrecondition("Clear secondary DTC memory")
        self.diag_manager.start()
        self.dtc_controller.clear_info_memory(self.PP_DIAG_ADR)
        self.diag_manager.restart()
        self.setPrecondition("Get DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Thermischer Fehler"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC in setUp:" + str(read_status))
        self.expectTrue(read_status in self.DTC_NOT_PRESENT_LIST, Severity.BLOCKER, "Checking that DTC is Not Present: 0x50 or None.")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.Low_level_error_diagnostics_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_low_level_002_THERMAL_ERROR_DLT_reported(self):
        self.startTestStep("Trigger error injection")
        self.startTestStep("Use MSR writer app to write the value 0x00007D03 into the register 0x19b to trigger Thermischer_Fehler DTC.")
        self.ssh_manager.executeCommandInTarget(command=f"{self.destination_path_msr}/{self.msr_writer_app} 0 0x19b 0x00007D03", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.sleep_for(self.SLEEP_TIME_AFTER_ERROR_FAULT_INJECTION_JOB_MS)
        self.startTestStep("Use MSR Reader app to read the value saved from bit 8 to bit 22 the register 0x19b.")
        self.ssh_manager.executeCommandInTarget(command=f"{self.destination_path_msr}/{self.msr_reader_app} 0 0x19c 8 22", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)


        self.startTestStep("Get DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Thermischer Fehler"][self.PP_NAME], memory_type="secondary") #todo
        logger.info("Status of DTC in the test Method: " + str(read_status))
        self.expectTrue(read_status == self.DTC_ACTIVE, Severity.BLOCKER, "Checking that DTC is Active: 0x2F.")

        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get LLED error DLT message")
        message_count, messages = self.dlt_manager.get_messages(searchMsg=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that message is reported")

        self.startTestStep("Get core value")
        core = self.get_statistic_value(message=messages[0], statistic_path="LLED.THERMAL.Statistics.core")
        self.expectTrue(core != self.INVALID_VALUE, Severity.MAJOR, "Check that core is reported")

        self.startTestStep("Get dec_value value")
        dec_value = self.get_statistic_value(message=messages[0], statistic_path="LLED.THERMAL.Statistics.dec_value")
        self.expectTrue(dec_value != self.INVALID_VALUE, Severity.MAJOR, "Check that dec_value is reported")

        self.startTestStep("Get hex_value value")
        hex_value = self.get_statistic_value(message=messages[0], statistic_path="LLED.THERMAL.Statistics.hex_value")
        self.expectTrue(hex_value != self.INVALID_VALUE, Severity.MAJOR, "Check that hex_value is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
