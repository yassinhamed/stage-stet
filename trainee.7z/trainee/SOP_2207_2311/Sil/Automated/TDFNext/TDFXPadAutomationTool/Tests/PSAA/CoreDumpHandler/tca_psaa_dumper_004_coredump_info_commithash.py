from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_004_coredump_info_commithash(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_004_coredump_info_commithash"
    REQ_ID = ["/item/1736864","/item/1736931","/item/1736943"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps commit hash"
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):

        self.setPrecondition("Check app-dui.json exist under app-dui.json exist")
        check_dui = self.ssh_manager.executeCommandInTarget(command=r"ls /var/lib/dui/ | grep  dui.json", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.expectTrue(check_dui["stdout"].strip() != "", Severity.MAJOR, "Check app-dui.json exist")

    def test_psaa_dumper_004_coredump_info_commithash(self):

        self.startTestStep("Kill application ETS")
        ets_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(ets_is_killed, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

        self.startTestStep("Check application ETS is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is not running")

        self.startTestStep("check coredumps created")
        coredumps_created = self.check_coredumps(self.ETS_APP_NAME)
        self.assertTrue(coredumps_created,Severity.BLOCKER,"Checking that coredumps files were created properly.")

        self.startTestStep("Get reference from context file")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"cat {self.CoreDumps_Path}/context.*|  grep 'ref:'", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Check cat command is executed")
        self.expectTrue(("Error" not in returnValue["stdout"]) and (returnValue["stdout"] != ""), Severity.BLOCKER,
                        "Check stdout is not empty")
 
    def tearDown(self):
        pass
