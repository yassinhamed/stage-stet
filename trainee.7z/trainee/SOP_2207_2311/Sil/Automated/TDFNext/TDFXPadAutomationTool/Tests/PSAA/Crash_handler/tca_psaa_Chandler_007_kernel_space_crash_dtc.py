from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_007_kernel_space_crash_dtc(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_007_kernel_space_crash_dtc"
    REQ_ID = ["/item/2593168", "/item/2593311"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check kernel space DTC status after kernel panic"
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        pass

    def test_tca_psaa_Chandler_007_kernel_space_crash_dtc(self):
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.restart()

        self.startTestStep("Perform Kernel panic")
        self.ssh_manager.executeCommandInTargetNoWait(command=self.kernel_panic_command, timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                      ip_address=self.PP_IP)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.startTestStep("get kernel coredumps names")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"ls -la {self.CoreDumps_Path}/kernel | grep -c kdump.vmcore",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Checking that the coredumps were generated")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.startTestStep("Check secondary DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Kernelpanik_oder_Kernel_OOP"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_ACTIVE, Severity.BLOCKER, "Checking that DTC is not set")

    def tearDown(self):
        result = self.ssh_manager.downloadFileFromTarget("kdump.vmcore", f"{self.CoreDumps_Path}/kernel",
                                                         OutputPathManager.get_test_case_path())
        self.expectTrue(result, "Checking that the Kernel coredumps were copied")