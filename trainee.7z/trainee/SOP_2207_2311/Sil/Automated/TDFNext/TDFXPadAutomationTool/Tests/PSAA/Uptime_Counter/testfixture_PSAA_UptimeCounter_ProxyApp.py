from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *

class testfixture_PSAA_UptimeCounter_ProxyApp(testfixture_PSAA_UptimeCounter):

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_UptimeCounter_ProxyApp setUpclsss")
        cls.deploy_proxy_app()
        cls.start_tdf_proxy_communication()
        cls.check_proxy_app()


    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_UptimeCounter_ProxyApp tearDownclsss")
        cls.stop_tdf_proxy_communication()
        cls.undeploy_proxy_app()

    def setUp(self):
        self.check_proxy_app()
