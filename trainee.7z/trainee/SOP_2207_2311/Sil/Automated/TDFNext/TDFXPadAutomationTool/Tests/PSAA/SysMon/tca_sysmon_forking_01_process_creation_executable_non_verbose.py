from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_forking_01_process_creation_executable_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_forking_01_process_creation_executable_non_verbose"
    REQ_ID = ["/item/5833125"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon report process creation using an exectuable in non-verbose mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_PMON_creation)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_forking_01_process_creation_executable_non_verbose(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_PMON_creation, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.startTestStep(f"Wait for DLT ({self.wait_for_forking_non_verbose_message_ms})")
        self.sleep_for(self.wait_for_forking_non_verbose_message_ms)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get PMON non-verbose DLT messages that contains process creation")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that PMON process creation non verbose DLT messages are available")
        self.expectTrue(dlt_messages[0]['payload'].get('id') is not None, Severity.MAJOR, "Check that the DLT contains the PID")
        self.expectTrue(dlt_messages[0]['payload'].get('creation_time_ns') is not None, Severity.MAJOR, "Check that the DLT contains the timestamp")
        self.expectTrue(dlt_messages[0]['payload'].get('command') is not None, Severity.MAJOR, "Check that the DLT contains the arguments")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
