from Tests.PSAA.DTCSender.testfixture_PSAA_DTCSender import *


class tca_psaa_dtcSend_003_DiagManKilled_Primary(testfixture_PSAA_DTCSender):

    TEST_ID = "IntC\tca_psaa_dtcSend_003_DiagManKilled_Primary"
    REQ_ID = ["/item/1598280"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Set primary DTC with diag manager app is killed and check UDP packet is not sent"
    STATUS = "Ready"
    OS = ['LINUX','QNX']

    default_check_empty = False

    def setUp(self):
        self.initiateConfigFile(memory_type="primary")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.apply_filter(contextId=self.context_Id, appId=self.LOG_COLLECTOR_APP_ID)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_dtcSend_003_DiagManKilled_Primary(self):
        self.startTestStep("Start tshark monitoring")
        self.network.sniffer.start_tshark_watching(filter=self.udpFilter(), adapater_name=self.Adapater_names[0])
        self.sleep_for(self.wait_tshark_to_start)
        self.startTestStep("Kill diag manager")
        is_killed = self.kill_application(self.DIAGNOSTIC_MANAGER_APP_NAME,self.killall_options['SIGABRT'])
        self.assertTrue(is_killed, Severity.MAJOR, "Check Diag app is killed")
        self.startTestStep("Set DTC")
        self.setDTC()
        self.sleep_for(self.wait_trigger_to_be_sent)
        self.startTestStep("Stop tshark monitoring")
        self.network.sniffer.stop_tshark_watching()
        self.sleep_for(self.wait_tshark_to_stop)
        self.startTestStep("Get packets")
        packets = self.network.sniffer.get_packets()
        self.expectTrue(len(packets) == 0, Severity.BLOCKER, "Check packet sent with matching filter were not captured")

    def tearDown(self):
        self.setPostcondition("Reset safety")
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_MS)
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)
