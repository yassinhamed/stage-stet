from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_psaa_router_005_is_platform_app(testfixture_PSAA_Datarouter):

    TEST_ID = "Datarouter\tca_psaa_router_005_is_platform_app"
    REQ_ID = ["/item/863411", "/item/145159"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        self.setPrecondition("Checking that DataRouter exist under /opt")
        returnValue = self.ssh_manager.executeCommandInTarget(command=r"ls /opt | grep -v conf | grep -c '{0}'".format(self.DATA_ROUTER_APP_NAME), timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER, "Checking that DataRouter is under /opt folder")

        self.setPrecondition("Checking that DataRouter has a valid folder under /etc/")
        returnValue = self.ssh_manager.executeCommandInTarget(command=r"ls /opt/{0} | grep -c 'etc'".format(self.DATA_ROUTER_APP_NAME), timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER, "Checking that DataRouter has a valid folder under /etc/")

    def test_datarouter_is_platform_app(self):
        self.startTestStep("Checking that DataRouter has a exec_config.json")
        returnValue = self.ssh_manager.executeCommandInTarget(command=r"ls /opt/{0}/etc | grep -wc '{1}'".format(self.DATA_ROUTER_APP_NAME, self.EXEC_CONFIG_FILE_NAME), timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "0", Severity.BLOCKER, "Checking that DataRouter do not have exec_config.json")

    def tearDown(self):
        pass
