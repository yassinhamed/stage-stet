**CodeBeamer requirements:**

https://codebeamer.bmwgroup.net/cb/tracker/566325?view_id=-2&layout_name=document&subtreeRoot=53135

**Documentations:**

**General description:**

https://asc.bmw.com/wiki/display/PSP/Parameter+Server

**Detailed description:**

https://cc-github.bmwgroup.net/swh/ddad_platform/tree/master/aas/pas/param_server

**Description:**

Parameter server is a component on all mpad performance processors that is meant to allow application testers and developers to experiment with different parameters in their autonomous driving algorithms. Parameters can be changed in the parameter server build, with a configuration file on the target, or by using the service interface that parameter server publishes.
ParamServer initialization sequence:
 
The Parameter Server binary is deployed to the target alongside a "default_values.json" file which could be used to override the default values of the parameters on startup. 
Parameter server checks this file on startup and loads new default values from it if it contains matching parameters. If a parameter is not found in the json file, the hardcoded value is used instead.
Autonomous driving applications use the parameter values from the parameter server to run autonomous driving algorithms. An external tool called CANAPE can be used to modify these parameters to test these algorithms with different parameters or in our case using Vsomeip simulation.

**SomeIP interface avalability:**

ParamServer someip service will be published in engineering mode only for debugging purposes and will be published in Field or plant mode only if the debug tokens are activated.
However internal IPC service is always activated.

**Someip configuration:**

After the Parameter Server initializes, it provides a service interface for getting and/or setting the parameter values that it contains. The IDs of the Some/IP Getter, Setter, Events and Events Groups could be found in the SomeIP config file under /opt/param_server/etc/someip_config.json or in xpad-shared repository https://cc-github.bmwgroup.net/swh/xpad-shared/blob/master/config/mpad/pp/pas/param_server/i_parameter_server_parameters.fdepl

**Coding dependent parameters:**

Some of the parameters are dependent from different coding values. This is the reason why in the default_values.json we find some duplicated parameter with the syntax CODINGNAME_CODINGVALUE_PARAMETERNAME
E.g the Field AdpCommon has a parameter named “vehicle_length_m”. This Field depends on the Coding parameter “FasKarosse” which could has different values between 0 and 30. In the default_values.json we find “FasKarosse_0_vehicle_length_m” .. “FasKarosse_30_vehicle_length_m”
In this link we can know the possible values of the Coding parameters https://cc-github.bmwgroup.net/swh/system_description/blob/master/coding/coding_common/coding_parameters/codingParameters.json

**Default values:**

Default values are saved in /opt/param_server/etc/default_values.json
To get the structure of all fields, parameters, types, dependent coding params, default values etc. we can parse the file modularKitModelmPAD_PP_Parameter_Server.json generated with the Software PDX under “collaterals/pp/calibration” directory. E.g. https://ddad.artifactory.cc.bmwgroup.net/artifactory/xpad-snapshots/20220215/master/gcc/mpad/collaterals/pp/calibration/modularKitModelmPAD_PP_Parameter_Server.json
