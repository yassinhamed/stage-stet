from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_emmc_wearout_DTC_SLC_eq_threshold(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_emmc_wearout_DTC_SLC_eq_threshold"
    REQ_ID = ["/item/7097673", "/item/7097665"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon set DTC if the SLC threshold is reached"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.emmc_health_report_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER,"Check that time interval was successfully retrieved")

        self.wearout_search_msg_array = self.statistic_data["EMMC"]["eMMC Health"]["Search_msg_array"]
        logger.info(f"Wearout levels search message array = {self.wearout_search_msg_array}")
        self.assertTrue(self.wearout_search_msg_array is not None, Severity.BLOCKER,"Check that wearout levels search message array was successfully retrieved")

        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.emmc_health_report_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

        self.startTestStep("Wait one cycle of eMMC * 2")
        self.sleep_for(self.time_interval * 2)

        self.setPrecondition("Get eMMC wearout level DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.wearout_search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that eMMC wearout level DLT messages are available")

        self.setPrecondition("Get DEVICE_LIFE_EST_SLC value")
        DEVICE_LIFE_EST_SLC = self.get_statistic_value(message=messages[0],statistic_path="EMMC.eMMC Health.Statistics.DEVICE_LIFE_EST_SLC")
        self.assertTrue(DEVICE_LIFE_EST_SLC != self.INVALID_VALUE, Severity.MAJOR,"Check that DEVICE_LIFE_EST_SLC is reported")
        DEVICE_LIFE_EST_SLC = int(DEVICE_LIFE_EST_SLC, 16)
        logger.info(f"life estimation for SLC = {DEVICE_LIFE_EST_SLC}")
        self.SLC_THRESHOLD = DEVICE_LIFE_EST_SLC
        self.SLC_Plus10_THRESHOLD= DEVICE_LIFE_EST_SLC + 1

        self.setPrecondition("Get DEVICE_LIFE_EST_MLC value")
        DEVICE_LIFE_EST_MLC = self.get_statistic_value(message=messages[0],statistic_path="EMMC.eMMC Health.Statistics.DEVICE_LIFE_EST_MLC")
        self.assertTrue(DEVICE_LIFE_EST_MLC != self.INVALID_VALUE, Severity.MAJOR,"Check that DEVICE_LIFE_EST_MLC is reported")
        DEVICE_LIFE_EST_MLC = int(DEVICE_LIFE_EST_MLC, 16)
        logger.info(f"life estimation for MLC = {DEVICE_LIFE_EST_MLC}")
        self.MLC_THRESHOLD = DEVICE_LIFE_EST_MLC + 1

        self.setPrecondition("Get PRE_EOL_INFO value")
        PRE_EOL_INFO = self.get_statistic_value(message=messages[0],statistic_path="EMMC.eMMC Health.Statistics.PRE_EOL_INFO")
        self.assertTrue(PRE_EOL_INFO != self.INVALID_VALUE, Severity.MAJOR,"Check that DEVICE_LIFE_EST_MLC is reported")
        PRE_EOL_INFO = int(PRE_EOL_INFO, 16)
        logger.info(f"life estimation for PRE_EOL_INFO = {PRE_EOL_INFO}")
        self.PRE_EOL_THRESHOLD = PRE_EOL_INFO + 1

        self.dlt_manager.stop_monitoring()

        self.diag_manager.start()

        self.setPrecondition("Set wearout thresholds SLC upper bound equal to current value and MLC lower bound and PRE_EOL to 10% greater than current values and set upper bound values to 0xFF using Diag job")
        WEAROUT_DIAG_JOB = self.get_wearout_error_injection_DIAG_payload(SLC_MIN=self.SLC_Plus10_THRESHOLD,SLC_MAX=0xFF, MLC_MIN=self.MLC_THRESHOLD,MLC_MAX=0xFF, PRE_EOL=self.PRE_EOL_THRESHOLD)
        DIAG_RESULT = self.diag_manager.syn_send(self.TESTER_DIAG_ADR, self.PP_DIAG_ADR, WEAROUT_DIAG_JOB)
        self.assertTrue(DIAG_RESULT == DiagResult.positive, Severity.BLOCKER, "Check DIAG positive response")

        self.setPrecondition("Wait one cycle of eMMC * 2")
        self.sleep_for(self.time_interval * 2)

        self.setPrecondition("Get status of wearout DTC")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR,dtc=self.DTC_LIST["EMMC_WEAR_OUT"][self.PP_NAME],memory_type="secondary")
        self.dlt_manager.stop_monitoring()
        logger.info("Status of DTC: " + str(read_status))

        self.assertTrue(read_status != self.DTC_ACTIVE, Severity.BLOCKER, "Checking that Wearout DTC is not active")

    def test_tca_sysmon_emmc_wearout_DTC_SLC_eq_threshold(self):

        self.startTestStep("Set wearout thresholds SLC lower bound equal to current value MLC lower bound and PRE_EOL to 10% greater than current values and set upper bound values to 0xFF using Diag job")
        WEAROUT_DIAG_JOB = self.get_wearout_error_injection_DIAG_payload(SLC_MIN=self.SLC_THRESHOLD, SLC_MAX=0xFF,MLC_MIN=self.MLC_THRESHOLD, MLC_MAX=0xFF,PRE_EOL=self.PRE_EOL_THRESHOLD)
        DIAG_RESULT = self.diag_manager.syn_send(self.TESTER_DIAG_ADR, self.PP_DIAG_ADR, WEAROUT_DIAG_JOB)
        self.assertTrue(DIAG_RESULT == DiagResult.positive, Severity.BLOCKER, "Check DIAG positive response")

        self.startTestStep("Wait one cycle of eMMC * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get status of wearout DTC")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR,dtc=self.DTC_LIST["EMMC_WEAR_OUT"][self.PP_NAME],memory_type="secondary")
        self.dlt_manager.stop_monitoring()
        logger.info("Status of DTC: " + str(read_status))

        self.diag_manager.stop()

        self.expectTrue(read_status == self.DTC_ACTIVE, Severity.BLOCKER, "Checking that Wearout DTC is active")

    def tearDown(self):
        self.setPostcondition("ECU Reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.setPostcondition("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
