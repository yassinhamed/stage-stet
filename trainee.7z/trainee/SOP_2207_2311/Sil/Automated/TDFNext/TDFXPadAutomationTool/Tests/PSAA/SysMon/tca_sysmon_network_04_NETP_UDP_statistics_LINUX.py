from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_network_04_NETP_UDP_statistics_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_network_04_NETP_UDP_statistics_LINUX"
    REQ_ID = ["/item/5909491", "/item/6447171"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that the NETP UDP reports contains all required statistics"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.network_protocols_statistics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["Network"]["TCP"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.network_protocols_statistics_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_network_04_NETP_UDP_statistics_LINUX(self):
        self.startTestStep("Wait cycle of NETP * 2")
        self.sleep_for(self.time_interval * 2)
        self.startTestStep("Get NETS DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that NETP DLT messages are available")

        self.startTestStep("Get in_datagrams value")
        in_datagrams = self.get_statistic_value(message=messages[0], statistic_path="Network.UDP.Statistics.in_datagrams")
        self.expectTrue(in_datagrams != self.INVALID_VALUE, Severity.MAJOR, "Check that in_datagrams is reported")

        self.startTestStep("Get no_ports value")
        no_ports = self.get_statistic_value(message=messages[0], statistic_path="Network.UDP.Statistics.no_ports")
        self.expectTrue(no_ports != self.INVALID_VALUE, Severity.MAJOR, "Check that no_ports is reported")

        self.startTestStep("Get in_errors value")
        in_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.UDP.Statistics.in_errors")
        self.expectTrue(in_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that in_errors is reported")

        self.startTestStep("Get out_datagrams value")
        out_datagrams = self.get_statistic_value(message=messages[0], statistic_path="Network.UDP.Statistics.out_datagrams")
        self.expectTrue(out_datagrams != self.INVALID_VALUE, Severity.MAJOR, "Check that out_datagrams is reported")

        self.startTestStep("Get rcv_buf_errors value")
        rcv_buf_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.UDP.Statistics.rcv_buf_errors")
        self.expectTrue(rcv_buf_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that rcv_buf_errors is reported")

        self.startTestStep("Get in_csum_errors value")
        in_csum_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.UDP.Statistics.in_csum_errors")
        self.expectTrue(in_csum_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that in_csum_errors is reported")

        self.startTestStep("Get ignored_multi value")
        ignored_multi = self.get_statistic_value(message=messages[0], statistic_path="Network.UDP.Statistics.ignored_multi")
        self.expectTrue(ignored_multi != self.INVALID_VALUE, Severity.MAJOR, "Check that ignored_multi is reported")

        self.startTestStep("Get snd_buf_errors value")
        snd_buf_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.UDP.Statistics.snd_buf_errors")
        self.expectTrue(snd_buf_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that snd_buf_errors is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
