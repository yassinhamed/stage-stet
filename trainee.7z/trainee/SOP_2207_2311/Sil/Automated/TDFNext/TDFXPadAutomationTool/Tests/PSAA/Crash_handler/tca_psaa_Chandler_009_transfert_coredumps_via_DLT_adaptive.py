from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_009_transfert_coredumps_via_DLT_adaptive(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_009_transfert_coredumps_via_DLT_adaptive"
    REQ_ID = ["/item/2593168", "/item/2593334"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check core dumps for killing adaptive app transferred over the DLT"
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    def setUp(self):
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.dlt_manager.add_callback_function(self.coredump_checker.coredumps_transfer_callback)
        self.sleep_for(self.DLT_START_MONITORING_TIMEOUT)

    def test_tca_psaa_Chandler_009_transfert_coredumps_via_DLT_adaptive(self):
        self.startTestStep("Get pid of the application to be killed")
        ETS_pid = self.get_process_id(app_name=self.ETS_APP_NAME)
        self.assertTrue(ETS_pid != -1, Severity.MAJOR, "Check the application is running")
        self.startTestStep("Kill application ETS")
        application_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(application_is_killed, Severity.BLOCKER, f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.startTestStep("Check application ETS is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER, f"Checking that the {self.ETS_APP_NAME} is not running")
        self.startTestStep("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Checking that 'ls ' command executed successfully")
        dumps_list = returnValue["stdout"].splitlines()
        self.assertTrue(self.check_coredumps(app_name=self.ETS_APP_NAME), Severity.BLOCKER, f"Checking that coredumps files were created properly")
        self.startTestStep("Get DLT messages")
        check = self.coredump_checker.check_coredump_transfert(dumps_list)
        self.expectTrue(check[0], Severity.BLOCKER, "Check {0} was transferred via DLT".format(dumps_list[0]))
        self.expectTrue(check[1], Severity.BLOCKER, "Check {0} was transferred via DLT".format(dumps_list[1]))

    def tearDown(self):
        self.dlt_manager.stop_monitoring()
        self.dlt_manager.clear_all_dlt_messages()
        self.dlt_manager.remove_callback_function(self.coredump_checker.coredumps_transfer_callback)
