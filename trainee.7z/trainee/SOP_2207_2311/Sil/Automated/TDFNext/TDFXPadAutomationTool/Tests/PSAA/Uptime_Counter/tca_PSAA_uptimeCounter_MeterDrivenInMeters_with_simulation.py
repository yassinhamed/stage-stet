from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *


class tca_PSAA_uptimeCounter_MeterDrivenInMeters_with_simulation(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_uptimeCounter_MeterDrivenInMeters_with_simulation"
    REQ_ID = ["/item/3316275"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check accumulated meters driven counter with simulating mileage"
    STATUS = "Ready"
    OS = ["QNX", "LINUX"]


    def setUp(self):
        self.setPrecondition("Configuration of MediaGateway for simulation")
        self.MediaGateway_controller.set_mediagateway_config(self.LifeCycle_MG)
        self.sleep_for(self.SET_MG_CONFIG_MS)

        self.setPrecondition("Start bcp simulation to simulate initial mileage value")
        self.someip_controller.set_adapter_configuration('Stimulation', self.ZGW_IP, self.DEFAULT_MASK)
        self.bus.power_supply.power_on_reset(downtime=self.PP_SHUTDOWN_TIMEOUT_MS,startup_time=self.PP_STARTUP_TIMEOUT_MS)
        self.someip_controller.init_simulation("BCP21_GW")
        self.someip_controller.start_all_offers("BCP21_GW")
        self.someip_controller.start_simulation("BCP21_GW")
        self.someip_controller.set_pwf_status("BCP21_GW", pwf_status="Pruefen_Analyse_Diagnose")


        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.VEHICLECONDITION_SERVICE_ID,
                                                 instance_id=self.VEHICLECONDITION_INSTANCE_ID,
                                                 method_id=self.VEHICLECONDITION_METHOD_ID,
                                                 signal_name="VehicleCondition.qualifierStatusConditionVehicle",
                                                 signal_value=2)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID,
                                                 instance_id=self.MILEAGESUPREME_INSTANCE_ID,
                                                 method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.mileageSupreme",
                                                 signal_value=self.initial_mileage)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID,
                                                 instance_id=self.MILEAGESUPREME_INSTANCE_ID,
                                                 method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.qualifierMileageSupreme",
                                                 signal_value=0x00)


        self.bcp21_nmController.start_udp_nm_simulation()
        self.bcp21_nmController.set_basic_partial_network(CtrBsPrtnt.KOM_Pruefen_Analyse_Diagnose)
        self.bcp21_nmController.set_functional_partial_network(self.DEFAULT_FUNCTIONAL_PARTIAL_NETWORK)
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)

        self.setPrecondition("Starting Diag Manager")
        self.diag_manager.start_with_param(chName="ETH-HSFZ-DIAG", srcPort=0, dstPort=self.HSFZ_Destination_Port, remoteIP=self.PP_IP)

        self.setPrecondition("Resetting ECU")
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        ECUs_are_OK = self.check_ECUs(is_BCP_simulated=True)
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUS are correctly reset")

        self.setPrecondition("Starting Diag Manager")
        self.diag_manager.start_with_param(chName="ETH-HSFZ-DIAG", srcPort=0, dstPort=self.HSFZ_Destination_Port, remoteIP=self.PP_IP)

        self.sleep_for(self.Wait_for_counters_incrementation_MS)


    def test_tca_PSAA_uptimeCounter_MeterDrivenInMeters_with_simulation(self):

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        First_MeterDrivenInMeters_from_kvs = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.MeterDrivenCounter)
        logger.info(f"First_MeterDrivenInMeters_from_kvs: {First_MeterDrivenInMeters_from_kvs}")

        self.expectTrue(int(First_MeterDrivenInMeters_from_kvs) == self.initial_mileage_decimal_value , Severity.MAJOR, "Check accumulated_meters_driven from kvs is equal to First simulated value")

        self.startTestStep("sending diag job STATUS_UNGEWOLLTE_RESETS_STATISTIKEN ")
        res = self.diag_manager.syn_send(self.TESTER_DIAG_ADR, self.PP_DIAG_ADR,self.STATUS_UNGEWOLLTE_RESETS_STATISTIKEN)
        self.assertTrue(res == DiagResult.positive, Severity.BLOCKER,"Check positive response for ECU state is received")
        self.startTestStep("Getting diag response containing the counters payload")

        res_diag1 = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        First_MeterDrivenInMeters_from_diag = self.diag_manager.payload_to_str(res_diag1.get_payload())
        logger.info(f"First_MeterDrivenInMeters_from_diag: {str(First_MeterDrivenInMeters_from_diag)}")

        self.startTestStep("Checking meters_driven counter from diag job is equal to the value simulated")
        payload_values = self.payload_to_dic(First_MeterDrivenInMeters_from_diag)
        self.expectTrue(payload_values["Total_accumulated_meters_driven"] == self.initial_mileage_decimal_value,Severity.MAJOR, "Check accumulated_meters_driven from diag is equal to First simulated value")

        self.startTestStep("Start bcp simulation to simulate new mileage value")
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.VEHICLECONDITION_SERVICE_ID,
                                                 instance_id=self.VEHICLECONDITION_INSTANCE_ID,
                                                 method_id=self.VEHICLECONDITION_METHOD_ID,
                                                 signal_name="VehicleCondition.qualifierStatusConditionVehicle",
                                                 signal_value=2)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID,
                                                 instance_id=self.MILEAGESUPREME_INSTANCE_ID,
                                                 method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.mileageSupreme",
                                                 signal_value=self.New_mileage)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID,
                                                 instance_id=self.MILEAGESUPREME_INSTANCE_ID,
                                                 method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.qualifierMileageSupreme",
                                                 signal_value=0x00)



        self.startTestStep("Resetting ECU")
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        ECUs_are_OK = self.check_ECUs(is_BCP_simulated=True)
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUS are correctly reset")

        self.startTestStep("Starting Diag Manager")
        self.diag_manager.start_with_param(chName="ETH-HSFZ-DIAG", srcPort=0, dstPort=self.HSFZ_Destination_Port, remoteIP=self.PP_IP)

        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        Second_MeterDrivenInMeters_from_kvs = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.MeterDrivenCounter)
        logger.info(f"Second_MeterDrivenInMeters_from_kvs: {Second_MeterDrivenInMeters_from_kvs}")

        self.expectTrue(int(Second_MeterDrivenInMeters_from_kvs) == self.New_mileage_decimal_value , Severity.MAJOR, "Check accumulated_meters_driven from kvs is equal to second simulated value")

        self.startTestStep("sending diag job STATUS_UNGEWOLLTE_RESETS_STATISTIKEN ")
        res = self.diag_manager.syn_send(self.TESTER_DIAG_ADR, self.PP_DIAG_ADR,self.STATUS_UNGEWOLLTE_RESETS_STATISTIKEN)
        self.assertTrue(res == DiagResult.positive, Severity.BLOCKER,"Check positive response for ECU state is received")

        self.startTestStep("Getting diag response containing the counters payload")
        res_diag1 = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        Second_MeterDrivenInMeters_from_diag = self.diag_manager.payload_to_str(res_diag1.get_payload())
        logger.info(f"Second_MeterDrivenInMeters_from_diag: {str(Second_MeterDrivenInMeters_from_diag)}")

        self.startTestStep("Checking meters_driven counter from diag job is equal to the value simulated")
        payload_values = self.payload_to_dic(Second_MeterDrivenInMeters_from_diag)
        self.expectTrue(payload_values["Total_accumulated_meters_driven"] == self.New_mileage_decimal_value,Severity.MAJOR, "Check meters_driven counter from diag job is equal to the second value simulated")


    def tearDown(self):
        self.diag_manager.stop()
        self.setPostcondition("Stop simulation")
        self.someip_controller.stop_all_offers("BCP21_GW")
        self.someip_controller.stop_simulation("BCP21_GW")
        self.bcp21_nmController.stop_nm_udp_simulation()
        self.someip_controller.clear_adapter_configuration('Stimulation', self.ZGW_IP, self.SOMEIP_MULTICAST_IP)
        self.MediaGateway_controller.set_mediagateway_config(self.Default_MG)
        self.sleep_for(self.SET_MG_CONFIG_MS)
        self.bus.power_supply.power_on_reset(downtime=self.PP_SHUTDOWN_TIMEOUT_MS, startup_time=self.PP_STARTUP_TIMEOUT_MS)
