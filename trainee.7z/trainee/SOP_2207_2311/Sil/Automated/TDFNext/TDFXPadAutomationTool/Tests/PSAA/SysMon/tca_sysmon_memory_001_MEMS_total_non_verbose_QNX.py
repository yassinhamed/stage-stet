from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_001_MEMS_total_non_verbose_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_001_MEMS_total_non_verbose_QNX"
    REQ_ID = ["/item/5904829"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports total RAM consumption in non-verbose mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_MEMS_totals)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_memory_001_MEMS_total_non_verbose_QNX(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_MEMS_totals, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep(f"Wait for DLT ({self.wait_for_memory_usage_non_verbose_message_ms})")
        self.sleep_for(self.wait_for_memory_usage_non_verbose_message_ms)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get MEMS non-verbose DLT messages that contains total RAM consumption")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that MEMS totals non verbose DLT messages are available")
        message_payload = dlt_messages[0]['payload']
        self.expectTrue(message_payload.get('total') is not None, Severity.MAJOR, "Check that the DLT contains the total memory")
        self.expectTrue(message_payload.get('available') is not None, Severity.MAJOR, "Check that the DLT contains the available memory")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
