from Tests.PSAA.Log_Collector.testfixture_PSAA_Log_Collector import *


class tca_PSAA_051_logC_Slog_DTCs_3_snapshots(testfixture_PSAA_Log_Collector):

    TEST_ID = "PSAA\tca_PSAA_051_logC_Slog_DTCs_3_snapshots"
    REQ_ID = ["/item/6037383","/item/6040647","/item/2939949","/item/2593566"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check that DTC environment lower,equal and greater variable are filled and Check Slog messages are being forwarded with Slog context ID"
    STATUS = "Ready"
    OS = ['QNX']

    equal_to_128_bytes_random_text = "aeznmufsdlrwsdynqeggzlwmeevmpgnaydaxdygbeqsjhqjnltbnxbsmrgurvhvjkhxhebtgrwqvbwnctcazertyuiopqsdfghjklmwxcvbnazertyuiopqsdfghjklc"
    more_than_128_bytes_random_text_after = "aeznmufsdlrwsdynqeggzlwmeevmpgnaydaxdygbeqsjhqjnltbnxbsmrgurvhvjkhxhebtgrwqvbwnctcnbvcxwmlkjhgfdsqpoiuytrezanbvcxwmlkjhgfdsqpoi"
    more_than_128_bytes_random_text = "aeznmufsdlrwsdynqeggzlwmeevmpgnaydaxdygbeqsjhqjnltbnxbsmrgurvhvjkhxhebtgrwqvbwnctcnbvcxwmlkjhgfdsqpoiuytrezanbvcxwmlkjhgfdsqpoiu"
    lower_than_128_bytes_random_text = "aeznmufsdlrwsdynqeggzlwmeevmpgnaydaxdygbeqsjhqjnltbnxbsmrgurvhvjkhxhebtgrwqvbwnctcpqwzsxedcrfvtgbyhnujik"

    def setUp(self):
        self.dlt_manager.apply_filter(contextId=self.Slog_context_ID, appId=self.LOG_COLLECTOR_APP_ID)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_PSAA_051_logC_Slog_DTCs_3_snapshots(self):
        self.startTestStep("Modify Message Regex in config file with 128 bytes random text")
        self.logCollectorModifyConfigFile_QNX(MessageSource=self.Slog_context_ID, MessageRegex="aeznmufsdlrwsdynqeggzlwmeevmpgnaydaxdygbeqsjhqjnltbnxbsmrgurvhvjkhxhebtgrwqvbwnctc", SetDTC022292="Clearable", SetDTC482EA9="Clearable", LogDlt="Yes")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        ecus_are_ok = self.check_ECUs()
        self.ssh_manager.downloadFileFromTarget(source_file=self.Config_file_name, source_path=self.Config_file_path,
                                                destination_path=OutputPathManager.get_test_case_path())
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.ssh_manager.executeCommandInTarget(command=f'cat {self.Config_file_path + self.Config_file_name}', timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.startTestStep("Check log collector application is running")
        grep_LogC = self.check_application_is_started(app_name=self.LOG_COLLECTOR_APP_NAME)
        self.expectTrue(grep_LogC, Severity.MAJOR, "Check The application was started")
        self.startTestStep("Add Slog equal messages")
        self.logCollectorAddSLog(MessageRegex=self.equal_to_128_bytes_random_text)
        self.startTestStep("Get Slog equal messages")
        Message1 = self.logCollectorGetSLog(MessageRegex=self.equal_to_128_bytes_random_text)
        logger.info(Message1)
        self.startTestStep("Add Slog greater messages")
        self.logCollectorAddSLog(MessageRegex=self.more_than_128_bytes_random_text)
        self.startTestStep("Get Slog greater messages")
        Message2 = self.logCollectorGetSLog(MessageRegex=self.more_than_128_bytes_random_text)
        logger.info(Message2)
        self.startTestStep("Add Slog lower messages")
        self.logCollectorAddSLog(MessageRegex=self.lower_than_128_bytes_random_text)
        self.startTestStep("Get Slog lower messages")
        Message3 = self.logCollectorGetSLog(MessageRegex=self.lower_than_128_bytes_random_text)
        logger.info(Message3)
        self.startTestStep("Get DLT messages")
        number, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.LOG_COLLECTOR_APP_ID, contextId=self.Slog_context_ID, searchMsgArray=["aeznmufsdlrwsdynqeggzl"])
        self.assertTrue(number > 0, Severity.BLOCKER, "Check Kernel messages are being forwarded with Slog context ID")
        self.startTestStep("Check primary SW_Integritätsprüfung_fehlgeschlagen DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR,
                                                       dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][self.PP_NAME],
                                                       memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that DTC is set")
        self.startTestStep("Check secondary Interne_System_Manipulation_erkannt DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR,
                                                       dtc=self.DTC_LIST["Interne_System_Manipulation_erkannt"][self.PP_NAME],
                                                       memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that DTC is set")

        self.startTestStep("Get all snapshots of SW_Integritätsprüfung_fehlgeschlagen DTC")
        service_response = self.dtc_manager.get_all_snapshots(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][self.PP_NAME])
        logger.info("result= " + str(service_response))
        message0 = self.get_env_variable(dtc_snapshots=service_response, env_variable=self.equal_to_128_bytes_random_text, index=0)
        self.assertTrue(message0 is not None, Severity.BLOCKER, "The messages are equal")
        self.assertTrue(self.equal_to_128_bytes_random_text in (bytes.fromhex(message0).decode('utf-8')), Severity.BLOCKER, "Checking that DTC environment variable is filled")
        message1 = self.get_env_variable(dtc_snapshots=service_response, env_variable=self.more_than_128_bytes_random_text, index=1)
        self.assertTrue(message1 is not None, Severity.BLOCKER, "The messages are equal")
        self.assertTrue(self.more_than_128_bytes_random_text_after in (bytes.fromhex(message1).decode('utf-8')), Severity.BLOCKER, "Checking that DTC environment variable is filled")
        message2 = self.get_env_variable(dtc_snapshots=service_response, env_variable=self.lower_than_128_bytes_random_text, index=2)
        self.assertTrue(message2 is not None, Severity.BLOCKER, "The messages are equal")
        self.assertTrue(self. lower_than_128_bytes_random_text in (bytes.fromhex(message2.split('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')[0]).decode('utf-8')),Severity.BLOCKER,"Checking that DTC environment variable is filled")
        self.startTestStep("Get all snapshots of Interne_System_Manipulation_erkannt DTC")
        service_response = self.dtc_manager.get_all_snapshots(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Interne_System_Manipulation_erkannt"][self.PP_NAME], memory_type=memory_type.SECONDARY)
        logger.info("result= " + str(service_response))
        message0 = self.get_env_variable(dtc_snapshots=service_response, env_variable=self.equal_to_128_bytes_random_text, index=0)
        self.assertTrue((message0 is not None), Severity.BLOCKER, "The messages are equal")
        self.assertTrue(self.equal_to_128_bytes_random_text in (bytes.fromhex(message0).decode('utf-8')), Severity.BLOCKER, "Checking that DTC environment variable is filled")
        message1 = self.get_env_variable(dtc_snapshots=service_response, env_variable=self.more_than_128_bytes_random_text, index=1)
        self.assertTrue((message1 is not None), Severity.BLOCKER, "The messages are equal")
        self.assertTrue(self.more_than_128_bytes_random_text_after in (bytes.fromhex(message1).decode('utf-8')), Severity.BLOCKER, "Checking that DTC environment variable is filled")
        message2 = self.get_env_variable(dtc_snapshots=service_response, env_variable=self.lower_than_128_bytes_random_text, index=2)
        self.assertTrue((message2 is not None), Severity.BLOCKER, "The messages are equal")
        self.assertTrue(self.lower_than_128_bytes_random_text in (bytes.fromhex(message2.split('FFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')[0]).decode('utf-8')),Severity.BLOCKER,"Checking that DTC environment variable is filled")

    def tearDown(self):
        self.diag_manager.start()
        self.setPostcondition("Revert Config file")
        self.logCollectorRevertConfigFile_QNX()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.diag_manager.start()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)

