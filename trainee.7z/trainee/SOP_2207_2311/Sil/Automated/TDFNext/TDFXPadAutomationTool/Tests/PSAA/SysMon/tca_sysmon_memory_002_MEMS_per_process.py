from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_002_MEMS_per_process(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_002_MEMS_per_process"
    REQ_ID = ["/item/8018348"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "23-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports total RAM consumption per process"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.memory_process_usage_context_id + "process")
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array_stack = self.statistic_data["Memory"]["mems_per_process_stack"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array_stack}")
        self.assertTrue(self.search_msg_array_stack is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.search_msg_array_heap = self.statistic_data["Memory"]["mems_per_process_heap"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array_heap}")
        self.assertTrue(self.search_msg_array_heap is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.memory_process_usage_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_memory_002_MEMS_per_process(self):
        self.startTestStep("Wait cycle of total MEMS * 2")
        #self.sleep_for(self.time_interval * 2) to be checked if it is a bug. time interval in the SW is equal to total time interval
        self.sleep_for(60000)

        self.startTestStep("Get MEMS heap RAM per process DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array_heap)
        self.expectTrue(message_count > 0, Severity.MAJOR, "Check that MEMS heap RAM per process DLT messages are available")

        self.startTestStep("Get MEMS stack RAM per process DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array_stack)
        self.expectTrue(message_count > 0, Severity.MAJOR, "Check that MEMS stack RAM per process DLT messages are available")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
