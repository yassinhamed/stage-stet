from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_emmc_erase_count_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_emmc_erase_count_non_verbose"
    REQ_ID = ["/item/5888418", "/item/5888677"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports erase count statistics in Non-Verbose mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.emmc_health_report_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.assertTrue(self.eMMC_manufacturer != "UNKNOWN", Severity.BLOCKER, "Check that eMMC manufacturer is known")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        if self.eMMC_manufacturer == "SAMSUNG":
            self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_EMMC_erase_count_samsung)
        if self.eMMC_manufacturer == "MICRON":
            self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_EMMC_erase_count_micron)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_emmc_erase_count_non_verbose(self):
        if self.eMMC_manufacturer == "SAMSUNG":
            self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_EMMC_erase_count_samsung, sender=self.PP_ECUID, filter_attributes=None)
        if self.eMMC_manufacturer == "MICRON":
            self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_EMMC_erase_count_micron, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait cycle of eMMC  * 2")
        self.sleep_for(self.time_interval * 2)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get DLT EMMC non-vebose messages")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that non-verbose DLT EMMC erase count messages are available")
        message_payload = dlt_messages[0]['payload']
        if self.eMMC_manufacturer == "SAMSUNG":
            self.expectTrue(message_payload.get('min_erase_slc') is not None, Severity.MAJOR, "Check that dlt messages contain min_erase_slc statistics")
            self.expectTrue(message_payload.get('max_erase_slc') is not None, Severity.MAJOR, "Check that dlt messages contain max_erase_slc statistics")
            self.expectTrue(message_payload.get('avg_cycle_slc') is not None, Severity.MAJOR, "Check that dlt messages contain avg_cycle_slc statistics")
            self.expectTrue(message_payload.get('min_erase_mlc') is not None, Severity.MAJOR, "Check that dlt messages contain min_erase_mlc statistics")
            self.expectTrue(message_payload.get('max_erase_mlc') is not None, Severity.MAJOR, "Check that dlt messages contain max_erase_mlc statistics")
            self.expectTrue(message_payload.get('avg_cycle_mlc') is not None, Severity.MAJOR, "Check that dlt messages contain avg_cycle_mlc statistics")
        if self.eMMC_manufacturer == "MICRON":
            self.expectTrue(message_payload.get('min_erase') is not None, Severity.MAJOR, "Check that dlt messages contain min_erase statistics")
            self.expectTrue(message_payload.get('max_erase') is not None, Severity.MAJOR, "Check that dlt messages contain max_erase statistics")
            self.expectTrue(message_payload.get('avg_cycle') is not None, Severity.MAJOR, "Check that dlt messages contain avg_cycle statistics")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
