from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_psaa_router_020_RingBufferSize_sysmon(testfixture_PSAA_Datarouter):

    TEST_ID = "PSAA\tca_psaa_router_020_RingBufferSize_sysmon"
    REQ_ID = ["/item/145004"]
    DEV_OBJ = ['mPAD_Performance_2C']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX','QNX']


    def setUp(self):
        self.dlt_manager.clear_all_dlt_messages()
        returnValue = self.ssh_manager.executeCommandInTarget(r"cp /opt/sysmon/etc/logging.json /persistent/Technica/sysmon_logging.json")
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.MAJOR, "Check the copy of the original json file")

    def test_tca_psaa_router_020_RingBufferSize_sysmon(self):
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECU_status = self.check_ECUs()
        self.expectTrue(ECU_status, Severity.BLOCKER, "Checking that ECU status is OK")
        self.dlt_manager.apply_filter(appId=self.SYSMON_APP_ID)
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.start_monitoring("SRR-DLT")

        self.sleep_for(self.wait_for_dlt_message_to_be_sent)
        self.startTestStep("Get DLT message before the update of ringBufferSize")
        messages_count, messages_array_set = self.dlt_manager.get_messages(searchMsg="CPU")
        self.expectTrue(messages_count > 0, Severity.BLOCKER, "Check messages are logged")
        logger.info("Messages Count = " + str(messages_count))
        self.dlt_manager.stop_monitoring()
        self.dlt_manager.clear_all_filters()
        self.startTestStep("Reduce ringBufferSize")
        exitcode=self.json_manager.updateNodeIntoJsonFile(filePath="/opt/sysmon/etc/logging.json", nodePath="ringBufferSize", value=10, use_cache = False, delete_cache = True, upload_file = True)
        self.expectTrue(exitcode, Severity.BLOCKER, "Check the update of ringBufferSize")

        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECU_status = self.check_ECUs()
        self.expectTrue(ECU_status, Severity.BLOCKER, "Checking that ECU status is OK")

        self.dlt_manager.apply_filter(appId=self.SYSMON_APP_ID)
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.sleep_for(self.wait_for_dlt_message_to_be_sent)
        self.startTestStep("Get DLT message after the update of ringBufferSize")
        messages_count_2, messages_array_set = self.dlt_manager.get_messages(searchMsg="CPU")
        self.expectTrue(messages_count_2 < messages_count, Severity.BLOCKER, "Check that some messages are lost after reducing ringBufferSize")
        logger.info("Messages Count = " + str(messages_count_2))

    def tearDown(self):
        self.dlt_manager.stop_monitoring()
        self.dlt_manager.clear_all_filters()
        self.RevertConfigFile()
