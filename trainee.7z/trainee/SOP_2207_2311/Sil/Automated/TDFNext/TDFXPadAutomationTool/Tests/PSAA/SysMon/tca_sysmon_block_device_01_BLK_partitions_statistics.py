from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_block_device_01_BLK_partitions_statistics(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_block_device_01_BLK_partitions_statistics"
    REQ_ID = ["/item/5833706"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports partitions statistics"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get partitions")
        self.partitions, self.partitions_info = self.get_partitions_info()
        self.assertTrue(self.partitions != self.INVALID_VALUE, Severity.BLOCKER, "Check that partitinos info were successfully retrieved")
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.blk_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["BLK"]["Filesystem"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.blk_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_block_device_01_BLK_partitions_statistics(self):
        self.startTestStep("Wait one cycle * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get BLK Filesystem statistics DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that BLK Filesystem statistics DLT messages are available")

        all_partitions_are_reported = self.check_if_all_partitions_are_reported(messages=messages, partitions=self.partitions)
        self.expectTrue(all_partitions_are_reported, Severity.MAJOR, "Check that all partitions are reported")

        self.startTestStep("Get type value")
        typ = self.get_statistic_value(message=messages[0], statistic_path="BLK.Filesystem.Statistics.type")
        self.expectTrue(typ != self.INVALID_VALUE, Severity.MAJOR, "Check that type is reported")

        self.startTestStep("Get path value")
        path = self.get_statistic_value(message=messages[0], statistic_path="BLK.Filesystem.Statistics.path")
        self.expectTrue(path != self.INVALID_VALUE, Severity.MAJOR, "Check that path is reported")

        self.startTestStep("Get overall_size value")
        overall_size = self.get_statistic_value(message=messages[0], statistic_path="BLK.Filesystem.Statistics.overall_size")
        self.expectTrue(overall_size != self.INVALID_VALUE, Severity.MAJOR, "Check that overall_size is reported")

        self.startTestStep("Get available_size value")
        available_size = self.get_statistic_value(message=messages[0], statistic_path="BLK.Filesystem.Statistics.available_size")
        self.expectTrue(available_size != self.INVALID_VALUE, Severity.MAJOR, "Check that available_size is reported")

        self.startTestStep("Get used_space value")
        used_space = self.get_statistic_value(message=messages[0], statistic_path="BLK.Filesystem.Statistics.used_space")
        self.expectTrue(used_space != self.INVALID_VALUE, Severity.MAJOR, "Check that used_space is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
