from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_DatarouterConf(testfixture_PSAA):
    dconf_config_path = "/opt/datarouterconf/etc"
    dconf_path = "/opt/datarouterconf"
    log_channels_config_file_path = "/opt/datarouter/etc/log-channels.json"
    STEUERN_DLT_SET_TRACESTATE = [0x31, 0x01, 0x10, 0x95, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00]
    STEUERN_DLT_SET_DEFAULT_TRACESTATE_AUS = [0x31, 0x01, 0x10, 0x97, 0x00]
    EM_START_DatarouterConf_MESSAGES = ["datarouterconf_instance", "Added process to execution list"]

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_DatarouterConf setUpclsss")
        cls.ssh_manager.executeCommandInTarget("ls /opt/datarouterconf/bin")
        cls.ssh_manager.executeCommandInTarget("ls /opt/datarouterconf/etc")

        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=path.join(OutputPathManager.get_tests_group_path(), "coredumps_setupclass_without_proxyapp"),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_DatarouterConf tearDownclsss")

    def tearDown(self):
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_test_case_path(),check_empty=False,ip_address=self.PP_IP,ignored_files=["currentswversion", "tmp"])

    def parse_log_channel_config_file(self, config_content, diag_result):
        for key in json.loads(config_content["stdout"])['channels'].keys():
            channel = " ".join([hex(ord(c)).replace("0x", "").upper() for c in key])
            self.expectTrue( channel in self.diag_manager.payload_to_str(diag_result.get_payload()).strip().upper(), Severity.BLOCKER, "Check the diag response")
