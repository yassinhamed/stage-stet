from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_network_03_NETP_ICMP_statistics_QNX_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_network_03_NETP_ICMP_statistics_QNX_non_verbose"
    REQ_ID = ["/item/5909472"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that the NETP ICMP reports contains all required statistics in Non-Verbose Mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.network_protocols_statistics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_NETP_ICMP)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_network_03_NETP_ICMP_statistics_QNX_non_verbose(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_NETP_ICMP, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait cycle of NETP * 2")
        self.sleep_for(self.time_interval * 10)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get DLT NETP ICMP non-verbose messages")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that DLT NETP ICMP messages are available")

        in_msgs = float(dlt_messages[0]["payload"]["in_msgs"])
        in_errors = float(dlt_messages[0]["payload"]["in_errors"])
        in_check_sum_errors = float(dlt_messages[0]["payload"]["in_check_sum_errors"])
        in_dest_unreachs = float(dlt_messages[0]["payload"]["in_dest_unreachs"])
        in_time_exds = float(dlt_messages[0]["payload"]["in_time_exds"])
        in_param_probs = float(dlt_messages[0]["payload"]["in_param_probs"])
        in_redirects = float(dlt_messages[0]["payload"]["in_redirects"])
        in_echos = float(dlt_messages[0]["payload"]["in_echos"])
        in_echo_reps = float(dlt_messages[0]["payload"]["in_echo_reps"])
        in_addr_masks = float(dlt_messages[0]["payload"]["in_addr_masks"])
        out_msgs = float(dlt_messages[0]["payload"]["out_msgs"])
        out_dest_unreachs = float(dlt_messages[0]["payload"]["out_dest_unreachs"])
        out_echos = float(dlt_messages[0]["payload"]["out_echos"])
        out_echo_reps = float(dlt_messages[0]["payload"]["out_echo_reps"])

        self.expectTrue(type(in_msgs) == float, Severity.MAJOR, "Check that in_msgs is reported")
        self.expectTrue(type(in_errors) == float, Severity.MAJOR, "Check that in_errors is reported")
        self.expectTrue(type(in_check_sum_errors) == float, Severity.MAJOR, "Check that in_check_sum_errors is reported")
        self.expectTrue(type(in_dest_unreachs) == float, Severity.MAJOR, "Check that in_dest_unreachs is reported")
        self.expectTrue(type(in_time_exds) == float, Severity.MAJOR, "Check that in_time_exds is reported")
        self.expectTrue(type(in_param_probs) == float, Severity.MAJOR, "Check that in_param_probs is reported")
        self.expectTrue(type(in_redirects) == float, Severity.MAJOR, "Check that in_redirects is reported")
        self.expectTrue(type(in_echos) == float, Severity.MAJOR, "Check that in_echos is reported")
        self.expectTrue(type(in_echo_reps) == float, Severity.MAJOR, "Check that in_echo_reps is reported")
        self.expectTrue(type(in_addr_masks) == float, Severity.MAJOR, "Check that in_addr_masks is reported")
        self.expectTrue(type(out_msgs) == float, Severity.MAJOR, "Check that out_msgs is reported")
        self.expectTrue(type(out_dest_unreachs) == float, Severity.MAJOR, "Check that out_dest_unreachs is reported")
        self.expectTrue(type(out_echos) == float, Severity.MAJOR, "Check that out_echos is reported")
        self.expectTrue(type(out_echo_reps) == float, Severity.MAJOR, "Check that out_echo_reps is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
