from Tests.PSAA.Resource_Manager.testfixture_PSAA_RM import *


class tca_mmr_exposed_file_pwrmbase(testfixture_PSAA_RM):

    TEST_ID = "PSAA\Ressource_Manager\tca_mmr_exposed_file_pwrmbase"
    REQ_ID = ['/item/5279950']
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    PRIORITY = "Critical"
    DESCRIPTION = "Check that the resource managers shall expose a /dev/mmr/pwrmbase file"
    STATUS = "Ready"
    OS = ['QNX']


    def setUp(self):
        pass

    def test_tca_mmr_exposed_file_pwrmbase(self):
        self.startTestStep("Check /dev/mmr/pwrmbase exist")

        result = self.ssh_manager.executeCommandInTarget(command=f"if [ -e /dev/mmr/pwrmbase ]; then echo file exists; fi", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(result['stdout'].strip() == "file exists", Severity.BLOCKER, "Check that /dev/mmr/pwrmbase  exists")


    def tearDown(self):
        pass
