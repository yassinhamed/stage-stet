from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_cpu_05_CPUT_thread_cpu_usage_empty_config_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_cpu_05_CPUT_thread_cpu_usage_empty_config_QNX"
    REQ_ID = ["/item/5832905"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon report threads cpu usage when no process is selected"
    OS = ['QNX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Find the config file that contains the selected process names")
        self.assertTrue(True, Severity.MAJOR, "Check that the config file exist")
        self.setPrecondition("Modify the config file with empty list of selected processes")
        self.setPrecondition("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.assertTrue(True, Severity.MAJOR, "Check that config file is correctly set")
        self.setPrecondition("Get thread Ids of the process")
        self.assertTrue(True, Severity.MAJOR, "Check that thread Ids could be retrieved")
        self.setPrecondition("Start DLT monitoring")

    def test_tca_sysmon_cpu_05_CPUT_thread_cpu_usage_empty_config_QNX(self):
        self.startTestStep("Wait the configured time interval * 2")
        self.startTestStep("Get CPUT DLT messages that contains the thread cpu usage")
        self.assertTrue(True, Severity.MAJOR, "Check that no DLT message is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.setPostcondition("Revert config file")
        self.setPostcondition("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
