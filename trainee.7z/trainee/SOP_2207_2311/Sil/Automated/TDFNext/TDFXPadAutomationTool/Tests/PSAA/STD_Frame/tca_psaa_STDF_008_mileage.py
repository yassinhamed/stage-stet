from Tests.PSAA.STD_Frame.testfixture_PSAA_STDFrame import *


class tca_psaa_STDF_008_mileage(testfixture_PSAA_STDFrame):

    TEST_ID = "PSAA\tca_psaa_STDF_008_mileage"
    REQ_ID = ["/item/2175806"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    OS = ['LINUX','QNX']
    STATUS = "Ready"



    def setUp(self):
        self.setPostcondition("Start bcp simulation to simulate mileage value")
        self.MediaGateway_controller.set_mediagateway_config(self.LifeCycle_MG)
        self.sleep_for(self.SET_MG_CONFIG_MS)
        self.someip_controller.set_adapter_configuration('Stimulation', self.ZGW_IP, self.DEFAULT_MASK)
        self.bus.power_supply.power_on_reset(downtime=self.PP_SHUTDOWN_TIMEOUT_MS, startup_time=self.PP_STARTUP_TIMEOUT_MS)
        self.someip_controller.init_simulation("BCP21_GW")
        self.someip_controller.start_all_offers("BCP21_GW")
        self.someip_controller.start_simulation("BCP21_GW")
        self.someip_controller.set_pwf_status("BCP21_GW", pwf_status="Pruefen_Analyse_Diagnose")
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                service_id=self.VEHICLECONDITION_SERVICE_ID, instance_id=self.VEHICLECONDITION_INSTANCE_ID, method_id=self.VEHICLECONDITION_METHOD_ID,
                                                signal_name="VehicleCondition.qualifierStatusConditionVehicle",
                                                signal_value=2)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID, instance_id=self.MILEAGESUPREME_INSTANCE_ID, method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.mileageSupreme", signal_value=self.initial_mileage)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID, instance_id=self.MILEAGESUPREME_INSTANCE_ID, method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.qualifierMileageSupreme", signal_value=0x00)
        self.bcp21_nmController.start_udp_nm_simulation()
        self.bcp21_nmController.set_basic_partial_network(CtrBsPrtnt.KOM_Pruefen_Analyse_Diagnose)
        self.bcp21_nmController.set_functional_partial_network(self.DEFAULT_FUNCTIONAL_PARTIAL_NETWORK)
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)
        self.diag_manager.start_with_param(chName="ETH-HSFZ-DIAG", srcPort=0, dstPort=self.HSFZ_Destination_Port, remoteIP=self.PP_IP)
        self.diag_manager.syn_send(0xF4, self.PP_DIAG_ADR, self.STEUERN_LOESCHEN_UNGEWOLLTE_RESETS_STATISTIKEN)
        self.sleep_for(5000)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID, instance_id=self.MILEAGESUPREME_INSTANCE_ID, method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.mileageSupreme", signal_value=self.initial_mileage)
        self.sleep_for(self.WAIT_AFTER_SET_SIGNAL_MS)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID, instance_id=self.MILEAGESUPREME_INSTANCE_ID, method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.mileageSupreme", signal_value=self.initial_mileage)
        self.sleep_for(self.WAIT_AFTER_SET_SIGNAL_MS)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID, instance_id=self.MILEAGESUPREME_INSTANCE_ID, method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.mileageSupreme", signal_value=self.initial_mileage)
        self.sleep_for(self.WAIT_AFTER_SET_SIGNAL_MS)
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_CurrentMileage)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_STDF_008_mileage(self):
        self.startTestStep("Get non verbose message 'Mileage_msg_short_name'")
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.Mileage_msg_short_name, sender=self.PP_ECUID, filter_attributes=None)
        self.sleep_for(self.wait_for_STDF_dlt_message)
        self.dlt_manager.stop_capturing_non_verbose_message()
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check the non verbose message 'Mileage_msg_short_name' was received")
        logger.info(f"DTL message = {dlt_messages[-1]}")
        dlt_msg = dlt_messages[-1]['payload']
        logger.info("[DLT Messages ]:{0}".format(dlt_msg))
        self.expectTrue(dlt_msg['mileage'] == self.initial_mileage_response, Severity.MAJOR, f"Check initial mileage. Expected: {self.initial_mileage_response}, actual {dlt_msg['mileage']}")

    def tearDown(self):
        self.diag_manager.stop()
        self.setPostcondition("Stop simulation")
        self.someip_controller.stop_all_offers("BCP21_GW")
        self.someip_controller.stop_simulation("BCP21_GW")
        self.bcp21_nmController.stop_nm_udp_simulation()
        self.someip_controller.clear_adapter_configuration('Stimulation', self.ZGW_IP, self.SOMEIP_MULTICAST_IP)
        self.MediaGateway_controller.set_mediagateway_config(self.Default_MG)
        self.sleep_for(self.SET_MG_CONFIG_MS)
        self.bus.power_supply.power_on_reset(downtime=self.PP_SHUTDOWN_TIMEOUT_MS, startup_time=self.PP_STARTUP_TIMEOUT_MS)
