from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_block_device_01_IOTD_threshold_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_block_device_01_IOTD_threshold_LINUX"
    REQ_ID = ["/item/5912144"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports IO statistics only when the delay exceeds 10ms"
    STATUS = "Ready"
    OS = ['LINUX']


    def setUp(self):
        self.Search_msg_array = self.statistic_data["block_delay"]["IOTD"]["Search_msg_array"]
        logger.info(f"Search message array = {self.Search_msg_array}")
        self.assertTrue(self.Search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.thread_io_statistics_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_block_device_01_IOTD_threshold_LINUX(self):
        self.startTestStep("Wait 60s")
        self.sleep_for(self.wait_for_iotd_message_MS)

        self.startTestStep("Get IOTD statistics DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.Search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that  IOTD statistics DLT messages are available")

        self.startTestStep("Get all delay values")
        all_delays = [int(self.get_statistic_value(message=x, statistic_path="block_delay.IOTD.Statistics.delay")) for x in messages]
        self.expectTrue(all(delay != self.INVALID_VALUE and delay >= self.IOTD_threshold for delay in all_delays), Severity.MAJOR, "Check that all delay is valid and bigger or equal than the configured threshold (10ms)")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
