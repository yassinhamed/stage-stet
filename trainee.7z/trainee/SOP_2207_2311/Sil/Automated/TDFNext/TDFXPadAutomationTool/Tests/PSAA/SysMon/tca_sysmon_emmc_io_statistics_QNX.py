from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_emmc_io_statistics_QNX(testfixture_PSAA_SysMon):
    TEST_ID = "PSAA/SysMon/tca_sysmon_emmc_io_statistics_QNX"
    REQ_ID = ["/item/6446988", "/item/5888677"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports the io statistics"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.emmc_health_report_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["EMMC"]["IO statistics QNX"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.emmc_health_report_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_emmc_io_statistics_QNX(self):
        self.startTestStep("Wait one cycle * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get eMMC IO statistics DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that eMMC IO statistics DLT messages are available")

        self.startTestStep("Get READ_SECTORS value")
        READ_SECTORS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics QNX.Statistics.READ_SECTORS")
        self.expectTrue(READ_SECTORS != self.INVALID_VALUE, Severity.MAJOR, "Check that READ_SECTORS is reported")

        self.startTestStep("Get WRITE_SECTORS value")
        WRITE_SECTORS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics QNX.Statistics.WRITE_SECTORS")
        self.expectTrue(WRITE_SECTORS != self.INVALID_VALUE, Severity.MAJOR, "Check that WRITE_SECTORS is reported")

        self.startTestStep("Get TRIM_SECTORS value")
        TRIM_SECTORS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics QNX.Statistics.TRIM_SECTORS")
        self.expectTrue(TRIM_SECTORS != self.INVALID_VALUE, Severity.MAJOR, "Check that TRIM_SECTORS is reported")

        self.startTestStep("Get ERASE_SECTORS value")
        ERASE_SECTORS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics QNX.Statistics.ERASE_SECTORS")
        self.expectTrue(ERASE_SECTORS != self.INVALID_VALUE, Severity.MAJOR, "Check that ERASE_SECTORS is reported")

        self.startTestStep("Get DISCARD_SECTORS value")
        DISCARD_SECTORS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics QNX.Statistics.DISCARD_SECTORS")
        self.expectTrue(DISCARD_SECTORS != self.INVALID_VALUE, Severity.MAJOR, "Check that DISCARD_SECTORS is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
