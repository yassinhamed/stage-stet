from Tests.PSAA.testfixture_PSAA import *
import random


class testfixture_PSAA_param_server(testfixture_PSAA):
    # ServiceID list
    AdpParameters_service_ID = 0xd087

    # InstanceID list
    AdpParameters_instances = {"mPAD_Performance": 0x0007, "mPAD_Performance_AddOn": 0x000A, "mPAD_Performance_High": 0x0001}

    param_server_etc_path = "/opt/param_server/etc"
    someip_config_backup = "someip_config_setupClass.json"
    defaut_values_file_name = "default_values.json"
    defaut_values_file_name_modified = "default_values_modified.json"
    default_values_backup = "default_values_setupClass.json"
    modularKitModelmPAD_file_name = "modularKitModelmPAD_PP_Parameter_Server.json"
    all_fields_file_name = "param_server_all_fields.json"

    @classmethod
    def setUpClass(cls):
        logger.debug("start testfixture_PSAA_param_server setUpclsss")
        cls.ssh_manager.executeCommandInTarget("ls /opt/param_server/bin")
        cls.ssh_manager.executeCommandInTarget("ls /opt/param_server/etc")

        # download someip_config.json
        cls.ssh_manager.downloadFileFromTarget(source_file=cls.SOMEIP_CONFIG_FILE_NAME, source_path=cls.param_server_etc_path,
                                               destination_path=OutputPathManager.get_tests_group_path())
        rename(path.join(OutputPathManager.get_tests_group_path(), cls.SOMEIP_CONFIG_FILE_NAME),
               path.join(OutputPathManager.get_tests_group_path(), cls.someip_config_backup))
        if not path.exists(path.join(OutputPathManager.get_tests_group_path(), cls.someip_config_backup)):
            logger.error(f"Could not find {cls.someip_config_backup}. This will affect the execution.")
        # download default_values.json
        cls.ssh_manager.downloadFileFromTarget(source_file=cls.defaut_values_file_name, source_path=cls.param_server_etc_path,
                                               destination_path=OutputPathManager.get_tests_group_path())
        rename(path.join(OutputPathManager.get_tests_group_path(), cls.defaut_values_file_name),
               path.join(OutputPathManager.get_tests_group_path(), cls.default_values_backup))
        if not path.exists(path.join(OutputPathManager.get_tests_group_path(), cls.default_values_backup)):
            logger.error(f"Could not find {cls.default_values_backup}. This will affect the execution.")

        cls.save_default_values_file_backup()

        # Generate a json file with all needed info
        if path.exists(path.join(OutputPathManager.get_tests_group_path(), cls.someip_config_backup)) and path.exists(
                path.join(OutputPathManager.get_tests_group_path(), cls.default_values_backup)):
            # inputs: modularKitModelmPAD_PP_Parameter_Server.json, someip_config.json, default_values.json
            # output: param_server_all_fields_info.json
            cls.generate_param_server_all_fields_info()
        else:
            logger.error("All fields info file generation skipped.")

        # get default CAFD values
        logger.debug("Get CAFD")
        cls.cafd_initial_values = cls.fdl_coder.read_cafd(controller=cls.PP_CAF_NAME)
        cls.display_cafd_parameters(cafd=cls.cafd_initial_values)

        cls.supported_fields_not_coding = cls.get_supported_fields(is_coding=False)
        cls.supported_fields_coding = cls.get_supported_fields(is_coding=True)
        testfixture_PSAA_param_server.indexes_not_coding_random = [i for i in range(len(cls.supported_fields_not_coding))]
        testfixture_PSAA_param_server.indexes_coding_random = [i for i in range(len(cls.supported_fields_coding))]
        logger.info(f"list for fields without coding dependencies {cls.indexes_not_coding_random}")
        logger.info(f"list for fields with coding dependencies {cls.indexes_not_coding_random}")


        cls.json_manager.updateNodeIntoJsonFile(filePath="/opt/param_server/etc/logging.json",
                                                nodePath="logLevel",
                                                value="kVerbose", use_cache=False, delete_cache=True, upload_file=True)
        cls.ssh_manager.executeCommandInTarget(command="rm /persistent/coredumps/* && sync", ip_address=cls.PP_IP)
        cls.diag_manager.start()
        cls.diag_manager.ecu_reset(target=cls.PP_DIAG_ADR, reset_duration=cls.PP_RESET_TIMEOUT_S)
        cls.diag_manager.stop()

        ECU_is_OK = cls.check_ECUs()

        cls.executed_TCs = []

        mkdir(path.join(OutputPathManager.get_tests_group_path(),"coredumps_setupclass"))
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=path.join(OutputPathManager.get_tests_group_path(), "coredumps_setupclass_without_proxyapp"),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])

        cls.start_TestEquipment_simulation()

        """
        logger.debug("########################")
        logger.debug("\n".join(cls.get_supported_fields(is_coding=True)))
        logger.debug("########################")
        logger.debug("\n".join(cls.get_supported_fields(is_coding=False)))
        logger.debug("########################")
        logger.debug("\n".join(cls.get_supported_parameters(field_name=cls.get_supported_fields(is_coding=False)[-1])))
        logger.debug("########################")
        logger.debug(f"{cls.get_field_dict(field_name=cls.get_supported_fields(is_coding=True)[-1])}")
        logger.debug("########################")
        logger.debug(f"{cls.get_parameter_dict(parameter_name=cls.get_supported_parameters(field_name=cls.get_supported_fields(is_coding=False)[-1])[-1])}")
        logger.debug("########################")
        logger.debug(f"{cls.get_field_property(field_name=cls.get_supported_fields(is_coding=True)[-1], property_name=cls.field_properties.SomeIP)}")
        logger.debug("########################")
        logger.debug(f"{cls.get_parameter_property(parameter_name=cls.get_supported_parameters(field_name=cls.get_supported_fields(is_coding=False)[-1])[-1], property_name=cls.parameter_properties.defaultValue)}")
        logger.debug("########################")
        logger.debug(f"{cls.get_parameter_all_default_values('attention_left_sidewindow_bottom_coordinate')}")
        logger.debug("########################")
        logger.debug(f"{cls.get_parameter_all_default_values('attention_fixation_debounce_time_ms')}")
        logger.debug("########################")
        parsed_p = cls.generate_paresed_payload_default_values(field_name=cls.get_supported_fields(is_coding=False)[-1])
        logger.debug(f"{parsed_p}")
        logger.debug("########################")
        for param in cls.get_supported_parameters(field_name=cls.get_supported_fields(is_coding=False)[-1]):
            logger.debug(f"{cls.set_parameter_in_parsed_payload(parsed_payload=parsed_p, parameter_name=param, setting_mode=cls.setting_mode.newRandomValue)}")
        logger.debug("########################")
        logger.debug(f"")
        logger.debug("########################")
        """

    @classmethod
    def tearDownClass(cls):
        logger.debug("start testfixture_PSAA_param_server tearDownclsss")
        cls.revert_default_values_file_to_backup()

    def setUp(self):
        logger.info("testfixture_PSAA_param_server setUp")

        if self.field_depends_on_coding is not None:
            if self.__class__.__name__ not in self.executed_TCs:
                logger.debug(f"TC {self.__class__.__name__} first time execution")
                self.executed_TCs.append(self.__class__.__name__)
                if self.field_depends_on_coding == True:
                    testfixture_PSAA_param_server.indexes_coding_random = [i for i in range(len(self.supported_fields_coding))]
                elif self.field_depends_on_coding == False:
                    testfixture_PSAA_param_server.indexes_not_coding_random = [i for i in range(len(self.supported_fields_not_coding))]
            logger.info(f"Field depends on coding is {self.field_depends_on_coding}")
            logger.info("get random index")
            self.field_index = self.random_index(is_coding=self.field_depends_on_coding)
            logger.info(f"field index = {self.field_index}")
            supported_fields = self.get_supported_fields(is_coding=self.field_depends_on_coding)
            logger.info(f"Supperted fields\n{supported_fields}")
            # self.tested_field = supported_fields[self.field_index % len(supported_fields)]
            self.tested_field = supported_fields[self.field_index]
            self.someipIds = self.get_field_property(field_name=self.tested_field, property_name=self.field_properties.SomeIP)
            self.field_size = self.get_field_property(field_name=self.tested_field, property_name=self.field_properties.totalSize)
            self.field_structure = self.get_field_property(field_name=self.tested_field, property_name=self.field_properties.structure)
            logger.info(f"Field depends on coding is {self.field_depends_on_coding}")
            if self.field_depends_on_coding:
                self.coding_dict = self.get_field_property(field_name=self.tested_field, property_name=self.field_properties.coding)
                self.coding_name = self.coding_dict['name']
                self.coding_values_list = self.coding_dict['values']
                self.coding_default_value = self.cafd_initial_values[self.coding_name].value
                logger.info(f"coding_default_value = {self.coding_default_value}")
            self.DLT_message_GET = f"Get  {self.tested_field}_Par"
            self.DLT_message_SET = f"Set  {self.tested_field}_Par"
            if self.field_depends_on_coding:
                self.initial_parsed_payload = self.generate_paresed_payload_default_values(field_name=self.tested_field,
                                                                                           coding_value=self.cafd_initial_values[self.coding_name].value)
            else:
                self.initial_parsed_payload = self.generate_paresed_payload_default_values(field_name=self.tested_field, coding_value=None)

            logger.info(f"Field name = {self.tested_field}")
            logger.info(f"Field payload size = {self.field_size}")
            logger.info(f"Field SomeIP info: \n {self.someipIds}")
            logger.info(f"Field structure: \n {self.field_structure}")
            if self.field_depends_on_coding:
                logger.info(f"Field coding: \n {self.coding_dict}")
            logger.info(f"DLT get message: {self.DLT_message_GET}")
            logger.info(f"DLT set message: {self.DLT_message_SET}")
            logger.info(f"Gererated parsed payload: \n {self.initial_parsed_payload}")
            # except:
            #     logger.warn(f"field_depends_on_coding is not defiened")
            self.someip_manager.reset(ecu="TestEquipmentIntern")
            self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
            self.dlt_manager.apply_filter(appId="Para")
            self.dlt_manager.apply_filter(contextId="DFLT")
            self.dlt_manager.start_monitoring("SRR-DLT")
        logger.info("testfixture_PSAA_param_server end setUp")

    def tearDown(self):
        logger.info("testfixture_PSAA_param_server teardown")
        self.dlt_manager.stop_monitoring()
        self.dlt_manager.clear_all_filters()
        self.someip_manager.reset(ecu="TestEquipmentIntern")
        self.wait_for_Planning_CoreDumps_generation()
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_test_case_path(),check_empty=False,ip_address=self.PP_IP,ignored_files=["currentswversion", "tmp"])
        logger.info("testfixture_PSAA_param_server end teardown")

    @classmethod
    def wait_for_Planning_CoreDumps_generation(cls):
        logger.info("wait_for_Planning_CoreDumps_generation")
        if cls.os_name == "QNX":
            result = cls.ssh_manager.executeCommandInTarget(command=
                                                            "ls /persistent/coredumps | grep Planning",
                                                            ip_address=cls.PP_IP)
            lines = result['stdout'].split("\n")
            nr_core = len([i for i in lines if "core" in i])
            nr_context = len([i for i in lines if "context" in i])
            if nr_core != nr_context:
                logger.debug("Planning coredump files exist, nr of core != nr of context -> wait 30s ")
                cls.tb.sleep_for(30000)
        else:
            result = cls.ssh_manager.executeCommandInTarget(command=
                "echo $(($(ls /persistent/coredumps | grep Planning | grep -v grep | grep core | wc -l) == $(ls /persistent/coredumps | grep Planning | grep -v grep | grep context | wc -l)))", ip_address=cls.PP_IP)
            tentatives = 12
            while result['stdout'].strip() != "1":
                logger.info("number of context file and core file of the generated file for Planning coredumps are not equal -> wait 5s")
                cls.tb.sleep_for(5000)
                tentatives -= 1
                if tentatives == 0:
                    logger.warn("Nr. of core and context files are still unequal. Stop waiting after 60 seconds")
                    break


    @classmethod
    def random_indexes(cls, number_of_indexes=3, is_coding=False):
        logger.info("random_indexes")
        return random.sample([i for i in range(len(cls.get_supported_fields(is_coding=is_coding)))], number_of_indexes)

    @classmethod
    def random_index(cls, is_coding=False):
        logger.info("random_index")
        if is_coding:
            index = random.choice(testfixture_PSAA_param_server.indexes_coding_random)
            testfixture_PSAA_param_server.indexes_coding_random.remove(index)
            if len(testfixture_PSAA_param_server.indexes_coding_random) == 0:
                testfixture_PSAA_param_server.indexes_coding_random = [i for i in range(len(cls.supported_fields_coding))]
            return index
        else:
            index = random.choice(testfixture_PSAA_param_server.indexes_not_coding_random)
            testfixture_PSAA_param_server.indexes_not_coding_random.remove(index)
            if len(testfixture_PSAA_param_server.indexes_not_coding_random) == 0:
                testfixture_PSAA_param_server.indexes_not_coding_random = [i for i in range(len(cls.supported_fields_not_coding))]
            return index

    @classmethod
    def get_random_field_indexes_727611_not_coding(cls, index):
        return cls.random_field_indexes_727611_not_coding[index]

    @classmethod
    def get_random_field_indexes_727611_coding(cls, index):
        return cls.random_field_indexes_727611_coding[index]

    @classmethod
    def get_random_parameter_in_field(cls, field_name, depends_on_coding=False):
        logger.info("get_random_parameter_in_field")
        if depends_on_coding:
            parameters = cls.get_field_property(field_name=field_name, property_name=cls.field_properties.coding)['params']
        else:
            parameters = cls.get_supported_parameters(field_name=field_name)
        return random.choice(parameters)

    def get_someip_messages_from_queue(self, method_id):
        logger.info("get_someip_messages_from_queue")
        messages = self.someip_manager.get_message_queue("TestEquipmentIntern")
        filtered_messages = []
        for msg in messages:
            logger.debug(f"method_id = {msg.method_id}")
            if msg.method_id == method_id:
                filtered_messages.append(msg)

        return filtered_messages

    def check_DLT_priority_get_vs_set(self, get_messages, set_messages):
        logger.info("get_DLT_log_priority")
        try:
            get_priority = get_messages[-1]['extendedHeader']['MessageTypeInfo']
            set_priority = set_messages[-1]['extendedHeader']['MessageTypeInfo']
            logger.info(f"Get message priority = {get_priority}")
            logger.info(f"Set message priority = {set_priority}")
            return get_priority > set_priority
        except:
            logger.error("exception occured in check_DLT_priority_get_vs_set")
            return False

    @classmethod
    def start_TestEquipment_simulation(cls):
        logger.debug("start_TestEquipment_simulation")
        supported_fields = cls.get_supported_fields(is_coding=None)
        cls.someip_controller.init_simulation("TestEquipmentIntern")
        cls.someip_controller.request_service(ecu="TestEquipmentIntern", service_id=cls.AdpParameters_service_ID,
                                              instance_id=cls.AdpParameters_instances[cls.PP_NAME], major=1, minor=0)

        _sub_filter = {}
        for field in supported_fields:
            someipIds = cls.get_field_property(field_name=field, property_name=cls.field_properties.SomeIP)
            _sub_filter[someipIds['getterID']] = [cls.AdpParameters_instances[cls.PP_NAME]]
            _sub_filter[someipIds['notifierID']] = [cls.AdpParameters_instances[cls.PP_NAME]]
        cls.someip_manager.start_listen(_filter={
            "TestEquipmentIntern": {cls.AdpParameters_service_ID: _sub_filter}})
        for field in supported_fields:
            someipIds = cls.get_field_property(field_name=field, property_name=cls.field_properties.SomeIP)
            cls.someip_controller.request_event(ecu="TestEquipmentIntern", service_id=cls.AdpParameters_service_ID,
                                                instance_id=cls.AdpParameters_instances[cls.PP_NAME], event_id=someipIds['notifierID'],
                                                eventgroup=someipIds['eventGroupID'], is_field=True)
            cls.someip_controller.subscribe(ecu="TestEquipmentIntern", service_id=cls.AdpParameters_service_ID, instance_id=cls.AdpParameters_instances[cls.PP_NAME],
                                            event_id=someipIds['notifierID'],
                                            eventgroup=someipIds['eventGroupID'], is_field=True)
        cls.someip_controller.start_simulation(ecu="TestEquipmentIntern")
        cls.tb.sleep_for(cls.START_SIMULATION_TIMEOUT_MS)

    @classmethod
    def stop_TestEquipment_simulation(cls):
        logger.debug("stop_TestEquipment_simulation")
        cls.someip_controller.stop_simulation("TestEquipmentIntern")

    def get_new_random_coding_value(self, coding_values, inital_value):
        logger.debug("get_new_random_coding_value")
        new_random_index = random.randint(0, len(coding_values) -1)
        while int(coding_values[new_random_index]) == int(inital_value):
            new_random_index = random.randint(0, len(coding_values) - 1)
        logger.info(f"new Random value = {coding_values[new_random_index]}")
        return coding_values[new_random_index]

    def check_if_all_parameter_values_are_default(self, parsed_payload, coding_value=None):
        logger.debug("check_if_all_parameter_values_are_default")
        parameter_values_are_correct = True
        for parameter in parsed_payload.keys():
            expected_value = self.get_parameter_default_value(parameter_name=parameter, coding_value=coding_value)
            if expected_value is None:
                expected_value = self.get_parameter_property(parameter_name=parameter, property_name=self.parameter_properties.initValue)
                logger.debug(f"default value not found for parameter {parameter}. InitValue will be checked = {expected_value}")
            else:
                logger.debug(f"default value found for parameter {parameter} = {expected_value}")

            if parsed_payload[parameter] == expected_value:
                logger.debug(f"Check passed for {parameter}")
            else:
                logger.debug(f"check failed for {parameter}")
                parameter_values_are_correct = False

        return parameter_values_are_correct

    @classmethod
    def save_default_values_file_backup(cls):
        logger.debug("save_default_values_file_backup")
        # cp default_values.json under /persistent/Technica
        result = cls.ssh_manager.executeCommandInTarget(command=f"rm {cls.technica_persistent_folder}/{cls.defaut_values_file_name} && sync", ip_address=cls.PP_IP)
        result = cls.ssh_manager.executeCommandInTarget(command=f"cp {cls.param_server_etc_path}/{cls.defaut_values_file_name} {cls.technica_persistent_folder}/{cls.defaut_values_file_name} && sync", ip_address=cls.PP_IP)
        if len(result['stderr']) > 0:
            logger.error(f"Could not copy {cls.defaut_values_file_name} in {cls.technica_persistent_folder}")
            return False
        result = cls.ssh_manager.executeCommandInTarget(command=f'[ -f {cls.technica_persistent_folder}/{cls.defaut_values_file_name} ] && echo "File exists" || "File does not exits"', ip_address=cls.PP_IP)
        if result['stdout'].strip() != "File exists":
            logger.error(f"The file {cls.technica_persistent_folder}/{cls.technica_persistent_folder} does not exist")
            return False
        return True

    @classmethod
    def revert_default_values_file_to_backup(cls):
        logger.debug("revert_default_values_file_to_backup")
        # rm file in /opt/param_server/etc
        result = cls.ssh_manager.executeCommandInTarget(command=f"rm {cls.param_server_etc_path}/{cls.defaut_values_file_name}", ip_address=cls.PP_IP)
        if len(result['stderr']) > 0:
            logger.error(f"Could not remove {cls.param_server_etc_path}/{cls.defaut_values_file_name}")
            return False
        # check if file was removed
        result = cls.ssh_manager.executeCommandInTarget(command=f'[ -f {cls.param_server_etc_path}/{cls.defaut_values_file_name} ] && echo "File exists" || "File does not exits"', ip_address=cls.PP_IP)
        if result['stdout'].strip() == "File exists":
            logger.error(f"The file {cls.param_server_etc_path}/{cls.defaut_values_file_name} still exists")
            return False
        # mv file from /persistent/Technica to /opt/param_server/etc
        result = cls.ssh_manager.executeCommandInTarget(command=f"cp {cls.technica_persistent_folder}/{cls.defaut_values_file_name} {cls.param_server_etc_path}/{cls.defaut_values_file_name} && sync && chmod 644 {cls.param_server_etc_path}/{cls.defaut_values_file_name}", ip_address=cls.PP_IP)
        if len(result['stderr']) > 0:
            logger.error(f"Could not move {cls.defaut_values_file_name} from {cls.technica_persistent_folder} to {cls.param_server_etc_path}")
            return False
        # check if file exist in /op/param_server/etc
        result = cls.ssh_manager.executeCommandInTarget(command=f'[ -f {cls.param_server_etc_path}/{cls.defaut_values_file_name} ] && echo "File exists" || "File does not exits"', ip_address=cls.PP_IP)
        if result['stdout'].strip() != "File exists":
            logger.error(f"The file {cls.param_server_etc_path}/{cls.defaut_values_file_name} does not exist")
            return False
        return True

    ###########################################################################

    complexitiy_level = {
        "simple": 0,
        "simple_array": 1,
        "complex_array": 2
    }

    dataTypes_length_dict = {
        "float32": 4,
        "uint8": 1,
        "uint16": 2,
        "uint32": 4,
        "bool": 1,
        "sint32": 4,
        "sint16": 2,
        "sint8": 1
    }

    class field_properties(Enum):
        name = "name"
        coding = "coding"
        parameterSets = "parameterSets"
        size = "size"
        totalSize = "totalSize"
        SomeIP = "SomeIP"
        structure = "structure"

    class parameter_properties(Enum):
        name = "name"
        type = "type"
        initValue = "initValue"
        defaultValue = "defaultValue"
        min = "min"
        max = "max"
        range_min = "range_min"
        range_max = "range_max"
        newSetValue = "newSetValue"
        newDefaultValue = "newDefaultValue"
        coding_name = "coding_name"

    all_fields_dict = {"fields": []}

    @classmethod
    def get_supported_fields(cls, is_coding=False):
        logger.debug("get_supported_fields")
        supported_fields = []
        try:
            if is_coding is None:
                supported_fields.extend(cls.get_supported_fields(is_coding=False))
                supported_fields.extend(cls.get_supported_fields(is_coding=True))
                return supported_fields
            for field in cls.all_fields_dict["fields"]:
                if (field["coding"] is not None) == is_coding:
                    supported_fields.append(field["name"])
        except:
            logger.error("error occured in get_supported_fields")
            logger.error(traceback.format_exc())
            return None
        return supported_fields

    @classmethod
    def get_supported_parameters(cls, field_name):
        logger.debug("get_supported_parameters")
        supported_parameters = []
        try:
            for field in cls.all_fields_dict['fields']:
                if field['name'] == field_name:
                    for parameterSet in ['parameters', 'maps', 'axes']:
                        for parameter in field['parameterSets'][parameterSet]:
                            supported_parameters.append(parameter['name'])
        except:
            logger.error("error occured in get_supported_parameters")
            logger.error(traceback.format_exc())
            return None
        return supported_parameters

    @classmethod
    def get_field_dict(cls, field_name):
        logger.debug("get_field_dict")
        try:
            for field in cls.all_fields_dict['fields']:
                if field['name'] == field_name:
                    return field
        except:
            logger.error("error occured in get_field_dict")
            logger.error(traceback.format_exc())

        return None

    @classmethod
    def get_parameter_dict(cls, parameter_name):
        logger.debug("get_parameter_dict")
        try:
            for field in cls.all_fields_dict['fields']:
                for parameterSet in ['parameters', 'maps', 'axes']:
                    for parameter in field['parameterSets'][parameterSet]:
                        if parameter_name == parameter['name']:
                            return parameter
        except:
            logger.error("error occured in get_parameter_dict")
            logger.error(traceback.format_exc())

        return None

    @classmethod
    def get_field_property(cls, field_name, property_name):
        logger.debug("get_field_property")
        """
        :param field_name: name of the field
        :param property_name: enum field_properties - the key in the field_dict
        :return: property value
        """
        if not isinstance(property_name, cls.field_properties):
            logger.error(f"property_name should be an instance of field_properties")
            return None
        field = cls.get_field_dict(field_name)
        if field is None:
            logger.error(f"Could not retrieve the field {field_name}")
            return None
        else:
            try:
                return field[property_name.value]
            except:
                logger.error(f"Error occured when getting the key {property_name} for the field {field_name}")
                logger.error(traceback.format_exc())
                return None

    @classmethod
    def get_parameter_property(cls, parameter_name, property_name):
        logger.debug("get_parameter_property")
        """
        :param parameter_name: name of the parameter
        :param property_name: enum parameter_properties - the key in the parameter_dict
        :return: property value
        """
        if not isinstance(property_name, cls.parameter_properties):
            logger.error(f"property_name should be an instance of parameter_properties")
            return None
        parameter = cls.get_parameter_dict(parameter_name=parameter_name)
        if parameter is None:
            logger.error(f"Could not retrieve the parameter {parameter_name}")
            return None
        else:
            try:
                return parameter[property_name.value]
            except:
                logger.error(f"Error occured when getting the key {property_name} for the parameter {parameter_name}")
                logger.error(traceback.format_exc())
                return None

    @classmethod
    def get_parameter_all_default_values(cls, parameter_name):
        logger.debug("get_parameter_all_default_values")
        param_default_value = {}
        for field in cls.all_fields_dict['fields']:
            for parameterSet in ['parameters', 'maps', 'axes']:
                for parameter in field['parameterSets'][parameterSet]:
                    if parameter['name'] == parameter_name:
                        if field['coding'] is not None:
                            if parameter_name in field['coding']['params']:
                                if type(parameter['defaultValue']) != list or len(field['coding']['values']) != len(parameter['defaultValue']):
                                    logger.error(f"default value of {parameter_name} is not correct.")
                                    return None
                                for index, coding_value in enumerate(field['coding']['values']):
                                    param_default_value[f"{field['coding']['name']}_{coding_value}_{parameter_name}"] = parameter['defaultValue'][index]
                                return param_default_value
                        return {parameter_name: parameter['defaultValue']}
        return None

    @classmethod
    def get_parameter_default_value(cls, parameter_name, coding_value=None):
        logger.debug("get_parameter_default_value")
        try:
            field_name = cls.get_field_of_parameter(parameter_name=parameter_name)
            coding_dict = cls.get_field_property(field_name=field_name, property_name=cls.field_properties.coding)
            default_value = cls.get_parameter_property(parameter_name=parameter_name, property_name=cls.parameter_properties.defaultValue)
            init_value = cls.get_parameter_property(parameter_name=parameter_name, property_name=cls.parameter_properties.initValue)
            if default_value is None:
                return init_value
            if coding_dict is None:
                return default_value
            else:
                if parameter_name in coding_dict['params'] and coding_value is None:
                    logger.error(f"parameter depends on coding {coding_dict['name']}. Please give a specific value to get the corresponding default value")
                    return None
                elif parameter_name in coding_dict['params']:
                    return default_value[int(coding_value)]
                else:
                    return default_value
        except:
            logger.error(f"Could not retrieve default value for {parameter_name} and coding value {coding_value}")
            logger.error(traceback.format_exc())
            return None

    @classmethod
    def get_field_of_parameter(cls, parameter_name):
        logger.debug("get_field_of_parameter")
        for field in cls.all_fields_dict['fields']:
            for parameterSet in ['parameters', 'maps', 'axes']:
                for parameter in field['parameterSets'][parameterSet]:
                    if parameter['name'] == parameter_name:
                        return field['name']
        return None

    @classmethod
    def get_coding_values(cls, coding_parameters, coding_name):
        logger.debug("get_coding_values")
        try:
            for coding in coding_parameters:
                if coding['name'] == coding_name:
                    return coding['codingValues']
        except:
            logger.error(f"Could not find conding {coding_name}")
            logger.error(traceback.format_exc())
        return None

    @classmethod
    def check_complexitiy(cls, value):
        logger.debug("check_complexitiy")
        complexitiy = "simple"
        if type(value) == list:
            complexitiy = "simple_array"
            for item in value:
                if type(item) == list:
                    return "complex_array"
        return complexitiy

    @classmethod
    def check_symmetry(cls, value):
        logger.debug("check_symmetry")
        dim = []
        if type(value) == list:
            for item in value:
                if type(item) == list:
                    dim.append(len(item))
                else:
                    dim.append(0)
        if len(dim) > 0 and not dim.count(dim[0]) == len(dim):
            return False
        return True

    @classmethod
    def get_param_size(cls, param, typ):
        logger.debug("get_param_size")
        unit = cls.dataTypes_length_dict[typ]
        size = 0
        if type(param) == list:
            for item in param:
                if type(item) == list:
                    for sub_item in item:
                        if type(sub_item) != list:
                            size += unit
                        else:
                            return -1
                else:
                    size += unit
        else:
            size += unit

        return size

    @classmethod
    def convert_initValue_to_structure(cls, initValue, typ):
        logger.debug("convert_initValue_to_structure")
        structure = ""
        if type(initValue) == list:
            structure += f"array_{len(initValue)}_"
            if type(initValue[0]) == list:
                structure += f"array_{len(initValue[0])}_{typ}"
            else:
                structure += typ
        else:
            structure += typ
        return structure

    @classmethod
    def get_default_value_from_json(cls, param_name, default_values, coding_dict):
        logger.debug("get_default_value_from_json")
        """
        return default values from default_values.json. If the parameter depends on coding, returns a list of all default values
        :param param_name:
        :param default_values:
        :param coding_dict:
        :return:
        """
        if not type(default_values) == dict:
            logger.error("default_values should be a dict")
            return None
        try:
            if coding_dict is None or (coding_dict is not None and param_name not in coding_dict['params']):
                for param in default_values['parameters']:
                    if param['name'] == param_name:
                        return param['initValue']
            else:
                result = []
                for coding_value in coding_dict['values']:
                    coding_def_value_found = False
                    for param in default_values['parameters']:
                        if param['name'] == f"{coding_dict['name']}_{coding_value}_{param_name}":
                            result.append(param['initValue'])
                            coding_def_value_found = True
                            break
                    if not coding_def_value_found:
                        result.append(None)
                if len(result) != len(coding_dict['values']):
                    logger.error(f"Could not retrieve all default values for parameter {param_name}")
                return result
        except:
            logger.error(traceback.format_exc())
            return None

    @classmethod
    def get_someip_ids_from_json(cls, field_name, someip_config):
        logger.debug("get_someip_ids_from_json")
        result = {}
        if not type(someip_config) == dict:
            logger.error("someip_config should be a dict")
            return None
        try:
            getter_found = False
            setter_found = False
            for method in someip_config['services'][0]['methods']:

                if method['name'] == f"{field_name}_Par_vsomeipGetter":
                    result['getterID'] = method['id']
                    getter_found = True
                    continue
                if method['name'] == f"{field_name}_Par_vsomeipSetter":
                    result['setterID'] = method['id']
                    setter_found = True
                    continue
                if getter_found and setter_found:
                    break

            for event in someip_config['services'][0]['events']:
                if event['name'] == f"{field_name}_Par_vsomeipNotifier":
                    result['notifierID'] = event['id']
                    break

            for eventGroup in someip_config['services'][0]['eventgroups']:
                if result['notifierID'] in eventGroup['events']:
                    result['eventGroupID'] = eventGroup['id']
                    break
        except:
            logger.error(traceback.format_exc())
            return None

        return result

    @classmethod
    def adjust_initValue(cls, value, typ):
        logger.debug("adjust_initValue")
        result = value
        if typ == "float32":
            if type(result) == list:
                for index, elem in enumerate(result):
                    if type(elem) == list:
                        for subindex, subelem in enumerate(elem):
                            result[index][subindex] = struct.unpack('>f', struct.pack('>f', result[index][subindex]))[0]
                    else:
                        result[index] = struct.unpack('>f', struct.pack('>f', result[index]))[0]

            else:
                result = struct.unpack('>f', struct.pack('>f', value))[0]

        return result

    @classmethod
    def generate_new_values(cls, default_value, initValue, typ, min, max):
        logger.debug(f"generate_new_values: default_value: {default_value}, initValue: {initValue}, typ: {typ}, min: {min}, max: {max}")
        new_setValue = None
        new_defaultValue = None
        if typ == "bool":
            if default_value is None:
                new_setValue = 0 if initValue == 1 else 1
                new_defaultValue = new_setValue
            else:
                new_setValue = 0 if default_value == 1 else 1
                new_defaultValue = new_setValue
        elif typ == "float32":
            if default_value is None:
                default_value = initValue
            tries = 0
            while tries < 10:
                random_nr = random.SystemRandom().uniform(min, max)
                random_nr = struct.unpack('>f', struct.pack('>f', random_nr))[0]
                if random_nr != default_value and random_nr != initValue:
                    new_setValue = random_nr
                    break
                tries += 1
            tries = 0
            while tries < 10:
                random_nr = random.SystemRandom().uniform(min, max)
                random_nr = struct.unpack('>f', struct.pack('>f', random_nr))[0]
                if random_nr != default_value and random_nr != initValue and random_nr != new_setValue:
                    new_defaultValue = random_nr
                    break
                tries += 1

        elif "int" in typ:
            min = int(min)
            max = int(max)
            if max == min:
                new_defaultValue = min
                new_setValue = min
            elif abs(max - min) == 1:
                if default_value is not None:
                    new_setValue = min if default_value != min else max
                    new_defaultValue = new_setValue
                else:
                    new_setValue = min if initValue != min else max
                    new_defaultValue = new_setValue
            elif abs(max - min) == 2:
                list_of_values = list(range(int(min), int(max + 1)))
                if default_value is not None:
                    if default_value in list_of_values: list_of_values.remove(default_value)
                if initValue in list_of_values: list_of_values.remove(initValue)
                if len(list_of_values) > 1:
                    new_setValue = list_of_values[0]
                    new_defaultValue = list_of_values[1]
                else:
                    new_setValue = list_of_values[0]
                    new_defaultValue = new_setValue
            elif abs(max - min) < 25:
                list_of_values = list(range(int(min), int(max + 1)))
                if default_value is not None:
                    if default_value in list_of_values: list_of_values.remove(default_value)
                if initValue in list_of_values: list_of_values.remove(initValue)

                new_setValue = random.choice(list_of_values)
                list_of_values.remove(new_setValue)
                new_defaultValue = random.choice(list_of_values)
            else:
                tries = 0
                while tries < 10:
                    random_nr = random.randint(min, max)
                    if random_nr != default_value and random_nr != initValue:
                        new_setValue = random_nr
                        break
                    tries += 1
                tries = 0
                while tries < 10:
                    random_nr = random.randint(min, max)
                    if random_nr != default_value and random_nr != initValue and random_nr != new_setValue:
                        new_defaultValue = random_nr
                        break
                    tries += 1
        else:
            logger.error("error while checking the type of the paramter")
            return None
        return new_setValue, new_defaultValue

    @classmethod
    def generate_param_server_all_fields_info(cls):
        min_max = {
            "bool": {"min": 0, "max": 1},
            "float32": {"min": -340282346638528859811704183484516925440.0, "max": 340282346638528859811704183484516925440.0},
            "sint8": {"min": -128, "max": 127},
            "uint8": {"min": 0, "max": 255},
            "sint16": {"min": -32768, "max": 32767},
            "uint16": {"min": 0, "max": 65535},
            "sint32": {"min": -2147483648, "max": 2147483647},
            "uint32": {"min": 0, "max": 4294967295}
        }
        logger.debug("generate_param_server_all_fields_info")
        semeip_config_dict = {}
        with io.open(path.join(OutputPathManager.get_tests_group_path(), cls.someip_config_backup)) as sc:
            semeip_config_dict = json.load(sc)

        default_values_dict = {}
        with io.open(path.join(OutputPathManager.get_tests_group_path(), cls.default_values_backup)) as dv:
            default_values_dict = json.load(dv)

        modularKitModelmPAD_path = path.join(cls.input_folder, cls.modularKitModelmPAD_file_name)
        cls.codings_values_dict = {}
        with io.open(modularKitModelmPAD_path) as json_file:
            imported_dict = json.load(json_file)
            for field in imported_dict['components']:
                coding_dict = None

                # check if field depends on conding
                if "codingParameters" in field.keys():
                    coding_name = field['codingParameters'][0]['codingParameter']['$ref']
                    coding_values = cls.get_coding_values(coding_parameters=imported_dict['codingParameters'], coding_name=coding_name)
                    params = []
                    for par in field['codingParameters'][0]['parameters']:
                        params.append(par['$ref'])
                    coding_dict = {"name": coding_name, "values": coding_values, "params": params}

                    if len(field['codingParameters']) > 1:
                        logger.error(f"{field['name']} has {len(field['codingParameters'])} coding params")

                parameters = {"parameters": [], "maps": [], "axes": []}
                lengths = {"parameters": 0, "maps": 0, "axes": 0}
                # check parameters - according to current json every parameterSets should contains 3 parameterSets: parameters, maps and axes
                if len(field['parameterSets']) != 1:
                    logger.error(f"{field['name']} has {len(field['parameterSets'])} parameterSets")

                # collect for all parameters: name, coding parameter (if exits), type, initValue, min (if exists), max (if exists)
                for key in ["parameters", "maps", "axes"]:
                    if key in field['parameterSets'][0]:
                        for obj in field['parameterSets'][0][key]:
                            if not cls.check_symmetry(obj['initValue']):
                                logger.error(f"unsymmetric complex type for param {obj['name']}")
                            # if check_complexitiy(obj['initValue']) == "complex_array":
                            #    print(f"complex type for param {obj['name']}")
                            min_ = None
                            max_ = None
                            range_min = None
                            range_max = None
                            if 'min' in obj['dataType'].keys():
                                min_ = obj['dataType']['min']
                                range_min = min_
                            else:
                                range_min = min_max[obj['dataType']['primitiveType']]['min']
                            if 'max' in obj['dataType'].keys():
                                max_ = obj['dataType']['max']
                                range_max = max_
                            else:
                                range_max = min_max[obj['dataType']['primitiveType']]['max']

                            default_value = cls.get_default_value_from_json(param_name=obj['name'], default_values=default_values_dict, coding_dict=coding_dict)
                            logger.debug(f"default values = {default_value}")
                            init_value = cls.adjust_initValue(value=obj['initValue'], typ=obj['dataType']['primitiveType'])
                            logger.debug(f"init_value values = {init_value}")
                            # new_value will be used to set new param value with someip setter request. This value should be different to default value and if possible
                            # also different to initValue (not possible vor boolean type or in case of integer with max/min limitation)
                            new_SetValue = None
                            new_DefaultValue = None
                            param_coding = None
                            if coding_dict is not None and obj['name'] in coding_dict[
                                'params']:  # tbd check if coding affects the parameter ( consider list of list etc)
                                logger.debug(f"parameter: {obj['name']} in {coding_dict}")
                                param_coding = coding_dict['name']
                                new_SetValue = [None for i in range(len(coding_dict['values']))]
                                new_DefaultValue = [None for i in range(len(coding_dict['values']))]
                                for index_coding, new_setValueCoding in enumerate(new_SetValue):
                                    if type(init_value) == list:
                                        new_SetValue[index_coding] = [None for i in range(len(init_value))]
                                        new_DefaultValue[index_coding] = [None for i in range(len(init_value))]
                                        for index, item in enumerate(init_value):
                                            if type(item) == list:
                                                new_SetValue[index_coding][index] = [None for i in range(len(init_value[index]))]
                                                new_DefaultValue[index_coding][index] = [None for i in range(len(init_value[index]))]
                                                for sub_index, sub_item in enumerate(item):
                                                    new_SetValue[index_coding][index][sub_index], new_DefaultValue[index_coding][index][
                                                        sub_index] = cls.generate_new_values(
                                                        default_value[index_coding][index][sub_index] if default_value[index_coding] is not None else None,
                                                        init_value[index][sub_index], obj['dataType']['primitiveType'], range_min, range_max)
                                            else:
                                                new_SetValue[index_coding][index], new_DefaultValue[index_coding][index] = cls.generate_new_values(
                                                    default_value[index_coding][index] if default_value[index_coding] is not None else None,
                                                    init_value[index],
                                                    obj['dataType']['primitiveType'], range_min, range_max)
                                    else:
                                        new_SetValue[index_coding], new_DefaultValue[index_coding] = cls.generate_new_values(default_value[index_coding],
                                                                                                                             init_value,
                                                                                                                             obj['dataType']['primitiveType'],
                                                                                                                             range_min, range_max)

                            else:
                                if type(init_value) == list:
                                    new_SetValue = [None for i in range(len(init_value))]
                                    new_DefaultValue = [None for i in range(len(init_value))]
                                    for index, item in enumerate(init_value):
                                        if type(item) == list:
                                            new_SetValue[index] = [None for i in range(len(init_value[index]))]
                                            new_DefaultValue[index] = [None for i in range(len(init_value[index]))]
                                            for sub_index, sub_item in enumerate(item):
                                                new_SetValue[index][sub_index], new_DefaultValue[index][
                                                    sub_index] = cls.generate_new_values(
                                                    default_value[index][sub_index] if default_value is not None else None,
                                                    init_value[index][sub_index], obj['dataType']['primitiveType'], range_min, range_max)
                                        else:
                                            new_SetValue[index], new_DefaultValue[index] = cls.generate_new_values(
                                                default_value[index] if default_value is not None else None,
                                                init_value[index],
                                                obj['dataType']['primitiveType'], range_min, range_max)
                                else:
                                    new_SetValue, new_DefaultValue = cls.generate_new_values(default_value,
                                                                                             init_value,
                                                                                             obj['dataType']['primitiveType'],
                                                                                             range_min, range_max)
                            logger.debug(f"append infos for parameter: {obj['name']}")

                            parameters[key].append(
                                {'name': obj['name'], 'type': obj['dataType']['primitiveType'], 'initValue': init_value, 'defaultValue': default_value, 'min': min_,
                                 'max': max_, 'range_min': range_min, 'range_max': range_max, 'newSetValue': new_SetValue, 'newDefaultValue': new_DefaultValue, 'coding_name': param_coding})

                # SomeIP IDs from someip_config.json
                someip_ids = cls.get_someip_ids_from_json(field_name=field["name"], someip_config=semeip_config_dict)

                cls.all_fields_dict["fields"].append(
                    {"name": field["name"], "coding": coding_dict, "parameterSets": parameters, "size": lengths, "totalSize": None, "SomeIP": someip_ids,
                     "structure": {}})
                if coding_dict:
                    cls.codings_values_dict[coding_dict['name']] = coding_dict['values']

            # add default_values

            # calculate size of every parameterSet (parameters, maps, axes)

            for field in cls.all_fields_dict["fields"]:
                field_size = 0
                for param_sets in field['parameterSets'].keys():
                    t_size = 0
                    for parameter in field['parameterSets'][param_sets]:
                        size = cls.get_param_size(parameter['initValue'], parameter['type'])
                        if size == -1:
                            logger.error(f"error when getting size of param {parameter['name']}")
                            t_size = -1
                            break
                        else:
                            t_size += size
                    field['size'][param_sets] = t_size
                    field_size += t_size

                field['totalSize'] = field_size

            # get the full structure of every fields
            # exemple of structures
            # primitive float32-> float32
            # 1-D array of float32 with length 5 -> array_5_float32
            # 2-D array of array with length 3 of float32 with length 5 -> array_3_array_5_float32
            for field in cls.all_fields_dict['fields']:
                for param in field['parameterSets']['parameters']:
                    field['structure'][param['name']] = cls.convert_initValue_to_structure(param['initValue'], param['type'])
                for param in field['parameterSets']['maps']:
                    field['structure'][param['name']] = cls.convert_initValue_to_structure(param['initValue'], param['type'])
                for param in field['parameterSets']['axes']:
                    field['structure'][param['name']] = cls.convert_initValue_to_structure(param['initValue'], param['type'])

        with io.open(path.join(OutputPathManager.get_tests_group_path(), cls.all_fields_file_name), 'w+') as fp:
            json.dump(cls.all_fields_dict, fp, indent=4)


    @classmethod
    def generate_param_server_all_fields_info_WA(cls): # with workarount diviation between init_value and default value
        min_max = {
            "bool": {"min": 0, "max": 1},
            "float32": {"min": -340282346638528859811704183484516925440.0, "max": 340282346638528859811704183484516925440.0},
            "sint8": {"min": -128, "max": 127},
            "uint8": {"min": 0, "max": 255},
            "sint16": {"min": -32768, "max": 32767},
            "uint16": {"min": 0, "max": 65535},
            "sint32": {"min": -2147483648, "max": 2147483647},
            "uint32": {"min": 0, "max": 4294967295}
        }
        logger.debug("generate_param_server_all_fields_info")
        semeip_config_dict = {}
        with io.open(path.join(OutputPathManager.get_tests_group_path(), cls.someip_config_backup)) as sc:
            semeip_config_dict = json.load(sc)

        default_values_dict = {}
        with io.open(path.join(OutputPathManager.get_tests_group_path(), cls.default_values_backup)) as dv:
            default_values_dict = json.load(dv)

        modularKitModelmPAD_path = path.join(cls.input_folder, cls.modularKitModelmPAD_file_name)
        cls.codings_values_dict = {}
        with io.open(modularKitModelmPAD_path) as json_file:
            imported_dict = json.load(json_file)
            for field in imported_dict['components']:
                coding_dict = None

                # check if field depends on conding
                if "codingParameters" in field.keys():
                    coding_name = field['codingParameters'][0]['codingParameter']['$ref']
                    coding_values = cls.get_coding_values(coding_parameters=imported_dict['codingParameters'], coding_name=coding_name)
                    params = []
                    for par in field['codingParameters'][0]['parameters']:
                        params.append(par['$ref'])
                    coding_dict = {"name": coding_name, "values": coding_values, "params": params}

                    if len(field['codingParameters']) > 1:
                        logger.error(f"{field['name']} has {len(field['codingParameters'])} coding params")

                parameters = {"parameters": [], "maps": [], "axes": []}
                lengths = {"parameters": 0, "maps": 0, "axes": 0}
                # check parameters - according to current json every parameterSets should contains 3 parameterSets: parameters, maps and axes
                if len(field['parameterSets']) != 1:
                    logger.error(f"{field['name']} has {len(field['parameterSets'])} parameterSets")

                # collect for all parameters: name, coding parameter (if exits), type, initValue, min (if exists), max (if exists)
                for key in ["parameters", "maps", "axes"]:
                    if key in field['parameterSets'][0]:
                        for obj in field['parameterSets'][0][key]:
                            if not cls.check_symmetry(obj['initValue']):
                                logger.error(f"unsymmetric complex type for param {obj['name']}")
                            # if check_complexitiy(obj['initValue']) == "complex_array":
                            #    print(f"complex type for param {obj['name']}")
                            min_ = None
                            max_ = None
                            range_min = None
                            range_max = None
                            if 'min' in obj['dataType'].keys():
                                min_ = obj['dataType']['min']
                                range_min = min_
                            else:
                                range_min = min_max[obj['dataType']['primitiveType']]['min']
                            if 'max' in obj['dataType'].keys():
                                max_ = obj['dataType']['max']
                                range_max = max_
                            else:
                                range_max = min_max[obj['dataType']['primitiveType']]['max']

                            default_value = cls.get_default_value_from_json(param_name=obj['name'], default_values=default_values_dict, coding_dict=coding_dict)
                            logger.debug(f"default values = {default_value}")
                            init_value = cls.adjust_initValue(value=obj['initValue'], typ=obj['dataType']['primitiveType'])
                            logger.debug(f"init_value values = {init_value}")
                            # new_value will be used to set new param value with someip setter request. This value should be different to default value and if possible
                            # also different to initValue (not possible vor boolean type or in case of integer with max/min limitation)
                            new_SetValue = None
                            new_DefaultValue = None
                            param_coding = None
                            if coding_dict is not None and obj['name'] in coding_dict[
                                'params']:  # tbd check if coding affects the parameter ( consider list of list etc)
                                logger.debug(f"parameter: {obj['name']} in {coding_dict}")
                                param_coding = coding_dict['name']
                                new_SetValue = [None for i in range(len(coding_dict['values']))]
                                new_DefaultValue = [None for i in range(len(coding_dict['values']))]
                                for index_coding, new_setValueCoding in enumerate(new_SetValue):
                                    if type(init_value) == list:
                                        # if default_value is not None:
                                        #     if len(init_value) != len(default_value):
                                        #         init_value = [init_value[index] for index, value in enumerate(default_value)]
                                        new_SetValue[index_coding] = [None for i in range(len(default_value[index_coding]))]
                                        new_DefaultValue[index_coding] = [None for i in range(len(default_value[index_coding]))]
                                        for index, item in enumerate(default_value[index_coding] if default_value is not None else init_value):
                                            if type(item) == list:
                                                new_SetValue[index_coding][index] = [None for i in range(len(init_value[index]))]
                                                new_DefaultValue[index_coding][index] = [None for i in range(len(init_value[index]))]
                                                for sub_index, sub_item in enumerate(item):
                                                    new_SetValue[index_coding][index][sub_index], new_DefaultValue[index_coding][index][
                                                        sub_index] = cls.generate_new_values(
                                                        default_value[index_coding][index][sub_index] if default_value[index_coding] is not None else None,
                                                        init_value[index][sub_index], obj['dataType']['primitiveType'], range_min, range_max)
                                            else:
                                                new_SetValue[index_coding][index], new_DefaultValue[index_coding][index] = cls.generate_new_values(
                                                    default_value[index_coding][index] if default_value[index_coding] is not None else None,
                                                    init_value[index],
                                                    obj['dataType']['primitiveType'], range_min, range_max)
                                    else:
                                        new_SetValue[index_coding], new_DefaultValue[index_coding] = cls.generate_new_values(default_value[index_coding],
                                                                                                                             init_value,
                                                                                                                             obj['dataType']['primitiveType'],
                                                                                                                             range_min, range_max)

                            else:
                                if type(init_value) == list:
                                    new_SetValue = [None for i in range(len(init_value))]
                                    new_DefaultValue = [None for i in range(len(init_value))]
                                    for index, item in enumerate(default_value if default_value is not None else init_value):
                                        if type(item) == list:
                                            new_SetValue[index] = [None for i in range(len(init_value[index]))]
                                            new_DefaultValue[index] = [None for i in range(len(init_value[index]))]
                                            for sub_index, sub_item in enumerate(item):
                                                new_SetValue[index][sub_index], new_DefaultValue[index][
                                                    sub_index] = cls.generate_new_values(
                                                    default_value[index][sub_index] if default_value is not None else None,
                                                    init_value[index][sub_index], obj['dataType']['primitiveType'], range_min, range_max)
                                        else:
                                            new_SetValue[index], new_DefaultValue[index] = cls.generate_new_values(
                                                default_value[index] if default_value is not None else None,
                                                init_value[index],
                                                obj['dataType']['primitiveType'], range_min, range_max)
                                else:
                                    new_SetValue, new_DefaultValue = cls.generate_new_values(default_value,
                                                                                             init_value,
                                                                                             obj['dataType']['primitiveType'],
                                                                                             range_min, range_max)
                            logger.debug(f"append infos for parameter: {obj['name']}")

                            parameters[key].append(
                                {'name': obj['name'], 'type': obj['dataType']['primitiveType'], 'initValue': init_value, 'defaultValue': default_value, 'min': min_,
                                 'max': max_, 'range_min': range_min, 'range_max': range_max, 'newSetValue': new_SetValue, 'newDefaultValue': new_DefaultValue, 'coding_name': param_coding})

                # SomeIP IDs from someip_config.json
                someip_ids = cls.get_someip_ids_from_json(field_name=field["name"], someip_config=semeip_config_dict)

                cls.all_fields_dict["fields"].append(
                    {"name": field["name"], "coding": coding_dict, "parameterSets": parameters, "size": lengths, "totalSize": None, "SomeIP": someip_ids,
                     "structure": {}})
                if coding_dict:
                    cls.codings_values_dict[coding_dict['name']] = coding_dict['values']

            # add default_values

            # calculate size of every parameterSet (parameters, maps, axes)

            for field in cls.all_fields_dict["fields"]:
                field_size = 0
                for param_sets in field['parameterSets'].keys():
                    t_size = 0
                    for parameter in field['parameterSets'][param_sets]:
                        size = cls.get_param_size(parameter['newSetValue'], parameter['type'])
                        if size == -1:
                            logger.error(f"error when getting size of param {parameter['name']}")
                            t_size = -1
                            break
                        else:
                            t_size += size
                    field['size'][param_sets] = t_size
                    field_size += t_size

                field['totalSize'] = field_size

            # get the full structure of every fields
            # exemple of structures
            # primitive float32-> float32
            # 1-D array of float32 with length 5 -> array_5_float32
            # 2-D array of array with length 3 of float32 with length 5 -> array_3_array_5_float32
            for field in cls.all_fields_dict['fields']:
                for param in field['parameterSets']['parameters']:
                    field['structure'][param['name']] = cls.convert_initValue_to_structure(param['newSetValue'], param['type'])
                for param in field['parameterSets']['maps']:
                    field['structure'][param['name']] = cls.convert_initValue_to_structure(param['newSetValue'], param['type'])
                for param in field['parameterSets']['axes']:
                    field['structure'][param['name']] = cls.convert_initValue_to_structure(param['newSetValue'], param['type'])

        with io.open(path.join(OutputPathManager.get_tests_group_path(), cls.all_fields_file_name), 'w+') as fp:
            json.dump(cls.all_fields_dict, fp, indent=4)


    @classmethod
    def hex_2_primitive(cls, hex_value, primitive_type):
        logger.debug("hex_2_primitive")

        if primitive_type == 'float32':
            return struct.unpack(">f", bytes(hex_value))[0]

        if primitive_type == 'bool':
            return int.from_bytes(hex_value, byteorder='big', signed=False)

        if primitive_type == 'uint8':
            return int.from_bytes(hex_value, byteorder='big', signed=False)

        if primitive_type == 'uint16':
            return int.from_bytes(hex_value, byteorder='big', signed=False)

        if primitive_type == 'uint32':
            return int.from_bytes(hex_value, byteorder='big', signed=False)

        if primitive_type == 'sint8':
            return int.from_bytes(hex_value, byteorder='big', signed=True)

        if primitive_type == 'sint16':
            return int.from_bytes(hex_value, byteorder='big', signed=True)

        if primitive_type == 'sint32':
            return int.from_bytes(hex_value, byteorder='big', signed=True)

        logger.error("wrong type")
        return None

    @classmethod
    def primitive_2_hex(cls, value, primitive_type):
        logger.debug("hex_2_primitive")

        if primitive_type == 'float32':
            return list(struct.pack('>f', value))

        if primitive_type == 'bool':
            return [value]

        if primitive_type == 'uint8':
            return list(struct.pack('>B', value))

        if primitive_type == 'uint16':
            return list(struct.pack('>H', value))

        if primitive_type == 'uint32':
            return list(struct.pack('>I', value))

        if primitive_type == 'sint8':
            return list(struct.pack('>b', value))

        if primitive_type == 'sint16':
            return list(struct.pack('>h', value))

        if primitive_type == 'sint32':
            return list(struct.pack('>i', value))

        logger.error("wrong type")
        return None

    @classmethod
    def get_param_value_from_payload(cls, payload, param_structure):
        logger.debug("get_param_value_from_payload")
        # return value, new offset
        offset = 0
        split_structure = param_structure.split("_")
        if len(split_structure) == 1:
            return cls.hex_2_primitive(payload[:cls.dataTypes_length_dict[param_structure]], param_structure), cls.dataTypes_length_dict[param_structure]
        if len(split_structure) == 3:  # e.g. array_5_bool
            value = []
            for i in range(int(split_structure[1])):  # length of the array
                value.append(cls.hex_2_primitive(payload[offset:offset + cls.dataTypes_length_dict[split_structure[2]]], split_structure[2]))
                offset += cls.dataTypes_length_dict[split_structure[2]]
            return value, offset
        if len(split_structure) == 5:  # e.g. array_3_array_5_bool
            value = []
            for i in range(int(split_structure[1])):  # length of the 1st d array
                sub_value = []
                for j in range(int(split_structure[3])):
                    sub_value.append(cls.hex_2_primitive(payload[offset:offset + cls.dataTypes_length_dict[split_structure[4]]], split_structure[4]))
                    offset += cls.dataTypes_length_dict[split_structure[4]]
                value.append(sub_value)
            return value, offset

    @classmethod
    def parse_field_someip_payload(cls, payload, field_structure):
        logger.debug("parse_field_someip_payload")
        parsed_payload = {}
        total_offset = 0
        for key, structure_value in field_structure.items():
            param_value, offset = cls.get_param_value_from_payload(payload[total_offset:], structure_value)
            parsed_payload[key] = param_value
            total_offset += offset
        return parsed_payload

    @classmethod
    def get_new_default_value(cls, parameter_name, coding_value=None):
        logger.debug("get_new_default_value")
        coding_of_param = cls.get_parameter_property(parameter_name=parameter_name, property_name=cls.parameter_properties.coding_name)

        new_default_value = cls.get_parameter_property(parameter_name=parameter_name, property_name=cls.parameter_properties.newDefaultValue)

        if coding_of_param is None:
            return new_default_value
        if coding_value is None:
            coding_value = int(cls.cafd_initial_values[coding_of_param].value)
        return new_default_value[coding_value]

    @classmethod
    def get_new_set_value(cls, parameter_name, coding_value=None):
        logger.debug("get_new_set_value")
        coding_of_param = cls.get_parameter_property(parameter_name=parameter_name, property_name=cls.parameter_properties.coding_name)

        new_set_value = cls.get_parameter_property(parameter_name=parameter_name, property_name=cls.parameter_properties.newSetValue)

        if coding_of_param is None:
            return new_set_value
        if coding_value is None:
            coding_value = int(cls.cafd_initial_values[coding_of_param].value)
        return new_set_value[coding_value]

    @classmethod
    def generate_paresed_payload_default_values(cls, field_name, coding_value=None):
        logger.debug("generate_paresed_payload_default_values")
        parsed_payload = {}
        try:
            for parameter in cls.get_supported_parameters(field_name=field_name):
                parsed_payload[parameter] = cls.get_parameter_default_value(parameter_name=parameter, coding_value=coding_value)
        except:
            logger.error("error occured in generate_paresed_payload_default_values")
            logger.error(traceback.format_exc())
            return None
        return parsed_payload

    @classmethod
    def generate_paresed_payload_default_values_for_coding_init_for_rest(cls, field_name, coding_value=None, coding_params=None):
        logger.debug("generate_paresed_payload_default_values_for_coding")
        parsed_payload = {}
        if coding_params is None:
            coding_params = []
        try:
            for parameter in cls.get_supported_parameters(field_name=field_name):
                if parameter in coding_params:
                    parsed_payload[parameter] = cls.get_parameter_default_value(parameter_name=parameter, coding_value=coding_value)
                else:
                    parsed_payload[parameter] = cls.get_parameter_property(parameter_name=parameter, property_name=cls.parameter_properties.initValue)
        except:
            logger.error("error occured in generate_paresed_payload_default_values")
            logger.error(traceback.format_exc())
            return None
        return parsed_payload

    @classmethod
    def generate_paresed_payload_initial_values(cls, field_name):
        logger.debug("generate_paresed_payload_initial_values")
        parsed_payload = {}
        try:
            for parameter in cls.get_supported_parameters(field_name=field_name):
                parsed_payload[parameter] = cls.get_parameter_property(parameter_name=parameter, property_name=cls.parameter_properties.initValue)
        except:
            logger.error("error occured in generate_paresed_payload_initial_values")
            logger.error(traceback.format_exc())
            return None
        return parsed_payload

    @classmethod
    def generate_paresed_payload_newDefaultvalues(cls, field_name, coding_value=None):
        logger.debug("generate_paresed_payload_newDefaultvalues")
        parsed_payload = {}

        try:
            for parameter in cls.get_supported_parameters(field_name=field_name):
                param_coding = cls.get_parameter_property(parameter_name=parameter, property_name=cls.parameter_properties.coding_name)
                if param_coding:
                    if coding_value is None:
                        coding_value = int(cls.cafd_initial_values[param_coding].value)
                    parsed_payload[parameter] = cls.get_parameter_property(parameter_name=parameter, property_name=cls.parameter_properties.newDefaultValue)[coding_value]
                else:
                    parsed_payload[parameter] = cls.get_parameter_property(parameter_name=parameter, property_name=cls.parameter_properties.newDefaultValue)
        except:
            logger.error("error occured in generate_paresed_payload_newDefaultvalues")
            logger.error(traceback.format_exc())
            return None
        return parsed_payload

    @classmethod
    def generate_paresed_payload_newSetValues(cls, field_name, coding_value=None):
        logger.debug("generate_paresed_payload_newSetValues")
        parsed_payload = {}

        try:
            for parameter in cls.get_supported_parameters(field_name=field_name):
                param_coding = cls.get_parameter_property(parameter_name=parameter, property_name=cls.parameter_properties.coding_name)
                if param_coding:
                    if coding_value is None:
                        coding_value = int(cls.cafd_initial_values[param_coding].value)
                    parsed_payload[parameter] = cls.get_parameter_property(parameter_name=parameter, property_name=cls.parameter_properties.newSetValue)[int(coding_value)]
                else:
                    parsed_payload[parameter] = cls.get_parameter_property(parameter_name=parameter, property_name=cls.parameter_properties.newSetValue)
        except:
            logger.error("error occured in generate_paresed_payload_newSetValues")
            logger.error(traceback.format_exc())
            return None
        return parsed_payload

    # def generate_paresed_payload_newSetValues(cls, field_name):
    #     logger.debug("generate_paresed_payload_newDefaultvalues")
    #     parsed_payload = {}
    #     try:
    #         for parameter in cls.get_supported_parameters(field_name=field_name):
    #             parsed_payload[parameter] = cls.get_parameter_property(parameter_name=parameter, property_name=cls.parameter_properties.newSetValue)
    #     except:
    #         logger.error("error occured in generate_paresed_payload_initial_values")
    #         logger.error(traceback.format_exc())
    #         return None
    #     return parsed_payload

    class setting_mode(Enum):
        initValue = "initValue"
        defaultValue = "defaultValue"
        newSetValue = "newSetValue"
        customValue = "customValue"

    @classmethod
    def get_coding_name_for_parameter(cls, parameter_name):
        logger.debug("get_coding_name_for_parameter")
        field_name = cls.get_field_of_parameter(parameter_name=parameter_name)
        if field_name:
            coding_dict = cls.get_field_property(field_name=field_name, property_name=cls.field_properties.coding)
            if coding_dict:
                if parameter_name in coding_dict['params']:
                    return coding_dict['name']
        else:
            logger.error(f"Could not find the field name of the paramter {parameter_name}")
        return None

    @classmethod
    def get_coding_name_for_field(cls, field_name):
        logger.debug("get_coding_name_for_field")

        coding_dict = cls.get_field_property(field_name=field_name, property_name=cls.field_properties.coding)
        if coding_dict:
            return coding_dict['name']

        return None

    @classmethod
    def set_parameter_in_parsed_payload(cls, parsed_payload, parameter_name, setting_mode, value=None, coding_value=None):
        logger.debug("set_parameter_in_parsed_payload")
        parsed_payload_new = parsed_payload
        coding_name = cls.get_coding_name_for_parameter(parameter_name=parameter_name)
        if coding_value is None:
            if coding_name:
                coding_value = cls.cafd_initial_values[coding_name].value
        default_value = cls.get_parameter_default_value(parameter_name=parameter_name, coding_value=coding_value)
        initValue = cls.get_parameter_property(parameter_name=parameter_name, property_name=cls.parameter_properties.initValue)
        if default_value is None:
            default_value = initValue
        if setting_mode.value == "initValue":
            parsed_payload_new[parameter_name] = initValue
        elif setting_mode.value == "defaultValue":
            parsed_payload_new[parameter_name] = default_value
        elif setting_mode.value == "newSetValue":
            newSetValue = cls.get_parameter_property(parameter_name=parameter_name, property_name=cls.parameter_properties.newSetValue)
            if coding_name is not None:
                newSetValue = newSetValue[int(coding_value)]
            parsed_payload_new[parameter_name] = newSetValue
        elif setting_mode.value == "customValue":
            if value is None:
                logger.error("argument 'value' is None")
                return parsed_payload_new
            parsed_payload_new[parameter_name] = value
        else:
            logger.error("argument 'setting_mode' is invalid")
        logger.debug(f"parameter {parameter_name} set to {parsed_payload_new[parameter_name]}")
        return parsed_payload_new

    # @classmethod
    # def set_all_parameters_in_parsed_payload(cls, parsed_payload, field_name, coding_value=None):
    #     logger.debug("set_all_parameters_in_parsed_payload")
    #     parsed_payload_modified = parsed_payload.copy()
    #     for parameter in cls.get_supported_parameters(field_name):
    #         parsed_payload_modified = cls.set_parameter_in_parsed_payload(parsed_payload=parsed_payload_modified, parameter_name=parameter,
    #                                                                       setting_mode=cls.setting_mode.newSetValue, coding_value=coding_value)
    #     return parsed_payload_modified
    #
    # @classmethod
    # def create_payload_with_new_parameter_values(cls, parsed_payload, field_name, coding_value=None):
    #     logger.debug("create_payload_with_new_parameter_values")
    #     parsed_payload = cls.set_all_parameters_in_parsed_payload(parsed_payload=parsed_payload, field_name=field_name, coding_value=coding_value)
    #     structure = cls.get_field_property(field_name=field_name, property_name=cls.field_properties.structure)
    #     return cls.parsed_payload_to_hex_list(parsed_payload=parsed_payload, structure=structure)

    @classmethod
    def parsed_payload_to_hex_list(cls, parsed_payload, structure):
        logger.debug("parsed_payload_to_hex_list")
        hex_list = []
        try:
            for key in parsed_payload.keys():
                if len(structure[key].split("_")) == 5:
                    for item in parsed_payload[key]:
                        for sub_item in item:
                            hex_list.extend(cls.primitive_2_hex(sub_item, structure[key].split("_")[-1]))
                elif len(structure[key].split("_")) == 3:
                    for item in parsed_payload[key]:
                        hex_list.extend(cls.primitive_2_hex(item, structure[key].split("_")[-1]))
                elif len(structure[key].split("_")) == 1:
                    hex_list.extend(cls.primitive_2_hex(parsed_payload[key], structure[key]))
                else:
                    logger.error("wrong structure")

            return hex_list

        except:
            logger.error("error occured in parsed_payload_to_hex_list")
            logger.error(traceback.format_exc())
            return None

    @classmethod
    def edit_parameter_in_default_values_json_file(cls, parameter_name, coding_value=None, all_coding=False, edit=False):
        logger.debug("remove_parameter_from_default_values_json_file")
        # if edit=False -> parameter will be removed else paramter will be changed with new_Defalut_value generated in the startup phase
        # if all_coding=False -> only parameter for the given coding_value will be modified. if True parameter for all coding values will be modified
        try:
            default_values_dict = {}
            cls.ssh_manager.downloadFileFromTarget(source_file=cls.defaut_values_file_name, source_path=cls.param_server_etc_path,
                                                   destination_path=OutputPathManager.get_test_case_path())
            with io.open(path.join(OutputPathManager.get_test_case_path(), cls.defaut_values_file_name)) as dfv:
                default_values_dict = json.load(dfv)
            print(datetime)
            rename(path.join(OutputPathManager.get_test_case_path(), cls.defaut_values_file_name),
                   path.join(OutputPathManager.get_test_case_path(), f"default_values_before_changes_{datetime.datetime.now().strftime('%d%m%Y_%H%M%S')}.json"))

            modified_dict = {"parameters": []}
            coding_name = cls.get_parameter_property(parameter_name=parameter_name, property_name=cls.parameter_properties.coding_name)
            if coding_value is None:
                if coding_name:
                    coding_value = cls.cafd_initial_values[coding_name].value

            parameters_to_be_edit = []
            if coding_name:
                if all_coding:
                    for value in cls.codings_values_dict[coding_name]:
                        parameters_to_be_edit.append(f"{coding_name}_{value}_{parameter_name}")

                else:
                    parameters_to_be_edit.append(f"{coding_name}_{coding_value}_{parameter_name}")
            else:
                parameters_to_be_edit = [parameter_name]

            logger.debug(f"List of edited/removed parameter\n{parameters_to_be_edit}")

            for param in default_values_dict["parameters"]:
                if param["name"] not in parameters_to_be_edit:
                    modified_dict["parameters"].append(param)
                else:
                    if edit:
                        edited_param = {}
                        edited_param["name"] = param["name"]
                        if coding_name:
                            edited_param['initValue'] = cls.get_parameter_property(
                                parameter_name=param["name"].replace(f"{coding_name}_{coding_value}_", ""),
                                property_name=cls.parameter_properties.newDefaultValue)[int(coding_value)]
                        else:
                            edited_param['initValue'] = cls.get_parameter_property(parameter_name=param["name"], property_name=cls.parameter_properties.newDefaultValue)
                        logger.debug(f" +++++++++++++ {edited_param}")
                        modified_dict["parameters"].append(edited_param)
            # test if it works!!!!!!!!
            with io.open(path.join(OutputPathManager.get_test_case_path(), cls.defaut_values_file_name), 'w+') as fp:
                json.dump(modified_dict, fp, indent=4)
            is_uploaded = cls.ssh_manager.uploadFileToTarget(source_path=OutputPathManager.get_test_case_path(),
                                                             source_file=cls.defaut_values_file_name,
                                                             destination_path=cls.param_server_etc_path)


            result = cls.ssh_manager.executeCommandInTarget(command=f"chmod 644 {cls.param_server_etc_path}/{cls.defaut_values_file_name}", ip_address=cls.PP_IP)
            if len(result['stderr']) > 0:
                logger.error(f"Could not add read access to {cls.param_server_etc_path}/{cls.defaut_values_file_name}")

            rename(path.join(OutputPathManager.get_test_case_path(), cls.defaut_values_file_name),
                   path.join(OutputPathManager.get_test_case_path(), f"default_values_local_changes_{datetime.datetime.now().strftime('%d%m%Y_%H%M%S')}.json"))

            cls.ssh_manager.downloadFileFromTarget(source_file=cls.defaut_values_file_name, source_path=cls.param_server_etc_path,
                                                   destination_path=OutputPathManager.get_test_case_path())

            rename(path.join(OutputPathManager.get_test_case_path(), cls.defaut_values_file_name),
                   path.join(OutputPathManager.get_test_case_path(),
                             f"default_values_downloaded_after_changes_{datetime.datetime.now().strftime('%d%m%Y_%H%M%S')}.json"))

            return parameters_to_be_edit
        except:
            logger.error(f"Error while modifing default_values.json")
            logger.error(traceback.format_exc())
            return None

    @classmethod
    def edit_all_parameter_in_field_in_default_values_json_file(cls, field_name, coding_name=None, coding_value=None, all_coding=False, edit=False):
        logger.debug("remove_parameter_from_default_values_json_file")
        # if edit=False -> parameter will be removed else paramter will be changed with new_Defalut_value generated in the startup phase
        # if all_coding=False -> only parameter for the given coding_value will be modified. if True parameter for all coding values will be modified
        try:
            default_values_dict = {}
            cls.ssh_manager.downloadFileFromTarget(source_file=cls.defaut_values_file_name, source_path=cls.param_server_etc_path,
                                                   destination_path=OutputPathManager.get_test_case_path())
            with io.open(path.join(OutputPathManager.get_test_case_path(), cls.defaut_values_file_name)) as dfv:
                default_values_dict = json.load(dfv)
            print(datetime)
            rename(path.join(OutputPathManager.get_test_case_path(), cls.defaut_values_file_name),
                   path.join(OutputPathManager.get_test_case_path(), f"default_values_before_changes_{datetime.datetime.now().strftime('%d%m%Y_%H%M%S')}.json"))

            modified_dict = {"parameters": []}
            coding_dict = None
            if coding_name is None:
                coding_dict = cls.get_field_property(field_name=field_name, property_name=cls.field_properties.coding)
                if coding_dict:
                    coding_name = coding_dict['name']
            if coding_value is None:
                if coding_name:
                    coding_value = cls.cafd_initial_values[coding_name].value
            # codings_values_dict
            parameters_to_be_edit = []
            parameters_in_field = cls.get_supported_parameters(field_name=field_name)
            logger.debug(f"##S P {parameters_in_field}")
            for parameter in parameters_in_field:
                if coding_name and parameter in coding_dict['params']:
                    if all_coding:
                        for value in cls.codings_values_dict[coding_name]:
                            parameters_to_be_edit.append(f"{coding_name}_{value}_{parameter}")
                    else:
                        parameters_to_be_edit.append(f"{coding_name}_{coding_value}_{parameter}")
                else:
                    parameters_to_be_edit.append(parameter)

            logger.debug(f"List of edited/removed parameter\n{parameters_to_be_edit}")

            for param in default_values_dict["parameters"]:
                if param["name"] not in parameters_to_be_edit:
                    modified_dict["parameters"].append(param)
                else:
                    if edit:
                        if coding_dict is not None:
                            param_coding = cls.get_parameter_property(parameter_name=param["name"].replace(f"{coding_dict['name']}_{coding_value}_", ""),
                                                                      property_name=cls.parameter_properties.coding_name)
                        else:
                            param_coding = cls.get_parameter_property(parameter_name=param["name"], property_name=cls.parameter_properties.coding_name)
                        logger.debug(f"param coding {param_coding}")
                        edited_param = {}
                        edited_param["name"] = param["name"]
                        if param_coding:
                            edited_param['initValue'] = cls.get_parameter_property(
                                parameter_name=param["name"].replace(f"{coding_dict['name']}_{coding_value}_", ""),
                                property_name=cls.parameter_properties.newDefaultValue)[int(coding_value)]
                        else:
                            edited_param['initValue'] = cls.get_parameter_property(parameter_name=param["name"], property_name=cls.parameter_properties.newDefaultValue)
                        modified_dict["parameters"].append(edited_param)

            with io.open(path.join(OutputPathManager.get_test_case_path(), cls.defaut_values_file_name), 'w+') as fp:
                json.dump(modified_dict, fp, indent=4)
            is_uploaded = cls.ssh_manager.uploadFileToTarget(source_path=OutputPathManager.get_test_case_path(),
                                                             source_file=cls.defaut_values_file_name,
                                                             destination_path=cls.param_server_etc_path)


            result = cls.ssh_manager.executeCommandInTarget(command=f"chmod 644 {cls.param_server_etc_path}/{cls.defaut_values_file_name}", ip_address=cls.PP_IP)
            if len(result['stderr']) > 0:
                logger.error(f"Could not add read access to {cls.param_server_etc_path}/{cls.defaut_values_file_name}")

            rename(path.join(OutputPathManager.get_test_case_path(), cls.defaut_values_file_name),
                   path.join(OutputPathManager.get_test_case_path(), f"default_values_local_changes_{datetime.datetime.now().strftime('%d%m%Y_%H%M%S')}.json"))

            cls.ssh_manager.downloadFileFromTarget(source_file=cls.defaut_values_file_name, source_path=cls.param_server_etc_path,
                                                   destination_path=OutputPathManager.get_test_case_path())

            rename(path.join(OutputPathManager.get_test_case_path(), cls.defaut_values_file_name),
                   path.join(OutputPathManager.get_test_case_path(),
                             f"default_values_downloaded_after_changes_{datetime.datetime.now().strftime('%d%m%Y_%H%M%S')}.json"))

            return parameters_to_be_edit
        except:
            logger.error(f"Error while modifing default_values.json")
            logger.error(traceback.format_exc())
            return None

    @classmethod
    def compare_2_dicts(cls, dict_1, dict_2):
        logger.debug("compare_2_dicts")
        logger.info(f"dict_1 :\n{json.dumps(dict_1, indent=4)}")
        logger.info(f"dict_2 :\n{json.dumps(dict_2, indent=4)}")
        result = True
        if len(dict_1.keys()) != len(dict_2.keys()):
            logger.error(f"length of dict_1 = {len(dict_1.keys())} is different to length of dict_2 = {len(dict_2.keys())}")
            result = False
        for key in dict_1.keys():
            if key not in dict_2.keys():
                logger.error(f"parameter {key} does not exist in dict_2")
                result = False
            else:
                if dict_1[key] == dict_2[key]:
                    logger.info(f"check passed for param {key}")
                else:
                    logger.error(f"check failed for param {key}\ndict_1[{key}]={dict_1[key]}\ndict_2[{key}]={dict_2[key]}")
                    result = False
        return result

    @classmethod
    def get_list_all_parameters(cls):
        logger.debug("get_list_all_parameters")
        default_parameters = []
        for field in cls.all_fields_dict['fields']:
            coding_name = None
            coding_values = []
            coding_params = []
            if field['coding'] is not None:
                coding_name = field['coding']['name']
                coding_values = field['coding']['values']
                coding_params = field['coding']['params']
            params_from_dict = cls.get_supported_parameters(field_name=field['name'])
            for param in params_from_dict:
                if param in coding_params:
                    for value in coding_values:
                        default_parameters.append(f"{coding_name}_{value}_{param}")
                else:
                    default_parameters.append(param)

        with io.open(path.join(OutputPathManager.get_test_case_path(), 'all_default_parameters.json'), 'w+') as fp:
            json.dump(default_parameters, fp, indent=4)

        return default_parameters

    @classmethod
    def check_all_param_names_in_config_file_are_valid(cls):
        logger.debug("check_all_param_names_in_config_file_are_valid")
        result = True
        default_parameters = cls.get_list_all_parameters()

        with io.open(path.join(OutputPathManager.get_tests_group_path(), cls.default_values_backup)) as dv:
            default_values_dict = json.load(dv)

        for default_param in default_values_dict['parameters']:
            if default_param['name'] in default_parameters:
                logger.debug(f"{default_param['name']} is valid")
            else:
                result = False
                logger.error(f"{default_param['name']} is not valid")

        return result

    @classmethod
    def check__default_values_file_is_valid(cls):
        logger.debug("check__default_values_file_is_valid")

        with io.open(path.join(OutputPathManager.get_tests_group_path(), cls.default_values_backup)) as dv:
            default_values_dict = json.load(dv)
        try:
            for default_param in default_values_dict['parameters']:
                name = default_param['name']
                value = default_param['initValue']
        except:
            logger.error(f"Error while getting name or value of parameter from default_values.json")
            logger.error(traceback.format_exc())
            return False

        return True
