from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_domain_reporting_01_DOMM_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_domain_reporting_01_DOMM_LINUX"
    REQ_ID = ["/item/5866377"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports the RSS per domain"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get list of domains")
        self.domain_list = self.get_domain_list()
        self.domain_list.append("other")
        self.assertTrue(self.domain_list is not None, Severity.BLOCKER, "Check that domain_list is not None")
        self.assertTrue(len(self.domain_list) > 0, Severity.BLOCKER, "Check that domain_list is not empty")

        self.time_interval = self.get_time_interval(contextID=self.domain_reporting_memory_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        self.search_msg_array = self.statistic_data["Domain"]["memory"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")

        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.domain_reporting_memory_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_domain_reporting_01_DOMM_LINUX(self):
        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get DOMC DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(contextId=self.domain_reporting_memory_context_id, searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that DOMC DLT Domain1 messages are available")

        reported_domains, reported_usages = self.get_reported_domains(messages=messages, reported_caracteristic="memory")

        self.domain_list.sort()
        reported_domains.sort()

        logger.info(f"expected domain list\n{self.domain_list}")
        logger.info(f"reported domain list\n{reported_domains}")

        self.expectTrue(self.domain_list == reported_domains, Severity.MAJOR, "Check that all domains are reported")
        self.expectTrue(all(usage != self.INVALID_VALUE for usage in reported_usages), Severity.MAJOR, "Check that usage was reported in all messages")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
