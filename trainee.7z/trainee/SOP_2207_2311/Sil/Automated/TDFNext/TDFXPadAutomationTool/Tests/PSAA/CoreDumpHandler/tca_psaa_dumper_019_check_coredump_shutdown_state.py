from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_019_check_coredump_shutdown_state(testfixture_PSAA_CoreDumpHandler):
    TEST_ID = "PSAA\tca_psaa_dumper_019_check_coredump_shutdown_state"
    REQ_ID = ["/item/1423077"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps not created on shutdown"
    STATUS = "Ready"
    OS = ['LINUX']


    def setUp(self):
        self.setPrecondition("Change exec_config.json")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"sed -i 's/Running/Shutdown/1' /opt/Fasinfo/etc/exec_config.json",
                                                              timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                              ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Check exec_config.json is changed succesfully")
        self.setPrecondition("Create backup of binary")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"cp /opt/Fasinfo/bin/Fasinfo /opt/Fasinfo/bin/Fasinfo_backup",
                                                              timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                              ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Check backup created succesfully")


        returnValue = self.ssh_manager.executeCommandInTarget(command=f"rm /opt/Fasinfo/bin/Fasinfo ", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Check Fasinfo removed succesfully")

        self.setPrecondition("Change bin of adaptive app with binary of non adaptive app")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"cp /opt/datarouter/bin/datarouter /opt/Fasinfo/bin/Fasinfo && sleep 1",
                                                              timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                              ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Check bin changed succesfully")

        self.setPrecondition("Delete old coredumps")
        removeCoredump = self.ssh_manager.executeCommandInTarget(
            command=f'rm {self.CoreDumps_Path}/*',
            timeout=self.SSH_CONNECTION_TIMEOUT_MS,
            ip_address=self.PP_IP)
        self.expectTrue(removeCoredump["exec_recv"] == 0, Severity.MAJOR,
                        "Checking that the old coredumps were deleted")
        self.setPrecondition("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}",
                                                              timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                              ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that 'ls | grep' command executed succesfully")
        dumps_list = returnValue["stdout"].splitlines()
        if "currentswversion" in dumps_list:
            self.expectTrue(len(dumps_list) == 1, Severity.BLOCKER,
                            "Checking that coredumps files not exist.")
        else:
            self.expectTrue(len(dumps_list) == 0, Severity.BLOCKER,
                            "Checking that coredumps files not exist.")

    def test_tca_psaa_dumper_019_check_coredump_shutdown_state(self):
        self.diag_manager.start()
        self.startTestStep("Reset ECU")
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_MS)
        self.diag_manager.wait_for_ecu_respawn(target=self.PP_DIAG_ADR, reset_max_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}",
                                                              timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                              ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that 'ls | grep' command executed succesfully")
        dumps_list = returnValue["stdout"].splitlines()
        logger.info("Number of core dumps" + str(len(dumps_list)))
        if "currentswversion" in dumps_list:
            self.expectTrue(len(dumps_list) == 1, Severity.BLOCKER,
                        "Checking that coredumps files not exist.")
        else:
            self.expectTrue(len(dumps_list) == 0, Severity.BLOCKER,
                            "Checking that coredumps files not exist.")

    def tearDown(self):
        self.setPostcondition("Revert changes")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"sed -i 's/Shutdown/Running/1' /opt/Fasinfo/etc/exec_config.json",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS,
            ip_address=self.PP_IP)
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Check exec_config.json is changed succesfully")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"cd /opt/Fasinfo/bin/ && ls | grep Fasinfo_backup",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS,
            ip_address=self.PP_IP)
        self.expectTrue("Fasinfo_backup" in returnValue["stdout"], Severity.BLOCKER,
                        "Check backup created succesfully")
        if "Fasinfo_backup" in returnValue["stdout"]:
            returnValue = self.ssh_manager.executeCommandInTarget(
                command=f"rm /opt/Fasinfo/bin/Fasinfo",
                timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                ip_address=self.PP_IP)
            self.expectTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                            "Check backup created succesfully")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"mv /opt/Fasinfo/bin/Fasinfo_backup /opt/Fasinfo/bin/Fasinfo && sleep 1",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS,
            ip_address=self.PP_IP)
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Check bin changed succesfully")
