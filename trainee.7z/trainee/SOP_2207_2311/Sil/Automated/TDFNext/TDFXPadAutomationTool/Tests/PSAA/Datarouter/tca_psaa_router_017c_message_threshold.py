from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter_ProxyApp import *


class tca_psaa_router_017c_message_threshold(testfixture_PSAA_Datarouter_ProxyApp):
    TEST_ID = "PSAA\tca_psaa_router_017c"

    REQ_ID = ["/item/1573751", "/item/1573764", "/item/1633236", "/item/1633238","/item/145159"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX','QNX']

    threshold = {
        "DFLT": "kInfo"
    }
    prxa_threshold = {
        "DFLT": "kWarn"
    }



    def setUp(self):
        self.setPrecondition("Get messageThresholds from log-channels.json file")
        origin_defaultThreshold = self.json_manager.getInfoFromJsonFile(filePath=self.log_channels_file_path+self.log_channels_file, valuePath="messageThresholds")
        origin_defaultThreshold[""] = self.threshold
        self.setPrecondition("Set messageThresholds in log-channels.json file")
        exitCode = self.json_manager.setInfoToJsonFile(filePath=self.log_channels_file_path+self.log_channels_file, valuePath="messageThresholds.PRXA", value=self.prxa_threshold)
        self.setPrecondition("Set the log manifest")
        exitCode, json_is_changed, message = self.proxy_app_settings.set_logging_manifest(logLevel=self.Log_levels["verbose"], logMode=self.Log_modes["remote"])
        self.assertTrue(exitCode, Severity.BLOCKER, "Check the log manifest is set")
        self.dlt_manager.clear_all_dlt_messages()
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECU_status = self.check_ECUs()
        self.expectTrue(ECU_status, Severity.BLOCKER, "Checking that ECU status is OK")

        exitCode, message = self.proxy_app_settings.check_logging_manifest(logLevel=self.Log_levels["verbose"], logMode=self.Log_modes["remote"])
        self.assertTrue(exitCode, Severity.BLOCKER, "Check the log manifest is set")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.ARA_LOG.value)

        self.dlt_manager.apply_filter(appId=self.PROXY_APP_APP_ID)
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_datarouter_message_threshold(self):
        self.startTestStep("Append log messages with log level info")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.APPEND_LOG, argType=araLogType.LOG_ARGS_TYPE_STRING, argVal=self.set_argVal_kInfo_017c + self.set_contextId_DFLT)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the append of the message")
        self.startTestStep("Log the message")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.LOG_INFO, contextId=None)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the log of the message")
        self.startTestStep("Append log messages with log level warn")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.APPEND_LOG, argType=araLogType.LOG_ARGS_TYPE_STRING, argVal=self.set_argVal_kWarn_017c + self.set_contextId_DFLT)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the append of the message")
        self.startTestStep("Log the message")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.LOG_WARN, contextId=None)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER, "Check the log of the message")

        self.startTestStep("wait for Logging")
        self.sleep_for(self.wait_for_dlt_log)

        self.startTestStep("Get DLT message related to log level info")
        messages_count, messages_array = self.dlt_manager.wait_for_message(ecuId=self.PP_ECUID, contextId=self.set_contextId_DFLT, search_message=self.set_argVal_kInfo_017c + self.set_contextId_DFLT, timeout=10)
        self.expectTrue(messages_count == 0, Severity.BLOCKER, "Check messages are not logged")
        logger.info("Messages Count = " + str(messages_count))
        self.startTestStep("Get DLT message related to log level warn")
        messages_count, messages_array = self.dlt_manager.wait_for_message(ecuId=self.PP_ECUID, contextId=self.set_contextId_DFLT, search_message=self.set_argVal_kWarn_017c + self.set_contextId_DFLT, timeout=30)

        for message in messages_array:
            self.assertTrue(message.get("extendedHeader").get("MessageTypeInfo") == dltLogLevel.DLT_LOG_WARN.value, Severity.BLOCKER, "Checking the MessageTypeInfo")
            logger.info("Current MessageTypeInfo = " + str(message.get("extendedHeader").get("MessageTypeInfo")))

    def tearDown(self):
        pass
