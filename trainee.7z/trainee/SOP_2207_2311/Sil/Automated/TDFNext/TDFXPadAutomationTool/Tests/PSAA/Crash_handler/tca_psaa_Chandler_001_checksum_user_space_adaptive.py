from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_001_checksum_user_space_adaptive(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_001_checksum_user_space_adaptive"
    REQ_ID = ["/item/2593168"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps of adaptive app are created properly and checksum file contains coredumps files names and check coredumps format"
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    def setUp(self):
        pass

    def test_tca_psaa_Chandler_001_checksum_user_space_adaptive(self):
        self.startTestStep("Get pid of the application to be killed")
        ETS_pid = self.get_process_id(app_name=self.ETS_APP_NAME)
        self.assertTrue(ETS_pid != -1, Severity.MAJOR, "Check the application is running")
        self.startTestStep("Kill application ETS")
        application_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(application_is_killed, Severity.BLOCKER, f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.startTestStep("Check application ETS is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER, f"Checking that the {self.ETS_APP_NAME} is not running")
        self.startTestStep("Get coredumps files names")
        self.assertTrue(self.check_coredumps(app_name=self.ETS_APP_NAME), Severity.BLOCKER, f"Checking that coredumps files were created properly and coredumps format is right")
        self.startTestStep("check ETS exist in checksum file")
        self.assertTrue(self.checksum_file_check(app_name=self.ETS_APP_NAME), Severity.BLOCKER, f"Checking that coredump files are listed correctly in checksum")

    def tearDown(self):
        pass
