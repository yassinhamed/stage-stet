from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_002_coredump_format(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_002_coredump_format"
    REQ_ID = ["/item/1736864","/item/1736931"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps format"
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        pass

    def test_psaa_dumper_002_coredump_format(self):
        self.startTestStep("Kill application ETS")
        ets_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(ets_is_killed, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

        self.startTestStep("Check application ETS is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is not running")

        self.startTestStep("check coredumps created")
        coredumps_created = self.check_coredumps(self.ETS_APP_NAME)
        self.assertTrue(coredumps_created,Severity.BLOCKER,"Checking that coredumps files were created properly.")

        self.startTestStep("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Checking that 'ls' command executed successfully")
        dumps_list = returnValue["stdout"].splitlines()
        self.startTestStep("check coredumps format")
        self.check_core_dumps_names(dumps_list)

    def tearDown(self):
        pass
