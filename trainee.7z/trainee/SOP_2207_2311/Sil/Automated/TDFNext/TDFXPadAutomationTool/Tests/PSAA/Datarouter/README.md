# Datarouter
Datarouter is the application implementing, as its name suggests, routing of data chunks from sources to subscribers.
Additionally datarouter implements some logging functionalities internally. This includes DLT daemon role.

**Sources**

A source is an application that is sending messages to datarouter. Sources use the library libtracing to send the messages. ara::log is implemented on top of libtracing, so every application using ara::log implicitely is a source. Sources connect using a UNIX domain socket to datarouter, put their messages into a ring buffer, signaling over a UNIX domain socket the status towards datarouter. Datarouter uses the UNIX domain socket to lock parts of the buffer at the source side.

**Subscribers**

A subscriber application is a consumer of data. Subscribers use datarouter_subscription library to request certain datatypes from datarouter. Communication happens over the same mechanism as for the sources: datarouter forwards data items into a ring buffer for the subscriber. Connection and synchronized access to the ring buffer are performed over a UNIX domain socket. The ring buffers are initially mapped at the datarouter side.

**Configuration**

Logging should be configured to match application needs. Configuration is done statically during application deployment. It should be deployed to /opt/$APP_NAME/etc/logging.json.

The following logging config items are responsible for performance of the logging (example for datarouter):

- "appId" -- 4-symbol identifier for the application
- "appDesc" -- description, not very important
- "logFilePath" -- if logMode includes kFile, this is the directory, where the logfile appId.dlt will be put
- "logLevel" -- global log level threshold for the application
- "logLevelThresholdConsole" -- if logMode includes kConsole, console message will be filtered by this log level (global one has priority, however)
- "logMode" -- an arbitrary combination of kFile, kConsole, kRemote; or kOff -- if logging should not be used
- "contextConfigs" -- a list of individual configs for logging contexts
- "stackBufferSize" -- size of the linear buffer used for storing metadata. If your application sends a lot of different datatypes, you might consider increasing this limit
- "ringBufferSize" -- size of ringbuffer for data sent to datarouter. All verbose and non-verbose DLT messages along with CDC land in the ringbuffer, so please consider increasing this one if you lose messages
- "overwriteOnFull" -- defines the ringbuffer write strategy, default (=true) is to overwrite when the buffer is full; alternatively (=false) the messages would just be dropped, the oldest unread messages are left intact (useful to identify the scenarios of ringbuffer overflow, for example)

```logLevel``` values, severity decreasing, are exclusive, you can use only one:

logLevel | Severity
---------|---------
kOff | No logging
kFatal | Fatal error, not recoverable
kError | Error with impact to correct functionality
kWarn | Warning if correct behavior cannot be ensured
kInfo | Informational, providing high level understanding
kDebug | Detailed information for programmers
kVerbose | Extra-verbose debug messages (highest detail of information) 

```logMode```'s are combined with or (```|```) operator, e.g., ```kRemote|kConsole```, the effect is that both are used

logMode | logSplained
---------|---------
kRemote | Sent remotely to DLT daemon, and further via DLT protocol out 
kFile | Save to file in a directory set via __logfilePath__
kConsole | Forward to console

The goals of the logging system are the following:

- capture the information from the applications via well-defined interfaces
- send logs via DLT protocol to be captured by logger
- distribute data messages and logs to subscription clients like CDC and EDR
- provide a suitable replacement for XCP protocol that is missing on the Adaptive AUTOSAR platform

DLT protocol defines two types of messages:

- **Verbose log messages** contain more information, and are completely self-contained. Their payload is formatted as "arguments", each of which is prepended by type specifier. They typically are used to transmit development log information.
- **Non-verbose log messages** are more compact, and are oriented on an "educated receiver". The structure of a particular message type is always the same, but message metadata is not present on the wire. This means that to decode such messages, a message catalogue is needed. AUTOSAR proposes to use FIBEX file format as such a message catalogue. Using a FIBEX file a DLT client is able to decode the message and display its fields in deserialized manner.

**Different log channels**

DLT protocol provides a possibility to define different log channels. These channels are different in our implementation in that they use different source port, so effectively datarouter splits the DLT datastream between a number of receiving channels, based on the configuration.

**log-channels.json**

This file contains the configuration of log channels. Some ECUs are required to have more than one channel for DLT logs, some have only one.
The file has multiple sections.

- **channels** specifies log channels: with their IDs (4-byte), UDP source port, reported ECU ID
- **channelAssignments**: based on AppID and CtxID the packets can be assigned to certain log channel
- **messageThresholds**: specifies filter thresholds based on AppId and CtxId
- **defaultChannel**: if no channelAssignment has been matched, this channel is used
- **defaultThresold**: if no messageThreshold matched, this threshold is used to filter the messages

**datarouterconf and datarouter-nonadaptive**

Datarouter has been split into two applications. The reason is that datarouter needs to implement diagnostic jobs. This means runtime dependency to someipd. To be able to receive logs from applications during startup, we need to start the main daemon as a nonadaptive application.

- datarouterconf is an adaptive application, implementing diagnostics and passing the configuration to datarouter
- datarouter-nonadaptive is a platform application, not implementing EM state client, and should be started as early as possible (after network is available).
- 