from Tests.PSAA.DatarouterConf.testfixture_PSAA_DatarouterConf_ProxyApp import *


class tca_psaa_drconf_diag_006a_set_fitlering_off(testfixture_PSAA_DatarouterConf_ProxyApp):

    TEST_ID = "PSAA\tca_psaa_dr_diag_006a"
    REQ_ID = ["/item/853028", "/item/1633236", "/item/1633238"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Set message filtering state to off and check dlt message is sent"
    STATUS = "READY"
    OS = ['LINUX','QNX']


    def setUp(self):
        grep_DConf = self.check_application_is_started(app_name=self.DATA_ROUTER_CONF_APP_NAME)
        self.expectTrue(grep_DConf, Severity.MAJOR, "Check The application was started")

        exitCode, json_is_changed, message = self.proxy_app_settings.set_logging_manifest(logLevel=self.Log_levels["verbose"], logMode=self.Log_modes["remote"])
        self.assertTrue(exitCode, Severity.BLOCKER, message)

        self.reset_ecu_if_json_changed(json_is_changed=json_is_changed)

        self.diag_manager.start()
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.ARA_LOG.value)

        self.dlt_manager.apply_filter(appId=self.PROXY_APP_APP_ID)
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.start_monitoring("SRR-DLT")

        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.CREATE_LOGGER, contextId=self.set_contextId,
                                                        ctxDescription="Log Description")
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER,
                        "Check the creation of logger. ExitCode: " + araLogExitCode(
                            exitCode).name if exitCode is not None else "No ExitCode is returned")

        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.APPEND_LOG, argType=araLogType.LOG_ARGS_TYPE_STRING,
                                                        argVal=self.set_argVal)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER,
                        "Check the append of the message. ExitCode: " + araLogExitCode(
                            exitCode).name if exitCode is not None else "No ExitCode is returned")

        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(self.set_logOperation_3, contextId=self.set_contextId)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER,
                        "Check the log of the message. ExitCode: " + araLogExitCode(
                            exitCode).name if exitCode is not None else "No ExitCode is returned")

        self.sleep_for(self.wait_for_dlt_message_to_be_sent)

        dlt_check = self.dlt_manager.message_exist(ecuId=self.PP_ECUID,
                                                   contextId=self.set_contextId,
                                                   appId=self.PROXY_APP_APP_ID,
                                                   searchMsg=self.set_argVal)
        self.assertTrue(dlt_check, Severity.BLOCKER, "Check the Message logged")

        self.dlt_manager.stop_monitoring()

        res = self.diag_manager.syn_send(0xF4, self.PP_DIAG_ADR,
                                         self.STEUERN_DLT_SET_LOGLEVEL_PRXA_CTX1_AUS)

        res_diag = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        logger.debug("Diag Job response -> returned payload: {}".format(
            self.diag_manager.payload_to_str(res_diag.get_payload())))

        self.expectTrue(res != DiagResult.send_failure, Severity.BLOCKER, "Check the diagnostic job payload was sent")
        self.expectTrue(res != DiagResult.timeout, Severity.BLOCKER, "Check the dut respond to diagnostic")
        self.expectTrue(res == DiagResult.positive, Severity.BLOCKER, "Check the response of the diag")

        self.dlt_manager.start_monitoring("SRR-DLT")

        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.APPEND_LOG, argType=araLogType.LOG_ARGS_TYPE_STRING,
                                                        argVal=self.set_argVal)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER,
                        "Check the append of the message. ExitCode: " + araLogExitCode(
                            exitCode).name if exitCode is not None else "No ExitCode is returned")

        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(self.set_logOperation_3, contextId=self.set_contextId)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER,
                        "Check the log of the message. ExitCode: " + araLogExitCode(
                            exitCode).name if exitCode is not None else "No ExitCode is returned")

        self.sleep_for(self.wait_for_dlt_message_to_be_sent)

        dlt_check = self.dlt_manager.message_exist(ecuId=self.PP_ECUID,
                                                   contextId=self.set_contextId,
                                                   appId=self.PROXY_APP_APP_ID,
                                                   searchMsg=self.set_argVal)
        self.assertTrue(not dlt_check, Severity.BLOCKER, "Check the Message not logged")

        self.dlt_manager.stop_monitoring()

        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_set_fitlering_off(self):
        self.startTestStep("Set message filtering state to off using diag")
        res = self.diag_manager.syn_send(0xF4, self.PP_DIAG_ADR, self.STEUERN_DLT_SET_MESSAGEFILTERINGSTATE_AUS)

        res_diag = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        logger.debug("Diag Job response -> returned payload: {}".format(
            self.diag_manager.payload_to_str(res_diag.get_payload())))

        self.expectTrue(res != DiagResult.send_failure, Severity.BLOCKER, "Check the diagnostic job payload was sent")
        self.expectTrue(res != DiagResult.timeout, Severity.BLOCKER, "Check the dut respond to diagnostic")
        self.expectTrue(res == DiagResult.positive, Severity.BLOCKER, "Check the response of the diag")
        self.startTestStep("Append specific log message using proxy app")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(LogOps.APPEND_LOG, argType=araLogType.LOG_ARGS_TYPE_STRING,
                                                        argVal=self.set_argVal)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER,
                        "Check the append of the message. ExitCode: " + araLogExitCode(
                            exitCode).name if exitCode is not None else "No ExitCode is returned")
        self.startTestStep("Set log level to debug using proxy app")
        exitCode = self.proxy_app_manager.ARA_LOG_comm.executeLogFunction(self.set_logOperation_3, contextId=self.set_contextId)
        self.assertTrue(exitCode == araLogExitCode.SUCCESS.value, Severity.BLOCKER,
                        "Check the log of the message. ExitCode: " + araLogExitCode(
                            exitCode).name if exitCode is not None else "No ExitCode is returned")

        self.sleep_for(self.wait_for_dlt_message_to_be_sent)
        self.startTestStep("Get the specific dlt log message")
        dlt_check = self.dlt_manager.message_exist(ecuId=self.PP_ECUID,
                                                   contextId=self.set_contextId,
                                                   appId=self.PROXY_APP_APP_ID,
                                                   searchMsg=self.set_argVal)
        logger.info(f"get  dlt messsage:{dlt_check}")
        self.assertTrue(dlt_check, Severity.BLOCKER, "Check the Message logged")

    def tearDown(self):
        self.setPostcondition("Set default trace status using diag")
        res = self.diag_manager.syn_send(0xF4, self.PP_DIAG_ADR, self.STEUERN_DLT_RESET_TO_DEFAULT)

        res_diag = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        logger.debug("Diag Job response -> returned payload: {}".format(
            self.diag_manager.payload_to_str(res_diag.get_payload())))

        self.expectTrue(res != DiagResult.send_failure, Severity.BLOCKER, "Check the diagnostic job payload was sent")
        self.expectTrue(res != DiagResult.timeout, Severity.BLOCKER, "Check the dut respond to diagnostic")
        self.expectTrue(res == DiagResult.positive, Severity.BLOCKER, "Check the response of the diag")

        self.dlt_manager.clear_all_filters()
        self.diag_manager.stop()
        self.dlt_manager.stop_monitoring()
        self.proxy_app_manager.remove_proxy_app_lib(libName.ARA_LOG.value)
