from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_emmc_bad_blocks(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_emmc_bad_blocks"
    REQ_ID = ["/item/5888402", "/item/5888677"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports bad blocks statistics"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.emmc_health_report_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["EMMC"]["Bad Blocks"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.assertTrue(self.eMMC_manufacturer != "UNKNOWN", Severity.BLOCKER, "Check that eMMC manufacturer is known")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.emmc_health_report_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_emmc_bad_blocks(self):
        self.startTestStep("Wait one cycle * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get eMMC bad blocks DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that eMMC bad blocks DLT messages are available")

        if self.eMMC_manufacturer == "MICRON":
            self.startTestStep("Get INITIAL_BAD_BLOCKS value if eMMC is MICRON")
            INITIAL_BAD_BLOCKS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Bad Blocks.Statistics.INITIAL_BAD_BLOCKS")
            self.expectTrue(INITIAL_BAD_BLOCKS != self.INVALID_VALUE, Severity.MAJOR, "Check that INITIAL_BAD_BLOCKS is reported if eMMC is MICRON")

            self.startTestStep("Get RUNTIME_BAD_BLOCKS value if eMMC is MICRON")
            RUNTIME_BAD_BLOCKS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Bad Blocks.Statistics.RUNTIME_BAD_BLOCKS")
            self.expectTrue(RUNTIME_BAD_BLOCKS != self.INVALID_VALUE, Severity.MAJOR, "Check that RUNTIME_BAD_BLOCKS is reported if eMMC is MICRON")

            self.startTestStep("Get REMAIN_SPR_BLOCKS value if eMMC is MICRON")
            REMAIN_SPR_BLOCKS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Bad Blocks.Statistics.REMAIN_SPR_BLOCKS")
            self.expectTrue(REMAIN_SPR_BLOCKS != self.INVALID_VALUE, Severity.MAJOR, "Check that REMAIN_SPR_BLOCKS is reported if eMMC is MICRON")

        if self.eMMC_manufacturer == "SAMSUNG":
            self.startTestStep("Get BAD_BLOCK_RATIO value if eMMC is SAMSUNG")
            BAD_BLOCK_RATIO = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Bad Blocks.Statistics.BAD_BLOCK_RATIO")
            self.expectTrue(BAD_BLOCK_RATIO != self.INVALID_VALUE, Severity.MAJOR, "Check that BAD_BLOCK_RATIO is reported if eMMC is SAMSUNG")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
