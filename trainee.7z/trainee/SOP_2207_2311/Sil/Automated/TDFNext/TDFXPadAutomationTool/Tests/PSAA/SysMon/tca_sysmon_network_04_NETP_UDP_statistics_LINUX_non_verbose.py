from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_network_04_NETP_UDP_statistics_LINUX_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_network_04_NETP_UDP_statistics_LINUX_non_verbose"
    REQ_ID = ["/item/5909491", "/item/6447171"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that the NETP UDP reports contains all required statistics in Non-Verbose Mode"
    OS = ['LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.network_protocols_statistics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_NETP_UDP)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_network_04_NETP_UDP_statistics_LINUX_non_verbose(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_NETP_UDP, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait cycle of NETP * 2")
        self.sleep_for(self.time_interval * 10)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get DLT NETP UDP non-verbose messages")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that DLT NETP UDP messages are available")

        in_datagrams = float(dlt_messages[0]["payload"]["in_datagrams"])
        no_ports = float(dlt_messages[0]["payload"]["no_ports"])
        in_errors = float(dlt_messages[0]["payload"]["in_errors"])
        out_datagrams = float(dlt_messages[0]["payload"]["out_datagrams"])
        rcv_buf_errors = float(dlt_messages[0]["payload"]["rcv_buf_errors"])
        snd_buf_errors = float(dlt_messages[0]["payload"]["snd_buf_errors"])
        in_check_sum_errors = float(dlt_messages[0]["payload"]["in_check_sum_errors"])
        ignored_multi = float(dlt_messages[0]["payload"]["ignored_multi"])

        self.expectTrue(type(in_datagrams) == float, Severity.MAJOR, "Check that in_datagrams is reported")
        self.expectTrue(type(no_ports) == float, Severity.MAJOR, "Check that no_ports is reported")
        self.expectTrue(type(in_errors) == float, Severity.MAJOR, "Check that in_errors is reported")
        self.expectTrue(type(out_datagrams) == float, Severity.MAJOR, "Check that out_datagrams is reported")
        self.expectTrue(type(rcv_buf_errors) == float, Severity.MAJOR, "Check that rcv_buf_errors is reported")
        self.expectTrue(type(snd_buf_errors) == float, Severity.MAJOR, "Check that snd_buf_errors is reported")
        self.expectTrue(type(in_check_sum_errors) == float, Severity.MAJOR, "Check that in_check_sum_errors is reported")
        self.expectTrue(type(ignored_multi) == float, Severity.MAJOR, "Check that ignored_multi is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
