from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_cpu_05_CPUT_thread_cpu_usage_one_process_non_verbose_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_cpu_05_CPUT_thread_cpu_usage_one_process_non_verbose_QNX"
    REQ_ID = ["/item/5832905"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon report threads cpu usage of one process in non-verbose mode"
    OS = ['QNX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Find the config file that contains the selected process names")
        self.assertTrue(True, Severity.MAJOR, "Check that the config file exist")
        self.setPrecondition("Modify the config file with one process")
        self.setPrecondition("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.assertTrue(True, Severity.MAJOR, "Check that config file is correctly set")
        self.setPrecondition("Get thread Ids of the process")
        self.assertTrue(True, Severity.MAJOR, "Check that thread Ids could be retrieved")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        # TODO add message id
        self.dlt_manager.apply_filter(messageId="")
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_cpu_05_CPUT_thread_cpu_usage_one_process_non_verbose_QNX(self):
        # TODO add message short name
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name="", sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait the configured time interval * 2")
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get CPUT non-verbose DLT messages that contains the thread cpu usage")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(True, Severity.MAJOR, "Check that all thread IDs are reported with the parent PID and parent pocess name")
        self.assertTrue(True, Severity.MAJOR, "Check that no thread ID of other process is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.setPostcondition("Revert config file")
        self.setPostcondition("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
