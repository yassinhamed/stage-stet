from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_emmc_used_lifetime_eq_threshold(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_emmc_used_lifetime_eq_threshold"
    REQ_ID = ["/item/5888482", "/item/5888677"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports the used lifetime when threshold is reached"
    OS = ['QNX', 'LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.emmc_health_report_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.wearout_search_msg_array = self.statistic_data["EMMC"]["eMMC Health"]["Search_msg_array"]
        logger.info(f"Wearout levels search message array = {self.wearout_search_msg_array}")
        self.assertTrue(self.wearout_search_msg_array is not None, Severity.BLOCKER, "Check that wearout levels search message array was successfully retrieved")

        self.used_lifetime_search_msg_array = self.statistic_data["EMMC"]["Used lifetime"]["Search_msg_array"]
        logger.info(f"Used lifetime search message array = {self.used_lifetime_search_msg_array}")
        self.assertTrue(self.used_lifetime_search_msg_array is not None, Severity.BLOCKER, "Check that used lifetime search message array was successfully retrieved")

        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.emmc_health_report_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

        self.startTestStep("Wait one cycle * 2")
        self.sleep_for(self.time_interval * 2)

        self.setPrecondition("Get eMMC wearout level DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.wearout_search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that eMMC wearout level DLT messages are available")

        self.setPrecondition("Get DEVICE_LIFE_EST_SLC value")
        DEVICE_LIFE_EST_SLC = self.get_statistic_value(message=messages[0], statistic_path="EMMC.eMMC Health.Statistics.DEVICE_LIFE_EST_SLC")
        self.assertTrue(DEVICE_LIFE_EST_SLC != self.INVALID_VALUE, Severity.MAJOR, "Check that DEVICE_LIFE_EST_SLC is reported")
        DEVICE_LIFE_EST_SLC = int(DEVICE_LIFE_EST_SLC, 16)
        logger.info(f"life estimation for SLC = {DEVICE_LIFE_EST_SLC}")
        SLC_THRESHOLD = DEVICE_LIFE_EST_SLC
        self.expected_SLC_value_in_DLT = "Exceeded its maximum estimated device lifetime"
        logger.info(f"expected SLC DLT value = '{self.expected_SLC_value_in_DLT}'")

        self.setPrecondition("Get DEVICE_LIFE_EST_MLC value")
        DEVICE_LIFE_EST_MLC = self.get_statistic_value(message=messages[0], statistic_path="EMMC.eMMC Health.Statistics.DEVICE_LIFE_EST_MLC")
        self.assertTrue(DEVICE_LIFE_EST_MLC != self.INVALID_VALUE, Severity.MAJOR, "Check that DEVICE_LIFE_EST_MLC is reported")
        DEVICE_LIFE_EST_MLC = int(DEVICE_LIFE_EST_MLC, 16)
        logger.info(f"life estimation for MLC = {DEVICE_LIFE_EST_MLC}")
        MLC_THRESHOLD = DEVICE_LIFE_EST_MLC
        self.expected_MLC_value_in_DLT = "Exceeded its maximum estimated device lifetime"
        logger.info(f"expected MLC DLT value = '{self.expected_MLC_value_in_DLT}'")

        self.dlt_manager.stop_monitoring()

        self.diag_manager.start()

        self.setPrecondition("Set max threshold using Diag Job")
        WEAROUT_DIAG_JOB = self.get_wearout_error_injection_DIAG_payload(SLC_MIN=0xFF, SLC_MAX=0xFF, MLC_MIN=0xFF, MLC_MAX=0xFF, PRE_EOL=0xFF)
        DIAG_RESULT = self.diag_manager.syn_send(self.TESTER_DIAG_ADR, self.PP_DIAG_ADR, WEAROUT_DIAG_JOB)
        self.assertTrue(DIAG_RESULT == DiagResult.positive, Severity.BLOCKER, "Check DIAG positive response")

        self.setPrecondition("Clear DTC Memory")
        self.dtc_controller.clear_info_memory(target=self.PP_DIAG_ADR)

        self.setPrecondition("Set the lower bound threshold for SLC and MLC equal to the current values and set upper bound to 0xff using Diag Job")
        WEAROUT_DIAG_JOB = self.get_wearout_error_injection_DIAG_payload(SLC_MIN=SLC_THRESHOLD, SLC_MAX=0xFF, MLC_MIN=MLC_THRESHOLD, MLC_MAX=0xFF, PRE_EOL=0xFF)
        DIAG_RESULT = self.diag_manager.syn_send(self.TESTER_DIAG_ADR, self.PP_DIAG_ADR, WEAROUT_DIAG_JOB)
        self.assertTrue(DIAG_RESULT == DiagResult.positive, Severity.BLOCKER, "Check DIAG positive response")

        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["EMMC_WEAR_OUT"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_ACTIVE, Severity.BLOCKER, "Checking that Wearout DTC is set")

        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_emmc_used_lifetime_eq_threshold(self):
        self.startTestStep("Wait one cycle * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get eMMC used lifetime DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.used_lifetime_search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that eMMC used lifetime DLT messages are available")

        self.startTestStep("Get SLC_USED_LIFETIME value")
        SLC_USED_LIFETIME = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Used lifetime.Statistics.SLC_USED_LIFETIME")
        self.expectTrue(SLC_USED_LIFETIME != self.INVALID_VALUE, Severity.MAJOR, "Check that SLC_USED_LIFETIME is reported")
        self.expectTrue(SLC_USED_LIFETIME == self.expected_SLC_value_in_DLT, Severity.MAJOR, "Check that SLC_USED_LIFETIME value is correct")

        self.startTestStep("Get MLC_USED_LIFETIME value")
        MLC_USED_LIFETIME = self.get_statistic_value(message=messages[0], statistic_path="EMMC.Used lifetime.Statistics.MLC_USED_LIFETIME")
        self.expectTrue(MLC_USED_LIFETIME != self.INVALID_VALUE, Severity.MAJOR, "Check that MLC_USED_LIFETIME is reported")
        self.expectTrue(MLC_USED_LIFETIME == self.expected_MLC_value_in_DLT, Severity.MAJOR, "Check that MLC_USED_LIFETIME value is correct")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.diag_manager.restart()
        self.setPostcondition("Clear DTC Memory")
        self.dtc_controller.clear_info_memory(target=self.PP_DIAG_ADR)
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
