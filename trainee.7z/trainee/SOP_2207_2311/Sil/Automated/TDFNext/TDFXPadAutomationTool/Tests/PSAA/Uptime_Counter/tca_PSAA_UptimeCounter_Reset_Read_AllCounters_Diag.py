from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *


class tca_PSAA_UptimeCounter_Reset_Read_AllCounters_Diag(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_Reset_Read_AllCounters_Diag"
    REQ_ID = ["/item/3316277","/item/3316280"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check counters after reseting counters using diagnostic job"
    STATUS = "Ready"
    OS = ["QNX", "LINUX"]

    def setUp(self):

        self.MediaGateway_controller.set_mediagateway_config(self.LifeCycle_MG)
        self.sleep_for(self.SET_MG_CONFIG_MS)
        self.someip_controller.set_adapter_configuration('Stimulation', self.ZGW_IP, self.DEFAULT_MASK)
        self.bus.power_supply.power_on_reset(downtime=self.PP_SHUTDOWN_TIMEOUT_MS,
                                             startup_time=self.PP_STARTUP_TIMEOUT_MS)
        self.someip_controller.init_simulation("BCP21_GW")
        self.someip_controller.start_all_offers("BCP21_GW")
        self.someip_controller.start_simulation("BCP21_GW")
        self.someip_controller.set_pwf_status("BCP21_GW", pwf_status="Pruefen_Analyse_Diagnose")
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.VEHICLECONDITION_SERVICE_ID,
                                                 instance_id=self.VEHICLECONDITION_INSTANCE_ID,
                                                 method_id=self.VEHICLECONDITION_METHOD_ID,
                                                 signal_name="VehicleCondition.qualifierStatusConditionVehicle",
                                                 signal_value=2)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID,
                                                 instance_id=self.MILEAGESUPREME_INSTANCE_ID,
                                                 method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.mileageSupreme",
                                                 signal_value=self.initial_mileage)
        self.someip_controller.set_someip_signal("BCP21_GW",
                                                 service_id=self.MILEAGESUPREME_SERVICE_ID,
                                                 instance_id=self.MILEAGESUPREME_INSTANCE_ID,
                                                 method_id=self.MILEAGESUPREME_METHOD_ID,
                                                 signal_name="mileageSupreme.qualifierMileageSupreme",
                                                 signal_value=0x00)
        self.bcp21_nmController.start_udp_nm_simulation()
        self.bcp21_nmController.set_basic_partial_network(CtrBsPrtnt.KOM_Pruefen_Analyse_Diagnose)
        self.bcp21_nmController.set_functional_partial_network(self.DEFAULT_FUNCTIONAL_PARTIAL_NETWORK)
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)
        self.diag_manager.start_with_param(chName="ETH-HSFZ-DIAG", srcPort=0, dstPort=self.HSFZ_Destination_Port,
                                           remoteIP=self.PP_IP)


    def test_tca_PSAA_UptimeCounter_Reset_Read_AllCounters_Diag(self):

        self.startTestStep("sending diag job STATUS_UNGEWOLLTE_RESETS_STATISTIKEN ")
        res = self.diag_manager.syn_send(self.TESTER_DIAG_ADR,self.PP_DIAG_ADR,self.STATUS_UNGEWOLLTE_RESETS_STATISTIKEN)
        self.assertTrue(res == DiagResult.positive, Severity.BLOCKER, "Check positive response for ECU state is received")
        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.startTestStep("Getting diag response containing the counters payload")
        res_diag1 = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        first_payload=self.diag_manager.payload_to_str(res_diag1.get_payload())
        logger.info("first_payload : " + str(first_payload))

        self.startTestStep("sending diag job STEUERN_LOESCHEN_UNGEWOLLTE_RESETS_STATISTIKEN ")
        res = self.diag_manager.syn_send(self.TESTER_DIAG_ADR,self.PP_DIAG_ADR,self.STEUERN_LOESCHEN_UNGEWOLLTE_RESETS_STATISTIKEN)
        self.assertTrue(res == DiagResult.positive, Severity.BLOCKER, "Check positive response for ECU state is received")
        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.startTestStep("sending diag job STATUS_UNGEWOLLTE_RESETS_STATISTIKEN ")
        res = self.diag_manager.syn_send(self.TESTER_DIAG_ADR,self.PP_DIAG_ADR,self.STATUS_UNGEWOLLTE_RESETS_STATISTIKEN)
        self.assertTrue(res == DiagResult.positive, Severity.BLOCKER, "Check positive response for ECU state is received")

        self.startTestStep("Getting diag response containing the counters payload")
        res_diag2 = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        Second_payload=self.diag_manager.payload_to_str(res_diag2.get_payload())
        logger.info("Second_payload : " + str(Second_payload))

        self.startTestStep("Checking the counters payload after reset diag job")
        payload_values = self.payload_to_dic(Second_payload)
        self.expectTrue(payload_values["Number_of_unwanted_resets"] == self.Counters_Zero_Number_of_unwanted_resets , Severity.MAJOR, "Check Number_of_unwanted_resets")
        self.expectTrue(payload_values["Total_accumulated_uptime_in milliseconds"] <= self.Counters_Zero_Total_accumulated_uptime_in_milliseconds , Severity.MAJOR, "Check Total_accumulated_uptime_in milliseconds")
        self.expectTrue(payload_values["Total_accumulated_meters_driven"] == self.Counters_Zero_Total_accumulated_meters_driven , Severity.MAJOR, "Check Total_accumulated_meters_driven")
        self.expectTrue(payload_values["Total_accumulated_uptime_in_milliseconds_when_HAF_READY_was_available"] == self.Counters_Zero_Total_accumulated_uptime_in_milliseconds_when_HAF_READY_was_available , Severity.MAJOR,
                        "Check Total_accumulated_uptime_in_milliseconds_when_HAF_READY_was_available")

    def tearDown(self):
        self.diag_manager.stop()
        self.setPostcondition("Stop simulation")
        self.someip_controller.stop_all_offers("BCP21_GW")
        self.someip_controller.stop_simulation("BCP21_GW")
        self.bcp21_nmController.stop_nm_udp_simulation()
        self.someip_controller.clear_adapter_configuration('Stimulation', self.ZGW_IP, self.SOMEIP_MULTICAST_IP)
        self.MediaGateway_controller.set_mediagateway_config(self.Default_MG)
        self.sleep_for(self.SET_MG_CONFIG_MS)
        self.setPostcondition("Resetting ECU")
        self.bus.power_supply.power_on_reset(downtime=self.PP_SHUTDOWN_TIMEOUT_MS, startup_time=self.PP_STARTUP_TIMEOUT_MS)
