from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *


class tca_PSAA_UptimeCounter_CP60_Availability_Linux(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_CP60_Availability_Linux"
    REQ_ID = ["/item/2081694"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Checking CP60 system Availability time is zero"
    STATUS = "Ready"
    OS = ["Linux"]

    def setUp(self):
        pass


    def test_tca_PSAA_UptimeCounter_CP60_Availability_Linux(self):

        self.startTestStep("waiting CP60 UptimeCounter update cyclicity")
        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.startTestStep("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.startTestStep("Getting CP60 Availability counter value from kvs")
        CP60_Availability = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.CP60_Uptime_counter)
        logger.info(f"CP60_Availability_value: {CP60_Availability}")

        self.assertTrue(CP60_Availability != 0 , Severity.BLOCKER, "Checking CP60 system Availability time is zero")

    def tearDown(self):
       pass
