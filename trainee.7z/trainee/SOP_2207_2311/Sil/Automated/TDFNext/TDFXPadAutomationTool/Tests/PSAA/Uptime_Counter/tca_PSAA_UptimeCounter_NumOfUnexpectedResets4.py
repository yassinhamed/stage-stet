from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *


class tca_PSAA_UptimeCounter_NumOfUnexpectedResets4(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_NumOfUnexpectedResets4"
    REQ_ID = ["/item/3316218"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):

        self.default_check_empty = False
        self.diag_manager.start()


    def test_tca_PSAA_UptimeCounter_NumOfUnexpectedResets4(self):

        self.startTestStep("sending diag job STATUS_UNGEWOLLTE_RESETS_STATISTIKEN ")
        res = self.diag_manager.syn_send(self.TESTER_DIAG_ADR,self.PP_DIAG_ADR,self.STATUS_UNGEWOLLTE_RESETS_STATISTIKEN)
        self.assertTrue(res == DiagResult.positive, Severity.BLOCKER, "Check positive response for ECU state is received")

        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.startTestStep("Getting diag response containing the counters payload")
        res_diag1 = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        first_payload=self.diag_manager.payload_to_str(res_diag1.get_payload())
        logger.info("first_payload : " + str(first_payload))

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting Num Of Unexpected Resets value")
        First_NumOfUnexpectedResets = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.Unexpected_reset_counter)
        logger.info(f"First_NumOfUnexpectedResets_value: {First_NumOfUnexpectedResets}")
        self.diag_manager.stop()

        self.startTestStep("performing kernel crash")
        kernel_crash = self.ssh_manager.executeCommandInTarget(self.kernel_panic_command)
        self.assertTrue(kernel_crash["stdout"] == "",Severity.MAJOR, "Check output of kernel crash command")

        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.diag_manager.start()
        self.startTestStep("sending diag job STATUS_UNGEWOLLTE_RESETS_STATISTIKEN ")
        res = self.diag_manager.syn_send(self.TESTER_DIAG_ADR,self.PP_DIAG_ADR,self.STATUS_UNGEWOLLTE_RESETS_STATISTIKEN)
        self.assertTrue(res == DiagResult.positive, Severity.BLOCKER, " Check positive response for ECU state is received")

        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.startTestStep("Getting diag response containing the counters payload")
        res_diag1 = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        Second_payload=self.diag_manager.payload_to_str(res_diag1.get_payload())
        logger.info("Second_payload : " + str(Second_payload))

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting Num Of Unexpected Resets value after kernel crash  ")
        Second_NumOfUnexpectedResets = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.Unexpected_reset_counter)
        logger.info(f"Second_NumOfUnexpectedResets_value: {Second_NumOfUnexpectedResets}")
        self.assertTrue(int(Second_NumOfUnexpectedResets) == int(First_NumOfUnexpectedResets) +1 , Severity.MAJOR, "Check number of unexpected resets after kernel_crash")

    def tearDown(self):

        self.startTestStep("Getting UptimeCounter kvs file")
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.stop()
