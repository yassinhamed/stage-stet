from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_block_device_01_IOTD_statistics_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_block_device_01_IOTD_statistics_LINUX"
    REQ_ID = ["/item/5833798"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports IO statistics for each thread"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.Search_msg_array = self.statistic_data["block_delay"]["IOTD"]["Search_msg_array"]
        logger.info(f"Search message array = {self.Search_msg_array}")
        self.assertTrue(self.Search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.thread_io_statistics_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_block_device_01_IOTD_statistics_LINUX(self):
        self.startTestStep("Wait 60s")
        self.sleep_for(self.wait_for_iotd_message_MS)

        self.startTestStep("Get IOTD statistics DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.Search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that  IOTD statistics DLT messages are available")

        self.startTestStep("Get delay value")
        delay = self.get_statistic_value(message=messages[0], statistic_path="block_delay.IOTD.Statistics.delay")
        self.expectTrue(delay != self.INVALID_VALUE, Severity.MAJOR, "Check that delay is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
