from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_cpu_04_CPUP_process_cpu_usage(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_cpu_04_CPUP_process_cpu_usage"
    REQ_ID = ["/item/5831492", "/item/142161"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports the cpu usage for each process"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.process_cpu_usage_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["CPU"]["Process"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.process_cpu_usage_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.setPrecondition("Get usage limit from the config file")
        self.cpu_threshold = self.get_process_cpu_usage_limit(SearchText="process_cpu_usage_limit")
        logger.info(f"Cpu threshold = {self.cpu_threshold} is the cpu usage limit")
        self.expectTrue(self.cpu_threshold != self.INVALID_VALUE, Severity.BLOCKER, "Check that configured CPU threshold was successfully retrieved")
        self.expectTrue(self.cpu_threshold == 0.1, Severity.MAJOR, "Check that configured CPU threshold is equal to 0.1")

    def test_tca_sysmon_cpu_04_CPUP_process_cpu_usage(self):
        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 2)
        self.startTestStep("Get CPUP DLT messages that contains the cpu usage of processes")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that all retrieved processes using SSH are logged by sysmon")
        self.startTestStep("Check all running processes with CPU usage more than the configured usage limit")
        all_processes_cpu_usage_more_than_usage_limit = self.check_process_cpu_usage_more_than_usage_limit(messages=messages, cpu_threshold=self.cpu_threshold)
        self.assertTrue(all_processes_cpu_usage_more_than_usage_limit, Severity.MAJOR, "Check that all processes consumed cpu usage are more than 0.1")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
