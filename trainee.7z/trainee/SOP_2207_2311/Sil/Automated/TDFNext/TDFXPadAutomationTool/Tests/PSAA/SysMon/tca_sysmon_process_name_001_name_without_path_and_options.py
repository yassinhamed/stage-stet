from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_process_name_001_name_without_path_and_options(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_process_name_001_name_without_path_and_options"
    REQ_ID = ["/item/5832857","/item/144783"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports process name with full path and without options"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        # requirement changed from without full path and options to with full path and options
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.process_cpu_usage_context_id)
        self.dlt_manager.apply_filter(contextId=self.thread_cpu_usage_context_id)
        self.dlt_manager.apply_filter(contextId=self.domain_reporting_context_id)
        self.dlt_manager.apply_filter(contextId=self.thread_forking_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_process_name_001_name_without_path_and_options(self):
        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.startTestStep("Check ECUs")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUs are Ok after ECU reset")

        self.startTestStep("Wait 120 seconds")
        self.sleep_for(self.wait_for_process_reports_ms)

        self.startTestStep("Get DLT messages that reports execution_manager")
        self.startTestStep("Get SDRT DLT message")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=["execution_manag"])
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that DLT messages are available")
        reported_with_full_path = self.check_report_with_full_path(messages=messages)
        self.expectTrue(reported_with_full_path, Severity.MAJOR, "Check that messages contain full path")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
