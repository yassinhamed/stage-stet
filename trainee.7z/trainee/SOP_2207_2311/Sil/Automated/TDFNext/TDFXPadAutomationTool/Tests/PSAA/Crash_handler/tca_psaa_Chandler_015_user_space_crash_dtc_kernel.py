from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_015_user_space_crash_dtc_kernel(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_015_user_space_crash_dtc_kernel"
    REQ_ID = ["/item/2593168", "/item/2593242"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check DTC of kernel pannic did not set when an non adaptive application is crashed"
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        pass

    def test_tca_psaa_Chandler_015_user_space_crash_dtc_kernel(self):
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.restart()
        self.startTestStep("get kernel coredumps names")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"ls -la {self.CoreDumps_Path}/kernel | grep -c kdump.vmcore",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "0", Severity.BLOCKER,
                        "Checking that the coredumps were generated")

        self.startTestStep("Kill XPC App")
        application_is_killed = self.kill_application(app_name=self.XPC_APP_NAME, signal=self.killall_options["SIGABRT"])
        self.assertTrue(application_is_killed, Severity.MAJOR, "Checking that Linux command executed successfully")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.startTestStep("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} ",
                                                              timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                              ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that 'ls | grep' command executed succesfully")
        dumps_list = returnValue["stdout"].splitlines()
        logger.info("Number of core dumps" + str(len(dumps_list)))
        self.expectTrue(len(dumps_list) == self.Number_Of_Coredumps_Files, Severity.BLOCKER,
                        "Checking that coredumps files were created properly.")
        self.startTestStep("Check secondary Kernelpanik_oder_Kernel_OOP DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Kernelpanik_oder_Kernel_OOP"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_NOT_PRESENT, Severity.BLOCKER, "Checking that DTC is not set")
        self.startTestStep("Check secondary Applikation_wurde_unerwartet_beendet DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Applikation_wurde_unerwartet_beendet"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that DTC is not set")

    def tearDown(self):
        self.setPostcondition("Reset safety")
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_MS)
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)
