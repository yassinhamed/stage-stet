from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_network_02_NETS_statistics_LINUX_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_network_02_NETS_statistics_LINUX_non_verbose"
    REQ_ID = ["/item/5906667", "/item/5979705"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that the NETS reports contains all required statistics in Non-Verbose Mode"
    OS = ['LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.network_statistic_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_NETS_2)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_network_02_NETS_statistics_LINUX_non_verbose(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_NETS_2, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait cycle of NETS * 2")
        self.sleep_for(self.time_interval * 10)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get NETS non-verbose DLT messages")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that NETS DLT  messages are available")

        self.startTestStep("Get all reported interfaces in the DLT messages")
        rx_bytes = float(dlt_messages[0]["payload"]["rx_bytes"])
        tx_bytes = float(dlt_messages[0]["payload"]["tx_bytes"])
        rx_elapsed_mbits_p_sec = float(dlt_messages[0]["payload"]["rx_elapsed_mbits_p_sec"])
        tx_elapsed_mbits_p_sec = float(dlt_messages[0]["payload"]["tx_elapsed_mbits_p_sec"])
        rx_packets = float(dlt_messages[0]["payload"]["rx_packets"])
        tx_packets = float(dlt_messages[0]["payload"]["tx_packets"])
        rx_errs = float(dlt_messages[0]["payload"]["rx_errs"])
        tx_errs = float(dlt_messages[0]["payload"]["tx_errs"])
        rx_drop = float(dlt_messages[0]["payload"]["rx_drop"])
        tx_drop = float(dlt_messages[0]["payload"]["tx_drop"])
        rx_frame = float(dlt_messages[0]["payload"]["rx_frame"])
        multicast = float(dlt_messages[0]["payload"]["multicast"])
        tx_colls = float(dlt_messages[0]["payload"]["tx_colls"])
        tx_carrier = float(dlt_messages[0]["payload"]["tx_carrier"])
        rx_fifo = float(dlt_messages[0]["payload"]["rx_fifo"])
        tx_fifo = float(dlt_messages[0]["payload"]["tx_fifo"])

        self.expectTrue(type(rx_bytes) == float, Severity.MAJOR, "Check that rx_bytes is reported")
        self.expectTrue(type(tx_bytes) == float, Severity.MAJOR, "Check that tx_bytes is reported")
        self.expectTrue(type(rx_elapsed_mbits_p_sec) == float, Severity.MAJOR, "Check that rx_elapsed_mbits_p_sec is reported")
        self.expectTrue(type(tx_elapsed_mbits_p_sec) == float, Severity.MAJOR, "Check that tx_elapsed_mbits_p_sec is reported")
        self.expectTrue(type(rx_packets) == float, Severity.MAJOR, "Check that rx_packets is reported")
        self.expectTrue(type(tx_packets) == float, Severity.MAJOR, "Check that tx_packets is reported")
        self.expectTrue(type(rx_errs) == float, Severity.MAJOR, "Check that rx_errs is reported")
        self.expectTrue(type(tx_errs) == float, Severity.MAJOR, "Check that tx_errs is reported")
        self.expectTrue(type(rx_drop) == float, Severity.MAJOR, "Check that rx_drop is reported")
        self.expectTrue(type(tx_drop) == float, Severity.MAJOR, "Check that tx_drop is reported")
        self.expectTrue(type(rx_frame) == float, Severity.MAJOR, "Check that rx_frame is reported")
        self.expectTrue(type(multicast) == float, Severity.MAJOR, "Check that multicast is reported")
        self.expectTrue(type(tx_colls) == float, Severity.MAJOR, "Check that tx_colls is reported")
        self.expectTrue(type(tx_carrier) == float, Severity.MAJOR, "Check that tx_carrier is reported")
        self.expectTrue(type(rx_fifo) == float, Severity.MAJOR, "Check that rx_fifo is reported")
        self.expectTrue(type(tx_fifo) == float, Severity.MAJOR, "Check that tx_fifo is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
