from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_CoreDumpHandler(testfixture_PSAA):
    COREDUMPS_GENERATION_TIMEOUT_MS = 40000
    Number_Of_Coredumps_Files = 6
    Number_Of_Coredumps_Files_After_Reset = 4
    default_check_empty = False
    messageID_log_file_request = 400

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_CoreDumpHandler setUpclsss")
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=path.join(OutputPathManager.get_tests_group_path(), "coredumps_setupclass"),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_CoreDumpHandler tearDownclsss")

    def setUp(self):
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=path.join(OutputPathManager.get_test_case_path(), "coredumps_setup"),check_empty=False,ip_address=self.PP_IP,ignored_files=["currentswversion", "tmp"])
        self.diag_manager.start()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        self.diag_manager.restart()

    def tearDown(self):
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=path.join(OutputPathManager.get_test_case_path(), "coredumps_teardown"),check_empty=False,ip_address=self.PP_IP,ignored_files=["currentswversion", "tmp"])
        self.diag_manager.start()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.restart()
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")

    def check_core_dumps_names(self, coredumps):
        for element in coredumps:
            if element != "checksum" and element != "currentswversion" and not ('logs' in element):
                logger.info(f"element:{element}")
                type, timestamp, app, pid, ext = element.split(".")
                self.expectTrue((type == "context") | (type == "core") | (type == "stacktrace"), Severity.BLOCKER, f"Check Coredump {element} context file has the right type name.")
                self.expectTrue(timestamp != "", Severity.BLOCKER, f"Check Coredump {element} context file has the right timestamp.")
                self.expectTrue(isinstance(app, str), Severity.BLOCKER, f"Check Coredump {element} context file has the right app name.")
                self.expectTrue(pid.isdigit(), Severity.BLOCKER, f"Check Coredump {element} context file has the right pid.")
                self.expectTrue(ext == ("txt" if ((type == "context") | (type == "stacktrace")) else "gz"), Severity.BLOCKER, f"Check Coredump {element} context file has the right extension.")
            if 'logs' in element:
                logger.info(f"element:{element}")
                type, timestamp, app, pid, trace, ext = element.split(".")
                self.expectTrue(type == "logs", Severity.BLOCKER, f"Check Coredump {element} context file has the right type name.")
                self.expectTrue(timestamp != "", Severity.BLOCKER, f"Check Coredump {element} context file has the right timestamp.")
                self.expectTrue(isinstance(app, str), Severity.BLOCKER, f"Check Coredump {element} context file has the right app name.")
                self.expectTrue(pid.isdigit(), Severity.BLOCKER, f"Check Coredump {element} context file has the right pid.")
                self.expectTrue(trace == "dlt", Severity.BLOCKER, f"Check Coredump {element} context file has the right trace type.")
                self.expectTrue(ext == "gz", Severity.BLOCKER, f"Check Coredump {element} context file has the right extension.")

    def context_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'context.*.txt'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of context_files" + str(len(dumps_list)))
            context_files = returnValue["stdout"].strip().split("\n")
            for context_file in context_files:
                app_name_in_context_file = context_file.split('.')[2]
                if app_name_in_context_file == app_name:
                    return True
                else:
                    continue
            return False

    def core_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'core.*.gz'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of core_files" + str(len(dumps_list)))
            core_files = returnValue["stdout"].strip().split("\n")
            for core_file in core_files:
                app_name_in_core_file = core_file.split('.')[2]
                if app_name_in_core_file == app_name:
                    return True
                else:
                    continue
            return False

    def logs_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'logs.*.gz'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of logs_files" + str(len(dumps_list)))
            logs_files = returnValue["stdout"].strip().split("\n")
            for logs_file in logs_files:
                app_name_in_logs_file = logs_file.split('.')[2]
                if app_name_in_logs_file == app_name:
                    return True
                else:
                    continue
            return False

    def stacktrace_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'stacktrace.*.txt'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of stacktrace_files" + str(len(dumps_list)))
            stacktrace_files = returnValue["stdout"].strip().split("\n")
            for stacktrace_file in stacktrace_files:
                app_name_in_stacktrace_file = stacktrace_file.split('.')[2]
                if app_name_in_stacktrace_file == app_name:
                    return True
                else:
                    continue
            return False
    
    def check_checksum_created(self):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'checksum'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            checksum_files = returnValue["stdout"].strip().split("\n")
            if checksum_files != []:
                return True
            else:
                return False

    def check_coredumps(self, app_name):
        Coredumps_created = False
        # context file check
        app_name_in_context_file = self.context_file_check(app_name=app_name)
        # core file check
        app_name_in_core_file = self.core_file_check(app_name=app_name)
        # logs file check
        app_name_in_logs_file = self.logs_file_check(app_name=app_name)
        # stacktrace file check
        app_name_in_stacktrace_file = self.stacktrace_file_check(app_name=app_name)
        # check that checksum file created
        checksum_in_coredumps = self.check_checksum_created()
        if app_name_in_context_file and app_name_in_core_file and app_name_in_logs_file and app_name_in_stacktrace_file and checksum_in_coredumps:
            Coredumps_created = True
        return Coredumps_created
