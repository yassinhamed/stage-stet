from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_018_coredump_commithash_Nona(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_018_coredump_commithash_Nona"
    REQ_ID = ["/item/1736864","/item/1736931","/item/1736943"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps commit hash by killing non adaptive application"
    STATUS = "Ready"
    OS = ['LINUX']

    pid_XPC = 0

    def setUp(self):
        self.setPrecondition("Check app-dui.json exist under app-dui.json exist")
        check_dui = self.ssh_manager.executeCommandInTarget(command=r"ls /var/lib/dui/ | grep  dui.json", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.expectTrue(check_dui["stdout"].strip() != "", Severity.MAJOR, "Check app-dui.json exist")

    def test_tca_psaa_dumper_018_coredump_commithash_Nona(self):
        self.setPrecondition("Get Pid of XPC App")
        returnValue = self.get_process_id(app_name=self.XPC_APP_NAME)
        self.assertTrue(returnValue != -1, Severity.BLOCKER,
                        f"Check the get pid of {self.XPC_APP_NAME}")
        self.pid_XPC = returnValue

        self.startTestStep("Kill XPC App")
        xpc_is_killed = self.kill_application(app_name=self.XPC_APP_NAME, signal=self.killall_options["SIGABRT"])
        self.assertTrue(xpc_is_killed, Severity.MAJOR,
                        "Checking that Linux command executed successfully")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

        self.startTestStep("check coredumps created")
        coredumps_created = self.check_coredumps(self.XPC_APP_NAME)
        self.assertTrue(coredumps_created,Severity.BLOCKER,"Checking that coredumps files were created properly.")

        self.startTestStep("Get ref from context file")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"cat {self.CoreDumps_Path}/context.*|  grep 'ref:'", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Check cat command is executed")
        self.expectTrue(("Error" not in returnValue["stdout"]) and (returnValue["stdout"] != ""), Severity.BLOCKER,
                        "Check stdout is not empty")

    def tearDown(self):
        self.setPostcondition("Reset safety")
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_MS)
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)
