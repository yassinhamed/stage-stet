from Tests.PSAA.Param_Server.testfixture_PSAA_param_server_ProxyApp import *


class tca_ParamS_006_IPC_FieldMode_1D1A_disabled(testfixture_PSAA_param_server_ProxyApp):

    TEST_ID = "ParamServer\tca_ParamS_006_IPC_FieldMode_1D1A_disabled"
    REQ_ID = ["/item/53169", "/item/144129", "/item/144130"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    field_depends_on_coding = None

    def setUp(self):
        self.ecu_uid = self.sfa_manager.get_ecu_uid(target=self.PP_DIAG_ADR)
        self.diag_manager.start()
        self.sfa_manager.set_up(target_address=self.PP_DIAG_ADR)

    def test_IPC_FieldMode_1D1A_disabled(self):

        resp = self.sfa_manager.safe_set_to_field_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(resp, Severity.BLOCKER, "check the return code of the switch to Field mode")
        mode = self.sfa_manager.sfa_get_ecu_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(mode == EcuMode.Field.value, Severity.BLOCKER, 'Check that the perf. controller is in Field mode')

        res = self.sfa_manager.sfa_clear_feature(target=self.PP_DIAG_ADR, feature_id=self.SFA_ID)
        self.expectTrue(res, Severity.BLOCKER, "check the return code of the disabling of 1D1A token in the perf. controller")
        self.sleep_for(self.TOKEN_STATUS_UPDATE_TIMEOUT_MS)
        feature_status = self.sfa_manager.sfa_get_status(self.PP_DIAG_ADR, self.SFA_ID)
        self.expectTrue(feature_status != Feature_Status.Enabled.value, Severity.BLOCKER, f"Check that the 1D1A token is not enabled, token status = {feature_status}")

        result = self.proxy_app_manager.PARAM_SERVER_comm.get_parameter(fieldName=self.field_name, parameterName=self.parameter_name)
        self.assertTrue(result == araParamServExitCode.SUCCESS.value, Severity.MAJOR, "Check exit code is success")

    def tearDown(self):
        resp = self.sfa_manager.safe_set_to_engineering_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(resp, Severity.BLOCKER, "check the return code of the switch to Eng mode")
        mode = self.sfa_manager.sfa_get_ecu_mode(target=self.PP_DIAG_ADR)
        self.expectTrue(mode == EcuMode.Engineering.value, Severity.BLOCKER, 'Check that the perf. controller is in Eng mode')

        res = self.sfa_manager.set_secure_feature(target=self.PP_DIAG_ADR, ecu_uid=self.ecu_uid, feature_id=self.SFA_ID,
                                                  result_dir=OutputPathManager.get_report_path(), feature_spec_fields=self.sfa_manager.generate_ssh_key_payload())
        self.expectTrue(res, Severity.BLOCKER, "check that 1D1A token was enabled successfully")
        self.sleep_for(self.TOKEN_STATUS_UPDATE_TIMEOUT_MS)
        feature_status = self.sfa_manager.sfa_get_status(self.PP_DIAG_ADR, self.SFA_ID)
        self.expectTrue(feature_status == Feature_Status.Enabled.value, Severity.BLOCKER, f"check that 1D1A is enabled, token status = {feature_status}")

        self.diag_manager.stop()
