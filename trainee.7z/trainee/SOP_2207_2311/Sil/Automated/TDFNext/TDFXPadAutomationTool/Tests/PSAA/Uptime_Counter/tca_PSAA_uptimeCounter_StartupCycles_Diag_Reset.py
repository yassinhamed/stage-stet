from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *


class tca_PSAA_uptimeCounter_StartupCycles_Diag_Reset(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_uptimeCounter_StartupCycles_Diag_Reset"
    REQ_ID = ["/item/6233405"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check startup cycles counter is incremented after restarting ECU"
    STATUS = "Ready"
    OS = ["QNX", "LINUX"]

    def setUp(self):

        self.setPrecondition("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR,"Checking command is successfully executed")

        self.setPrecondition("Getting StartupCycles counter value from kvs")
        self.First_Startup_cycles = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.StartupCycles_counter)
        logger.info(f"First_Startup_cycles_value: {self.First_Startup_cycles}")

        self.setPrecondition("apply dlt filters ")
        self.dlt_manager.apply_filter(appId=self.MSM_APP_ID)

        self.setPrecondition("start dlt monitoring")
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_PSAA_uptimeCounter_StartupCycles_Diag_Reset(self):

        self.startTestStep("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.startTestStep("get shutdown DLT message from MSM ")
        shutdown_count, message = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID,searchMsgArray=self.SHUTDOWN_Successfully_messages)
        self.assertTrue(shutdown_count > 0, Severity.BLOCKER, "Checking shutdown DLT message from MSM")

        self.startTestStep("Check Ecus")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUS are correctly reset")

        self.startTestStep("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.startTestStep("Getting StartupCycles counter value from kvs")
        Second_Startup_cycles = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.StartupCycles_counter)
        logger.info(f"Second_Startup_cycles_value: {Second_Startup_cycles}")

        self.assertTrue(int(Second_Startup_cycles) == int(self.First_Startup_cycles) + 1 ,Severity.BLOCKER,"Checking StartupCycles counter value is incremented")

    def tearDown(self):
        self.setPostcondition("Clearing all dlt filters")
        self.dlt_manager.clear_all_filters()

        self.setPostcondition("Stopping dlt monitoring")
        self.dlt_manager.stop_monitoring()
