from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter import *


class tca_psaa_CrashReporter_008_context_file_name_and_path(testfixture_PSAA_Crash_Reporter):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_008_context_file_name_and_path"
    REQ_ID = ["/item/6413337", "/item/6159354", "/item/6159356"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check context file name and path"
    STATUS = "Ready"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Clear old core dumps")
        remove_is_done = self.remove_old_coredumps()
        self.expectTrue(remove_is_done, Severity.MAJOR, "Check the remove of old coredumps is done")
        self.setPrecondition("Get crash reporter is running")
        crash_reporter_is_running = self.parse_crash_reporter_commandline_parameters()
        self.expectTrue(crash_reporter_is_running != None, Severity.MAJOR, "Check that crash reporter is running")

    def test_tca_psaa_CrashReporter_008_context_file_name_and_path(self):
        self.startTestStep("Get pid of the application to be killed")
        Plannning_pid = self.get_process_id(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(Plannning_pid != -1, Severity.MAJOR, "Check the application is running")
        self.startTestStep("Kill application")
        application_is_killed = self.kill_application_CR(app_name=self.PLANNING_APP_NAME, signal="SIGABRT")
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check the kill command is executed")
        self.startTestStep("Wait for coredumps creation")
        self.sleep_for(self.default_dumper_timeout)
        self.startTestStep("Check application is killed")
        Plannning_still_running = self.check_application_is_started(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(not Plannning_still_running, Severity.MAJOR, "Check the application is killed")
        self.startTestStep("Get context name using ls command")
        context_file_name = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'context.*.{self.PLANNING_APP_NAME}.*.txt'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(self.PLANNING_APP_NAME in context_file_name["stdout"], Severity.MAJOR, "Check the context file exists under /persistent/coredumps")
        context_file_name_list = context_file_name["stdout"].split('.')
        self.expectTrue(context_file_name_list[0].strip() == "context", Severity.MAJOR, "Check context is in the context file name")
        self.expectTrue(context_file_name_list[1].strip().isdigit(), Severity.MAJOR, "Check <crash_timestamp> is in the context file name")
        self.expectTrue(context_file_name_list[2].strip() == self.PLANNING_APP_NAME, Severity.MAJOR, "Check <crashed_process_name> is in the context file name")
        self.expectTrue(context_file_name_list[3].strip() == str(Plannning_pid), Severity.MAJOR, "Check <crashed_process_PID> is in the context file name")
        self.expectTrue(context_file_name_list[4].strip() == "txt", Severity.MAJOR, "Check txt is in the context file name")

    def tearDown(self):
        self.setPostcondition("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
