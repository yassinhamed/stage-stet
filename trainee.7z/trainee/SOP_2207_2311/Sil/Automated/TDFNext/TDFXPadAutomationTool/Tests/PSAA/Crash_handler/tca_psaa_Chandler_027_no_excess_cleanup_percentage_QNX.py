from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_027_no_excess_cleanup_percentage_QNX(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_027_no_excess_cleanup_percentage_QNX"
    REQ_ID = ["/item/8253068", "/item/2593376", "/item/2593168"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check coredumps cleanup with no excess cleanup percentage"
    STATUS = "Ready"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Restart crash handler with parameter --coredumps_storage_quota_mb 40 and --storage_cleanup_percentage 50")
        crash_handler_restarted = self.restart_crash_handler_with_params(coredumps_storage_quota_mb="40", storage_cleanup_percentage="50")
        self.assertTrue(crash_handler_restarted, Severity.MAJOR, "Check crash handler restarted")
        self.setPrecondition("Get crash reporter process information using ps -A -o pid,args | grep crash_handler")
        crash_handler_parameters = self.parse_crash_handler_commandline_parameters()
        self.assertTrue(crash_handler_parameters is not None, Severity.MAJOR, "Check crash handler restarted")
        self.assertTrue(crash_handler_parameters["percentage"] == "50", Severity.MAJOR, "Check crash handler quota equal to 50")
        self.assertTrue(crash_handler_parameters["quota"] == "40", Severity.MAJOR, "Check crash handler quota equal to 40")
        self.setPrecondition("Clear old core dumps")
        remove_is_done = self.remove_old_coredumps()
        self.expectTrue(remove_is_done, Severity.MAJOR, "Check the remove of old coredumps is done")

    def test_tca_psaa_Chandler_027_no_excess_cleanup_percentage_QNX(self):
        self.startTestStep("Get pid of ets application to be killed")
        ets_pid = self.get_process_id(app_name=self.ETS_APP_NAME)
        self.assertTrue(ets_pid != -1, Severity.MAJOR, "Check ets application is running")
        self.startTestStep("Kill ets application")
        application_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal="SIGABRT")
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check the kill command is executed")
        self.startTestStep("Wait for coredumps creation")
        self.sleep_for(self.default_dumper_timeout)
        self.startTestStep("Check ets application is killed")
        ets_still_running = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.assertTrue(not ets_still_running, Severity.MAJOR, "Check ets application is killed")
        self.startTestStep("Get coredumps names using ls command")
        logger.info(self.ssh_manager.executeCommandInTarget(command=f"ls -la {self.CoreDumps_Path}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)["stdout"])
        ets_coredumps_created = self.check_coredumps(app_name=self.ETS_APP_NAME)
        self.assertTrue(ets_coredumps_created, Severity.BLOCKER, f"Checking that coredumps files of ets were created")

        self.startTestStep("Get pid of sysmon application to be killed")
        sysmon_pid = self.get_process_id(app_name=self.SYSMON_APP_NAME)
        self.assertTrue(sysmon_pid != -1, Severity.MAJOR, "Check sysmon application is running")
        self.startTestStep("Kill sysmon application")
        application_is_killed = self.kill_application(app_name=self.SYSMON_APP_NAME, signal="SIGABRT")
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check the kill command is executed")
        self.startTestStep("Wait for coredumps creation")
        self.sleep_for(self.default_dumper_timeout)
        self.startTestStep("Check sysmon application is killed")
        sysmon_still_running = self.check_application_is_started(app_name=self.SYSMON_APP_NAME)
        self.assertTrue(not sysmon_still_running, Severity.MAJOR, "Check sysmon application is killed")
        self.startTestStep("Get coredumps names using ls command")
        logger.info(self.ssh_manager.executeCommandInTarget(command=f"ls -la {self.CoreDumps_Path}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)["stdout"])
        sysmon_coredumps_created = self.check_coredumps(app_name=self.SYSMON_APP_NAME)
        ets_coredumps_created = self.check_coredumps(app_name=self.ETS_APP_NAME)
        self.expectTrue(sysmon_coredumps_created, Severity.BLOCKER, f"Checking that coredumps files of sysmon were created properly")
        self.expectTrue(ets_coredumps_created, Severity.BLOCKER, f"Checking that coredumps files of ets were not deleted")

    def tearDown(self):
        self.setPostcondition("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
