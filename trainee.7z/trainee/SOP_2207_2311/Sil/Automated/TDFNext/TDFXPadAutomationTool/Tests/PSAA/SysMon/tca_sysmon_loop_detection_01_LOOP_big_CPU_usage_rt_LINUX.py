from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_loop_detection_01_LOOP_big_CPU_usage_rt_LINUX(testfixture_PSAA_SysMon):
    TEST_ID = "PSAA/sysmon/tca_sysmon_loop_detection_01_LOOP_big_CPU_usage_rt_LINUX"
    REQ_ID = ["/item/5979602", "/item/5910322"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports real time process loop that exceed the configured CPU threshold"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.loop_detection_rt_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.Search_msg_array = self.statistic_data["LOOP"]["RT"]["Search_msg_array"]
        logger.info(f"Search message array = {self.Search_msg_array}")
        self.assertTrue(self.Search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.loop_detection_rt_context_id)

    def test_tca_sysmon_loop_detection_01_LOOP_big_CPU_usage_rt_LINUX(self):
        self.startTestStep("Execute yes command to made NRT loop")
        command_is_executed = self.ssh_manager.executeCommandInTarget(command=f"yes > /dev/null &", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(command_is_executed["exec_recv"] == 0, Severity.MAJOR, "Check that yes command is executed")

        self.dlt_manager.start_monitoring("SRR-DLT")

        command_is_running = self.ssh_manager.executeCommandInTarget(command="ps axw | grep yes", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(command_is_running["stdout"] != "", Severity.MAJOR, "Check that yes command is running")

        self.startTestStep("chrt -r -p 1 yes")
        real_time_change = self.ssh_manager.executeCommandInTarget(command="chrt -r -p 1 $(pidof yes)", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(real_time_change['exec_recv'] == 0, Severity.MAJOR, "change yes to real time process")

        command_is_running = self.ssh_manager.executeCommandInTarget(command="ps axw | grep yes", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(command_is_running["stdout"] != "", Severity.MAJOR, "Check that yes command is running")

        self.sleep_for(self.wait_RT_precess_report_ms)

        self.startTestStep("Wait the configured time for loop detection * 2")
        self.sleep_for(self.time_interval * 2 * 1000)

        self.startTestStep("Get LOOP  DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.Search_msg_array)
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that DLT message of LOOP exist")

        message = self.get_real_time_messages(messages=messages)
        self.assertTrue(message != -1, Severity.MAJOR, "Check that RT DLT message of LOOP exist")

        self.startTestStep("Get thread_name with RT exists in the message")
        in_hdr_errors = self.get_statistic_value(message=message, statistic_path="LOOP.RT.Statistics.thread_name")
        self.expectTrue(in_hdr_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that DLT message contains thread name and reported as real time thread")

        self.startTestStep("Get used_CPU_time value")
        used_CPU_time = self.get_statistic_value(message=message, statistic_path="LOOP.RT.Statistics.used_CPU_time")
        self.expectTrue(used_CPU_time != self.INVALID_VALUE, Severity.MAJOR, "Check that used_CPU_time is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
