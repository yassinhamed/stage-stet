from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter_ProxyApp import *


class tca_PSAA_UptimeCounter_aracom_Reset_Negative(testfixture_PSAA_UptimeCounter_ProxyApp):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_aracom_Reset_Negative"
    REQ_ID = ["/item/6233416"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check UptimeCounter component counters values after reset using ara::com interface"
    STATUS = "Ready"
    OS = ["QNX"]

    def setUp(self):
        self.setPrecondition("Create backup of exec_config_file")
        self.create_uptime_counter_exec_config_backup()

        self.setPrecondition("Changing uptime_counter cyclicity under exec_config file to 10s")
        self.change_cyclicity(new_cyclicity=self.Cyclicity_10s_MS)

        self.setPrecondition("Resetting ECU with PowerSupply ")
        self.bus.power_supply.power_on_reset(downtime=self.PP_SHUTDOWN_TIMEOUT_MS,startup_time=self.PP_STARTUP_TIMEOUT_MS)

        self.setPrecondition("Check Ecus")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUS are correctly reset")

        self.setPrecondition("Check Uptime Counter is running")
        Check_UTC = self.check_application_is_started(app_name=self.UPTIME_COUNTER_APP_NAME)
        self.expectTrue(Check_UTC, Severity.MAJOR, "Check The Uptime Counter was started")


        self.setPrecondition("Get cyclicity from exec_config file")
        cyclicity = self.get_cyclicity_from_exec_config()
        logger.info(f"cyclicity_value: {cyclicity}")
        self.assertTrue(cyclicity == self.Cyclicity_10s_MS, Severity.MAJOR,"Checking cyclicity is successfully changed")

        self.setPrecondition("Load FuSa Library")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.FUSA.value)

    def test_tca_PSAA_UptimeCounter_aracom_Reset_Negative(self):
        self.startTestStep("Get startup cycles counter value")
        exit_code = self.proxy_app_manager.FUSA_comm.get_utc_num_operating_startup_cycles()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR,"Check SUCCESS ExitCode recieved from ProxyApp")
        first_startup_cycles = self.proxy_app_manager.FUSA_comm.utc_operatingStartupCyclesNum
        logger.info(f"first_startup_cycles= {first_startup_cycles}")

        self.expectTrue(int(first_startup_cycles) != 0, Severity.BLOCKER, "Check that startup cycles counter value is different to 0")

        self.startTestStep("Get Operating time in milliseconds")
        exit_code = self.proxy_app_manager.FUSA_comm.get_utc_operating_time()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR,"Check SUCCESS ExitCode recieved from ProxyApp")
        first_operating_time = self.proxy_app_manager.FUSA_comm.utc_operatingTimeMS
        logger.info(f"first_operating_time= {first_operating_time}")

        self.expectTrue(int(first_operating_time) != 0 , Severity.BLOCKER,"Check that OperatingTime counter value is different to 0")

        self.startTestStep("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.startTestStep("Getting startup cycles counter value from kvs file")
        first_StartupCycles_kvs = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.StartupCycles_counter)
        logger.info(f"first_StartupCycles_kvs_value: {first_StartupCycles_kvs}")

        self.expectTrue(int(first_StartupCycles_kvs) != 0, Severity.BLOCKER,"Check that startup cycles counter value is different to 0")

        self.startTestStep("Getting operating time Counter value from kvs")
        first_OperatingTime_kvs = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.OperatingTime_counter)
        logger.info(f"first_OperatingTime_kvs_value: {first_OperatingTime_kvs}")

        self.expectTrue(int(first_OperatingTime_kvs) != 0 , Severity.BLOCKER,"Check that OperatingTime counter value is different to 0")

        self.startTestStep("Getting UpTime Counter value from kvs")
        First_UpTimeInMilliSeconds = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.UpTimeCounter)
        logger.info(f"UpTimeInMilliSeconds_value: {First_UpTimeInMilliSeconds}")

        self.expectTrue(int(First_UpTimeInMilliSeconds) != 0, Severity.BLOCKER, "Check that UpTimeInMilliSeconds counter value is different to 0")

        self.startTestStep("Get unexpected reset counter value from kvs file")
        First_NumOfUnexpectedResets = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.Unexpected_reset_counter)
        logger.info(f"First_NumOfUnexpectedResets_value: {First_NumOfUnexpectedResets}")

        self.expectTrue(int(First_NumOfUnexpectedResets) != 0, Severity.BLOCKER, "Check that startup cycles counter value is different to 0")


        self.startTestStep("Reset Operating time and startup cycles counters values using ara::com interface")
        exit_code = self.proxy_app_manager.FUSA_comm.reset_utc_operationg_statistics()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR,"Check SUCCESS ExitCode recieved from ProxyApp")


        self.startTestStep("Wait for cyclicity : 10s")
        self.sleep_for(self.Wait_for_counters_incrementation_MS)


        self.startTestStep("Get startup cycles counter value")
        exit_code = self.proxy_app_manager.FUSA_comm.get_utc_num_operating_startup_cycles()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR,"Check SUCCESS ExitCode recieved from ProxyApp")
        Second_startup_cycles = self.proxy_app_manager.FUSA_comm.utc_operatingStartupCyclesNum
        logger.info(f"second_startup_cycles= {Second_startup_cycles}")

        self.expectTrue(int(Second_startup_cycles) == 0, Severity.BLOCKER, "Check that startup cycles counter value is reset")

        self.startTestStep("Get Operating time in milliseconds")
        exit_code = self.proxy_app_manager.FUSA_comm.get_utc_operating_time()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR,"Check SUCCESS ExitCode recieved from ProxyApp")
        second_operating_time = self.proxy_app_manager.FUSA_comm.utc_operatingTimeMS
        logger.info(f"second_operating_time= {second_operating_time}")

        self.expectTrue(int(second_operating_time) < 1.2 * int(self.Cyclicity_10s_MS), Severity.BLOCKER, "Check that operating time counter value is reset")

        self.startTestStep("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.startTestStep("Getting operating time Counter value from kvs")
        second_OperatingTime_kvs = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.OperatingTime_counter)
        logger.info(f"second_OperatingTime_kvs_value: {second_OperatingTime_kvs}")

        self.expectTrue(int(second_OperatingTime_kvs) < 1.2 * int(self.Cyclicity_10s_MS), Severity.BLOCKER, "Check that OperatingTime counter value from kvs is reset")


        self.startTestStep("Getting startup cycles counter value from kvs file")
        Second_StartupCycles_kvs = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.StartupCycles_counter)
        logger.info(f"Second_StartupCycles_kvs_value: {Second_StartupCycles_kvs}")

        self.expectTrue(int(Second_StartupCycles_kvs) == 0, Severity.BLOCKER, "Check that startup cycles counter value is equal to 0")

        self.startTestStep("Getting UpTime Counter value from kvs")
        second_UpTimeInMilliSeconds = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.UpTimeCounter)
        logger.info(f"second_UpTimeInMilliSeconds_value: {second_UpTimeInMilliSeconds}")

        self.expectTrue(int(second_UpTimeInMilliSeconds) > int(First_UpTimeInMilliSeconds), Severity.BLOCKER, "Check that UpTimeInMilliSeconds counter value is updated")

        self.startTestStep("Getting unexpected reset counter value from kvs file")
        Second_NumOfUnexpectedResets = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.Unexpected_reset_counter)
        logger.info(f"Second_NumOfUnexpectedResets_value: {Second_NumOfUnexpectedResets}")

        self.expectTrue(int(Second_NumOfUnexpectedResets) == int(First_NumOfUnexpectedResets), Severity.BLOCKER, "Check that NumOfUnexpectedResets counter value is not reset")

    def tearDown(self):
        self.setPostcondition("Reverting uptime_counter exec_config file ")
        self.set_default_uptime_counter_exec_config()

        self.setPostcondition("Unload FuSa Library")
        self.proxy_app_manager.remove_proxy_app_lib(libName.FUSA.value)

        self.setPostcondition("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.setPostcondition("Check uptime_counter exec_config file is reverted")
        cyclicity = self.get_cyclicity_from_exec_config()
        logger.info(f"cyclicity_value: {cyclicity}")
        self.expectTrue(cyclicity == self.Cyclicity_60m_MS, Severity.MAJOR,"Checking cyclicity is successfully reverted")
