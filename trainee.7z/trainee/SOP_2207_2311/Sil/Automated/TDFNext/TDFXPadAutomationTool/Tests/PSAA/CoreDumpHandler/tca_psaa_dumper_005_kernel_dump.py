from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_005_kernel_dump(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_005_kernel_dump"
    REQ_ID = ["/item/1736864","/item/576342","/item/795709"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps creation by kernel pannic"
    STATUS = "Ready"
    OS = ['LINUX']


    def setUp(self):
        pass

    def test_tca_psaa_dumper_005_kernel_dump(self):

        self.startTestStep("Perform kernel panic")
        self.ssh_manager.executeCommandInTargetNoWait(command=self.kernel_panic_command,
                                                      timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                      ip_address=self.PP_IP)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)

        self.startTestStep("Get coredumps")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"ls -la {self.CoreDumps_Path}/kernel | grep -c kdump.vmcore",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Checking that the coredumps were generated")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

    def tearDown(self):
        pass
