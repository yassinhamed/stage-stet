from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_psaa_router_021_non_verbose_msg_extended_header(testfixture_PSAA_Datarouter):

    TEST_ID = "PSAA\tca_psaa_router_021_non_verbose_msg_extended_header"
    REQ_ID = ["/item/6213539"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check non verbose message without extended header"
    OS = ['LINUX','QNX']
    STATUS = "Ready"

    def setUp(self):

        self.setPrecondition("Apply filter to enable non_verbose sniffing")
        self.dlt_manager.apply_filter(nonVerbose=True)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.setPrecondition("Apply filter to disable verbose sniffing")
        self.dlt_manager.apply_filter(verbose=False)
        self.setPrecondition("Apply filter ECU_ID")
        self.dlt_manager.apply_filter(ecu_id=self.PP_ECUID)
        self.setPrecondition("Start monitoring")
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_router_021_non_verbose_msg_extended_header(self):

        self.startTestStep("Wait 1 second to fill the queue with random non-verbose messages")
        self.sleep_for(1000)
        self.startTestStep("Get all messages in the queue")
        dlt_messages = self.dlt_manager.get_messages(ecu_id=self.PP_ECUID)
        self.assertTrue(len(dlt_messages) > 0, Severity.BLOCKER, "Check that at least one message exist in the queue")
        non_verbose_message = self.without_extended_header(dlt_messages=dlt_messages)
        self.assertTrue(non_verbose_message, Severity.BLOCKER,"Check non verbose message without extended header")


    def tearDown(self):

        self.setPostcondition("Clear all filters")
        self.dlt_manager.clear_all_filters()
        self.setPostcondition("Stop monitoring")
        self.dlt_manager.stop_monitoring()
