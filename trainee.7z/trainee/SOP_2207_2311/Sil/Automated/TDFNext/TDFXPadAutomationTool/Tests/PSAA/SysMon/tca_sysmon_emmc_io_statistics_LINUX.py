from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_emmc_io_statistics_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_emmc_io_statistics_LINUX"
    REQ_ID = ["/item/5888380", "/item/5888677"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports EMMC IO statistics"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.emmc_health_report_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["EMMC"]["IO statistics LINUX"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.emmc_health_report_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_emmc_io_statistics_LINUX(self):
        self.startTestStep("Wait one cycle * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get eMMC IO statistics DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that eMMC IO statistics DLT messages are available")

        self.startTestStep("Get READ_IOS value")
        READ_IOS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.READ_IOS")
        self.expectTrue(READ_IOS != self.INVALID_VALUE, Severity.MAJOR, "Check that READ_IOS is reported")

        self.startTestStep("Get READ_MERGES value")
        READ_MERGES = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.READ_MERGES")
        self.expectTrue(READ_MERGES != self.INVALID_VALUE, Severity.MAJOR, "Check that READ_MERGES is reported")

        self.startTestStep("Get READ_SECTORS value")
        READ_SECTORS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.READ_SECTORS")
        self.expectTrue(READ_SECTORS != self.INVALID_VALUE, Severity.MAJOR, "Check that READ_SECTORS is reported")

        self.startTestStep("Get READ_TICKS value")
        READ_TICKS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.READ_TICKS")
        self.expectTrue(READ_TICKS != self.INVALID_VALUE, Severity.MAJOR, "Check that READ_TICKS is reported")

        self.startTestStep("Get WRITE_IOS value")
        WRITE_IOS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.WRITE_IOS")
        self.expectTrue(WRITE_IOS != self.INVALID_VALUE, Severity.MAJOR, "Check that WRITE_IOS is reported")

        self.startTestStep("Get WRITE_MERGES value")
        WRITE_MERGES = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.WRITE_MERGES")
        self.expectTrue(WRITE_MERGES != self.INVALID_VALUE, Severity.MAJOR, "Check that WRITE_MERGES is reported")

        self.startTestStep("Get WRITE_SECTORS value")
        WRITE_SECTORS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.WRITE_SECTORS")
        self.expectTrue(WRITE_SECTORS != self.INVALID_VALUE, Severity.MAJOR, "Check that WRITE_SECTORS is reported")

        self.startTestStep("Get WRITE_TICKS value")
        WRITE_TICKS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.WRITE_TICKS")
        self.expectTrue(WRITE_TICKS != self.INVALID_VALUE, Severity.MAJOR, "Check that WRITE_TICKS is reported")

        self.startTestStep("Get IN_FLIGTH value")
        IN_FLIGTH = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.IN_FLIGTH")
        self.expectTrue(IN_FLIGTH != self.INVALID_VALUE, Severity.MAJOR, "Check that IN_FLIGTH is reported")

        self.startTestStep("Get IO_TICKTS value")
        IO_TICKTS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.IO_TICKTS")
        self.expectTrue(IO_TICKTS != self.INVALID_VALUE, Severity.MAJOR, "Check that IO_TICKTS is reported")

        self.startTestStep("Get TIME_IN_QUEUE value")
        TIME_IN_QUEUE = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.TIME_IN_QUEUE")
        self.expectTrue(TIME_IN_QUEUE != self.INVALID_VALUE, Severity.MAJOR, "Check that TIME_IN_QUEUE is reported")

        self.startTestStep("Get DISCARD_IOS value")
        DISCARD_IOS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.DISCARD_IOS")
        self.expectTrue(DISCARD_IOS != self.INVALID_VALUE, Severity.MAJOR, "Check that DISCARD_IOS is reported")

        self.startTestStep("Get DISCARD_MERGES value")
        DISCARD_MERGES = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.DISCARD_MERGES")
        self.expectTrue(DISCARD_MERGES != self.INVALID_VALUE, Severity.MAJOR, "Check that DISCARD_MERGES is reported")

        self.startTestStep("Get DISCARD_SECTORS value")
        DISCARD_SECTORS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.DISCARD_SECTORS")
        self.expectTrue(DISCARD_SECTORS != self.INVALID_VALUE, Severity.MAJOR, "Check that DISCARD_SECTORS is reported")

        self.startTestStep("Get DISCARD_TICKS value")
        DISCARD_TICKS = self.get_statistic_value(message=messages[0], statistic_path="EMMC.IO statistics LINUX.Statistics.DISCARD_TICKS")
        self.expectTrue(DISCARD_TICKS != self.INVALID_VALUE, Severity.MAJOR, "Check that DISCARD_TICKS is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
