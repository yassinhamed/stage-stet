from Tests.PSAA.Resource_Manager.testfixture_PSAA_RM import *


class tca_mmr_exposed_file_gsysvtmsk(testfixture_PSAA_RM):

    TEST_ID = "PSAA\Ressource_Manager\tca_mmr_exposed_file_gsysvtmsk"
    REQ_ID = ['/item/7129921']
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    PRIORITY = "Critical"
    DESCRIPTION = "Check that the resource managers shall expose a /dev/bar/glreg_gsysevtmsk  file"
    STATUS = "Ready"
    OS = ['QNX']


    def setUp(self):
        pass

    def test_tca_mmr_exposed_file_gsysvtmsk(self):
        self.startTestStep("Check /dev/bar/glreg_gsysevtmsk exist")

        result = self.ssh_manager.executeCommandInTarget(command=f"if [ -e /dev/bar/glreg_gsysevtmsk ]; then echo file exists; fi", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(result['stdout'].strip() == "file exists", Severity.BLOCKER, "Check that /dev/bar/glreg_gsysevtmsk  exists")


    def tearDown(self):
        pass
