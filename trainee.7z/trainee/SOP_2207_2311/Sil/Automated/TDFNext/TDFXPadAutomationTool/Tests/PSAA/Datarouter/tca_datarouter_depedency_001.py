from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_datarouter_depedency_001(testfixture_PSAA_Datarouter):

    TEST_ID = "Datarouter\tca_datarouter_depedency_001"
    REQ_ID = ["/item/1573713", "/item/145159"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        pass

    def test_tca_datarouter_depedency_001(self):
        self.startTestStep("Get the PID of EXECUTION_MANAGER")
        exec_manager_pid = self.get_process_id(app_name=self.EXECUTION_MANAGER_APP_NAME)
        self.expectTrue(str(exec_manager_pid) != "", Severity.BLOCKER, "Checking that the PID of EXECUTION_MANAGER was returned successfully")

        self.startTestStep("Kill EXECUTION_MANAGER")
        application_is_killed = self.kill_application(app_name=self.EXECUTION_MANAGER_APP_NAME,signal=self.killall_options["SIGKILL"])
        self.expectTrue(application_is_killed, Severity.MAJOR, "Checking that the execution manager was killed")

        self.startTestStep("Get the PID of EXECUTION_MANAGER")
        exec_manager_pid_postkill = self.get_process_id(app_name=self.EXECUTION_MANAGER_APP_NAME)
        self.expectTrue(exec_manager_pid_postkill != exec_manager_pid, Severity.BLOCKER, "Checking that the EXECUTION_MANAGER was terminated")

        self.startTestStep("Get the PID of datarouter")
        datarouter_pid = self.get_process_id(app_name=self.DATA_ROUTER_APP_NAME, exclude=True, exclude_app_name="conf")
        self.expectTrue(datarouter_pid != -1, Severity.BLOCKER, "Checking that the pid of datarouter was returned successfully")

    def tearDown(self):
        pass
