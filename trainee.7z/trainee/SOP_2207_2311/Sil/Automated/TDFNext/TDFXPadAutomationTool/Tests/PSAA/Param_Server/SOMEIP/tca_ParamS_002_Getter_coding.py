from Tests.PSAA.Param_Server.testfixture_PSAA_param_server import *


class tca_ParamS_002_Getter_coding(testfixture_PSAA_param_server):

    TEST_ID = "ParamServer\tca_ParamS_002_Getter_coding"
    REQ_ID = ["/item/53142", "/item/53153", "/item/727611", "/item/1605533"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    field_depends_on_coding = True

    def setUp(self):
        pass

    def test_Getter_coding(self):

        self.someip_controller.send_request("TestEquipmentIntern", service_id=self.AdpParameters_service_ID, instance_id=self.AdpParameters_instances[self.PP_NAME],
                                            method_id=self.someipIds['getterID'], interface_version=1, is_TCP=False)

        self.sleep_for(self.GETTER_RESPONSE_TIMEOUT_MS)

        someip_response_messages = self.get_someip_messages_from_queue(method_id=self.someipIds['getterID'])

        self.expectTrue(len(someip_response_messages) > 0, Severity.BLOCKER, "Check that a response of the getter request is received")
        self.expectTrue(len(someip_response_messages) == 1, Severity.MAJOR, "Check that exactly 1 response of the getter request is received")

        messages_count, dlt_messages = self.dlt_manager.get_messages(searchMsg=self.DLT_message_GET)
        self.expectTrue(messages_count > 0, Severity.BLOCKER, "Check that DLT Get message exists")
        self.expectTrue(messages_count == 1, Severity.BLOCKER, "Check that only 1 DLT Get message exists")

        getter_response = someip_response_messages[-1].payload
        logger.info(f"Response payload of the getter = {getter_response}")

        getter_response_size = len(getter_response)
        logger.info(f"The size of the received Getter response = {getter_response_size}")
        self.assertTrue(getter_response_size == self.field_size, Severity.BLOCKER, "Check that the payload size of the getter response is correct.")

        parsed_getter_response = self.parse_field_someip_payload(payload=getter_response, field_structure=self.field_structure)
        logger.info(f"Parsed Getter response :\n{json.dumps(parsed_getter_response, indent=4)}")

        parameter_values_are_correct = self.check_if_all_parameter_values_are_default(parsed_payload=parsed_getter_response, coding_value=self.cafd_initial_values[self.coding_name].value)
        self.assertTrue(parameter_values_are_correct, Severity.BLOCKER, "Check that the parameter Values equal default value if exist else initValue")

        new_random_coding_value = self.get_new_random_coding_value(coding_values=self.coding_dict['values'], inital_value=self.cafd_initial_values[self.coding_name].value)

        self.fdl_coder.add_caf_parameter(caf_name=self.coding_name, caf_value=new_random_coding_value, caf_value_interpretation="OFF")
        result = self.fdl_coder.start_fdl_coding(controller=self.PP_CAF_NAME, diag_addr=self.PP_DIAG_ADR)
        self.assertTrue(result, Severity.BLOCKER, f"Checking that fdl coding was done successfully with random new value for {self.coding_name} with value {new_random_coding_value}")
        self.sleep_for(self.FDL_CODING_TIMEOUT_MS)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)

        new_cafd = self.fdl_coder.read_cafd(controller=self.PP_CAF_NAME)
        logger.info(f"Read new value of {self.coding_name} returns {new_cafd[self.coding_name].value} after the CAFD flashing")
        self.assertTrue(int(new_cafd[self.coding_name].value) == int(new_random_coding_value), Severity.BLOCKER,
                        "Checking that the expected caf param was coded properly with the new value")

        self.someip_manager.reset(ecu="TestEquipmentIntern")
        self.dlt_manager.clear_all_dlt_messages()

        self.someip_controller.send_request("TestEquipmentIntern", service_id=self.AdpParameters_service_ID, instance_id=self.AdpParameters_instances[self.PP_NAME],
                                            method_id=self.someipIds['getterID'], interface_version=1, is_TCP=False)

        self.sleep_for(self.GETTER_RESPONSE_TIMEOUT_MS)

        someip_response_messages = self.get_someip_messages_from_queue(method_id=self.someipIds['getterID'])

        self.expectTrue(len(someip_response_messages) > 0, Severity.BLOCKER, "Check that a response of the getter request is received (after CAFD flashing)")
        self.expectTrue(len(someip_response_messages) == 1, Severity.MAJOR, "Check that exactly 1 response of the getter request is received (after CAFD flashing)")

        messages_count, dlt_messages = self.dlt_manager.get_messages(searchMsg=self.DLT_message_GET)
        self.expectTrue(messages_count > 0, Severity.BLOCKER, "Check that DLT Get message exists (after CAFD flashing)")
        self.expectTrue(messages_count == 1, Severity.BLOCKER, "Check that only 1 DLT Get message exists (after CAFD flashing)")

        getter_response = someip_response_messages[-1].payload
        logger.info(f"Response payload of the getter = {getter_response}")

        getter_response_size = len(getter_response)
        logger.info(f"The size of the received Getter response = {getter_response_size}")
        self.assertTrue(getter_response_size == self.field_size, Severity.BLOCKER, "Check that the payload size of the getter response is correct.(after CAFD flashing)")

        parsed_getter_response = self.parse_field_someip_payload(payload=getter_response, field_structure=self.field_structure)
        logger.info(f"Parsed Getter response :\n{json.dumps(parsed_getter_response, indent=4)}")

        parameter_values_are_correct = self.check_if_all_parameter_values_are_default(parsed_payload=parsed_getter_response, coding_value=new_random_coding_value)
        self.assertTrue(parameter_values_are_correct, Severity.BLOCKER, "Check that the parameter Values equal default value if exist else initValue (after CAFD flashing)")

    def tearDown(self):
        self.fdl_coder.add_caf_parameter(caf_name=self.coding_name, caf_value=self.cafd_initial_values[self.coding_name].value, caf_value_interpretation="OFF")
        result = self.fdl_coder.start_fdl_coding(controller=self.PP_CAF_NAME, diag_addr=self.PP_DIAG_ADR)
        self.expectTrue(result, Severity.BLOCKER, "Checking that default fdl coding was done successfully in the TearDown")
        self.sleep_for(self.FDL_CODING_TIMEOUT_MS)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)

        reverted_cafd = self.fdl_coder.read_cafd(controller=self.PP_CAF_NAME)
        logger.info(f"value of {self.coding_name} returns {reverted_cafd[self.coding_name].value} after the CAFD flashing with intial values")
        self.expectTrue(int(reverted_cafd[self.coding_name].value) == int(self.cafd_initial_values[self.coding_name].value), Severity.BLOCKER,
                        "Checking that the expected caf param was coded properly with the initial value in the TearDown")

