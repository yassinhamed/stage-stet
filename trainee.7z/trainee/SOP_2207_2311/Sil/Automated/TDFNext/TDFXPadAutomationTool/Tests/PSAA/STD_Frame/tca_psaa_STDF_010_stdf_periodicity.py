from Tests.PSAA.STD_Frame.testfixture_PSAA_STDFrame import *


class tca_psaa_STDF_010_stdf_periodicity(testfixture_PSAA_STDFrame):

    TEST_ID = "PSAA\tca_psaa_STDF_010_stdf_periodicity"
    REQ_ID = ["/item/2175805"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check cyclicity of stdf non verbose messages"
    OS = ['LINUX','QNX']
    STATUS = "Ready"


    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_HWVersion)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_STDF_010_stdf_periodicity(self):
        self.startTestStep("Get non verbose message 'HW_version_msg_short_name'")
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.HW_version_msg_short_name, sender=self.PP_ECUID,
                                                             filter_attributes=None)
        self.sleep_for(self.wait_for_STDF_dlt_message)
        self.dlt_manager.stop_capturing_non_verbose_message()
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check the non verbose message 'HW_version_msg_short_name' was received")
        self.print_dlt_messages(dlt_messages)
        result=self.dlt_manager.check_cyclicity(messages_array=dlt_messages,time_interval=self.stdf_periodicity_time_interval,tolerance_percentage=self.periodicity_tolerance_percentage)
        self.expectTrue(result, Severity.BLOCKER,"Check the cyclicity is okay ")

    def tearDown(self):
        pass
