from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_network_05_NETP_TCP_statistics(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_network_05_NETP_TCP_statistics"
    REQ_ID = ["/item/5909527"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that the NETP TCP reports contains all required statistics"
    OS = ['LINUX', 'QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.network_protocols_statistics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["Network"]["TCP"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.network_protocols_statistics_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_network_05_NETP_TCP_statistics(self):
        self.startTestStep("Wait cycle of NETP * 2")
        self.sleep_for(self.time_interval * 2)
        self.startTestStep("Get NETS DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that NETP DLT messages are available")

        self.startTestStep("Get cur_estab value")
        cur_estab = self.get_statistic_value(message=messages[0], statistic_path="Network.TCP.Statistics.cur_estab")
        self.expectTrue(cur_estab != self.INVALID_VALUE, Severity.MAJOR, "Check that cur_estab is reported")

        self.startTestStep("Get in_csum_errors value")
        in_csum_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.TCP.Statistics.in_csum_errors")
        self.expectTrue(in_csum_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that in_csum_errors is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
