from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_DTCSender(testfixture_PSAA):
    Config_file_name = "security_events.json"
    Config_file_path = "/opt/log_collector/etc/"
    logLevel = "kVerbose"
    searchMessage = "Hello"
    mpad_primary_DTC = "0x022292"
    mpad_secondary_DTC = "0x482ea9"
    high_primary_DTC = "0x029192"
    high_secondary_DTC= "0x808b10"
    context_Id_Linux = "SYSL"
    context_Id_QNX = "SLOG"
    Adapater_names = ["Log_CM", "Stimulation"]
    wait_for_slog_message_to_be_logged = 3000
    wait_trigger_to_be_sent_after_dtc_clear = 25000
    wait_trigger_to_be_sent = 30000
    wait_trigger_to_be_sent_without_debounce_time = 10000
    wait_between_two_triggers = 30000
    wait_tshark_to_start = 10000
    wait_tshark_to_stop = 3000
    wait_DTC_to_be_set = 10000
    TOKEN_STATUS_UPDATE_TIMEOUT_MS = 3000
    DTC_SENDER_UDP_MESSAGE = {

        "DTC_ID": "",
        "New_Status": "",
        "Old_Status": ""

    }

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA setUpclsss")
        cls.ssh_manager.executeCommandInTarget("ls /opt/DtcStatusSender/bin")
        cls.ssh_manager.executeCommandInTarget("ls /opt/DtcStatusSender/etc")

        if cls.os_name=="Linux":
            cls.context_Id=cls.context_Id_Linux
        else:
            cls.context_Id = cls.context_Id_QNX
        cls.ssh_manager.executeCommandInTarget(
            command=f"cp -f {cls.Config_file_path + cls.Config_file_name} /persistent/",
            timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        cls.ssh_manager.downloadFileFromTarget(cls.Config_file_name, cls.Config_file_path,
                                               OutputPathManager.get_global_path(), ip_address=cls.PP_IP)
        cls.logLevel = cls.json_manager.findNodeFromJsonFile(
            filePath=f"{cls.Config_file_path}logging.json", nodePath="logLevel",
            use_cache=False, delete_cache=False, upload_file=False)
        cls.json_manager.updateNodeIntoJsonFile(filePath=f"{cls.Config_file_path}logging.json",
                                                nodePath="logLevel",
                                                value="kVerbose", use_cache=False, delete_cache=True, upload_file=True)
        cls.diag_manager.start()
        cls.diag_manager.ecu_reset(target=cls.PP_DIAG_ADR, reset_duration=cls.PP_RESET_TIMEOUT_S)
        cls.diag_manager.restart()
        cls.check_ECUs()
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_tests_group_path(),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA tearDownclsss")
        cls.json_manager.updateNodeIntoJsonFile(filePath=f"{cls.Config_file_path}logging.json",
                                                nodePath="logLevel",
                                                value=cls.logLevel, use_cache=False, delete_cache=True,
                                                upload_file=True)
        cls.ssh_manager.executeCommandInTarget(
            command=f"cp -f /persistent/{cls.Config_file_name} {cls.Config_file_path}",
            timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        cls.ssh_manager.executeCommandInTarget(command=f"chmod 644 {cls.Config_file_path + cls.Config_file_name}",
                                               timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
        result = cls.ssh_manager.executeCommandInTarget(
            command=f'stat -c "%a" {cls.Config_file_path + cls.Config_file_name}', timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
            ip_address=cls.PP_IP)
        cls.expectTrue('644' in result['stdout'], Severity.MAJOR,
                       f"False Permission, Permission = {result['stdout']}")
        cls.diag_manager.start()
        cls.diag_manager.ecu_reset(target=cls.SC_DIAG_ADR, reset_duration=cls.SC_RESET_TIMEOUT_MS)
        cls.sleep_for(cls.PP_RESET_TIMEOUT_MS)
        cls.diag_manager.stop()
        cls.check_ECUs()

    def setUp(self):
        grep_LogC = self.check_application_is_started(app_name=self.LOG_COLLECTOR_APP_NAME)
        self.expectTrue(grep_LogC, Severity.MAJOR, "Check The application was started")

    def tearDown(self):
        self.ssh_manager.executeCommandInTarget(
            command=f"cp -f /persistent/{self.Config_file_name} {self.Config_file_path}",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.ssh_manager.executeCommandInTarget(command=f"chmod 644 {self.Config_file_path + self.Config_file_name}",
                                               timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_MS)
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)
        self.diag_manager.restart()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        self.sleep_for(self.wait_trigger_to_be_sent_after_dtc_clear)
        self.check_ECUs()
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_test_case_path(),check_empty=False,ip_address=self.PP_IP,ignored_files=["currentswversion", "tmp"])

    def setDTC(self):
        grep_LogC = self.check_application_is_started(app_name=self.LOG_COLLECTOR_APP_NAME)
        self.expectTrue(grep_LogC, Severity.MAJOR, "Check The application was started")
        if self.os_name == "Linux":
            self.setDTC_Linux()
        else:
            self.setDTC_QNX()

        number, messages = self.dlt_manager.wait_for_message(ecuId=self.PP_ECUID, appId=self.LOG_COLLECTOR_APP_ID,contextId=self.context_Id,search_message=[self.searchMessage])
        self.expectTrue(number > 0, Severity.BLOCKER, f" messages are not being forwarded with {self.context_Id} context ID")

    def setDTC_Linux(self):
        self.ssh_manager.executeCommandInTarget(command=f'logger –t syslog "{self.searchMessage}"',
                                                timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                ip_address=self.PP_IP)
        Message = self.ssh_manager.executeCommandInTarget(
            command=f'journalctl _TRANSPORT=syslog | grep "{self.searchMessage}"',
            timeout=self.SSH_CONNECTION_TIMEOUT_MS,
            ip_address=self.PP_IP)
        self.expectTrue(self.searchMessage in str(Message),
                        Severity.MAJOR, "The log message was not logged")
    def setDTC_QNX(self):
        res = self.ssh_manager.executeCommandInTarget(command=f'echo "{self.searchMessage}" > /dev/slog2/stdout',
                                                      timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(res["exec_recv"] == 0, Severity.MAJOR, "Check command executed")
        self.sleep_for(self.wait_for_slog_message_to_be_logged)
        Message = self.ssh_manager.executeCommandInTarget(command=f'slog2info | grep "{self.searchMessage}"',
                                                          timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(self.searchMessage in str(Message),
                        Severity.MAJOR, "The log message was not logged")
        
    def setDTC_with_delay(self):
        if self.os_name == "Linux":
            self.ssh_manager.executeCommandInTarget(command=f'sleep 45 ; logger –t syslog "{self.searchMessage}"',
                                               timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                               ip_address=self.PP_IP)
        else:
            self.ssh_manager.executeCommandInTarget(command=f'sleep 80 ; echo "{self.searchMessage}" > /dev/slog2/stdout',
                                               timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                               ip_address=self.PP_IP)

    def checkPayload(self, payload_origin, DTC=mpad_primary_DTC):
        payload = [payload_origin[i:i + 2] for i in range(0, len(payload_origin), 2)]
        self.DTC_SENDER_UDP_MESSAGE['DTC_ID'] = f"0x{payload[2]}{payload[1]}{payload[0]}"
        self.DTC_SENDER_UDP_MESSAGE['New_Status'] = payload[4]
        self.DTC_SENDER_UDP_MESSAGE['Old_Status'] = payload[5]
        logger.info("packets: " + str(self.DTC_SENDER_UDP_MESSAGE['DTC_ID']))
        logger.info("packets: " + str(self.DTC_SENDER_UDP_MESSAGE['New_Status']))
        logger.info("packets: " + str(self.DTC_SENDER_UDP_MESSAGE['Old_Status']))
        self.expectTrue(self.DTC_SENDER_UDP_MESSAGE['DTC_ID'] == DTC, Severity.BLOCKER,
                        "no packet with matching filter were captured")

        self.expectTrue(self.DTC_SENDER_UDP_MESSAGE['New_Status'] == "2f", Severity.BLOCKER,
                        "no packet with matching filter were captured")
        self.expectTrue(
            (self.DTC_SENDER_UDP_MESSAGE['Old_Status'] == "00") or (self.DTC_SENDER_UDP_MESSAGE['Old_Status'] == "50"),
            Severity.BLOCKER,
            "no packet with matching filter were captured")

    def initiateConfigFile_Linux(self, memory_type):
        for i in range(0, 9):
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath=f"EventsConfigs[{i}].LogDlt",
                                                     value="No", use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                 nodePath="EventsConfigs[7].MessageRegex",
                                                 value=self.searchMessage, use_cache=False, delete_cache=False,
                                                 upload_file=True)
        if memory_type == "primary":
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[7].SetDTC022292",
                                                     value="Permanent", use_cache=False, delete_cache=False, upload_file=True)
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[7].SetDTC482EA9",
                                                     value="None", use_cache=False, delete_cache=False, upload_file=True)
        if memory_type == "secondary":
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[7].SetDTC022292",
                                                     value="None", use_cache=False, delete_cache=False, upload_file=True)
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[7].SetDTC482EA9",
                                                     value="Permanent", use_cache=False, delete_cache=False, upload_file=True)
        if memory_type == "all":
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[7].SetDTC022292",
                                                     value="Permanent", use_cache=False, delete_cache=False, upload_file=True)
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[7].SetDTC482EA9",
                                                     value="Permanent", use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                 nodePath="EventsConfigs[7].LogDlt",
                                                 value="Yes", use_cache=False, delete_cache=False, upload_file=True)
        
    def initiateConfigFile_QNX(self, memory_type):
        self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                 nodePath="EventsConfigs[0].MessageSource",
                                                 value=self.context_Id_QNX, use_cache=False, delete_cache=False,
                                                 upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                 nodePath="EventsConfigs[0].MessageRegex",
                                                 value=self.searchMessage, use_cache=False, delete_cache=False,
                                                 upload_file=True)
        if memory_type == "primary":
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[0].SetDTC022292",
                                                     value="Clearable", use_cache=False, delete_cache=False, upload_file=True)
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[0].SetDTC482EA9",
                                                     value="None", use_cache=False, delete_cache=False, upload_file=True)
        if memory_type == "secondary":
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[0].SetDTC022292",
                                                     value="None", use_cache=False, delete_cache=False, upload_file=True)
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[0].SetDTC482EA9",
                                                     value="Clearable", use_cache=False, delete_cache=False, upload_file=True)
        if memory_type == "all":
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[0].SetDTC022292",
                                                     value="Clearable", use_cache=False, delete_cache=False, upload_file=True)
            self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                     nodePath="EventsConfigs[0].SetDTC482EA9",
                                                     value="Clearable", use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=f"{self.Config_file_path + self.Config_file_name}",
                                                 nodePath="EventsConfigs[0].LogDlt",
                                                 value="Yes", use_cache=False, delete_cache=False, upload_file=True)
        
    def  initiateConfigFile(self, memory_type="primary"):
        if self.os_name == "Linux":
            self.initiateConfigFile_Linux(memory_type)
        else:
            self.initiateConfigFile_QNX(memory_type)
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.start()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        self.sleep_for(self.wait_trigger_to_be_sent_after_dtc_clear)
        self.ssh_manager.downloadFileFromTarget(self.Config_file_name, self.Config_file_path, OutputPathManager.get_test_case_path())
    def udpFilter(self):
        udp_filter = f"udp.dstport == 3489 and ip.src == {self.PP_IP} and ip.dst == 239.255.42.98"
        return udp_filter
    def dtc_variant(self, memory_type="primary"):
        if memory_type == "primary":
            if self.PP_NAME == "mPAD_Performance_AddOn" or self.PP_NAME == "mPAD_Performance":
                return self.mpad_primary_DTC
            else:
                return self.high_primary_DTC
        if memory_type == "secondary":
            if self.PP_NAME == "mPAD_Performance_AddOn" or self.PP_NAME == "mPAD_Performance":
                return self.mpad_secondary_DTC
            else:
                return self.high_secondary_DTC
