from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_network_03_NETP_ICMP_statistics_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_network_03_NETP_ICMP_statistics_QNX"
    REQ_ID = ["/item/5909472"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that the NETP ICMP reports contains all required statistics"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.network_protocols_statistics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["Network"]["TCP"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.network_protocols_statistics_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_network_03_NETP_ICMP_statistics_QNX(self):
        self.startTestStep("Wait cycle of NETP * 2")
        self.sleep_for(self.time_interval * 2)
        self.startTestStep("Get NETS DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that NETP DLT messages are available")

        self.startTestStep("Get in_msgs value")
        in_msgs = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.in_msgs")
        self.expectTrue(in_msgs != self.INVALID_VALUE, Severity.MAJOR, "Check that in_msgs is reported")

        self.startTestStep("Get in_errors value")
        in_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.in_errors")
        self.expectTrue(in_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that in_errors is reported")

        self.startTestStep("Get in_csum_errors value")
        in_csum_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.in_csum_errors")
        self.expectTrue(in_csum_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that in_csum_errors is reported")

        self.startTestStep("Get in_dest_unreachs value")
        in_dest_unreachs = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.in_dest_unreachs")
        self.expectTrue(in_dest_unreachs != self.INVALID_VALUE, Severity.MAJOR, "Check that in_dest_unreachs is reported")

        self.startTestStep("Get in_time_exds value")
        in_time_exds = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.in_time_exds")
        self.expectTrue(in_time_exds != self.INVALID_VALUE, Severity.MAJOR, "Check that in_time_exds is reported")

        self.startTestStep("Get in_param_probs value")
        in_param_probs = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.in_param_probs")
        self.expectTrue(in_param_probs != self.INVALID_VALUE, Severity.MAJOR, "Check that in_param_probs is reported")

        self.startTestStep("Get in_redirects value")
        in_redirects = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.in_redirects")
        self.expectTrue(in_redirects != self.INVALID_VALUE, Severity.MAJOR, "Check that in_redirects is reported")

        self.startTestStep("Get in_echos value")
        in_echos = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.in_echos")
        self.expectTrue(in_echos != self.INVALID_VALUE, Severity.MAJOR, "Check that in_echos is reported")

        self.startTestStep("Get in_echo_reps value")
        in_echo_reps = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.in_echo_reps")
        self.expectTrue(in_echo_reps != self.INVALID_VALUE, Severity.MAJOR, "Check that in_echo_reps is reported")

        self.startTestStep("Get in_addr_masks value")
        in_addr_masks = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.in_addr_masks")
        self.expectTrue(in_addr_masks != self.INVALID_VALUE, Severity.MAJOR, "Check that in_addr_masks is reported")

        self.startTestStep("Get out_msgs value")
        out_msgs = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.out_msgs")
        self.expectTrue(out_msgs != self.INVALID_VALUE, Severity.MAJOR, "Check that out_msgs is reported")

        self.startTestStep("Get out_dest_unreachs value")
        out_dest_unreachs = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.out_dest_unreachs")
        self.expectTrue(out_dest_unreachs != self.INVALID_VALUE, Severity.MAJOR, "Check that out_dest_unreachs is reported")

        self.startTestStep("Get out_echos value")
        out_echos = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.out_echos")
        self.expectTrue(out_echos != self.INVALID_VALUE, Severity.MAJOR, "Check that out_echos is reported")

        self.startTestStep("Get out_echo_reps value")
        out_echo_reps = self.get_statistic_value(message=messages[0], statistic_path="Network.ICMP.Statistics.out_echo_reps")
        self.expectTrue(out_echo_reps != self.INVALID_VALUE, Severity.MAJOR, "Check that out_echo_reps is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
