from Tests.PSAA.Resource_Manager.testfixture_PSAA_RM import *


class tca_mmr_003_read_all_registers(testfixture_PSAA_RM):

    TEST_ID = "PSAA\Ressource_Manager\tca_mmr_003_read_all_registers"
    REQ_ID = ['/item/5280137','/item/5279976','/item/7117977','/item/7117977','/item/7129908','/item/7129917','/item/7129942','/item/7110137','/item/5280903','/item/5280938','/item/5311827']
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    PRIORITY = "Critical"
    DESCRIPTION = "Resource managers shall only accept requests to interact with registers which are specified in the configuration JSON file"
    STATUS = "Ready"
    OS = ['QNX']


    def setUp(self):
        pass

    def test_tca_mmr_003_read_all_registers(self):
        logger.info(f"Get Exposed_file_path, register_offset and register_size from: {self.MMR_JSON_PATH} for each MMR register")
        exposed_file_path, register_offset, register_offset_int, register_size, register_size_int, bar_type, bar_port = self.get_all_mmr_info(self.MMR_JSON_PATH)

        logger.info("Iterate over all MMR registers, open corresponding exposed file, lseek to correct offset and read with correct size")
        for index, item in enumerate(exposed_file_path):
            self.startTestStep("open exposed file")
            logger.info(f"open exposed file: {exposed_file_path[index]}")
            result = self.proxy_app_manager.FUSA_comm.open_resource_manager(path=exposed_file_path[index], oflag=RMOflag.RDWR.value)
            logger.info("ExitCode received from proxApp is: {0}".format(result))
            self.assertTrue(result == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Checking SUCCESS ExitCode received from proxyApp")
            output = self.proxy_app_manager.FUSA_comm.rm_error
            logger.info("System error received from proxApp response is: {0}".format(output))
            self.assertTrue(output == RMSystemError.EOK.value, Severity.MAJOR, "Checking that exposed file is opened successfuly and no error was raised")

            self.startTestStep("Lseek to correct offset")
            logger.info("Lseek to correct offset: {0}(hex: {1})".format(register_offset_int[index], register_offset[index]))
            result = self.proxy_app_manager.FUSA_comm.set_resource_manager_offset(register_offset_int[index], whence=RMWhence.SEEK_SET.value)
            logger.info("ExitCode received from proxApp is: {0}".format(result))
            self.expectTrue(result == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Checking that success exitCode received from proxyApp response")
            output = self.proxy_app_manager.FUSA_comm.rm_error
            logger.info("System error received from proxApp response is: {0}".format(output))
            self.expectTrue(output == RMSystemError.EOK.value, Severity.MAJOR, "Checking that no error was raised while lseeking offset")

            self.startTestStep("Read with correct size")
            logger.info("Read with correct size: {0}(hex: {1})".format(register_size_int[index], register_size[index]))
            result = self.proxy_app_manager.FUSA_comm.read_with_resource_manager(register_size_int[index])
            logger.info("ExitCode received from proxApp is: {0}".format(result))
            self.expectTrue(result == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Checking that success exitCode received from proxyApp response")
            output = self.proxy_app_manager.FUSA_comm.rm_error
            logger.info("System error received from proxApp response is: {0}".format(output))
            self.expectTrue(output == RMSystemError.EOK.value, Severity.MAJOR, "Checking that no error was raised while reading register")

            self.startTestStep("close exposed file")
            logger.info(f"close exposed file: {exposed_file_path[index]}")
            result = self.proxy_app_manager.FUSA_comm.close_resource_manager()
            logger.info("ExitCode received from proxApp is: {0}".format(result))
            self.assertTrue(result == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Checking SUCCESS ExitCode received from proxyApp")
            output = self.proxy_app_manager.FUSA_comm.rm_error
            logger.info("System error received from proxApp response is: {0}".format(output))
            self.assertTrue(output == RMSystemError.EOK.value, Severity.MAJOR, "Checking that exposed file is closed successfuly and no error was raised")


    def tearDown(self):
        pass
