from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_cpu_04_CPUP_process_cpu_usage_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_cpu_04_CPUP_process_cpu_usage_non_verbose"
    REQ_ID = ["/item/5831492"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports the cpu usage for each process in non-verbose mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.process_cpu_usage_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.setPrecondition("Start monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_CPUP)
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.setPrecondition("Get usage limit from the config file")
        self.cpu_threshold = self.get_process_cpu_usage_limit(SearchText="process_cpu_usage_limit")
        logger.info(f"Cpu threshold = {self.cpu_threshold} is the cpu usage limit")
        self.expectTrue(self.cpu_threshold != self.INVALID_VALUE, Severity.BLOCKER, "Check that configured CPU threshold was successfully retrieved")
        self.expectTrue(self.cpu_threshold == 0.1, Severity.MAJOR, "Check that configured CPU threshold is equal to 0.1")

    def test_tca_sysmon_cpu_04_CPUP_process_cpu_usage_non_verbose(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_CPUP, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 2)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get CPUP non-verbose DLT messages that contains the cpu usage of processes")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that all retrieved processes using SSH are logged by sysmon")
        self.startTestStep("Check all running processes with CPU usage more than the configured usage limit")
        all_processes_cpu_usage_more_than_usage_limit = self.check_process_cpu_usage_more_than_usage_limit_non_verbose(dlt_messages=dlt_messages, cpu_threshold=self.cpu_threshold)
        self.assertTrue(all_processes_cpu_usage_more_than_usage_limit, Severity.MAJOR, "Check that all processes consumed cpu usage are more than 0.1")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
