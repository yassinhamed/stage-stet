from Tests.PSAA.STD_Frame.testfixture_PSAA_STDFrame import *


class tca_psaa_STDF_004_Serial_number_compare(testfixture_PSAA_STDFrame):

    TEST_ID = "PSAA\tca_psaa_STDF_004_Serial_number_compare"
    REQ_ID = ["/item/2175806"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check 'Serial_number' got from dlt and 'Serial_number' got from diag are the same"
    OS = ['LINUX','QNX']
    STATUS = "Ready"

    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_SerialNumber)
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.diag_manager.start()

    def test_tca_psaa_STDF_004_Serial_number_compare(self):
        self.startTestStep("Get non verbose message 'Serial_number'")
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.Serial_number_msg_short_name, sender=self.PP_ECUID, filter_attributes=None)
        self.sleep_for(self.wait_for_STDF_dlt_message)
        self.dlt_manager.stop_capturing_non_verbose_message()
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "No DLT message received")
        logger.info(f"DTL message = {dlt_messages[-1]}")
        dlt_msg = dlt_messages[-1]['payload']
        result, serial_number_dlt = self.check_Serial_number(dlt_msg)
        self.assertTrue(result, Severity.MAJOR, f"Check Serial_number logged")
        self.startTestStep("Get 'Serial_number' using diag job")
        res = self.diag_manager.syn_send(self.TESTER_DIAG_ADR, self.PP_DIAG_ADR, self.DIAG_SERIAL_NUMBER_LESEN)
        self.assertTrue(res == DiagResult.positive, Severity.BLOCKER, "Check the Ecu responds to the diagnostic job SERIAL_NUMBER_LESEN or not")
        res_diag = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        logger.debug(f"Diag Job response -> returned payload: {self.diag_manager.payload_to_str(res_diag.get_payload())}")
        jobs_bytes = res_diag.get_payload()[3:]
        result = self.compare_Serial_number(serial_number_dlt, jobs_bytes)
        self.expectTrue(result, Severity.MAJOR, f"Check Serial_number from DLT and from Diag are the same")

    def tearDown(self):
        self.diag_manager.stop()