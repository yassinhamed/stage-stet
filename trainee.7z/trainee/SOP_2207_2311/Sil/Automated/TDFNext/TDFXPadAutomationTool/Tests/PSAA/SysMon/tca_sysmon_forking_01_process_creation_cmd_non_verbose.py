from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_forking_01_process_creation_cmd_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_forking_01_process_creation_cmd_non_verbose"
    REQ_ID = ["/item/5833125"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon report process creation using cmd in non-verbose mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_PMON_creation)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_forking_01_process_creation_cmd_non_verbose(self):

        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_PMON_creation, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("send command ls and get it's pid")
        result = self.ssh_manager.executeCommandInTarget(command="ls & echo $!", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(result["stdout"] != "", Severity.MAJOR, "Check that stdout is not empty")
        ls_pid = int(result["stdout"].splitlines()[0].strip())
        logger.info(f"ls pid : {ls_pid}")
        self.startTestStep(f"Wait for DLT ({self.wait_for_forking_non_verbose_message_ms})")
        self.sleep_for(self.wait_for_forking_non_verbose_message_ms)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get PMON non-verbose DLT messages that contains process creation")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that PMON process creation non verbose DLT messages are available")
        search_message = self.get_non_verbose_message_by_pid(ls_pid,dlt_messages)
        self.assertTrue(search_message is not None, Severity.MAJOR, "Check that the DLT contains the PID")
        self.expectTrue(search_message['payload'].get('creation_time_ns') is not None, Severity.MAJOR, "Check that the DLT contains the timestamp")
        self.assertTrue(search_message['payload'].get('command') is not None, Severity.MAJOR, "Check that the DLT contains the arguments")
        self.expectTrue("sh -c sh" in search_message['payload'].get('command'), Severity.MAJOR, "Check that the arguments are valid")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
