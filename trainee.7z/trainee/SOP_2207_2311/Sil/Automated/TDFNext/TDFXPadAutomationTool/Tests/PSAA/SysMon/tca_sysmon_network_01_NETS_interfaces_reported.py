from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_network_01_NETS_interfaces_reported(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_network_01_NETS_interfaces_reported"
    REQ_ID = ["/item/5906667", "/item/5828629"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon report NETS statistics of all interfaces"
    OS = ['LINUX', 'QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.network_statistic_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["Network"]["General"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.network_statistic_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_network_01_NETS_interfaces_reported(self):
        self.startTestStep("Wait cycle of NETS * 2")
        self.sleep_for(self.time_interval * 2)
        self.startTestStep("Get NETS DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that NETS DLT messages are available")
        self.startTestStep("Get all reported interfaces in the DLT messages")
        reported_interfaces = self.get_reported_interfaces(messages=messages)
        logger.info(f"Reported interfaces:\n{reported_interfaces}")
        self.expectTrue(self.eth0_interface in reported_interfaces, Severity.MAJOR, "Check that eth0 is reported")
        self.expectTrue(self.vlan_interface in reported_interfaces, Severity.MAJOR, "Check that vlan interface is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
