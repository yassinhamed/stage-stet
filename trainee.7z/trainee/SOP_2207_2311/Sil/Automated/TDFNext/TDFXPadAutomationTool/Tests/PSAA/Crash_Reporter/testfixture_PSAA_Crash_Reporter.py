from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_Crash_Reporter(testfixture_PSAA):
    default_dumper_timeout = 30000
    time_for_incomplete_coredumps = 2000


    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_crashreporter setUpclsss")
        cls.ssh_manager.executeCommandInTarget("ls /opt/crash_reporter/bin")
        cls.ssh_manager.executeCommandInTarget("ls /opt/crash_reporter/etc")

        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_tests_group_path(),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_crashreporter tearDownclsss")

    def restart_crash_reporter_with_params(self, quota="0", min_persistent_space="0", timeout="30"):
        application_is_killed = self.kill_application(app_name=self.CRASH_REPORTER_APP_NAME, signal="SIGABRT", option="-v crash_reporter_ara_proxy")
        if not application_is_killed:
            logger.error("the kill command is not executed")
            return False
        remove_lola_files = self.ssh_manager.executeCommandInTarget(command=f"rm /dev/shmem/lola-*", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if remove_lola_files["exec_recv"] == 0:
            logger.info("Remove command is executed")
        else:
            logger.error("Remove command isn't executed")

        crash_reporter_starting = self.ssh_manager.executeCommandInTarget(command=f"cd /opt/crash_reporter && ./bin/crash_reporter --dumper-timeout-seconds {timeout} --coredump-quota-mb {quota} --min-persistent-space-mb {min_persistent_space} -U crash_handler:crash_services &", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if crash_reporter_starting["exec_recv"] == 0:
            logger.info("crash reporter command is executed")
            return True
        else:
            logger.error("crash reporter command isn't executed")
            return False

    def parse_crash_reporter_commandline_parameters(self):
        crash_reporter = self.ssh_manager.executeCommandInTarget(command=f"ps -A -o pid,args | grep ./bin/crash_reporter | grep -v grep", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if crash_reporter["stdout"] != "":
            pid = crash_reporter["stdout"].split(" ")[3].strip()
            if "--coredump-quota-mb " in crash_reporter["stdout"]:
                quota = crash_reporter["stdout"].split("--coredump-quota-mb ")[1].split(" ")[0]
            else:
                quota = None
            if "--min-persistent-space-mb " in crash_reporter["stdout"]:
                min_free_space = crash_reporter["stdout"].split("--min-persistent-space-mb ")[1].split(" ")[0]
            else:
                min_free_space = None
            if "--dumper-timeout-seconds " in crash_reporter["stdout"]:
                timeout = crash_reporter["stdout"].split("--dumper-timeout-seconds ")[1].split(" ")[0]
            else:
                timeout = None
            logger.info(f"pid value:  {pid}")
            logger.info(f"quota value:  {quota}")
            logger.info(f"min free space value:  {min_free_space}")
            logger.info(f"timeout value:  {timeout}")
            parameters = {
                "pid": pid,
                "quota": quota,
                "min_free_space": min_free_space,
                "timeout": timeout
            }
            return parameters
        else:
            logger.info("Crash reporter is not running")
            return None

    def remove_old_coredumps(self):
        Old_coredumps_before_the_remove = self.ssh_manager.executeCommandInTarget(command=f"ls /persistent/coredumps/", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        logger.info(f"Old coredumps before the remove: {Old_coredumps_before_the_remove['stdout']}")
        dumps_list = Old_coredumps_before_the_remove["stdout"].splitlines()
        for coredump in dumps_list:
            if len(dumps_list) == 0:
                break
            if coredump == "currentswversion" or coredump == "tmp":
                continue
            else:
                self.ssh_manager.executeCommandInTarget(command=f"rm -rf /persistent/coredumps/{coredump}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        Old_coredumps_after_the_remove = self.ssh_manager.executeCommandInTarget(command=f"ls /persistent/coredumps/", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        logger.info(f"Old coredumps after the remove: {Old_coredumps_after_the_remove['stdout']}")

        if "tmp" in Old_coredumps_after_the_remove['stdout']:
            tmp_Old_coredumps_before_the_remove = self.ssh_manager.executeCommandInTarget(command=f"ls /persistent/coredumps/tmp/", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
            logger.info(f"Old coredumps before the remove in tmp: {tmp_Old_coredumps_before_the_remove['stdout']}")
            dumps_list = tmp_Old_coredumps_before_the_remove["stdout"].splitlines()
            for coredump in dumps_list:
                if len(dumps_list) == 0:
                    break
                else:
                    self.ssh_manager.executeCommandInTarget(command=f"rm -rf /persistent/coredumps/tmp/{coredump}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
            tmp_Old_coredumps_after_the_remove = self.ssh_manager.executeCommandInTarget(command=f"ls /persistent/coredumps/tmp/", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
            logger.info(f"Old coredumps after the remove in tmp: {tmp_Old_coredumps_after_the_remove['stdout']}")

            if (Old_coredumps_after_the_remove['stdout'] == "currentswversion\ntmp\n" or Old_coredumps_after_the_remove['stdout'] == "currentswversion\n") and tmp_Old_coredumps_after_the_remove["stdout"] == "":
                return True
            else:
                return False
        else:
            if Old_coredumps_after_the_remove['stdout'] == "currentswversion\ntmp\n" or Old_coredumps_after_the_remove['stdout'] == "currentswversion\n":
                return True
            else:
                return False

    def tmp_context_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'context.*.tmp'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of core dumps" + str(len(dumps_list)))
            context_files = returnValue["stdout"].strip().split("\n")
            for context_file in context_files:
                app_name_in_context_file = context_file.split('.')[2]
                if app_name_in_context_file == app_name:
                    return True
                else:
                    continue
            return False

    def context_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'context.*.txt'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of core dumps" + str(len(dumps_list)))
            context_files = returnValue["stdout"].strip().split("\n")
            for context_file in context_files:
                app_name_in_context_file = context_file.split('.')[2]
                if app_name_in_context_file == app_name:
                    return True
                else:
                    continue
            return False

    def core_file_check(self, app_name):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'core.*.gz'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] == 1:
            logger.info("'ls' command didn't executed successfully")
            return False
        else:
            dumps_list = returnValue["stdout"].splitlines()
            logger.info("Number of core dumps" + str(len(dumps_list)))
            core_files = returnValue["stdout"].strip().split("\n")
            for core_file in core_files:
                app_name_in_core_file = core_file.split('.')[2]
                if app_name_in_core_file == app_name:
                    return True
                else:
                    continue
            return False

    def check_blacklist_file(self):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"cat /opt/crash_reporter/etc/ignorelist.json", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if "dumper" in returnValue["stdout"] and "crash_reporter" in returnValue["stdout"]:
            logger.info("dumper and crash reporter are listed in blacklist file")
            return True
        else:
            logger.error("dumper and crash reporter are not listed in blacklist file")
            return False

    def freeze_dumper(self, dumper_pid):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"kill -STOP {dumper_pid}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] ==0:
            logger.info("dumper application is freezed")
            return True
        else:
            logger.info("dumper application is not freezed")
            return False

    def continue_dumper(self, dumper_pid):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"kill -CONT {dumper_pid}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        if returnValue["exec_recv"] ==0:
            logger.info("dumper application is continued")
            return True
        else:
            logger.info("dumper application is not continued")
            return False

    def get_persistent_storage_size(self):
        persistent_total_storage = self.ssh_manager.executeCommandInTarget(command="df -h | grep persistent/ | awk '{print $2}'", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        persistent_storage_size = self.ssh_manager.executeCommandInTarget(command="df -h | grep persistent/", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        logger.info(f"persistent_total_storage: {persistent_storage_size['stdout']}")
        if "G" in persistent_total_storage['stdout'].strip():
            size = float(persistent_total_storage['stdout'].strip().split('G')[0])*1024
        elif "M" in persistent_total_storage['stdout'].strip():
            size = float(persistent_total_storage['stdout'].strip().split('M')[0])
        else:
            size = 1
            logger.info("Couldn't get size")
        logger.info(f"persistent size: {size}")
        return size

    def kill_application_CR(cls, app_name, signal, option=None):
        returnValue = None
        pid = cls.get_process_id(app_name=app_name, option=option)
        if pid != -1:
            returnValue = cls.ssh_manager.executeCommandInTarget(command=f"kill -{signal} {pid}",
                                                                     timeout=cls.SSH_CONNECTION_TIMEOUT_MS,
                                                                     ip_address=cls.PP_IP)

        if returnValue["stderr"].strip() == "" or returnValue != None:
            return True
        else:
            return False

