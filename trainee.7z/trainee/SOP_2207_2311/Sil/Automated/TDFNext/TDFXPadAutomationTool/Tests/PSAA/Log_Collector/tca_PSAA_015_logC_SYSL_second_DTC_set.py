from Tests.PSAA.Log_Collector.testfixture_PSAA_Log_Collector import *


class tca_PSAA_015_logC_SYSL_second_DTC_set(testfixture_PSAA_Log_Collector):

    TEST_ID = "PSAA\tca_PSAA_015_logC_SYSL_second_DTC_set"
    REQ_ID = ["/item/2593566","/item/2939949","/item/2939941","/item/6040647"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.apply_filter(contextId=self.Syslog_context_ID, appId=self.LOG_COLLECTOR_APP_ID)
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.setPrecondition("Modify two DTCs of Syslog to clearable")
        self.logCollectorModifyConfigFile(MessageSource=self.Syslog_context_ID, MessageRegex=self.second_random_text, SetDTC022292="Clearable",
                                          SetDTC482EA9="Clearable", LogDlt="Yes")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.setPrecondition("Check log collector application is running")
        grep_LogC = self.check_application_is_started(app_name=self.LOG_COLLECTOR_APP_NAME)
        self.expectTrue(grep_LogC, Severity.MAJOR, "Check The application was started")
        self.setPrecondition("Add Syslog messages")
        self.logCollectorAddSyslLog(MessageRegex=self.second_random_text)
        self.setPrecondition("Get Syslog messages")
        Message = self.logCollectorGetSyslLog(MessageRegex=self.second_random_text)
        logger.info(str(Message))
        self.assertTrue(Message is not None, "check that message exist in logger")
        self.setPrecondition("Get DLT messages")
        number, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.LOG_COLLECTOR_APP_ID, contextId=self.Syslog_context_ID)
        self.assertTrue(number > 0, Severity.BLOCKER, "Check Syslog messages are being forwarded with SYSL context ID")
        self.setPrecondition("Check primary SW_Integritätsprüfung_fehlgeschlagen DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR,
                                                       dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][
                                                           self.PP_NAME],
                                                       memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that DTC is set")
        self.setPrecondition("Check secondary Interne_System_Manipulation_erkannt DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR,
                                                       dtc=self.DTC_LIST["Interne_System_Manipulation_erkannt"][
                                                           self.PP_NAME],
                                                       memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that DTC is set")

        self.dlt_manager.stop_monitoring()
        self.dlt_manager.clear_all_dlt_messages()
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)

    def test_tca_PSAA_015_logC_SYSL_second_DTC_set(self):
        self.startTestStep("Modify two DTCs of Syslog to clearable and none ")
        self.logCollectorModifyConfigFile(MessageSource=self.Syslog_context_ID, MessageRegex=self.first_random_text, SetDTC022292="None", SetDTC482EA9="Clearable", LogDlt="Yes")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        ecus_are_ok = self.check_ECUs()
        self.ssh_manager.downloadFileFromTarget(source_file=self.Config_file_name, source_path=self.Config_file_path, destination_path=OutputPathManager.get_test_case_path())
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.startTestStep("Check log collector application is running")
        grep_LogC = self.check_application_is_started(app_name=self.LOG_COLLECTOR_APP_NAME)
        self.expectTrue(grep_LogC, Severity.MAJOR, "Check The application was started")
        self.startTestStep("Add Syslog messages")
        self.logCollectorAddSyslLog(MessageRegex=self.first_random_text)
        self.startTestStep("Get Syslog messages")
        Message = self.logCollectorGetSyslLog(MessageRegex=self.first_random_text)
        logger.info(str(Message))
        self.assertTrue(Message is not None, "check that message exist in logger")
        self.startTestStep("Get DLT messages")
        number, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.LOG_COLLECTOR_APP_ID, contextId=self.Syslog_context_ID)
        self.assertTrue(number > 0, Severity.BLOCKER, "Check Syslog messages are being forwarded with SYSL context ID")
        self.startTestStep("Check primary SW_Integritätsprüfung_fehlgeschlagen DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR,
                                                       dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][self.PP_NAME],
                                                       memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_NOT_PRESENT, Severity.BLOCKER, "Checking that DTC is set")
        self.startTestStep("Check secondary Interne_System_Manipulation_erkannt DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR,
                                                       dtc=self.DTC_LIST["Interne_System_Manipulation_erkannt"][self.PP_NAME],
                                                       memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that DTC is set")

    def tearDown(self):
        self.diag_manager.start()
        self.setPostcondition("Revert Config file")
        self.logCollectorRevertConfigFile()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.diag_manager.restart()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
