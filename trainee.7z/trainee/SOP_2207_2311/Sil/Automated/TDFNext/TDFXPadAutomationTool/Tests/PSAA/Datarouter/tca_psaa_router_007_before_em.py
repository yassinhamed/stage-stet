from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_psaa_router_007_before_em(testfixture_PSAA_Datarouter):

    TEST_ID = "Datarouter\tca_psaa_router_007_before_em"
    REQ_ID = ["/item/1573696", "/item/863411", "/item/145159"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        pass

    def test_datarouter_before_em(self):
        self.startTestStep("Get the PID of datarouter")
        datarouter_pid = self.get_process_id(app_name=self.DATA_ROUTER_APP_NAME, exclude=True, exclude_app_name="conf")
        self.assertTrue(datarouter_pid != -1, Severity.BLOCKER, "Checking that the pid of datarouter is returned successfully")

        self.startTestStep("Get the PID of execution manager")
        EXECUTION_MANAGER_APP_NAME_pid = self.get_process_id(app_name=self.EXECUTION_MANAGER_APP_NAME)
        self.assertTrue(EXECUTION_MANAGER_APP_NAME_pid != -1, Severity.BLOCKER, "Checking that the pid of execution manager is returned successfully")
        logger.info(f"execution manager pid={EXECUTION_MANAGER_APP_NAME_pid},datarouter pid={datarouter_pid}")
        self.assertTrue(EXECUTION_MANAGER_APP_NAME_pid > datarouter_pid, Severity.BLOCKER, "Checking that datarouter started before execution manager")

    def tearDown(self):
        pass
