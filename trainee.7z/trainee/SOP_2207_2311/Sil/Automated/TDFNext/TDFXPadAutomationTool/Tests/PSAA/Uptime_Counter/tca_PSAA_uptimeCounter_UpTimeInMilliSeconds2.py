from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *


class tca_PSAA_uptimeCounter_UpTimeInMilliSeconds2(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_uptimeCounter_UpTimeInMilliSeconds2"
    REQ_ID = ["/item/3316266"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check Uptime counter after reset"
    STATUS = "Ready"
    OS = ["QNX", "LINUX"]

    def setUp(self):

        self.setPrecondition("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK == True, Severity.MAJOR, "Check ECUS are correctly reset")

    def test_tca_PSAA_UptimeCounter_UpTimeInMilliSeconds2(self):

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting UpTimeInMilliSeconds value")
        First_UpTimeInMilliSeconds = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.UpTimeCounter)
        logger.info(f"UpTimeInMilliSeconds_value: {First_UpTimeInMilliSeconds}")

        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting UpTimeInMilliSeconds value after delay")
        Second_UpTimeInMilliSeconds = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.UpTimeCounter)
        logger.info(f"Second_UpTimeInMilliSeconds_value: {Second_UpTimeInMilliSeconds}")
        self.assertTrue(int(First_UpTimeInMilliSeconds) == int(Second_UpTimeInMilliSeconds), Severity.MAJOR, "Check UpTimeInMilliSeconds after delay")

        self.startTestStep("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK == True, Severity.MAJOR, "Check ECUS are correctly reset")

        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting Num Of Unexpected Resets value")
        Third_UpTimeInMilliSeconds = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.UpTimeCounter)
        logger.info(f"UpTimeInMilliSeconds_value: {Third_UpTimeInMilliSeconds}")
        self.assertTrue(int(Second_UpTimeInMilliSeconds) < int(Third_UpTimeInMilliSeconds), Severity.MAJOR, "Check UpTimeInMilliSeconds after reset")

    def tearDown(self):

        pass
