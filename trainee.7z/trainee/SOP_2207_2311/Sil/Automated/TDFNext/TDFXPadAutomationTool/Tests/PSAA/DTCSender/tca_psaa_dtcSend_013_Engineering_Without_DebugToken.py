from Tests.PSAA.DTCSender.testfixture_PSAA_DTCSender import *


class tca_psaa_dtcSend_013_Engineering_Without_DebugToken(testfixture_PSAA_DTCSender):

    TEST_ID = "IntC\tca_psaa_dtcSend_013_Engineering_Without_DebugToken"
    REQ_ID = ["/item/3335897"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check UDP packet is sent in engineering mode without Debug token"
    STATUS = "Ready"
    OS = ['LINUX','QNX']

    def setUp(self):
        self.initiateConfigFile(memory_type="primary")
        self.ecu_uid = self.sfa_manager.get_ecu_uid(target=self.PP_DIAG_ADR)
        self.sfa_manager.set_up(target_address=self.PP_DIAG_ADR)
        self.setPrecondition("Set engineering mode")
        self.sfa_manager.safe_set_to_engineering_mode(target=self.PP_DIAG_ADR)
        self.setPrecondition("Get ECU mode")
        mode = self.sfa_manager.sfa_get_ecu_mode(target=self.PP_DIAG_ADR)
        self.assertTrue(EcuMode.Engineering.value == mode, Severity.BLOCKER, 'Error when reading ECU mode')
        self.setPrecondition("Get 1D1A token status")
        feature_status = self.sfa_manager.sfa_get_status(self.PP_DIAG_ADR, feature_id=self.SFA_ID)
        self.expectTrue(feature_status == Feature_Status.Enabled.value, Severity.BLOCKER, "check that 1D1A token is enabled")
        self.setPrecondition("Set DTC with delay")
        self.setDTC_with_delay()
        self.setPrecondition("Set SFA clear feature")
        res = self.sfa_manager.sfa_clear_feature(target=self.PP_DIAG_ADR, feature_id=self.SFA_ID)
        self.expectTrue(res, Severity.BLOCKER,
                        "check the return code of the disabling of 1D1A token in the perf. controller")
        self.sleep_for(self.TOKEN_STATUS_UPDATE_TIMEOUT_MS)
        self.setPrecondition("Get 1D1A token status")
        feature_status = self.sfa_manager.sfa_get_status(self.PP_DIAG_ADR, feature_id=self.SFA_ID)
        self.expectTrue(feature_status != Feature_Status.Enabled.value, Severity.BLOCKER,
                        f"Check that the 1D1A token is not enabled, token status = {feature_status}")
        self.sleep_for(self.wait_trigger_to_be_sent)

    def test_tca_psaa_dtcSend_013_Engineering_Without_DebugToken(self):
        self.startTestStep("Start tshark monitoring")
        self.network.sniffer.start_tshark_watching(filter=self.udpFilter(), adapater_name=self.Adapater_names[0])
        self.sleep_for(self.wait_tshark_to_start)
        self.startTestStep("Get DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR,
                                                       dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][self.PP_NAME],
                                                       memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue((read_status == self.DTC_ACTIVE) or (read_status == self.DTC_INACTIVE), Severity.BLOCKER, "Checking that DTC is set")
        self.sleep_for(self.wait_trigger_to_be_sent)
        self.startTestStep("Stop tshark monitoring")
        self.network.sniffer.stop_tshark_watching()
        self.sleep_for(self.wait_tshark_to_stop)
        self.startTestStep("Get packets")
        packets = self.network.sniffer.get_packets()
        self.expectTrue(len(packets) == 0, Severity.BLOCKER, f"Check packet with matching filter were not captured")

    def tearDown(self):
        self.setPostcondition("Set secure feature")
        res = self.sfa_manager.set_secure_feature(target=self.PP_DIAG_ADR, ecu_uid=self.ecu_uid, feature_id=self.SFA_ID,
                                                  result_dir=OutputPathManager.get_report_path(),
                                                  feature_spec_fields=self.sfa_manager.generate_ssh_key_payload(), enable=True, use_cache=False)
        self.expectTrue(res, Severity.BLOCKER, "check that 1D1A token was enabled successfully")
        self.sleep_for(self.TOKEN_STATUS_UPDATE_TIMEOUT_MS)
        self.setPostcondition("Get 1D1A token status")
        feature_status = self.sfa_manager.sfa_get_status(self.PP_DIAG_ADR, feature_id=self.SFA_ID)
        self.expectTrue(feature_status == Feature_Status.Enabled.value, Severity.BLOCKER,
                        f"check that 1D1A is enabled, token status = {feature_status}")
        self.sfa_manager.stop_sfa_manager()
