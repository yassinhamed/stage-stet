from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_STDFrame(testfixture_PSAA):
    wait_for_STDF_dlt_message = 10000
    wait_for_start_STDF_dlt_message = 25000
    sfa_update_delay = 10000
    stdf_periodicity_time_interval = 5000
    tsync_periodicity_time_interval = 1000
    periodicity_tolerance_percentage = 10

    messageID_STDF_HWVersion = 11
    messageID_STDF_SWVersion1 = 12
    messageID_STDF_SWVersion2 = 13
    messageID_STDF_SWVersion3 = 14
    messageID_STDF_SWVersion4 = 15
    messageID_STDF_SWVersion5 = 16
    messageID_STDF_SWVersion6 = 17
    messageID_STDF_SWVersion7 = 18
    messageID_STDF_SWVersion8 = 19
    messageID_STDF_SWVersion9 = 20
    messageID_STDF_SWVersion10 = 21
    messageID_STDF_SerialNumber = 22
    messageID_STDF_VehicleId = 23
    messageID_STDF_CurrentEngMode = 24
    messageID_STDF_InterfaceVersion = 25
    messageID_STDF_CurrentMileage = 26
    messageID_STDF_timesync = 27

    first_search_msg = "Send stdframe"
    HW_version_msg_short_name = 'bmw_logging_standard_frame_EcuHwVersion'
    SW_version1_msg_short_name = 'bmw_logging_standard_frame_EcuSwVersion1'
    SW_version2_msg_short_name = 'bmw_logging_standard_frame_EcuSwVersion2'
    SW_version3_msg_short_name = 'bmw_logging_standard_frame_EcuSwVersion3'
    SW_version4_msg_short_name = 'bmw_logging_standard_frame_EcuSwVersion4'
    SW_version5_msg_short_name = 'bmw_logging_standard_frame_EcuSwVersion5'
    SW_version6_msg_short_name = 'bmw_logging_standard_frame_EcuSwVersion6'
    SW_version7_msg_short_name = 'bmw_logging_standard_frame_EcuSwVersion7'
    SW_version8_msg_short_name = 'bmw_logging_standard_frame_EcuSwVersion8'
    SW_version9_msg_short_name = 'bmw_logging_standard_frame_EcuSwVersion9'
    SW_version10_msg_short_name = 'bmw_logging_standard_frame_EcuSwVersion10'
    Serial_number_msg_short_name = 'bmw_logging_standard_frame_EcuSerialNumber'
    Vehicule_id_msg_short_name = 'bmw_logging_standard_frame_VehicleId'
    Eng_mode_msg_short_name = 'bmw_logging_standard_frame_CurrentEngineeringMode'
    Interface_ver_msg_short_name = 'bmw_logging_standard_frame_InterfaceVersion'
    Mileage_msg_short_name = 'bmw_logging_standard_frame_CurrentMileage'
    TSync_TimeStamp_msg_short_name = 'bmw_logging_timesync_DltTimeSyncTimestamp'

    datarouter_Config_file_path = "/opt/datarouter/etc/"
    stdf_Config_file_path = "/opt/std_frame/etc/"
    Low_channel_port_node = "channels.LOW.port"
    High_channel_port_node = "channels.HIGH.port"

    initial_mileage = 0x750
    initial_mileage_response = 2702049280
    initial_mileage_decimal_value = 1872

    expected_vin = "123456"
    serial_number_dlt = ""

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_STDFrame setUpclsss")
        cls.ssh_manager.executeCommandInTarget("ls /opt/std_frame/bin")
        cls.ssh_manager.executeCommandInTarget("ls /opt/std_frame/etc")

        cls.json_manager.updateNodeIntoJsonFile(filePath=f"{cls.stdf_Config_file_path}logging.json",
                                                nodePath="contextConfigs[0].logLevel",
                                                value="kDebug", use_cache=False, delete_cache=True, upload_file=True)
        cls.json_manager.updateNodeIntoJsonFile(filePath=f"{cls.stdf_Config_file_path}logging.json",
                                                nodePath="contextConfigs[1].logLevel",
                                                value="kDebug", use_cache=False, delete_cache=True, upload_file=True)
        cls.json_manager.updateNodeIntoJsonFile(filePath=f"{cls.stdf_Config_file_path}logging.json",
                                                nodePath="contextConfigs[2].logLevel",
                                                value="kDebug", use_cache=False, delete_cache=True, upload_file=True)
        cls.diag_manager.start()
        cls.diag_manager.ecu_reset(target=cls.PP_DIAG_ADR, reset_duration=cls.PP_RESET_TIMEOUT_S)
        cls.diag_manager.restart()
        cls.check_ECUs()
        cls.ssh_manager.downloadFileFromTarget("logging.json", cls.stdf_Config_file_path,
                                               OutputPathManager.get_global_path(), ip_address=cls.PP_IP)
        grep_STDF = cls.check_application_is_started(app_name=cls.STD_Frame_APP_NAME)
        cls.expectTrue(grep_STDF, Severity.MAJOR, "Check The application was started")
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_tests_group_path(),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_STDFrame tearDownclsss")
        cls.json_manager.updateNodeIntoJsonFile(filePath=f"{cls.stdf_Config_file_path}logging.json",
                                                nodePath="contextConfigs[0].logLevel",
                                                value="kInfo", use_cache=False, delete_cache=True, upload_file=True)
        cls.json_manager.updateNodeIntoJsonFile(filePath=f"{cls.stdf_Config_file_path}logging.json",
                                                nodePath="contextConfigs[1].logLevel",
                                                value="kInfo", use_cache=False, delete_cache=True, upload_file=True)
        cls.json_manager.updateNodeIntoJsonFile(filePath=f"{cls.stdf_Config_file_path}logging.json",
                                                nodePath="contextConfigs[2].logLevel",
                                                value="kInfo", use_cache=False, delete_cache=True, upload_file=True)
        cls.diag_manager.start()
        cls.diag_manager.ecu_reset(target=cls.PP_DIAG_ADR, reset_duration=cls.PP_RESET_TIMEOUT_S)
        cls.diag_manager.stop()
        cls.check_ECUs()

    def setUp(self):
        grep_STDF = self.check_application_is_started(app_name=self.STD_Frame_APP_NAME)
        logger.info(f"get_process_id_qnx returns {grep_STDF} with type {str(type(grep_STDF))}")
        self.expectTrue(grep_STDF, Severity.MAJOR, "Check The application was started")

    def tearDown(self):
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_test_case_path(),check_empty=False,ip_address=self.PP_IP,ignored_files=["currentswversion", "tmp"])

    def check_SW_version_was_sent(self, dlt_msg, SGBM_ID):
        Check = True
        ID = ""
        byte1 = dlt_msg['ecu_sw_version_ecu_swel_version_id_ecu_version_id2']
        byte2 = dlt_msg['ecu_sw_version_ecu_swel_version_id_ecu_version_id3']
        byte3 = dlt_msg['ecu_sw_version_ecu_swel_version_id_ecu_version_id4']
        byte4 = dlt_msg['ecu_sw_version_ecu_swel_version_id_ecu_version_id5']
        for b in [byte1, byte2, byte3, byte4]:
            val = hex(b)
            ID = ID + str(bytearray.fromhex(val.split('x')[1]).decode())
        if str(ID) == SGBM_ID:
            logger.info(f"Check ID = {SGBM_ID}, current value = {ID}")
        else:
            logger.error(f"Check ID = {SGBM_ID}, current value = {ID}")
            Check = False
        if str(dlt_msg['ecu_sw_version_ecu_swel_major']) != "":
            logger.info(
                f"Check the ecu_sw_version_ecu_swel_major in payload{dlt_msg['ecu_sw_version_ecu_swel_major']} is not empty")
        else:
            logger.error(f"Check the ecu_sw_version_ecu_swel_major in payload{dlt_msg['ecu_sw_version_ecu_swel_major']} is not empty")
            Check = False
        if str(dlt_msg['ecu_sw_version_ecu_swel_minor']) != "":
            logger.info(
                f"Check the ecu_sw_version_ecu_swel_minor in payload{dlt_msg['ecu_sw_version_ecu_swel_minor']} is not empty")
        else:
            logger.error(
                f"Check the ecu_sw_version_ecu_swel_minor in payload{dlt_msg['ecu_sw_version_ecu_swel_minor']} is not empty")
            Check = False
        if str(dlt_msg['ecu_sw_version_ecu_swel_patch']) != "":
            logger.info(
                f"Check the ecu_sw_version_ecu_swel_patch in payload{dlt_msg['ecu_sw_version_ecu_swel_patch']} is not empty")
        else:
            logger.error(
                f"Check the ecu_sw_version_ecu_swel_patch in payload{dlt_msg['ecu_sw_version_ecu_swel_patch']} is not empty")
            Check = False
        return Check

    def check_Serial_number(self, dlt_msg):
        Check = True
        serial_number_dlt = ""
        for key in dlt_msg.keys():
            if key != 'ecu_serial_id_len':
                val = hex(dlt_msg[key])
                logger.info(f"######    {key} = {dlt_msg[key]}  type = {type(dlt_msg[key])}")
                serial_number_dlt = serial_number_dlt + str(bytearray.fromhex(val.split('x')[1]).decode())
        logger.info(f" serial_number_dlt str = {serial_number_dlt}")
        if dlt_msg['ecu_serial_id_len'] == 10:
            logger.info(f"Check the ecu_serial_id_len in payload {dlt_msg['ecu_serial_id_len']} is with size 10")
        else:
            logger.error(f"Check the ecu_serial_id_len in payload {dlt_msg['ecu_serial_id_len']} is with size 10")
            Check = False
        if len(serial_number_dlt) == dlt_msg['ecu_serial_id_len']:
            logger.info(
                f"Check the ecu_serial_id in payload {serial_number_dlt} is not empty and with length {dlt_msg['ecu_serial_id_len']}")
        else:
            logger.error(f"Check the ecu_serial_id in payload {serial_number_dlt} is not empty and with length {dlt_msg['ecu_serial_id_len']}")
            Check = False
        return Check, serial_number_dlt

    def check_vehicule_id(self, dlt_msg):
        Check = True
        logger.info("[DLT Messages ]:{0}".format(dlt_msg))
        vin = ""
        for key in dlt_msg.keys():
            if key != 'vehicle_id_len':
                val = hex(dlt_msg[key])
                vin = vin + str(bytearray.fromhex(val.split('x')[1]).decode())
        if (dlt_msg['vehicle_id_len']) == 17:
            logger.info(f"Check the vehicle_id_len in payload{dlt_msg['vehicle_id_len']} is with size 17")
        else:
            logger.error(f"Check the vehicle_id_len in payload{dlt_msg['vehicle_id_len']} is with size 17")
            Check = False
        if len(vin) == 17:
            logger.info(f"Check the vin in payload{vin} is not empty and with length {dlt_msg['vehicle_id_len']}")
        else:
            logger.error(f"Check the vin in payload{vin} is not empty and with length {dlt_msg['vehicle_id_len']}")
            Check = False
        if vin[11:] == self.expected_vin:
            logger.info(f"check last 6 chars in vin. expected: {self.expected_vin}, current {vin[11:]}")
        else:
            logger.error(f"check last 6 chars in vin. expected: {self.expected_vin}, current {vin[11:]}")
            Check = False
        return Check

    def is_uint8(self, number):
        if (number >= 0) and (number <= 255):
            return True
        return False

    def compare_HW_version(self, dlt_payload, res_payload):
        Check = True
        svk_report = {"HWEL": {}, "BTLD": {}, "FLSL": {}, "SWFL": [], "CAFD": {}}
        i = 11
        while i < len(res_payload):
            sgbm_id = res_payload[i + 1: i + 5]
            major_version = res_payload[i + 5]
            minor_version = res_payload[i + 6]
            patch_version = res_payload[i + 7]
            temp_dict = {"SGBM_ID": sgbm_id, "MAJOR_VER": major_version, "MINOR_VER": minor_version,
                         "PATCH_VER": patch_version}
            if res_payload[i] == 0x01:
                svk_report["HWEL"] = temp_dict
            elif res_payload[i] == 0x06:
                svk_report["BTLD"] = temp_dict
            elif res_payload[i] == 0x07:
                svk_report["FLSL"] = temp_dict
            elif res_payload[i] == 0x08:
                svk_report["SWFL"].append(temp_dict)
            elif res_payload[i] == 0x05:
                svk_report["CAFD"] = temp_dict
            i = i + 8

        logger.info(f"parsed svk = {svk_report}")
        if dlt_payload['ecu_hwel_major'] == svk_report["HWEL"]["MAJOR_VER"]:
            logger.info(f"Check HW major version, expected = {dlt_payload['ecu_hwel_major']}, actual = {svk_report['HWEL']['MAJOR_VER']}")
        else:
            logger.error(f"Check HW major version, expected = {dlt_payload['ecu_hwel_major']}, actual = {svk_report['HWEL']['MAJOR_VER']}")
            Check = False
        if dlt_payload['ecu_hwel_minor'] == svk_report["HWEL"]["MINOR_VER"]:
            logger.info(f"Check HW minor version, expected = {dlt_payload['ecu_hwel_minor']}, actual = {svk_report['HWEL']['MINOR_VER']}")
        else:
            logger.error(f"Check HW minor version, expected = {dlt_payload['ecu_hwel_minor']}, actual = {svk_report['HWEL']['MINOR_VER']}")
            Check = False
        if dlt_payload['ecu_hwel_patch'] == svk_report["HWEL"]["PATCH_VER"]:
            logger.info(f"Check HW patch version, expected = {dlt_payload['ecu_hwel_patch']}, actual = {svk_report['HWEL']['PATCH_VER']}")
        else:
            logger.error(f"Check HW patch version, expected = {dlt_payload['ecu_hwel_patch']}, actual = {svk_report['HWEL']['PATCH_VER']}")
            Check = False
        return Check

    def compare_SW_version(self, dlt_payload, res_payload):
        Check = True
        svk_report = {"HWEL": {}, "BTLD": {}, "FLSL": {}, "SWFL": [], "CAFD": {}}
        i = 11
        while i < len(res_payload):
            sgbm_id = res_payload[i + 1: i + 5]
            major_version = res_payload[i + 5]
            minor_version = res_payload[i + 6]
            patch_version = res_payload[i + 7]
            temp_dict = {"SGBM_ID": sgbm_id, "MAJOR_VER": major_version, "MINOR_VER": minor_version,
                         "PATCH_VER": patch_version}
            if res_payload[i] == 0x01:
                svk_report["HWEL"] = temp_dict
            elif res_payload[i] == 0x06:
                svk_report["BTLD"] = temp_dict
            elif res_payload[i] == 0x07:
                svk_report["FLSL"] = temp_dict
            elif res_payload[i] == 0x08:
                svk_report["SWFL"].append(temp_dict)
            elif res_payload[i] == 0x05:
                svk_report["CAFD"] = temp_dict
            i = i + 8

        logger.info(f"parsed svk = {svk_report}")
        if dlt_payload['ecu_sw_version_ecu_swel_major'] == svk_report["SWFL"][0]["MAJOR_VER"]:
            logger.info(f"Check SW major version, expected = {dlt_payload['ecu_sw_version_ecu_swel_major']}, actual = {svk_report['SWFL'][0]['MAJOR_VER']}")
        else:
            logger.error(f"Check SW major version, expected = {dlt_payload['ecu_sw_version_ecu_swel_major']}, actual = {svk_report['SWFL'][0]['MAJOR_VER']}")
            Check = False
        if dlt_payload['ecu_sw_version_ecu_swel_minor'] == svk_report["SWFL"][0]["MINOR_VER"]:
            logger.info(f"Check SW minor version, expected = {dlt_payload['ecu_sw_version_ecu_swel_minor']}, actual = {svk_report['SWFL'][0]['MINOR_VER']}")
        else:
            logger.error(f"Check SW minor version, expected = {dlt_payload['ecu_sw_version_ecu_swel_minor']}, actual = {svk_report['SWFL'][0]['MINOR_VER']}")
            Check = False
        if dlt_payload['ecu_sw_version_ecu_swel_patch'] == svk_report["SWFL"][0]["PATCH_VER"]:
            logger.info(f"Check SW patch version, expected = {dlt_payload['ecu_sw_version_ecu_swel_patch']}, actual = {svk_report['SWFL'][0]['PATCH_VER']}")
        else:
            logger.error(f"Check SW patch version, expected = {dlt_payload['ecu_sw_version_ecu_swel_patch']}, actual = {svk_report['SWFL'][0]['PATCH_VER']}")
            Check = False
        return Check

    def compare_Serial_number(self, serial_number_dlt, jobs_bytes):
        Check = True
        serial_number_diag = ""
        for byte in jobs_bytes:
            val = hex(byte)
            serial_number_diag = serial_number_diag + str(bytearray.fromhex(val.split('x')[1]).decode())
        logger.info(f" serial_number_diag str = {serial_number_diag}")
        if serial_number_dlt == serial_number_diag:
            logger.info(f"Check serial_nr from DLT == serial_nr from diag, current: dlt: {serial_number_dlt}, diag: {serial_number_diag}")
        else:
            logger.error(f"Check serial_nr from DLT == serial_nr from diag, current: dlt: {serial_number_dlt}, diag: {serial_number_diag}")
            Check = False
        return Check

    def print_dlt_messages(self, dlt_messages):
        for dlt_msg in dlt_messages:
            logger.info("[DLT Messages ]:{0}\n".format(dlt_msg))
