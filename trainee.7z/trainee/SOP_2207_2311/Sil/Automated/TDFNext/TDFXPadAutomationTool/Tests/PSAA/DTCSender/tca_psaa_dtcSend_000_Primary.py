from Tests.PSAA.DTCSender.testfixture_PSAA_DTCSender import *


class tca_psaa_dtcSend_000_Primary(testfixture_PSAA_DTCSender):

    TEST_ID = "IntC\tca_psaa_dtcSend_000_Primary"
    REQ_ID = ["/item/1598725","/item/1598290","/item/1598280","/item/1598705"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Set primary DTC and check UDP packet is sent"
    STATUS = "Ready"
    OS = ['LINUX','QNX']

    def setUp(self):
        self.initiateConfigFile(memory_type="primary")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.apply_filter(contextId=self.context_Id, appId=self.LOG_COLLECTOR_APP_ID)
        self.dlt_manager.start_monitoring("SRR-DLT")
    def test_tca_psaa_dtcSend_000_Primary(self):
        self.startTestStep("Start tshark monitoring")
        self.network.sniffer.start_tshark_watching(filter=self.udpFilter(), adapater_name=self.Adapater_names[0])
        self.sleep_for(self.wait_tshark_to_start)
        self.startTestStep("Set DTC")
        self.setDTC()
        self.sleep_for(self.wait_DTC_to_be_set)
        self.startTestStep("Get DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR,
                                                       dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][self.PP_NAME],
                                                       memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue((read_status == self.DTC_ACTIVE) or (read_status == self.DTC_INACTIVE), Severity.BLOCKER, "Checking that DTC is set")
        self.sleep_for(self.wait_trigger_to_be_sent)
        self.startTestStep("Stop tshark monitoring")
        self.network.sniffer.stop_tshark_watching()
        self.sleep_for(self.wait_tshark_to_stop)
        self.startTestStep("Get packets")
        packets = self.network.sniffer.get_packets()
        self.expectTrue(len(packets)>0,Severity.BLOCKER,"Check packet with matching filter were captured")
        logger.info("packets: " + str(packets[0]['DATA'].data))

    def tearDown(self):
        pass
    
