from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_014_storage_cleanUp_03(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_014_storage_cleanUp_03"
    REQ_ID = ["/item/2593168", "/item/2593376"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check core dumps cleanup"
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        pass

    def test_tca_psaa_Chandler_014_storage_cleanUp_03(self):
        # kill ets
        self.startTestStep("Kill ETS app")
        application_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(application_is_killed, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.startTestStep("Check application ETS is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is not running")
        self.startTestStep("Get coredumps files names")
        self.assertTrue(self.check_coredumps(app_name=self.ETS_APP_NAME), Severity.BLOCKER, f"Checking that coredumps files were created properly")
        # kill uptime counter
        self.startTestStep("Kill uptime counter")
        application_is_killed = self.kill_application(app_name=self.UPTIME_COUNTER_APP_NAME,
                                            signal=self.killall_options["SIGSEGV"])
        self.expectTrue(application_is_killed, Severity.BLOCKER,
                        f"Checking that the {self.UPTIME_COUNTER_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.setPostcondition("Check application Uptimer counter is not running")
        uptime_counter_is_started = self.check_application_is_started(app_name=self.UPTIME_COUNTER_APP_NAME)
        self.expectTrue(not uptime_counter_is_started, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is not running")
        self.startTestStep("Get coredumps files names")
        self.assertTrue(self.check_coredumps(app_name=self.ETS_APP_NAME), Severity.BLOCKER, f"Checking that ets coredumps files were created properly")
        self.assertTrue(self.check_coredumps(app_name=self.UPTIME_COUNTER_APP_NAME), Severity.BLOCKER, f"Checking that uptime counter coredumps files were created properly")
        self.startTestStep("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls -lh {self.CoreDumps_Path}", ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Checking that the command executed successfully")
        logger.info("########## ls -lh returned : " + str(returnValue["stdout"].strip()) + "##########")
        dumps_list = returnValue["stdout"].splitlines()
        output = returnValue["stdout"].strip().splitlines()[0].split(' ')[1]
        target = self.convert_storage_size(Size=output, pourcentage=0.48)
        time = self.get_date()
        self.startTestStep("Create coredumps files under persistent")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command="fallocate -l {0} /persistent/coredumps/core.{1}.test.888.gz".format(target, time))
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        self.startTestStep("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls -lh {self.CoreDumps_Path}",
                                                              ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        logger.info("########## ls -lh returned : " + str(returnValue["stdout"].strip()) + "##########")
        new_dump_list = returnValue["stdout"].splitlines()
        logger.info("new_dump_list_size=" + str(len(new_dump_list)) + " must be == dumps_list_size=" + str(len(dumps_list)) + " + 1")
        self.expectTrue(len(new_dump_list) == len(dumps_list)+1, Severity.BLOCKER,
                        "Checking that crash handler is cleaning up persistent storage.")

    def tearDown(self):
        pass
