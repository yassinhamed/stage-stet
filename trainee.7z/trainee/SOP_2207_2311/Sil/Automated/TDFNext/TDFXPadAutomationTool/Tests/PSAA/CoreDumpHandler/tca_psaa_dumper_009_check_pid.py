from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_009_check_pid(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_009_check_pid"
    REQ_ID = ["/item/1736864","/item/1736931"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check the pid in coredumps file"
    STATUS = "Ready"
    OS = ['LINUX']

    pid_of_ETS = 0

    def setUp(self):

        self.setPrecondition("Get pid of ETS app")
        returnValue = self.get_process_id(app_name=self.ETS_APP_NAME)
        self.assertTrue(returnValue != -1, Severity.BLOCKER,
                        f"Check the get pid of {self.ETS_APP_NAME}")
        self.pid_of_ETS = returnValue

    def test_tca_psaa_dumper_009_check_pid(self):

        self.startTestStep("Kill application ETS")
        ets_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(ets_is_killed, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

        self.startTestStep("Check application is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is not running")

        self.startTestStep("check coredumps created")
        coredumps_created = self.check_coredumps(self.ETS_APP_NAME)
        self.assertTrue(coredumps_created,Severity.BLOCKER,"Checking that coredumps files were created properly.")

        self.startTestStep("Get Pid from context file")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep 'context.*.txt'", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Check 'ls | grep' command is executed")
        context_files = returnValue["stdout"].strip().split("\n")


        dump_file = context_files[0].split('.')
        logger.info(f"dump_file:{dump_file}")
        self.expectTrue(int(dump_file[3]) == int(self.pid_of_ETS), Severity.MAJOR, f"Check Pid from file {dump_file[3]} is the same from real pid {self.pid_of_ETS}")

    def tearDown(self):
        pass
