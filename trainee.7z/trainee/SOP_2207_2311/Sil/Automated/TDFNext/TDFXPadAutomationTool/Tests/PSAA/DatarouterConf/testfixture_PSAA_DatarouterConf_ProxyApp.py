from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_DatarouterConf_ProxyApp(testfixture_PSAA):
    dconf_config_path = "/opt/datarouterconf/etc"
    dconf_path = "/opt/datarouterconf"
    log_channels_config_file_path = "/opt/datarouter/etc/log-channels.json"
    set_argVal = "append log string debug message"
    set_argVal_1 = "append log string info message"
    set_argVal_2 = "append log string warn message"
    set_contextId = "CTX1"
    set_logOperation_3 = LogOps.LOG_DEBUG
    set_logOperation_0 = LogOps.LOG_VERBOSE
    set_logOperation_1 = LogOps.LOG_INFO
    set_logOperation_2 = LogOps.LOG_WARN
    STEUERN_DLT_SET_LOGLEVEL_PRXA_CTX1_AUS = [0x31, 0x01, 0x10, 0x90, 0x50, 0x52, 0x58, 0x41, 0x43, 0x54, 0x58, 0x31, 0x00]
    STEUERN_DLT_SET_LOGLEVEL_PRXA_CTX1_WARN = [0x31, 0x01, 0x10, 0x90, 0x50, 0x52, 0x58, 0x41, 0x43, 0x54, 0x58, 0x31, 0x03]
    STEUERN_DLT_SET_LOGLEVEL_PRXA_CTX1_STANDARD = [0x31, 0x01, 0x10, 0x90, 0x50, 0x52, 0x58, 0x41, 0x43, 0x54, 0x58, 0x31, 0xff]
    STEUERN_DLT_SET_MESSAGEFILTERINGSTATE_AUS = [0x31, 0x01, 0x10, 0x92, 0x00]
    STEUERN_DLT_SET_MESSAGEFILTERINGSTATE_EIN = [0x31, 0x01, 0x10, 0x92, 0x01]
    STEUERN_DLT_SET_LOGCHANNEL_THRESHOLD_HIGH_AUS_ON = [0x31, 0x01, 0x10, 0x93, 0x48, 0x49, 0x47, 0x48, 0x00, 0x01]
    STEUERN_DLT_SET_LOGCHANNEL_THRESHOLD_LOW_AUS_ON = [0x31, 0x01, 0x10, 0x93, 0x48, 0x49, 0x47, 0x48, 0x00, 0x01]
    diag_payload = [0x31, 0x01, 0xF0, 0x05]
    PRXA_hex = [0x50, 0x52, 0x58, 0x41]
    CTX1_hex = [0x43, 0x54, 0x58, 0x31]
    LOW_hex = [0x4C, 0x4F, 0x57, 0x00]
    enable_hex = [0x01]
    disable_hex = [0x00]
    wait_for_dlt_message_to_be_sent = 4000


    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_IntC_RxSWIN_ProxyApp setUpclass")
        cls.deploy_proxy_app()
        cls.start_tdf_proxy_communication()
        cls.check_proxy_app()
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=path.join(OutputPathManager.get_tests_group_path(), "coredumps_setupclass_with_proxyapp"),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])
        cls.proxy_app_settings = ProxyAppSettings()

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_IntC_RxSWIN_ProxyApp tearDownclass")
        cls.stop_tdf_proxy_communication()
        cls.undeploy_proxy_app()

    def reset_ecu_if_json_changed(self, json_is_changed):
        if json_is_changed:
            self.diag_manager.start()
            self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
            self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
            self.diag_manager.restart()
            exitCode, message = self.proxy_app_settings.check_logging_manifest(logLevel=self.Log_levels["verbose"], logMode=self.Log_modes["remote"])
            self.assertTrue(exitCode, Severity.BLOCKER, message)

    def setUp(self):
        self.check_proxy_app()

    def tearDown(self):
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_test_case_path(),check_empty=False,ip_address=self.PP_IP,ignored_files=["currentswversion", "tmp"])

