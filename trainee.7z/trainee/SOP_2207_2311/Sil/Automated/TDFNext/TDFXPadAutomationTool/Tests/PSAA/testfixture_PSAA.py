from Tests.testBase_SIL import *

class testfixture_PSAA(testBase_SIL):
    Log_channels_file_name = "log-channels.json"
    uptimecounter_kvs_path = "/persistent/uptime_counter/"
    kvs_name = "key_value_storage"


    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA setUpclsss")
        # ToDo add mkdir of paths for all changed files under PSAA domain
        if cls.os_name == "QNX":
            cls.sfa_manager.set_up(target_address=cls.PP_DIAG_ADR)
            cls.ecu_uid = cls.sfa_manager.get_ecu_uid(cls.PP_DIAG_ADR, use_cache=False)
            cls.sfa_manager.safe_set_to_engineering_mode(target=cls.PP_DIAG_ADR)
            mode = cls.sfa_manager.sfa_get_ecu_mode(target=cls.PP_DIAG_ADR)
            cls.assertTrue(EcuMode.Engineering.value == mode, Severity.BLOCKER, 'Error when reading ECU mode')
            feature_status = cls.sfa_manager.sfa_get_status(cls.PP_DIAG_ADR, feature_id=cls.SFA_ID)
            if feature_status != Feature_Status.Enabled.value:
                res = cls.sfa_manager.set_secure_feature(target=cls.PP_DIAG_ADR, ecu_uid=cls.ecu_uid,
                                                         feature_id=cls.SFA_ID,
                                                         feature_spec_fields=cls.sfa_manager.generate_ssh_key_payload())
            feature_status = cls.sfa_manager.sfa_get_status(cls.PP_DIAG_ADR, feature_id=cls.SFA_ID)
            cls.expectTrue(feature_status == Feature_Status.Enabled.value, Severity.BLOCKER,
                           "check that 1D1A token is enabled")

            cls.clear_and_activate_d1c5()
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/datarouter", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/datarouter/etc", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/datarouterconf", timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/datarouterconf/etc",timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/log_collector", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/log_collector/etc", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/DtcStatusSender", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/DtcStatusSender/etc", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/proxy_app", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/proxy_app/bin", timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/proxy_app/etc", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/crash_reporter", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/crash_reporter/etc", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/uptime_counter", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/uptime_counter/etc", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/std_frame", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/std_frame/etc", timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/sysmon", timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/sysmon/etc", timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/param_server", timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/param_server/etc", timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/mmr_reader",timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)
            cls.ssh_manager.executeCommandInTarget(command="mkdir -p /opt/mmr_reader/etc",timeout=cls.SSH_CONNECTION_TIMEOUT_MS, ip_address=cls.PP_IP)

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA tearDownclsss")
