from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *
import io


class tca_sysmon_domain_reporting_01_check_config_file_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_domain_reporting_01_check_config_file_LINUX"
    REQ_ID = ["/item/5866393"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check information in the domain grouping config file"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        pass

    def test_tca_sysmon_domain_reporting_01_check_config_file_LINUX(self):
        self.startTestStep("Download the domain reporting config file")
        self.ssh_manager.downloadFileFromTarget(source_file="domainlist.json", source_path="/opt/sysmon/etc", destination_path=OutputPathManager.get_test_case_path())
        self.startTestStep("Get the content of the file")
        with io.open(path.join(OutputPathManager.get_test_case_path(), "domainlist.json")) as domainlist_file:
            config_dict = json.load(domainlist_file)

        self.expectTrue(all("domain_name" in process_dict for process_dict in config_dict["processes"]), Severity.BLOCKER, "Check that each process has the key for the domain name")
        self.expectTrue(all("process_name" in process_dict for process_dict in config_dict["processes"]), Severity.BLOCKER, "Check that each process has the key for process name")

    def tearDown(self):
        pass
