from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_004_user_space_initial_dtc(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_004_user_space_initial_dtc"
    REQ_ID = ["/item/2593168", "/item/2593271", "/item/6612659"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check user space DTC status without kill of adaptive app"
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    def setUp(self):
        pass

    def test_tca_psaa_Chandler_004_user_space_initial_dtc(self):
        self.diag_manager.start()
        self.startTestStep("Reset ECU")
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.restart()

        self.startTestStep("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Checking that 'ls ' command executed successfully")
        dumps_list = returnValue["stdout"].splitlines()
        self.expectTrue(self.check_no_coredumps_exists(coredumps=dumps_list), Severity.BLOCKER, "Checking that no Coredumps exists")
        self.download_core_dumps_by_names(dumps_list=dumps_list)
        """self.startTestStep("Check primary DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Software_Fehler"][self.PP_NAME], memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_NOT_PRESENT, Severity.BLOCKER, "Checking that DTC is not set")"""
        self.startTestStep("Check secondary DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Applikation_wurde_unerwartet_beendet"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_NOT_PRESENT, Severity.BLOCKER, "Checking that DTC is not set")

    def tearDown(self):
        pass
