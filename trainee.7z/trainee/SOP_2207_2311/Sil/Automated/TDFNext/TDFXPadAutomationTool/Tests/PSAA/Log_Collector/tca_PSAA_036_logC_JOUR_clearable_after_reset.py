from Tests.PSAA.Log_Collector.testfixture_PSAA_Log_Collector import *


class tca_PSAA_036_logC_JOUR_clearable_after_reset(testfixture_PSAA_Log_Collector):

    TEST_ID = "PSAA\tca_PSAA_036_logC_JOUR_clearable_after_reset"
    REQ_ID = ["/item/6040647", "/item/2939949"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Modify primary and secondary DTCs of Journal to clearable in config file and check DTCs are clearables after reset"
    STATUS = "Obsolete"
    OS = ['LINUX']

    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appId=self.LOG_COLLECTOR_APP_ID)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_PSAA_036_logC_JOUR_clearable_after_reset(self):
        self.startTestStep("Modify primary and secondary DTCs of Journal to clearable in config file")
        self.logCollectorModifyConfigFile(MessageSource=self.Journal_context_ID, MessageRegex=self.specific_journal_message, SetDTC022292="Clearable", SetDTC482EA9="Clearable", LogDlt="Yes")
        self.diag_manager.start()
        self.startTestStep("Reset ECU")
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECU")
        self.check_ECUs()
        self.startTestStep("Check log collector application is running")
        grep_LogC = self.check_application_is_started(app_name=self.LOG_COLLECTOR_APP_NAME)
        self.expectTrue(grep_LogC, Severity.MAJOR, "Check The application was started")
        self.startTestStep("Get Journal log messages")
        Message = self.logCollectorGetJournalLog(MessageRegex=self.specific_journal2_message)
        logger.info(str(Message))
        self.assertTrue(Message is not None, "check that message exist in journalctl")
        self.startTestStep("Get DLT messages")
        number, messages = self.dlt_manager.wait_for_message(search_message=self.specific_journal2_message)
        self.assertTrue(number > 0, Severity.BLOCKER, "Check Journal messages are being forwarded with JOUR context ID")
        self.startTestStep("Check primary SW_Integritätsprüfung_fehlgeschlagen DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][self.PP_NAME], memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that DTC is set")
        self.startTestStep("Check secondary Interne_System_Manipulation_erkannt DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Interne_System_Manipulation_erkannt"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that DTC is set")

        self.diag_manager.start()
        self.startTestStep("Reset ECU")
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECU")
        self.check_ECUs()

        self.startTestStep("Check primary SW_Integritätsprüfung_fehlgeschlagen DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][self.PP_NAME], memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue((read_status == self.DTC_STATUS_AFTER_RESET_OnStartupDTC), Severity.BLOCKER,"Checking that primary DTC is set")
        self.startTestStep("Check secondary Interne_System_Manipulation_erkannt DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Interne_System_Manipulation_erkannt"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue((read_status == self.DTC_STATUS_AFTER_RESET_OnStartupDTC), Severity.BLOCKER,"Checking that secondary DTC is set")

        self.startTestStep("Clear all DTC memory")
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)

        self.startTestStep("Check primary SW_Integritätsprüfung_fehlgeschlagen DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["SW_Integritätsprüfung_fehlgeschlagen"][self.PP_NAME], memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue((read_status == self.DTC_NOT_PRESENT), Severity.BLOCKER, "Checking the primary DTC after clear is not set")
        self.startTestStep("Check secondary Interne_System_Manipulation_erkannt DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Interne_System_Manipulation_erkannt"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue((read_status == self.DTC_NOT_PRESENT), Severity.BLOCKER,"Checking that secondary DTC is not set")

    def tearDown(self):
        self.diag_manager.start()
        self.setPostcondition("Revert Config file")
        self.logCollectorRevertConfigFile()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
