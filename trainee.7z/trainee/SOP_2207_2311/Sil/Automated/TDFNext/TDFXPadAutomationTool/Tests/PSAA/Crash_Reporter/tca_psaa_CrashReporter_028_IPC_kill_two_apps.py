from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter_With_Proxy_App import *


class tca_psaa_CrashReporter_028_IPC_kill_two_apps(testfixture_PSAA_Crash_Reporter_With_Proxy_App):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_028_IPC_kill_two_apps"
    REQ_ID = ["/item/6588649", "/item/6588684"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check IPC coredump status notification when killing two applications"
    STATUS = "Ready"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Clear old core dumps")
        remove_is_done = self.remove_old_coredumps()
        self.expectTrue(remove_is_done, Severity.MAJOR, "Check the remove of old coredumps is done")

        self.setPrecondition("Check crash reporter is running")
        crash_reporter_is_running = self.get_process_id(app_name=self.CRASH_REPORTER_APP_NAME)
        self.expectTrue(crash_reporter_is_running != -1, Severity.MAJOR, "Check that crash reporter is running")

        self.setPrecondition("Import proxy app library")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.FUSA.value)

    def test_tca_psaa_CrashReporter_028_IPC_kill_two_apps(self):
        self.startTestStep("Subscribe to IPC event using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.subscribe_to_crash_reporter()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_subcriptionState == CrashReporterEventType.SUBSCRIBE.value, Severity.MAJOR, "Check that Crash Reporter is unsubscribed successfully")

        self.startTestStep("Wait for IPC notification to be sent")
        self.sleep_for(self.WAIT_IPC_notification_MS)

        self.startTestStep("Checking that Planning is running")
        app_is_running = self.check_application_is_started(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(app_is_running, Severity.MAJOR, "Check that Planning is running ")

        self.startTestStep("Checking that Fasinfo is running")
        app_is_running = self.check_application_is_started(app_name=self.FASINFO_APP_NAME)
        self.assertTrue(app_is_running, Severity.MAJOR, "Check that Fasinfo is running ")

        self.startTestStep("Killing Planning application")
        application_is_killed = self.kill_application_CR(app_name=self.PLANNING_APP_NAME, signal=self.killall_options["SIGABRT"])
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check command is successfully executed")

        self.startTestStep("Check IPC coredump active notification of Planning is sent")
        exit_code = self.proxy_app_manager.FUSA_comm.get_crash_reporter_status()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_coreDumpState == CrashReporterCoreDumpStatus.COREDUMP_Active.value, Severity.MAJOR, "Check IPC coredump notification is sent")

        #self.startTestStep("Checking coredump active notification of Planning is sent to proxy app")
        #message_count, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.PROXY_APP_APP_ID, searchMsgArray=self.kCoreDumpActive_Message_PrApp)
        #self.expectTrue(message_count > 0, Severity.BLOCKER, "Check coredump active notification of Planning is sent to proxy app")

        #self.startTestStep("Checking coredump active notification of Planning is sent to CrashReporterAraProxy")
        #kCoreDumpsDetected, dlt_messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.CRASH_REPORTER_ARA_PROXY_APP_NAME_APP_ID, searchMsgArray=self.kCoreDumpActive_Message_CRP)
        #self.expectTrue(kCoreDumpsDetected > 0, Severity.BLOCKER, "Check coredump active notification of Planning is sent to CrashReporterAraProxy")

        self.startTestStep("Wait for coredumps creation")
        self.sleep_for(self.WAIT_FOR_COREDUMPS_GENERATION_MS)

        self.startTestStep("Checking that Planning application is killed")
        app_is_running = self.check_application_is_started(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(not app_is_running, Severity.MAJOR, "Check that Planning is running")

        self.startTestStep("Check IPC coredump completed notification of Planning contains the request of persistent log file")
        exit_code = self.proxy_app_manager.FUSA_comm.get_crash_reporter_status()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")

        self.startTestStep("Checking coredump completed notification of Planning is sent to proxy app")
        message_count, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.PROXY_APP_APP_ID, searchMsgArray=self.kCoreDumpCompleted_Message_PrApp)
        self.expectTrue(message_count > 0, Severity.BLOCKER, "Check that coredump completed notification of Planning is sent to proxy app")

        #self.startTestStep("Checking coredump completed notification of Planning is sent to CrashReporterAraProxy")
        #kCoreDumpCompleted, dlt_messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.CRASH_REPORTER_ARA_PROXY_APP_NAME_APP_ID, searchMsgArray=self.kCoreDumpCompleted_Message_CRP)
        #self.expectTrue(kCoreDumpCompleted > 0, Severity.BLOCKER, "Check coredump completed notification of Planning is sent to CrashReporterAraProxy")

        self.startTestStep("Checking that Planning coredumps are successfully created")
        #context file check
        app_name_in_context_file = self.context_file_check(app_name=self.PLANNING_APP_NAME)
        self.expectTrue(app_name_in_context_file, Severity.MAJOR, "Check the context file is created successfully under /persistent/coredumps")
        # core file check
        app_name_in_core_file = self.core_file_check(app_name=self.PLANNING_APP_NAME)
        self.expectTrue(app_name_in_core_file, Severity.MAJOR, "Check the core file is created successfully under /persistent/coredumps")

        self.startTestStep("Killing Fasinfo application")
        application_is_killed = self.kill_application(app_name=self.FASINFO_APP_NAME, signal=self.killall_options["SIGABRT"])
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check command is successfully executed")

        self.startTestStep("Check IPC coredump active notification of Fasinfo is sent")
        exit_code = self.proxy_app_manager.FUSA_comm.get_crash_reporter_status()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_coreDumpState == CrashReporterCoreDumpStatus.COREDUMP_Active.value, Severity.MAJOR, "Check IPC coredump notification is sent")

        #self.startTestStep("Checking coredump active notification of Fasinfo is sent to proxy app")
        #message_count, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.PROXY_APP_APP_ID, searchMsgArray=self.kCoreDumpActive_Message_PrApp)
        #self.expectTrue(message_count > 1, Severity.BLOCKER, "Check coredump active notification of Fasinfo is sent to proxy app")

        #self.startTestStep("Checking coredump active notification of Fasinfo is sent to CrashReporterAraProxy")
        #kCoreDumpsDetected, dlt_messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.CRASH_REPORTER_ARA_PROXY_APP_NAME_APP_ID, searchMsgArray=self.kCoreDumpActive_Message_CRP)
        #self.expectTrue(kCoreDumpsDetected > 1, Severity.BLOCKER, "Check coredump active notification of Fasinfo is sent to CrashReporterAraProxy")

        self.startTestStep("Wait for coredumps creation")
        self.sleep_for(self.WAIT_FOR_COREDUMPS_GENERATION_MS)

        self.startTestStep("Checking that Fasinfo application is killed")
        app_is_running = self.check_application_is_started(app_name=self.FASINFO_APP_NAME)
        self.assertTrue(not app_is_running, Severity.MAJOR, "Check that Fasinfo is running")

        self.startTestStep("Check IPC coredump completed notification of Fasinfo contains the request of persistent log file")
        exit_code = self.proxy_app_manager.FUSA_comm.get_crash_reporter_status()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")

        self.startTestStep("Checking coredump completed notification of Planning is sent to proxy app")
        message_count, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.PROXY_APP_APP_ID, searchMsgArray=self.kCoreDumpCompleted_Message_PrApp)
        self.expectTrue(message_count > 0, Severity.BLOCKER, "Check that coredump completed notification of Planning is sent to proxy app")

        #self.startTestStep("Checking coredump completed notification of Fasinfo is sent to CrashReporterAraProxy")
        #kCoreDumpCompleted, dlt_messages = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.CRASH_REPORTER_ARA_PROXY_APP_NAME_APP_ID, searchMsgArray=self.kCoreDumpCompleted_Message_CRP)
        #self.expectTrue(kCoreDumpCompleted > 0, Severity.BLOCKER, "Check coredump completed notification of Fasinfo is sent to CrashReporterAraProxy")

        self.startTestStep("Checking that Fasinfo coredumps are successfully created")
        #context file check
        app_name_in_context_file = self.context_file_check(app_name=self.FASINFO_APP_NAME)
        self.expectTrue(app_name_in_context_file, Severity.MAJOR, "Check the context file is created successfully under /persistent/coredumps")
        # core file check
        app_name_in_core_file = self.core_file_check(app_name=self.FASINFO_APP_NAME)
        self.expectTrue(app_name_in_core_file, Severity.MAJOR, "Check the core file is created successfully under /persistent/coredumps")

        self.startTestStep("Unsubscribe to IPC event using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.unsubscribe_to_crash_reporter()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_subcriptionState == CrashReporterEventType.UNSUBSCRIBE.value, Severity.MAJOR, "Check that Crash Reporter is unsubscribed successfully")

    def tearDown(self):
        self.setPostcondition("Remove proxy app library")
        self.proxy_app_manager.remove_proxy_app_lib(libName.FUSA.value)
