from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_configuration_001_reporting_intervals_QNX(testfixture_PSAA_SysMon):
    TEST_ID = "PSAA/SysMon/tca_sysmon_configuration_001_reporting_intervals_QNX"
    REQ_ID = ["/item/5906449"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon configuration file has for each monitoring an interval"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        pass

    def test_tca_sysmon_configuration_001_reporting_intervals_QNX(self):
        for context_id in self.qnx_time_interval_mapping:
            time_interval = self.get_time_interval_qnx(contextID=context_id)
            self.expectTrue(time_interval != self.INVALID_VALUE, Severity.MAJOR, "Check that time_interval could be retrieved")

    def tearDown(self):
        pass
