from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter_With_Proxy_App import *


class tca_psaa_CrashReporter_030_IPC_notifications_of_two_apps_sent_separately(testfixture_PSAA_Crash_Reporter_With_Proxy_App):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_030_IPC_notifications_of_two_apps_sent_separately"
    REQ_ID = ["/item/6588649", "/item/6588684"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check IPC coredump status notification of two applications are sent separately"
    STATUS = "Obsolete"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Clear old core dumps")
        remove_is_done = self.remove_old_coredumps()
        self.expectTrue(remove_is_done, Severity.MAJOR, "Check the remove of old coredumps is done")

        self.setPrecondition("Check crash reporter is running")
        crash_reporter_is_running = self.parse_crash_reporter_commandline_parameters()
        self.expectTrue(crash_reporter_is_running, Severity.MAJOR, "Check that crash reporter is running")

        self.setPrecondition("Import proxy app library")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.FUSA.value)

    def test_tca_psaa_CrashReporter_030_IPC_notifications_of_two_apps_sent_separately(self):
        self.startTestStep("Subscribe to IPC event using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.subscribe_to_crash_reporter()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_subcriptionState == CrashReporterEventType.SUBSCRIBE.value, Severity.MAJOR, "Check that Crash Reporter is unsubscribed successfully")

        self.startTestStep("Checking that Planning is running")
        app_is_running = self.check_application_is_started(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(app_is_running, Severity.MAJOR, "Check that Planning is running ")

        self.startTestStep("Killing Planning application")
        application_is_killed = self.kill_application_CR(app_name=self.PLANNING_APP_NAME, signal=self.killall_options["SIGABRT"])
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check command is successfully executed")

        self.startTestStep("Freeze dumper of first application kill")
        self.startTestStep("Get IPC coredump notification")
        self.expectTrue(True, Severity.MAJOR, "Check IPC coredump notification is sent")
        self.expectTrue(True, Severity.MAJOR, "Check IPC coredump notification contains the kCoreDumpActive status (1) of first application is sent")

        self.startTestStep("Checking that Fasinfo is running")
        app_is_running = self.check_application_is_started(app_name=self.FASINFO_APP_NAME)
        self.assertTrue(app_is_running, Severity.MAJOR, "Check that Fasinfo is running ")

        self.startTestStep("Killing Fasinfo application")
        application_is_killed = self.kill_application_CR(app_name=self.FASINFO_APP_NAME, signal=self.killall_options["SIGABRT"])
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check command is successfully executed")

        self.startTestStep("Get IPC coredump notification")
        self.expectTrue(True, Severity.MAJOR, "Check IPC coredump notification is sent")
        self.expectTrue(True, Severity.MAJOR, "Check IPC coredump notification contains the kCoreDumpActive status (1) of second application is sent")
        self.startTestStep("Wait for coredumps creation")

        self.startTestStep("Checking that Fasinfo application is killed")
        app_is_running = self.check_application_is_started(app_name=self.FASINFO_APP_NAME)
        self.assertTrue(not app_is_running, Severity.MAJOR, "Check that Fasinfo is running")

        self.startTestStep("Checking that Fasinfo coredumps are successfully created")
        #context file check
        app_name_in_context_file = self.context_file_check(app_name=self.FASINFO_APP_NAME)
        self.expectTrue(app_name_in_context_file, Severity.MAJOR, "Check the context file is created successfully under /persistent/coredumps")
        # core file check
        app_name_in_core_file = self.core_file_check(app_name=self.FASINFO_APP_NAME)
        self.expectTrue(app_name_in_core_file, Severity.MAJOR, "Check the core file is created successfully under /persistent/coredumps")

        self.startTestStep("Get IPC coredump notification")
        self.expectTrue(True, Severity.MAJOR, "Check IPC coredump notification is sent")
        self.expectTrue(True, Severity.MAJOR, "Check IPC coredump notification contains the kCoreDumpCompleted status (2) of second application is sent")
        self.startTestStep("Continue dumper of first application kill")

        self.startTestStep("Wait for coredumps creation")
        self.sleep_for(self.WAIT_FOR_COREDUMPS_GENERATION_MS)

        self.startTestStep("Killing Planning application")
        application_is_killed = self.kill_application_CR(app_name=self.PLANNING_APP_NAME, signal=self.killall_options["SIGABRT"])
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check command is successfully executed")

        self.startTestStep("Checking that Planning coredumps are successfully created")
        #context file check
        app_name_in_context_file = self.context_file_check(app_name=self.PLANNING_APP_NAME)
        self.expectTrue(app_name_in_context_file, Severity.MAJOR, "Check the context file is created successfully under /persistent/coredumps")
        # core file check
        app_name_in_core_file = self.core_file_check(app_name=self.PLANNING_APP_NAME)
        self.expectTrue(app_name_in_core_file, Severity.MAJOR, "Check the core file is created successfully under /persistent/coredumps")

        self.startTestStep("Get IPC coredump notification")
        self.expectTrue(True, Severity.MAJOR, "Check IPC coredump notification is sent")
        self.expectTrue(True, Severity.MAJOR, "Check IPC coredump notification contains the kCoreDumpCompleted status (2) of first application is sent")

        self.startTestStep("Unsubscribe to IPC event using proxy app")
        exit_code = self.proxy_app_manager.FUSA_comm.unsubscribe_to_crash_reporter()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR, "Check SUCCESS ExitCode recieved from ProxyApp")
        self.expectTrue(self.proxy_app_manager.FUSA_comm.crashReporter_subcriptionState == CrashReporterEventType.UNSUBSCRIBE.value, Severity.MAJOR, "Check that Crash Reporter is unsubscribed successfully")

    def tearDown(self):
        self.setPostcondition("Remove proxy app library")
        self.proxy_app_manager.remove_proxy_app_lib(libName.FUSA.value)