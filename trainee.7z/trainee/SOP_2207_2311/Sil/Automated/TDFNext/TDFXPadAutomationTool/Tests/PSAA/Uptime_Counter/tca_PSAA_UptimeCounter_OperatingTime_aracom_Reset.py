from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter_ProxyApp import *


class tca_PSAA_UptimeCounter_OperatingTime_aracom_Reset(testfixture_PSAA_UptimeCounter_ProxyApp):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_OperatingTime_aracom_Reset"
    REQ_ID = ["/item/6233416"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check Operating time counter value after reset using ara::com interface"
    STATUS = "Ready"
    OS = ["QNX"]

    def setUp(self):
        self.setPrecondition("Load FuSa Library")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.FUSA.value)

    def test_tca_PSAA_UptimeCounter_OperatingTime_aracom_Reset(self):
        self.startTestStep("Get Operating time in milliseconds")
        exit_code = self.proxy_app_manager.FUSA_comm.get_utc_operating_time()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR,"Check SUCCESS ExitCode recieved from ProxyApp")
        first_operating_time = self.proxy_app_manager.FUSA_comm.utc_operatingTimeMS
        logger.info(f"first_operating_time= {first_operating_time}")

        self.startTestStep("Reset Operating time counter")
        exit_code = self.proxy_app_manager.FUSA_comm.reset_utc_operationg_statistics()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR,"Check SUCCESS ExitCode recieved from ProxyApp")

        self.startTestStep("Unload FuSa Library")
        self.proxy_app_manager.remove_proxy_app_lib(libName.FUSA.value)

        self.startTestStep("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        self.startTestStep("Check Ecus")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUS are correctly reset")

        self.startTestStep("Load FuSa Library")
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.FUSA.value)

        self.startTestStep("Get operating time counter value after reset")
        exit_code = self.proxy_app_manager.FUSA_comm.get_utc_operating_time()
        self.expectTrue(exit_code == linuxExitCode.SUCCESS.value, Severity.MAJOR,"Check SUCCESS ExitCode recieved from ProxyApp")
        second_operating_time = self.proxy_app_manager.FUSA_comm.utc_operatingTimeMS
        logger.info(f"second_operating_time= {second_operating_time}")

        self.assertTrue(int(second_operating_time) < 30000, Severity.BLOCKER, "Check that Operating time counter are reset")

    def tearDown(self):
        self.setPostcondition("Unload FuSa Library")
        self.proxy_app_manager.remove_proxy_app_lib(libName.FUSA.value)
