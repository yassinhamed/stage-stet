from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_low_level_003_LLED_temperature_report(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_low_level_003_LLED_temperature_report"
    REQ_ID = ["/item/5897072", "/item/5889679"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that  sysmon reports the temperature for each CPU core"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get number of cores")
        self.assertTrue(self.number_of_cores != self.INVALID_VALUE, Severity.MAJOR, "Check that number of online cores is available")
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.Low_level_error_diagnostics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["LLED"]["temperature"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.Low_level_error_diagnostics_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_low_level_003_LLED_temperature_report(self):
        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get LLED temperature report DLT message")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that LLED DLT messages are available")

        self.startTestStep("Get core0 value")
        core0 = self.get_statistic_value(message=messages[0], statistic_path="LLED.temperature.Statistics.core0")
        self.expectTrue(core0 != self.INVALID_VALUE, Severity.MAJOR, "Check that core0 is reported")

        self.startTestStep("Get core1 value")
        core1 = self.get_statistic_value(message=messages[0], statistic_path="LLED.temperature.Statistics.core1")
        self.expectTrue(core1 != self.INVALID_VALUE, Severity.MAJOR, "Check that core1 is reported")

        self.startTestStep("Get core2 value")
        core2 = self.get_statistic_value(message=messages[0], statistic_path="LLED.temperature.Statistics.core2")
        self.expectTrue((core2 != self.INVALID_VALUE) == (self.number_of_cores == 4), Severity.MAJOR, "Check that core2 is reported if nr of cores is > 2")

        self.startTestStep("Get core3 value")
        core3 = self.get_statistic_value(message=messages[0], statistic_path="LLED.temperature.Statistics.core3")
        self.expectTrue((core3 != self.INVALID_VALUE) == (self.number_of_cores == 4), Severity.MAJOR, "Check that core2 is reported if nr of cores is > 3")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
