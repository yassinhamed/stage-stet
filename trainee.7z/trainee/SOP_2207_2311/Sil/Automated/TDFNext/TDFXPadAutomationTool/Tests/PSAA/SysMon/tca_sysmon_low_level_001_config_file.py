from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_low_level_001_config_file(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_low_level_001_config_file"
    REQ_ID = ["/item/5890355", "/item/5889679"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that hw registers configuration file"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        pass

    def test_tca_sysmon_low_level_001_config_file(self):
        self.startTestStep("Find hw_reg.json using ls command")
        result = self.ssh_manager.executeCommandInTarget(command=f"if [ -e /opt/sysmon/etc/hw_reg.json ]; then echo file exists; fi", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(result['stdout'].strip() == "file exists", Severity.BLOCKER, "Check that hw_reg.json exists")
        self.startTestStep("Get the content of the configuration file")
        self.ssh_manager.downloadFileFromTarget(source_file="hw_reg.json", source_path="/opt/sysmon/etc", destination_path=OutputPathManager.get_test_case_path())
        hw_reg_dict = None
        with io.open(path.join(OutputPathManager.get_test_case_path(), "hw_reg.json")) as fl:
            hw_reg_dict = json.load(fl)
        self.assertTrue(hw_reg_dict is not None, Severity.BLOCKER, "Check that hw_reg.json content could be load in a dict")
        self.startTestStep("Check the schema of the dict ")
        self.expectTrue(all("register_type" in hw_reg for hw_reg in hw_reg_dict), Severity.MAJOR, "Check that register_type is defined")
        self.expectTrue(all("summary" in hw_reg for hw_reg in hw_reg_dict), Severity.MAJOR, "Check that summary is defined")
        self.expectTrue(all("start_bit" in hw_reg for hw_reg in hw_reg_dict), Severity.MAJOR, "Check that start_bit is defined")
        self.expectTrue(all("end_bit" in hw_reg for hw_reg in hw_reg_dict), Severity.MAJOR, "Check that end_bit is defined")
        self.expectTrue(all("report_" in " ".join(list(hw_reg.keys())) for hw_reg in hw_reg_dict), Severity.MAJOR, "Check that error condition is defined")

    def tearDown(self):
        pass
