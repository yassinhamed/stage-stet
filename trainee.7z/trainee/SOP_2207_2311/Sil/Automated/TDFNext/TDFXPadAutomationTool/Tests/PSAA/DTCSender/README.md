# DtcStatusSender

DtcStatusSender is an adaptive application (Applictaion id : DTCS) that sends a UDP multicast message when a DTC has failed to trigger the VIGEM logger. The UDP frame has the following fields mentioned in this filter:  

- ip.src = 160.48.199.34 
- ip.dst = 239.255.42.98
- udp.dstport = 3489
- adapater_name = "Stimulation"
- proto_filter = "udp"  

**Trigger conditions**

The trigger message is sent if all conditions are met: 

1. Secure Debug is enabled, e.g. with ECU mode in ENGINEERING mode or SFA token 0x001D1A. 

2. A (primary or secondary) DTC status change from false to true in the testFailed bit (Bit 0 of the DTC status) 

3. Debounce interval of 30 seconds is passed. 

**Message format**

Field | Value
------ | ------
Source IP Address    | 160.48.199.34
Destination IP Address    | 239.255.42.98
Destination MAC Address    | 01:00:5e:7f:2a:62
Source Port   | 3488
Destination Port   | 3489
Network port    | Forwared to FRR only  

**Payload format**

UDP mulitcast message with a payload length of 6 bytes: 

Index | Value
------ | ------
0-3     | DTC identifier (little-endian) 
4     | New DTC status byte 
5     | Old DTC status byte 
