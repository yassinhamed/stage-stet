from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_023_exceed_quota_Linux(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_023_exceed_quota_Linux"
    REQ_ID = ["/item/8253068", "/item/2593376", "/item/2593168"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check coredumps cleanup after killing two apps with first app coredumps doesn't excess quota and the second excess quota"
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        self.setPrecondition("Restart crash handler with parameter --coredumps_storage_quota_mb 5 and --storage_cleanup_percentage 100")
        crash_handler_restarted = self.restart_crash_handler_with_params(coredumps_storage_quota_mb="5", storage_cleanup_percentage="100")
        self.assertTrue(crash_handler_restarted, Severity.MAJOR, "Check crash handler restarted")
        self.setPrecondition("Get crash reporter process information using ps -A -o pid,args | grep crash_handler")
        crash_handler_parameters = self.parse_crash_handler_commandline_parameters()
        self.assertTrue(crash_handler_parameters is not None, Severity.MAJOR, "Check crash handler restarted")
        self.assertTrue(crash_handler_parameters["quota"] == "5", Severity.MAJOR, "Check crash handler quota equal to 5")
        self.assertTrue(crash_handler_parameters["percentage"] == "100", Severity.MAJOR, "Check crash handler quota equal to 100")
        self.setPrecondition("Clear old core dumps")
        remove_is_done = self.remove_old_coredumps()
        self.expectTrue(remove_is_done, Severity.MAJOR, "Check the remove of old coredumps is done")

    def test_tca_psaa_Chandler_023_exceed_quota_Linux(self):
        file_created = self.ssh_manager.executeCommandInTarget(command="fallocate -l 5000000 /persistent/coredumps/core.10000.test.888.gz", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(file_created["exec_recv"] == 0, Severity.BLOCKER, "Checking that the command executed successfully")
        self.startTestStep("Get pid of Fasinfo application to be killed")
        Fasinfo_pid = self.get_process_id(app_name=self.FASINFO_APP_NAME)
        self.assertTrue(Fasinfo_pid != -1, Severity.MAJOR, "Check Fasinfo application is running")
        self.startTestStep("Kill Fasinfo application")
        application_is_killed = self.kill_application(app_name=self.FASINFO_APP_NAME, signal="SIGABRT")
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check the kill command is executed")
        self.startTestStep("Wait for coredumps creation")
        self.sleep_for(self.default_dumper_timeout)
        self.startTestStep("Check Fasinfo application is killed")
        Fasinfo_still_running = self.check_application_is_started(app_name=self.FASINFO_APP_NAME)
        self.assertTrue(not Fasinfo_still_running, Severity.MAJOR, "Check Fasinfo application is killed")
        self.startTestStep("Get coredumps names using ls command")
        logger.info(self.ssh_manager.executeCommandInTarget(command=f"ls -la {self.CoreDumps_Path}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)["stdout"])
        Fasinfo_coredumps_created = self.check_coredumps(app_name=self.FASINFO_APP_NAME)
        self.assertTrue(Fasinfo_coredumps_created, Severity.BLOCKER, f"Checking that coredumps files of Fasinfo were created properly")
        core_dumps = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}", ip_address=self.PP_IP)
        dumps_list = core_dumps["stdout"].splitlines()
        self.expectTrue("core.10000.test.888.gz" not in dumps_list, Severity.BLOCKER, "Checking that coredumps files were created properly.")


        """self.startTestStep("Get pid of Planning application to be killed")
        Planning_pid = self.get_process_id(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(Planning_pid != -1, Severity.MAJOR, "Check Planning application is running")
        self.startTestStep("Kill Planning application")
        application_is_killed = self.kill_application(app_name=self.PLANNING_APP_NAME, signal="SIGABRT")
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check the kill command is executed")
        self.startTestStep("Wait for coredumps creation")
        self.sleep_for(self.default_dumper_timeout)
        self.startTestStep("Check Planning application is killed")
        Planning_still_running = self.check_application_is_started(app_name=self.PLANNING_APP_NAME)
        self.assertTrue(not Planning_still_running, Severity.MAJOR, "Check Planning is killed")
        self.startTestStep("Get coredumps names using ls command")
        logger.info(self.ssh_manager.executeCommandInTarget(command=f"ls -la {self.CoreDumps_Path}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)["stdout"])
        Fasinfo_coredumps_created = self.check_coredumps(app_name=self.FASINFO_APP_NAME)
        Planning_coredumps_created = self.check_coredumps(app_name=self.PLANNING_APP_NAME)
        self.expectTrue(Planning_coredumps_created, Severity.BLOCKER, f"Checking that coredumps files of Planning were created properly")
        self.expectTrue(not Fasinfo_coredumps_created, Severity.BLOCKER, f"Checking that coredumps files of Fasinfo were deleted")"""

    def tearDown(self):
        self.setPostcondition("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
