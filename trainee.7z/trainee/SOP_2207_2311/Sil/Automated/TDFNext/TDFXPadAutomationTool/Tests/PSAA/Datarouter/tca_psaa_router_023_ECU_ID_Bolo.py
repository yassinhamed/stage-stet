from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_psaa_router_023_ECU_ID_Bolo(testfixture_PSAA_Datarouter):

    TEST_ID = "PSAA\tca_psaa_router_023_ECU_ID_Bolo"
    REQ_ID = ["/item/6453823"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check ECUID of Bolo in the DLT Standard header according to the deployed software variant"
    STATUS = "Ready"
    OS = ['LINUX','QNX']


    def setUp(self):
        self.diag_manager.start()
        self.setPrecondition("Setting default session boot")
        self.diag_manager.set_default_session_boot(target=self.PP_DIAG_ADR)
        boot_session_set = self.diag_manager.is_default_session_boot_set(target=self.PP_DIAG_ADR)
        self.assertTrue(boot_session_set, Severity.BLOCKER, "Check PP is in boot session")

        self.setPrecondition("Apply DLT filter with PP ECUID in BOLO")
        self.dlt_manager.apply_filter(ecuId=self.BOLO_ECU_ID)
        self.setPrecondition("Start monitoring")
        self.dlt_manager.start_monitoring()

    def test_tca_psaa_router_023_ECU_ID_Bolo(self):
        self.startTestStep("Get DLT messages")
        self.sleep_for(self.WAIT_FOR_DLT_LOG_MS)
        msg_count, messages = self.dlt_manager.get_messages_by_AND(ecuId=self.BOLO_ECU_ID)
        self.startTestStep("Check ecuID according to the deployed software variant")
        self.expectTrue(msg_count > 0, Severity.BLOCKER, "Checking the ecuID of BOLO according to the deployed software variant")

    def tearDown(self):
        self.setPostcondition("Setting default session")
        self.diag_manager.activate_normal_mode(target=self.PP_DIAG_ADR)
        self.diag_manager.deactivate_flashmode(target=self.PP_DIAG_ADR)
        self.diag_manager.set_default_session_app(target=self.PP_DIAG_ADR)
        self.setPostcondition("Checking default session is set")
        default_session_set = self.diag_manager.is_default_session_app_fmd_set(target=self.PP_DIAG_ADR)
        self.expectTrue(default_session_set, Severity.BLOCKER, "Checking that PP is in default session FMD")

        self.setPostcondition("Resetting the Performance Controller")
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.setPostcondition("Clear all filters")
        self.dlt_manager.clear_all_filters()
        self.setPostcondition("Stop monitoring")
        self.dlt_manager.stop_monitoring()

