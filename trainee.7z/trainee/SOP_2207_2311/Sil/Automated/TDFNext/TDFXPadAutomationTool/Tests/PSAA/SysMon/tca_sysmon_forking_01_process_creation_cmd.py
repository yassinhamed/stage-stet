from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_forking_01_process_creation_cmd(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_forking_01_process_creation_cmd"
    REQ_ID = ["/item/5833125"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon report process creation using cmd"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.search_msg_array = self.statistic_data["PMON"]["creation"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.process_forking_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_forking_01_process_creation_cmd(self):
        self.startTestStep("send command ls /opt/ | grep *")
        command_executed = self.ssh_manager.executeCommandInTarget(command=f"ls & echo $!", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        logger.info(f"ls pid : {command_executed['stdout']}")
        self.assertTrue(command_executed["stdout"] != "", Severity.MAJOR, "Check that stdout is not empty")
        ls_pid = command_executed["stdout"].splitlines()[0].strip()
        logger.info(f"ls pid : {ls_pid}")

        self.startTestStep("Wait for DLT (3 seconds)")
        self.sleep_for(3000)

        self.startTestStep("Get PMON DLT messages that contains process creation")
        search_messages = self.search_msg_array
        search_messages.append(ls_pid)
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=search_messages)
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that PMON process creation DLT messages are available")

        process_name = self.get_statistic_value(message=messages[0], statistic_path="PMON.creation.Statistics.process_name")
        self.assertTrue(process_name != -1, Severity.MAJOR, "Check that the ls command was reported")
        self.expectTrue("sh -c sh" in process_name, Severity.MAJOR, "Check that the DLT contains the arguments")

        process_pid = self.get_statistic_value(message=messages[0], statistic_path="PMON.creation.Statistics.pid")
        self.expectTrue(process_pid != -1, Severity.MAJOR, "Check that the DLT contains the PID")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
