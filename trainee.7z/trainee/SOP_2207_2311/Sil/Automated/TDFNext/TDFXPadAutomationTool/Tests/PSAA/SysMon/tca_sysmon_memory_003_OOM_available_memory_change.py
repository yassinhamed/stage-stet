from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_003_OOM_available_memory_change(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_003_OOM_available_memory_change"
    REQ_ID = ["/item/5911241"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports available memory change"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.search_msg_array = self.statistic_data["Memory"]["oom_memory_change"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")

        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.cgroup_oom_report_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_memory_003_OOM_available_memory_change(self):
        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.startTestStep("Check ECUs")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUs are Ok after ECU reset")

        self.startTestStep("Get OOM DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that OOM messages are available")

        self.startTestStep("Get change_in_percent value")
        change_in_percent = self.get_statistic_value(message=messages[0], statistic_path="Memory.oom_memory_change.Statistics.change_in_percent")
        self.expectTrue(change_in_percent != self.INVALID_VALUE, Severity.MAJOR, "Check that change_in_percent is reported")

        self.startTestStep("Get old_value value")
        old_value = self.get_statistic_value(message=messages[0], statistic_path="Memory.oom_memory_change.Statistics.old_value")
        self.expectTrue(old_value != self.INVALID_VALUE, Severity.MAJOR, "Check that old_value is reported")

        self.startTestStep("Get new_value value")
        new_value = self.get_statistic_value(message=messages[0], statistic_path="Memory.oom_memory_change.Statistics.new_value")
        self.expectTrue(new_value != self.INVALID_VALUE, Severity.MAJOR, "Check that new_value is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
