# Datarouterconf

Datarouterconf is the application that provides platform-specific configuration interfaces to datarouter.
Datarouterconf is an adaptive application.

Datarouterconf used to test these diagnostic jobs:

- **STEUERN_DLT_SET_LOGLEVEL with arguments appId=PRXA and ctxId=CTX1** = [0x31, 0x01, 0x10, 0x90, 0x50, 0x52, 0x58, 0x41, 0x43, 0x54, 0x58, 0x31, 0x00]
- **STEUERN_DLT_STORE_CONFIGURATION** = [0x31, 0x01, 0x10, 0x94]
- **STEUERN_DLT_RESET_TO_DEFAULT** = [0x31, 0x01, 0x10, 0x91]
