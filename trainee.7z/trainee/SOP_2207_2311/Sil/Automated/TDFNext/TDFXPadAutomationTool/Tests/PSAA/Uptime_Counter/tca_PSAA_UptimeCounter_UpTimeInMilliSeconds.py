from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *

class tca_PSAA_UptimeCounter_UpTimeInMilliSeconds(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_uptimeCounter_UpTimeInMilliSeconds"
    REQ_ID = ["/item/3316266"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check Uptime counter existence"
    STATUS = "Ready"
    OS = ["QNX", "LINUX"]

    def setUp(self):
        pass

    def test_tca_PSAA_uptimeCounter_UpTimeInMilliSeconds(self):
        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        file_contents = grep_kvs_file["stdout"].strip()
        self.assertTrue("UpTimeInMilliSeconds" in file_contents , Severity.BLOCKER, f"Check {self.UpTimeCounter} existence")

    def tearDown(self):
        pass
