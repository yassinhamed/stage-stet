from Tests.PSAA.Resource_Manager.testfixture_PSAA_RM import *



class tca_mmr_exposed_file_sberg(testfixture_PSAA_RM):
    TEST_ID = "PSAA\Ressource_Manager\tca_mmr_exposed_file_sberg"
    REQ_ID = ['/item/7108305']
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    PRIORITY = "Critical"
    DESCRIPTION = "Check that the resource managers shall expose a /dev/mmr/sbreg/N file"
    STATUS = "Ready"
    OS = ['QNX']


    def setUp(self):
        pass

    def test_tca_mmr_exposed_file_sberg(self):

        self.startTestStep("Check /dev/mmr/sbreg/10 exist")
        result = self.ssh_manager.executeCommandInTarget(command=f"if [ -e /dev/mmr/sbreg/10 ]; then echo file exists; fi", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(result['stdout'].strip() == "file exists", Severity.BLOCKER, "Check that /dev/mmr/sbreg/10  exists")

        self.startTestStep("Check /dev/mmr/sbreg/12 exist")
        result = self.ssh_manager.executeCommandInTarget(command=f"if [ -e /dev/mmr/sbreg/12 ]; then echo file exists; fi", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(result['stdout'].strip() == "file exists", Severity.BLOCKER,"Check that /dev/mmr/sbreg/12  exists")

        self.startTestStep("Check /dev/mmr/sbreg/c2 exist")
        result = self.ssh_manager.executeCommandInTarget(command=f"if [ -e /dev/mmr/sbreg/c2 ]; then echo file exists; fi", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(result['stdout'].strip() == "file exists", Severity.BLOCKER,"Check that /dev/mmr/sbreg/c2  exists")

        self.startTestStep("Check /dev/mmr/sbreg/c5 exist")
        result = self.ssh_manager.executeCommandInTarget(command=f"if [ -e /dev/mmr/sbreg/c5 ]; then echo file exists; fi", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(result['stdout'].strip() == "file exists", Severity.BLOCKER,"Check that /dev/mmr/sbreg/c5  exists")

    def tearDown(self):
        pass
