from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class testfixture_PSAA_Datarouter_ProxyApp(testfixture_PSAA_Datarouter):
    set_contextId_CTX1 = "CTX1"
    set_contextId_CTX2 = "CTX2"
    set_contextId_DFLT = "DFLT"
    set_contextId_PRX1 = "PRX1"
    set_contextId_PRX2 = "PRX2"
    set_argVal_CTX1_009 = "log message PRXA CTX1 009"
    set_argVal_CTX2_009 = "log message PRXA CTX2 009"
    set_argVal_DFLT_009 = "log message PRXA DFLT 009"
    set_argVal_CTX1_010 = "log message PRXA CTX1 010"
    set_argVal_DFLT_010 = "log message PRXA DFLT 010"
    set_argVal_debug_011 = "log message PRXA CTC1 kDebug 011"
    set_argVal_info_011 = "log message PRXA CTC1 kInfo 011"
    set_argVal_012 = "log message PRXA CTC1 kInfo 012"
    set_argVal_013 = "log message PRXA CTC1 kInfo 013"
    set_argVal_014 = "log message PRXA CTC1 kInfo 014"
    set_argVal_015 = "log message PRXA CTX1 kInfo 015"
    set_argVal_kDebug_016 = "log message PRXA CTC1 kDebug 016"
    set_argVal_kInfo_016 = "log message PRXA CTC1 kInfo 016"
    set_argVal_kDebug_17a = "log message PRXA PRX1 kDebug 17a"
    set_argVal_kInfo_17a = "log message PRXA PRX1 kInfo 17a"
    set_argVal_kVerbose_017b = "log message PRXA kVerbose 017b"
    set_argVal_kDebug_017b = "log message PRXA kDebug 017b"
    set_argVal_kInfo_017b = "log message PRXA kInfo 017b"
    set_argVal_kWarn_017b = "log message PRXA kWarn 017b"
    set_argVal_kInfo_017c = "log message PRXA kInfo 017c"
    set_argVal_kWarn_017c = "log message PRXA kWarn 017c"
    set_argVal_kDebug_018 = "log message PRXA CTC1 kDebug 018"
    set_argVal_kInfo_018 = "log message PRXA CTC1 kInfo 018"
    wait_for_dlt_log = 1000
    wait_for_dlt_message_to_be_sent = 10000
    wait_for_performance_bitrate_logging_to_finish = 60000
    performance_bitrate_logging_iterationNumber = 1000
    performance_bitrate_logging_logStringSize = 15
    performance_bitrate_logging_timeIntervalus = 30000
    performance_bitrate_logging_threadNumber = 2

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_Datarouter_ProxyApp setUpClass")
        cls.proxy_app_settings = ProxyAppSettings()
        cls.deploy_proxy_app()
        cls.start_tdf_proxy_communication()
        cls.check_proxy_app()
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/", output_folder=path.join(OutputPathManager.get_tests_group_path(), "coredumps_setupclass"),check_empty=True, ip_address=cls.PP_IP)
        cls.port_1 = 3490
        cls.port_2 = 3491
        cls.log_channels_file_path = "/opt/datarouter/etc/"
        cls.log_channels_file = "log-channels.json"

    def setUp(self):
        self.check_proxy_app()

        self.download_path = OutputPathManager.get_test_case_path()
        self.download_path_for_backup = OutputPathManager.get_tests_group_path()

        backup_dowload_status = self.ssh_manager.downloadFileFromTarget(source_file=self.log_channels_file, source_path=self.log_channels_file_path, destination_path=OutputPathManager.get_tests_group_path(), ip_address=self.PP_IP)

        self.assertTrue(backup_dowload_status, Severity.BLOCKER, "checking that the backup file was downloaded successfully")
        self.dlt_manager.clear_all_dlt_messages()

    def tearDown(self):
        self.dlt_manager.stop_monitoring()
        self.dlt_manager.clear_all_filters()

        self.proxy_app_manager.remove_proxy_app_lib(libName.ARA_LOG.value)
        result = self.ssh_manager.downloadFileFromTarget(source_file=self.log_channels_file, source_path=self.log_channels_file_path, destination_path=OutputPathManager.get_test_case_path(), ip_address=self.PP_IP)
        self.expectTrue(result, Severity.BLOCKER, "Checking that the copy of log-channels.json is done")

        self.ssh_manager.uploadFileToTarget(source_path=OutputPathManager.get_tests_group_path(), source_file=self.log_channels_file, destination_path=self.log_channels_file_path, ip_address=self.PP_IP)

        self.ssh_manager.executeCommandInTarget(command=r"chmod -R 644 "+self.log_channels_file_path+self.log_channels_file, timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)

        self.ssh_manager.executeCommandInTarget(command=r"cat "+self.log_channels_file_path+self.log_channels_file, timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)


    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_Datarouter_ProxyApp tearDownclsss")
        cls.stop_tdf_proxy_communication()
        cls.undeploy_proxy_app()

    def RevertConfigFile(self):
        self.ssh_manager.executeCommandInTarget(command=f"cp -f /persistent/Technica/prxa_logging.json /opt/proxy_app/etc/logging.json",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.ssh_manager.executeCommandInTarget(command=f"chmod 644 /opt/proxy_app/etc/logging.json",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        result = self.ssh_manager.executeCommandInTarget(command=f'ls -l /opt/proxy_app/etc/logging.json',timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue('-rw-r--r--' in result['stdout'], Severity.MAJOR,f"False Permission, Permission = {result['stdout']}")
