from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_cpu_02_CPUS_overall_cpu_usage_since_boot(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_cpu_02_CPUS_overall_cpu_usage_since_boot"
    REQ_ID = ["/item/5829148", "/item/142158"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports the overall cpu usage since boot"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.assertTrue(self.number_of_cores != self.INVALID_VALUE, Severity.MAJOR, "Check that number of online cores is available")
        self.time_interval = self.get_time_interval(contextID=self.CPU_system_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.overall_search_msg_array = self.statistic_data["CPU"]["Overall"]["Search_msg_array"]
        logger.info(f"Search message array = {self.overall_search_msg_array}")
        self.assertTrue(self.overall_search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.core_search_msg_array = self.statistic_data["CPU"]["Cores"]["Search_msg_array"]
        logger.info(f"Search message array = {self.core_search_msg_array}")
        self.assertTrue(self.core_search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.CPU_system_context_id)
        self.dlt_manager.apply_filter(contextId=self.CPU_core_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_cpu_02_CPUS_overall_cpu_usage_since_boot(self):
        self.startTestStep("Wait one cycle * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get CPU overall DLT messages")
        message_count_overall, messages_overall = self.dlt_manager.get_messages_by_AND(contextId=self.CPU_system_context_id, searchMsgArray=self.overall_search_msg_array)

        self.startTestStep("Get CPU overall DLT messages")
        message_count_cores, messages_cores = self.dlt_manager.get_messages_by_AND(contextId=self.CPU_core_context_id, searchMsgArray=self.core_search_msg_array)

        self.assertTrue(message_count_overall > 0, Severity.MAJOR, "Check that CPU overall DLT messages are available")

        self.startTestStep("Get last CPUS DLT message that contains the overall cpu usage since boot")
        last_dlt_msg = self.get_last_dlt_message(messages=messages_overall)
        since_boot = self.get_statistic_value(message=last_dlt_msg, statistic_path="CPU.Overall.Statistics.since_boot")
        self.assertTrue(since_boot != self.INVALID_VALUE, Severity.MAJOR, "Check that since_boot is reported")

        self.startTestStep("Get overall average from CPUC DLT message that contains the cpu usage since boot per core")
        self.assertTrue(message_count_cores > 0, Severity.MAJOR, "Check that CPU cores DLT messages are available")
        calculated_overall_cpu = self.get_overall_cpu_from_core_cpu(messages=messages_cores, statistic_path="CPU.Cores.Statistics.since_boot")
        self.assertTrue(calculated_overall_cpu != self.INVALID_VALUE, Severity.MAJOR, "Check that overall CPU could be calculated form Core CPU reports")
        self.assertTrue((calculated_overall_cpu * 0.8) <= float(since_boot) <= (calculated_overall_cpu * 1.2), Severity.MAJOR, "Check that overall CPU from DLT equals the calculated  Core CPU from the reports")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
