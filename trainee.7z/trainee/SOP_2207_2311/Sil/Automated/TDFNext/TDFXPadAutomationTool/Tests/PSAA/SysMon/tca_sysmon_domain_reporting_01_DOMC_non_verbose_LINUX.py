from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_domain_reporting_01_DOMC_non_verbose_LINUX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_domain_reporting_01_DOMC_non_verbose_LINUX"
    REQ_ID = ["/item/5866507"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports the CPU usage per domain in non-verbose mode"
    OS = ['LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        pass

    def test_tca_sysmon_domain_reporting_01_DOMC_non_verbose_LINUX(self):
        self.startTestStep("Add in the domain grouping config 4 entries: Domain1: process_dummy, Domain2: sysmon, Domain3: crash_hander, Domain4: sysmon & crash_handler")
        self.startTestStep("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.startTestStep("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        # TODO add message id
        self.dlt_manager.apply_filter(messageId="")
        self.dlt_manager.start_monitoring("SRR-DLT")
        # TODO add message short name
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name="", sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait the configured time interval * 2")
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get DOMC non-verbose DLT messages")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(True, Severity.MAJOR, "Check that DLT message exits")
        self.expectTrue(True, Severity.MAJOR, "check that Domain1 CPU usage = 0")
        self.expectTrue(True, Severity.MAJOR, "check that Domain4 CPU usage = Domain2+Domain3")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.setPostcondition("Revert config file changes")
        self.setPostcondition("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
