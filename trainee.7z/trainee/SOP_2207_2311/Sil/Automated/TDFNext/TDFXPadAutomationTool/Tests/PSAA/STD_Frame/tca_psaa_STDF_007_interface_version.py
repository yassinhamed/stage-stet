from Tests.PSAA.STD_Frame.testfixture_PSAA_STDFrame import *


class tca_psaa_STDF_007_interface_version(testfixture_PSAA_STDFrame):

    TEST_ID = "PSAA\tca_psaa_STDF_007_interface_version"
    REQ_ID = ["/item/2175806"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check non verbose message 'Interface_ver_msg_short_name' is logged"
    OS = ['LINUX','QNX']
    STATUS = "Ready"

    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_InterfaceVersion)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_STDF_007_interface_version(self):
        self.startTestStep("Get non verbose message 'Interface_ver_msg_short_name'")
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.Interface_ver_msg_short_name, sender=self.PP_ECUID,
                                                             filter_attributes=None)
        self.sleep_for(self.wait_for_STDF_dlt_message)
        self.dlt_manager.stop_capturing_non_verbose_message()
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, f"Check the non verbose message 'Interface_ver_msg_short_name' was received")
        logger.info(f"DTL message = {dlt_messages[-1]}")
        dlt_msg = dlt_messages[-1]['payload']
        logger.info(f"[DLT Messages ]:{dlt_msg}")
        version_type = self.is_uint8(dlt_msg['v'])
        self.expectTrue(version_type, Severity.MAJOR, f"Check version value. Expected version with type uint8 Actual:Value in dlt = {dlt_msg['v']}")

    def tearDown(self):
        pass
