from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_006_NonAdaptive_dump(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_006_NonAdaptive_dump"
    REQ_ID = ["/item/1736864"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps creation by killing non adaptive application"
    STATUS = "Ready"
    OS = ['LINUX']


    def setUp(self):
        pass

    def test_tca_psaa_dumper_006_NonAdaptive_dump(self):

        self.startTestStep("Kill XPC app")
        xpc_is_killed = self.kill_application(app_name=self.XPC_APP_NAME, signal=self.killall_options["SIGABRT"])
        self.assertTrue(xpc_is_killed, Severity.MAJOR, "Checking that Linux command executed successfully")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

        self.startTestStep("check coredumps created")
        coredumps_created = self.check_coredumps(self.XPC_APP_NAME)
        self.assertTrue(coredumps_created,Severity.BLOCKER,"Checking that coredumps files were created properly.")

    def tearDown(self):
        self.setPostcondition("Reset SSC")
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_MS)
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)
