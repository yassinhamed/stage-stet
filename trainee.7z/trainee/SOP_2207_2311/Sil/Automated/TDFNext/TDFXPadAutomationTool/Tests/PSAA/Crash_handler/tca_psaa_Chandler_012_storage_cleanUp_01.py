from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_012_storage_cleanUp_01(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_012_storage_cleanUp_01"
    REQ_ID = ["/item/2593168", "/item/2593376"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check core dumps doesn't cleanup when it's under 50%"
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        self.setPrecondition("Delete unwated dumps")
        removeCoredump = self.ssh_manager.executeCommandInTarget(command=r"rm -rf /persistent/sin/dlt-cdh/tmp/*",
                                                                 ip_address=self.PP_IP)
        self.expectTrue(removeCoredump["exec_recv"] == 0, Severity.MAJOR,
                        "Checking that file unwated dumps were deleted")

    def test_tca_psaa_Chandler_012_storage_cleanUp_01(self):
        # kernel panic
        self.startTestStep("Perform kernel panic")
        self.ssh_manager.executeCommandInTargetNoWait(command=self.kernel_panic_command,
                                                      timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                      ip_address=self.PP_IP)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.startTestStep("get kernel coredumps names")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"ls -la {self.CoreDumps_Path}/kernel | grep -c kdump.vmcore",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Checking that the coredumps were generated")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        #------------
        self.startTestStep("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls -lh {self.CoreDumps_Path}", ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Checking that the command executed successfully")
        dumps_list = returnValue["stdout"].splitlines()
        logger.info("Number of core dumps" + str(len(dumps_list)))
        logger.info("########## ls -lh returned : " + str(returnValue["stdout"].strip()) + "##########")
        output = returnValue["stdout"].strip().splitlines()[0].split(' ')[1]
        target = self.convert_storage_size(Size=output, pourcentage=0.2)
        time = self.get_date()
        logger.info(f"Time:{time}")
        logger.info(f"Time:{type(time)}")
        self.startTestStep("Create coredumps files under persistent")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command="fallocate -l {0} /persistent/coredumps/core.{1}.test.888.gz".format(target, time))
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        self.startTestStep("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls -lh {self.CoreDumps_Path}", ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Checking that the command executed successfully")
        logger.info("########## ls -lh returned : " + str(returnValue["stdout"].strip()) + "##########")
        self.startTestStep("Get the size of coredumps")
        size = self.ssh_manager.executeCommandInTarget(command=f"du {self.CoreDumps_Path}/*",
                                                              ip_address=self.PP_IP)
        self.assertTrue(size["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that the command executed successfully")
        logger.info(f"du result:{size}")
        new_dump_list = returnValue["stdout"].splitlines()
        logger.info("new_dump_list_size=" + str(len(new_dump_list)) + " must be < dumps_list_size=" + str(len(dumps_list)))
        self.expectTrue(len(new_dump_list) == len(dumps_list)+1, Severity.BLOCKER,
                        "Checking that crash handler is cleaning up persistent storage.")

    def tearDown(self):
        pass
