from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_low_level_002_PMC_ERROR_DLT_reported(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_low_level_002_PMC_ERROR_DLT_reported"
    REQ_ID = ["/item/5896865", "/item/5889679"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that  sysmon reports PMC error in DLT"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.Low_level_error_diagnostics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["LLED"]["PMC"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")

        self.setPrecondition("Clear secondary DTC memory")
        self.diag_manager.start()
        self.dtc_controller.clear_info_memory(self.PP_DIAG_ADR)
        self.diag_manager.restart()
        self.setPrecondition("Get DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["PMC_Fehler"][self.PP_NAME], memory_type="secondary") #todo
        logger.info("Status of DTC in setUp:" + str(read_status))
        self.expectTrue(read_status in self.DTC_NOT_PRESENT_LIST, Severity.BLOCKER, "Checking that DTC is Not Present: 0x50 or None.")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.Low_level_error_diagnostics_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_low_level_002_PMC_ERROR_DLT_reported(self):
        self.startTestStep("Send DIAG error injection")
        diag_request = self.diag_manager.syn_send(src=self.TESTER_DIAG_ADR, target=self.PP_DIAG_ADR, payload= self.SET_PMC_PAYLOAD) #todo
        self.expectTrue(diag_request == DiagResult.positive, Severity.BLOCKER, "Checking if there was a positive response")
        diag_received_payload = self.diag_manager.get_last_response_str(target=self.PP_DIAG_ADR, res=diag_request)
        logger.info("received payload: " + str(diag_received_payload))
        self.sleep_for(self.SLEEP_TIME_AFTER_ERROR_FAULT_INJECTION_JOB_MS)

        self.startTestStep("Get DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["PMC_Fehler"][self.PP_NAME], memory_type="secondary") #todo
        logger.info("Status of DTC in the test Method: " + str(read_status))
        self.expectTrue(read_status == self.DTC_ACTIVE, Severity.BLOCKER, "Checking that DTC is Active: 0x2F.")

        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get LLED error DLT message")
        message_count, messages = self.dlt_manager.get_messages(searchMsg=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that message is reported")

        self.startTestStep("Get core value")
        core = self.get_statistic_value(message=messages[0], statistic_path="LLED.MEC.Statistics.core")
        self.expectTrue(core == self.INVALID_VALUE, Severity.MAJOR, "Check that core is not reported for MMR register")

        self.startTestStep("Get dec_value value")
        dec_value = self.get_statistic_value(message=messages[0], statistic_path="LLED.MEC.Statistics.dec_value")
        self.expectTrue(dec_value != self.INVALID_VALUE, Severity.MAJOR, "Check that dec_value is reported")

        self.startTestStep("Get hex_value value")
        hex_value = self.get_statistic_value(message=messages[0], statistic_path="LLED.MEC.Statistics.hex_value")
        self.expectTrue(hex_value != self.INVALID_VALUE, Severity.MAJOR, "Check that hex_value is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
