# STDFrame

**StdFrame is a small logging app that prints periodically non verbose DLT messages containing the following informations:**

- ECU HW Version (major.minor.patch) 
- SWE version. 10 different SWEs (HWEL, CAFD, BTLD, SWFL, 0000) 
- ECU Serial Number 
- Vehicule ID 
- Mode (Plant, Engineering, Field) 
- Interface Version Info 
- Mileage Info

**The message IDs for non verbose DLT messages are:**

- messageID_STDF_HWVersion = 11 
- messageID_STDF_SWVersion1 = 12 
- messageID_STDF_SWVersion2 = 13 
- messageID_STDF_SWVersion3 = 14
- messageID_STDF_SWVersion4 = 15
- messageID_STDF_SWVersion5 = 16
- messageID_STDF_SWVersion6 = 17
- messageID_STDF_SWVersion7 = 18
- messageID_STDF_SWVersion8 = 19
- messageID_STDF_SWVersion9 = 20
- messageID_STDF_SWVersion10 = 21
- messageID_STDF_SerialNumber = 22
- messageID_STDF_VehicleId = 23
- messageID_STDF_CurrentEngMode = 24
- messageID_STDF_InterfaceVersion = 25
- messageID_STDF_CurrentMileage = 26 
- messageID_STDF_timesync = 27

**PS:** 

In the test case *tca_psaa_STDF_008_mileage* we set the value of the mileage and we check if it is sent by STDF application in the DLT. But the value set in the input will not be sent like it is in the DLT, it will be converted. For exemple :
1. If we want to set the mileage value to 1872, the input value must be in hexadécimal (0x750).
2. This value will be converted to binary and shifted to the left by one bit (011101010000 -> 111010100000).
3. Then it will add 1 to the value (111010100000 -> 111010100001).
4. At this moment the value will be converted back to hexadécimal (0000 0EA1) and then converted from LSB to MSB (A10E 0000).
5. This value (A10E 0000) in décimal is 2702049280 wich is the value will be found in the DLT sent by STDF application. 

For more info about the conversion check the ticket : https://asc.bmw.com/jira/browse/SPPAD-72161 

For more info : 
https://cc-github.bmwgroup.net/swh/ddad_platform/tree/master/aas/pas/std_frame