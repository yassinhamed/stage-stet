from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_Log_Collector(testfixture_PSAA):
    logLevel = "kVerbose"
    Audit_context_ID = 'AUD'
    Syslog_context_ID = 'SYSL'
    Journal_context_ID = 'JOUR'
    Kernel_context_ID = 'KMSG'
    Slog_context_ID = 'SLOG'
    Configuration_error_context_ID = 'ConR'
    Config_file_name = "security_events.json"
    Config_file_path = "/opt/log_collector/etc/"
    first_random_text = "Hello"
    second_random_text = "Good"
    qnx_random_text = "Nice"
    qnx2_random_text = "cute"
    specific_journal_message = "execution_manag"
    specific_journal2_message = "link_config"

    specific_audit_message = "node=localhost"
    wait_message_to_be_logged = 10000

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_Log_Collector setUpclsss")
        cls.ssh_manager.executeCommandInTarget("ls /opt/log_collector/bin")
        cls.ssh_manager.executeCommandInTarget("ls /opt/log_collector/etc")

        cls.ssh_manager.executeCommandInTarget(command=f"cp -f {cls.Config_file_path + cls.Config_file_name} /persistent/",timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
        cls.ssh_manager.downloadFileFromTarget(cls.Config_file_name, cls.Config_file_path,
                                                OutputPathManager.get_global_path(),ip_address=cls.PP_IP)
        cls.logLevel = cls.json_manager.findNodeFromJsonFile(
            filePath=f"{cls.Config_file_path}logging.json", nodePath="logLevel",
            use_cache=False, delete_cache=False, upload_file=False)
        cls.json_manager.updateNodeIntoJsonFile(filePath=f"{cls.Config_file_path}logging.json",
                                                 nodePath="logLevel",
                                                 value="kVerbose", use_cache=False, delete_cache=True, upload_file=True)
        cls.diag_manager.start()
        cls.diag_manager.ecu_reset(target=cls.PP_DIAG_ADR, reset_duration=cls.PP_RESET_TIMEOUT_S)
        cls.diag_manager.restart()
        cls.check_ECUs()
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_tests_group_path(),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_Log_Collector tearDownclsss")
        cls.json_manager.updateNodeIntoJsonFile(filePath=f"{cls.Config_file_path}logging.json",
                                                nodePath="logLevel",
                                                value=cls.logLevel, use_cache=False, delete_cache=True, upload_file=True)
        cls.ssh_manager.executeCommandInTarget(command=f"cp -f /persistent/{cls.Config_file_name} {cls.Config_file_path}",timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
        cls.ssh_manager.executeCommandInTarget(command=f"chmod 644 {cls.Config_file_path + cls.Config_file_name}",timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
        result = cls.ssh_manager.executeCommandInTarget(command=f'stat -c "%a" {cls.Config_file_path + cls.Config_file_name}',timeout=cls.SSH_CONNECTION_TIMEOUT_MS,ip_address=cls.PP_IP)
        cls.expectTrue('644' in result['stdout'], Severity.MAJOR,
                       f"False Permission, Permission = {result['stdout']}")
        cls.diag_manager.start()
        cls.diag_manager.ecu_reset(target=cls.SC_DIAG_ADR, reset_duration=cls.PP_RESET_TIMEOUT_S)
        cls.diag_manager.stop()
        cls.check_ECUs()

    def setUp(self):
        grep_LogC = self.check_application_is_started(app_name=self.LOG_COLLECTOR_APP_NAME)
        self.assertTrue(grep_LogC, Severity.MAJOR, "Check The application was started")

    def tearDown(self):
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_test_case_path(),check_empty=False,ip_address=self.PP_IP,ignored_files=["currentswversion", "tmp"])
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()

    def logCollectorModifyConfigFile(self, MessageSource, MessageRegex, SetDTC022292, SetDTC482EA9, LogDlt):
        events_configuration = self.json_manager.findNodeFromJsonFile(
            filePath=self.Config_file_path + self.Config_file_name, nodePath="EventsConfigs",
            use_cache=False, delete_cache=False, upload_file=False)
        iterations = len(events_configuration)
        logger.info(str(iterations))
        for i in range(0, iterations):
            self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                    nodePath=f"EventsConfigs[{i}].LogDlt", value="No",
                                                    use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                 nodePath="EventsConfigs[0].MessageSource", value=MessageSource,
                                                 use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                 nodePath="EventsConfigs[0].MessageRegex", value=MessageRegex,
                                                 use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                 nodePath="EventsConfigs[0].SetDTC022292", value=SetDTC022292,
                                                 use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                 nodePath="EventsConfigs[0].SetDTC482EA9", value=SetDTC482EA9,
                                                 use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                 nodePath="EventsConfigs[0].LogDlt", value=LogDlt,
                                                 use_cache=False, delete_cache=False, upload_file=True)

        self.ssh_manager.executeCommandInTarget(command=f'cat {self.Config_file_path + self.Config_file_name}',timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)

    def logCollectorModifyConfigFile_QNX(self, MessageSource, MessageRegex, SetDTC022292, SetDTC482EA9, LogDlt):

        self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                     nodePath="EventsConfigs[0].MessageSource", value=MessageSource,
                                                     use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                     nodePath="EventsConfigs[0].MessageRegex", value=MessageRegex,
                                                     use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                     nodePath="EventsConfigs[0].SetDTC022292", value=SetDTC022292,
                                                     use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                     nodePath="EventsConfigs[0].SetDTC482EA9", value=SetDTC482EA9,
                                                     use_cache=False, delete_cache=False, upload_file=True)
        self.json_manager.updateNodeIntoJsonFile(filePath=self.Config_file_path + self.Config_file_name,
                                                     nodePath="EventsConfigs[0].LogDlt", value=LogDlt,
                                                     use_cache=False, delete_cache=False, upload_file=True)

        self.ssh_manager.executeCommandInTarget(command=f'cat {self.Config_file_path + self.Config_file_name}',
                                                    timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)

    def logCollectorRevertConfigFile(self):
        self.ssh_manager.executeCommandInTarget(command=f"cp -f /persistent/Technica/{self.Config_file_name} {self.Config_file_path}",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.ssh_manager.executeCommandInTarget(command=f"chmod 644 {self.Config_file_path + self.Config_file_name}",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        result = self.ssh_manager.executeCommandInTarget(command=f'stat -c "%a" {self.Config_file_path + self.Config_file_name}',timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue('644' in result['stdout'], Severity.MAJOR,
                       f"False Permission, Permission = {result['stdout']}")

    def logCollectorRevertConfigFile_QNX(self):
        self.ssh_manager.executeCommandInTarget(
            command=f"cp -f /persistent/Technica/{self.Config_file_name} {self.Config_file_path}",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.ssh_manager.executeCommandInTarget(
            command=f"chmod 644 {self.Config_file_path + self.Config_file_name}",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)

    def logCollectorAddSyslLog(self, MessageRegex="Hello"):
        res = self.ssh_manager.executeCommandInTarget(command=f'logger –t syslog "{MessageRegex}"',timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(res["exec_recv"] == 0, Severity.MAJOR, "Check command executed")

    def logCollectorAddKernelLog(self, MessageRegex="Hello"):
        res = self.ssh_manager.executeCommandInTarget(command=f'echo "{MessageRegex}" > /dev/kmsg',timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(res["exec_recv"] == 0, Severity.MAJOR, "Check command executed")

    def logCollectorAddSLog(self, MessageRegex="Hello"):
        res = self.ssh_manager.executeCommandInTarget(command=f'echo "{MessageRegex}" > /dev/slog2/stdout',timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(res["exec_recv"] == 0, Severity.MAJOR, "Check command executed")

    def logCollectorGetKernelLog(self, timeout=3000, MessageRegex="Hello"):
        self.sleep_for(timeout)
        Message = self.ssh_manager.executeCommandInTarget(command=f"journalctl _TRANSPORT=kernel | grep {MessageRegex}",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        if (MessageRegex in str(Message)):
            return str(Message)
        else:
            return None

    def logCollectorGetSyslLog(self, timeout=3000, MessageRegex="Hello"):
        self.sleep_for(timeout)
        Message = self.ssh_manager.executeCommandInTarget(command=f"journalctl _TRANSPORT=syslog | grep {MessageRegex}",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        if (MessageRegex in str(Message)):
            return str(Message)
        else:
            return None

    def logCollectorGetJournalLog(self, timeout=3000, MessageRegex="execution_manag"):
        self.sleep_for(timeout)
        ssh_return = self.ssh_manager.executeCommandInTarget(command=f'journalctl _TRANSPORT=journal | grep {MessageRegex}',timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        if len(ssh_return["stdout"].strip()) > 0:
            return ssh_return["stdout"].strip()
        else:
            return None

    def logCollectorGetAuditLog(self, timeout=3000, MessageRegex="node=localhost"):
        self.sleep_for(timeout)
        ssh_return = self.ssh_manager.executeCommandInTarget(command=f'journalctl -t audispd | grep "{MessageRegex}"',timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        if len(ssh_return["stdout"].strip()) > 0:
            return ssh_return["stdout"].strip()
        else:
            return None


    def logCollectorGetSLog(self, timeout=3000, MessageRegex="Nice"):
        self.sleep_for(timeout)
        Message = self.ssh_manager.executeCommandInTarget(command=f'slog2info | grep "{MessageRegex}"',timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        if str(Message) is not None:
            return str(Message)
        else:
            return None

    def security_events_file_parser(self, events_configuration):
        Check = True
        for event_Config in events_configuration:
            if "MessageSource" in event_Config.keys():
                logger.info("Check message Source field exists")
            else:
                logger.error("Check message Source field exists")
                Check = False
            if "MessageRegex" in event_Config.keys():
                logger.info("Check message regex field exists")
            else:
                logger.error("Check message regex field exists")
                Check = False
            if "SetDTC022292" in event_Config.keys():
                logger.info("Check SetDTC022292 field exists")
            else:
                logger.error("Check SetDTC022292 field exists")
                Check = False
            if "SetDTC482EA9" in event_Config.keys():
                logger.info("Check SetDTC482EA9 field exists")
            else:
                logger.error("Check SetDTC482EA9 field exists")
                Check = False
            if "LogDlt" in event_Config.keys():
                logger.info("Check LogDlt field exists")
            else:
                logger.error("Check LogDlt field exists")
                Check = False
        return Check

    def get_env_variable(self, dtc_snapshots, env_variable, index):
        random_message_t = []
        for random_message in dtc_snapshots.values():
            logger.info(f"random_message_1: {type(random_message)}")
            logger.info(f"random_message_1: {str(random_message)}")
            logger.info(f"text_to_be_checked:{str(env_variable)}")
            if "61657A6E6D756673646C72777364796E716567677A6C776D" in random_message[self.UWB_ENV['LOG_COLLECTOR_INFO']]:
                logger.info("the messages are equal")
                random_message_t.append(random_message[self.UWB_ENV['LOG_COLLECTOR_INFO']])
            logger.info(f"random_message_1: {random_message}")
        logger.info(f"index: {index}")
        logger.info(f"list: {random_message_t}")
        if random_message_t[index] != "":
            return random_message_t[index]
        else:
            return None

    def get_snapshots(self, dtc_snapshots, env_variable, index, message):
        random_message_t = []
        for random_message in dtc_snapshots.values():
            logger.info(f"random_message_1: {type(random_message)}")
            logger.info(f"random_message_1: {str(random_message)}")
            logger.info(f"text_to_be_checked:{str(env_variable)}")
            if message in random_message[self.UWB_ENV['LOG_COLLECTOR_INFO']]:
                logger.info("the messages are equal")
                random_message_t.append(random_message[self.UWB_ENV['LOG_COLLECTOR_INFO']])
            logger.info(f"random_message_1: {random_message}")
        logger.info(f"index: {index}")
        logger.info(f"list: {random_message_t}")
        if random_message_t[index] != "":
            return random_message_t[index]
        else:
            return None



    def edit_JSON_file(self):

        file_path = path.join(OutputPathManager.get_test_case_path(), "security_events.json")
        with io.open(file_path, 'w') as jsonFile:
            file_content = '{"EventsConfigs": [{"MessageSource": "SLOG", "MessageRegex": "cute", "SetDTC022292": "Clearable", "SetDTC482EA9": "None", "LogDlt": "Yes"},{"MessageSource": "SLOG","MessageRegex": "Nice","SetDTC022292": "None","SetDTC482EA9": "Clearable","LogDlt": "Yes"},{"MessageSource": "SLOG","MessageRegex": "Hello","SetDTC022292": "None","SetDTC482EA9": "None","LogDlt": "Yes"}]}'
            data = jsonFile.write(file_content)
        logger.info(f"data: {data}")



