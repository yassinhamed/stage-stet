from Tests.PSAA.STD_Frame.testfixture_PSAA_STDFrame import *


class tca_psaa_STDF_011_TimeSync_timestamped(testfixture_PSAA_STDFrame):

    TEST_ID = "PSAA\tca_psaa_STDF_011_TimeSync_timestamped"
    REQ_ID = ["/item/2175811"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check non verbose message 'TSync_TimeStamp_msg_short_name' time stamped"
    OS = ['LINUX','QNX']
    STATUS = "Ready"

    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.messageID_STDF_timesync)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_STDF_011_TimeSync_timestamped(self):
        self.startTestStep("Get non verbose message 'TSync_TimeStamp_msg_short_name'")
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.TSync_TimeStamp_msg_short_name, sender=self.PP_ECUID,
                                                             filter_attributes=None)
        self.sleep_for(self.wait_for_STDF_dlt_message)
        self.dlt_manager.stop_capturing_non_verbose_message()
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check the non verbose message 'TSync_TimeStamp_msg_short_name' was received")
        dlt_msg = dlt_messages[-1]
        self.expectTrue(str(dlt_msg['timestamp']) !="",Severity.MAJOR,f"Check the TimeStamp in payload{dlt_msg['timestamp']} is not empty")

    def tearDown(self):
        pass
