from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_006_user_space_crash_dtc_adaptive(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_006_user_space_crash_dtc_adaptive"
    REQ_ID = ["/item/2593168", "/item/2593242", "/item/2593292", "/item/6612659"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check user space DTC status after kill of adaptive app"
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    def setUp(self):
        pass

    def test_tca_psaa_Chandler_006_user_space_crash_dtc_adaptive(self):
        self.startTestStep("Get pid of the application to be killed")
        ETS_pid = self.get_process_id(app_name=self.ETS_APP_NAME)
        self.assertTrue(ETS_pid != -1, Severity.MAJOR, "Check the application is running")
        self.startTestStep("Kill ETS App")
        application_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(application_is_killed, Severity.BLOCKER, f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.startTestStep("Check application ETS is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER, f"Checking that the {self.ETS_APP_NAME} is not running")
        self.startTestStep("Get coredumps files names")
        self.assertTrue(self.check_coredumps(app_name=self.ETS_APP_NAME), Severity.BLOCKER, f"Checking that coredumps files were created properly")
        """self.startTestStep("Check primary DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Software_Fehler"][self.PP_NAME], memory_type="primary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that DTC is not set")"""
        self.startTestStep("Check secondary DTC status")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Applikation_wurde_unerwartet_beendet"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC: " + str(read_status))
        self.expectTrue(read_status == self.DTC_INACTIVE, Severity.BLOCKER, "Checking that DTC is not set")

    def tearDown(self):

        pass
