from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_network_02_NETS_statistics_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_network_02_NETS_statistics_QNX"
    REQ_ID = ["/item/5906667"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that the NETS reports contains all required statistics"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.network_statistic_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array = self.statistic_data["Network"]["General"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.network_statistic_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_network_02_NETS_statistics_QNX(self):
        self.startTestStep("Wait cycle of NETS * 2")
        self.sleep_for(self.time_interval * 2)
        self.startTestStep("Get NETS DLT messages value")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that NETS DLT messages are available")

        self.startTestStep("Get rx total number of bytes value")
        rx_total_number_of_bytes = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.RX Total number of bytes")
        self.expectTrue(rx_total_number_of_bytes != self.INVALID_VALUE, Severity.MAJOR, "Check that rx total number of bytes is reported")

        self.startTestStep("Get tx total number of bytes value")
        tx_total_number_of_bytes = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.TX Total number of bytes")
        self.expectTrue(tx_total_number_of_bytes != self.INVALID_VALUE, Severity.MAJOR, "Check that tx total number of bytes is reported")

        self.startTestStep("Get rx bandwith value")
        rx_bandwith = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.RX Bandwidth")
        self.expectTrue(rx_bandwith != self.INVALID_VALUE, Severity.MAJOR, "Check that rx bandwith is reported")

        self.startTestStep("Get tx bandwith value")
        tx_bandwith = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.TX Bandwidth")
        self.expectTrue(tx_bandwith != self.INVALID_VALUE, Severity.MAJOR, "Check that tx bandwith is reported")

        self.startTestStep("Get rx Total number of packets value")
        rx_total_number_of_packets = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.RX Total number of packets")
        self.expectTrue(rx_total_number_of_packets != self.INVALID_VALUE, Severity.MAJOR, "Check that rx Total number of packets is reported")

        self.startTestStep("Get tx Total number of packets value")
        tx_total_number_of_packets = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.TX Total number of packets")
        self.expectTrue(tx_total_number_of_packets != self.INVALID_VALUE, Severity.MAJOR, "Check that tx Total number of packets is reported")

        self.startTestStep("Get rx Total number of errors value")
        rx_total_number_of_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.RX Total number of errors")
        self.expectTrue(rx_total_number_of_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that rx Total number of errors is reported")

        self.startTestStep("Get tx Total number of errors value")
        tx_total_number_of_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.TX Total number of errors")
        self.expectTrue(tx_total_number_of_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that tx Total number of errors is reported")

        self.startTestStep("Get rx Number of dropped packets value")
        rx_number_of_dropped_packets = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.RX Number of dropped packets")
        self.expectTrue(rx_number_of_dropped_packets != self.INVALID_VALUE, Severity.MAJOR, "Check that rx Number of dropped packets is reported")

        self.startTestStep("Get tx Number of dropped packets value")
        tx_number_of_dropped_packets = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.TX Number of dropped packets")
        self.expectTrue(tx_number_of_dropped_packets != self.INVALID_VALUE, Severity.MAJOR, "Check that tx Number of dropped packets is reported")

        self.startTestStep("Get rx Number of aggregated packet framing errors value")
        rx_number_of_aggr_packet_framing_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.RX Number of aggregated packet framing errors")
        self.expectTrue(rx_number_of_aggr_packet_framing_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that rx Number of aggregated packet framing errors is reported")

        self.startTestStep("Get rx Number of multicast packets value")
        rx_number_of_multicast_patckets = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.RX Number of multicast packets")
        self.expectTrue(rx_number_of_multicast_patckets != self.INVALID_VALUE, Severity.MAJOR, "Check that rx Number of multicast packets is reported")

        self.startTestStep("Get tx Number of multicast packets value")
        tx_number_of_multicast_patckets = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.TX Number of multicast packets")
        self.expectTrue(tx_number_of_multicast_patckets != self.INVALID_VALUE, Severity.MAJOR, "Check that tx Number of multicast packets is reported")

        self.startTestStep("Get tx Number of collision errors detected on the interface value")
        tx_number_collision_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.TX Number of collision errors detected on the interface")
        self.expectTrue(tx_number_collision_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that tx Number of collision errors detected on the interface is reported")

        self.startTestStep("Get tx Number of aggregated carrier errors value")
        tx_number_of_carrier_errors = self.get_statistic_value(message=messages[0], statistic_path="Network.General.Statistics.TX Number of aggregated carrier errors")
        self.expectTrue(tx_number_of_carrier_errors != self.INVALID_VALUE, Severity.MAJOR, "Check that tx Number of aggregated carrier errors is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
