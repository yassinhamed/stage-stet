from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *



class tca_PSAA_UptimeCounter_Reset_Read_AllCounters_File(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_Reset_Read_AllCounters_File"
    REQ_ID = ["/item/3316277","/item/3316280"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check counters after ECU reset using kvs file"
    STATUS = "Ready"
    OS = ["QNX", "LINUX"]

    def setUp(self):
       pass

    def test_tca_PSAA_UptimeCounter_Reset_Read_AllCounters_File(self):

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting Num Of Unexpected Resets value")
        First_NumOfUnexpectedResets = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.Unexpected_reset_counter)
        logger.info(f"First_NumOfUnexpectedResets_value: {First_NumOfUnexpectedResets}")

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting UpTimeInMilliSeconds value")
        First_UpTimeInMilliSeconds = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.UpTimeCounter)
        logger.info(f"First_UpTimeInMilliSeconds_value: {First_UpTimeInMilliSeconds}")


        self.startTestStep("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK == True, Severity.MAJOR, "Check ECUS are correctly reset")

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting Num Of Unexpected Resets value")
        Second_NumOfUnexpectedResets = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.Unexpected_reset_counter)
        logger.info(f"Second_NumOfUnexpectedResets_value: {Second_NumOfUnexpectedResets}")

        self.startTestStep("Getting UptimeCounter kvs file")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Check linux command execution")
        self.startTestStep("Getting UpTimeInMilliSeconds value")
        Second_UpTimeInMilliSeconds = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.UpTimeCounter)
        logger.info(f"Second_UpTimeInMilliSeconds_value: {Second_UpTimeInMilliSeconds}")

        self.assertTrue(int(Second_NumOfUnexpectedResets) == int(First_NumOfUnexpectedResets), Severity.MAJOR, "Check number of unexpected resets")
        self.assertTrue(int(Second_UpTimeInMilliSeconds) > int(First_UpTimeInMilliSeconds), Severity.MAJOR, "Check UpTimeInMilliSeconds")

    def tearDown(self):

        pass
