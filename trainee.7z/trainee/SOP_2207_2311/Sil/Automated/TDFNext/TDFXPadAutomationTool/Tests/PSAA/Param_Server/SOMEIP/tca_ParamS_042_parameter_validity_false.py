from Tests.PSAA.Param_Server.testfixture_PSAA_param_server import *


class tca_ParamS_042_parameter_validity_false(testfixture_PSAA_param_server):

    TEST_ID = "PSAA/Param_Server/tca_ParamS_042_parameter_validity_false"
    REQ_ID = ["/item/7788282"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that ParametersQualifier is true in case of no errors"
    OS = ['QNX', 'LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get parameter server PID")
        self.assertTrue(True, Severity.MAJOR, "Check that parameter server is running (has PID)")
        self.setPrecondition("get ParametersQualifier Getter ID from the someip_config.json ")
        self.assertTrue(True, Severity.MAJOR, "check that the qualifier getter exist")
        self.assertTrue(True, Severity.MAJOR, "check that the qualifier getter exist")

    def test_tca_ParamS_042_parameter_validity_false(self):
        self.startTestStep("corrupt default_values.json file")
        self.startTestStep("ECU reset")
        self.assertTrue(True, Severity.MAJOR, "check positive response")
        self.startTestStep("check ecus")
        self.expectTrue(True, Severity.MAJOR, "check that ecus are OK")
        self.startTestStep("check that parameter serve reported an initialization error")
        self.assertTrue(True, Severity.MAJOR, "Check that initialization error is reported")
        self.startTestStep("Get ParametersQualifier")
        self.assertTrue(True, Severity.MAJOR, "check that Parameter server respond to the Getter request")
        self.assertTrue(True, Severity.MAJOR, "check that ParametersQualifier value is False")

    def tearDown(self):
        self.setPostcondition("revert default_values.json file")
        self.setPostcondition("ECU reset")
        self.expectTrue(True, Severity.MAJOR, "check positive response")
