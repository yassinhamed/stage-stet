from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_007_create_dump_inLoop(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_007_create_dump_inLoop"
    REQ_ID = ["/item/1736864"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps creation by killing adaptive application multiple times"
    STATUS = "Ready"
    OS = ['LINUX']

    pid_Planning = 0

    def setUp(self):
        pass

    def test_tca_psaa_dumper_007_create_dump_inLoop(self):

        i=1
        while i < 5 :

            self.startTestStep("Check application ETS is running")
            ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
            self.expectTrue(ets_is_started, Severity.BLOCKER,
                            f"Checking that the {self.ETS_APP_NAME} is running")

            self.startTestStep("Kill application ETS")
            ets_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
            self.expectTrue(ets_is_killed, Severity.BLOCKER,
                            f"Checking that the {self.ETS_APP_NAME} is killed")
            self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

            self.startTestStep("Check application ETS is not running")
            ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
            self.expectTrue(not ets_is_started, Severity.BLOCKER,
                            f"Checking that the {self.ETS_APP_NAME} is not running")

            self.startTestStep("check coredumps created")
            coredumps_created = self.check_coredumps(self.ETS_APP_NAME)
            self.assertTrue(coredumps_created,Severity.BLOCKER,"Checking that coredumps files were created properly.")
            
            self.ecu_utilities.download_coredumps_and_clear(coredumps_folder=f"{self.CoreDumps_Path}/",
                                                            output_folder=OutputPathManager.get_test_case_path(),
                                                            check_empty=False, ip_address=self.PP_IP)
            self.diag_manager.start()
            self.dtc_controller.clear_all_dtc_memory_for_ecu(self.PP_DIAG_ADR)
            self.startTestStep("Reset ECU")
            self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
            self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
            self.diag_manager.restart()
            ecus_are_ok = self.check_ECUs()
            self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
            i+=1

    def tearDown(self):
        pass
