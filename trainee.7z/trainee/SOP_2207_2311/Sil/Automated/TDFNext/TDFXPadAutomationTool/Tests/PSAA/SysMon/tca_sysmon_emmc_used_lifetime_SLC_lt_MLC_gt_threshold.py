from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_emmc_used_lifetime_SLC_lt_MLC_gt_threshold(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_emmc_used_lifetime_SLC_lt_MLC_gt_threshold"
    REQ_ID = ["/item/5888482", "/item/5888677"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports the used lifetime correctly when SLC not exceeded and MLC is exceeded"
    OS = ['QNX', 'LINUX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Start Monitoring")
        self.setPrecondition("get lifetime estimation for SLC and MLC from EMMC health DLT message")
        self.assertTrue(True, Severity.MAJOR, "Check lifetime estimation for SLC and MLC are available")
        self.setPrecondition("Set the lower bound threshold for SLC to 0xFF and MLC to 0x00 and set upper bound to 0xff using Diag Job")
        self.assertTrue(True, Severity.MAJOR, "check positive response")

    def test_tca_sysmon_emmc_used_lifetime_SLC_lt_MLC_gt_threshold(self):
        self.startTestStep("Wait cycle of eMMC  * 2")
        self.startTestStep("Get DLT EMMC messages")
        self.assertTrue(True, Severity.MAJOR, "Check that DLT EMMC used lifetime messages are available")
        self.expectTrue(True, Severity.MAJOR, "Check that dlt messages contain all required statistics")
        self.expectTrue(True, Severity.MAJOR, "Check that the value of the SLC is in percentage")
        self.expectTrue(True, Severity.MAJOR, "Check that the value of the MLC is exceeded")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.setPostcondition("ECU reset")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
