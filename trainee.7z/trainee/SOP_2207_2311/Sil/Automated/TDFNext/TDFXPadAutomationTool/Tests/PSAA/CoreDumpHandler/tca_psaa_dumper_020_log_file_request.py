from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_020_log_file_request(testfixture_PSAA_CoreDumpHandler):
    TEST_ID = "PSAA\tca_psaa_dumper_020_log_file_request"
    REQ_ID = ["/item/5269321"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check the sent of non-verbose log message to request a persistent log file from Datarouter"
    STATUS = "Ready"
    OS = ['LINUX']


    def setUp(self):
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(verbose=False)
        self.dlt_manager.apply_filter(nonVerbose=True)
        self.dlt_manager.apply_filter(ipSrc=self.PP_IP)
        self.dlt_manager.apply_filter(messageId=self.messageID_log_file_request)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_psaa_dumper_020_log_file_request(self):
        self.startTestStep("Kill application ETS")
        application_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(application_is_killed, Severity.BLOCKER, f"Checking that the {self.ETS_APP_NAME} is killed")
        self.startTestStep("Wait for message to be sent")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.startTestStep("Check application ETS is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER, f"Checking that the {self.ETS_APP_NAME} is not running")
        self.startTestStep("Get coredumps files names")
        core_dumps_created = self.check_coredumps(app_name=self.ETS_APP_NAME)
        self.assertTrue(core_dumps_created, Severity.BLOCKER, "Checking coredumps files are created successfully")
        self.startTestStep("Get non verbose messages")
        messages_count, messages_array_set = self.dlt_manager.get_messages(messageId=self.messageID_log_file_request)
        logger.info(f"messagess: {messages_array_set}")
        self.expectTrue(messages_count > 0, Severity.BLOCKER, "Checking non verbose message was sent successfully")

    def tearDown(self):
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/", output_folder=OutputPathManager.get_test_case_path(), check_empty=False, ip_address=self.PP_IP, ignored_files=["currentswversion"])
