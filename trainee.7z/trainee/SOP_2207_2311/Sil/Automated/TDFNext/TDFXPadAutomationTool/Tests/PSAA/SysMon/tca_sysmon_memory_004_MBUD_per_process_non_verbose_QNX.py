from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_004_MBUD_per_process_non_verbose_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_004_MBUD_per_process_non_verbose_QNX"
    REQ_ID = ["/item/6343130"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "23-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon is reporting RAM comsumption per process in non-verbose mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_MBUD_per_process)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_memory_002_MBUD_totals_non_verbose_QNX(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_MBUD_per_process, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep(f"Wait for DLT ({self.wait_for_budget_report_non_verbose_message_ms})")
        self.sleep_for(self.wait_for_budget_report_non_verbose_message_ms)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get MBUD non-verbose DLT messages that contains per-process RAM consumption")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that MBUD per-process non verbose DLT messages are available")
        message_payload = dlt_messages[0]['payload']
        self.expectTrue(message_payload.get('rss') is not None, Severity.MAJOR, "Check that the DLT contains the resident set size (rss)")
        self.expectTrue(message_payload.get('uss') is not None, Severity.MAJOR, "Check that the DLT contains the unique set size (uss)")
        self.expectTrue(message_payload.get('shm') is not None, Severity.MAJOR, "Check that the DLT contains the shared memory (shm)")
        self.expectTrue(message_payload.get('vm') is not None, Severity.MAJOR, "Check that the DLT contains the virtual memory size (vmSize)")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
