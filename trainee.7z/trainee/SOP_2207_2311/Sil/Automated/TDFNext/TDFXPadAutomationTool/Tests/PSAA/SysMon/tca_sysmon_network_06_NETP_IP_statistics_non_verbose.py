from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_network_06_NETP_IP_statistics_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_network_06_NETP_IP_statistics_non_verbose"
    REQ_ID = ["/item/5909511"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that the NETP IP reports contains all required statistics in Non-Verbose Mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.network_protocols_statistics_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_NETP_IP)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_network_06_NETP_IP_statistics_non_verbose(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_NETP_IP, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait cycle of NETP * 2")
        self.sleep_for(self.time_interval * 10)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get DLT NETP IP non-verbose messages")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that DLT NETP IP messages are available")

        in_receives = float(dlt_messages[0]["payload"]["in_receives"])
        in_hdr_errors = float(dlt_messages[0]["payload"]["in_hdr_errors"])
        in_discards = float(dlt_messages[0]["payload"]["in_discards"])
        in_delivers = float(dlt_messages[0]["payload"]["in_delivers"])
        out_requests = float(dlt_messages[0]["payload"]["out_requests"])
        out_discards = float(dlt_messages[0]["payload"]["out_discards"])
        out_no_routes = float(dlt_messages[0]["payload"]["out_no_routes"])
        reasm_oks = float(dlt_messages[0]["payload"]["reasm_oks"])
        frag_oks = float(dlt_messages[0]["payload"]["frag_oks"])
        frag_fails = float(dlt_messages[0]["payload"]["frag_fails"])
        frag_creates = float(dlt_messages[0]["payload"]["frag_creates"])

        self.expectTrue(type(in_receives) == float, Severity.MAJOR, "Check that in_receives is reported")
        self.expectTrue(type(in_hdr_errors) == float, Severity.MAJOR, "Check that in_hdr_errors is reported")
        self.expectTrue(type(in_discards) == float, Severity.MAJOR, "Check that in_discards is reported")
        self.expectTrue(type(in_delivers) == float, Severity.MAJOR, "Check that in_delivers is reported")
        self.expectTrue(type(out_requests) == float, Severity.MAJOR, "Check that out_requests is reported")
        self.expectTrue(type(out_discards) == float, Severity.MAJOR, "Check that out_discards is reported")
        self.expectTrue(type(out_no_routes) == float, Severity.MAJOR, "Check that out_no_routes is reported")
        self.expectTrue(type(reasm_oks) == float, Severity.MAJOR, "Check that reasm_oks is reported")
        self.expectTrue(type(frag_oks) == float, Severity.MAJOR, "Check that frag_oks is reported")
        self.expectTrue(type(frag_fails) == float, Severity.MAJOR, "Check that frag_fails is reported")
        self.expectTrue(type(frag_creates) == float, Severity.MAJOR, "Check that frag_creates is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
