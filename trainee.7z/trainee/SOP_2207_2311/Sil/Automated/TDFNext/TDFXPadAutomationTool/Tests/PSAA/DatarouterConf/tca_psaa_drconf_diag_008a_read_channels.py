from Tests.PSAA.DatarouterConf.testfixture_PSAA_DatarouterConf import *


class tca_psaa_drconf_diag_008a_read_channels(testfixture_PSAA_DatarouterConf):

    TEST_ID = "PSAA\tca_psaa_dr_diag_008a"
    REQ_ID = ["/item/853028", "/item/1633236", "/item/1633238"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Read log channels"
    STATUS = "Ready"
    OS = ['LINUX','QNX']


    def setUp(self):
        grep_DConf = self.check_application_is_started(app_name=self.DATA_ROUTER_CONF_APP_NAME)
        self.expectTrue(grep_DConf, Severity.MAJOR, "Check The application was started")

        self.diag_manager.start()

    def test_read_channels(self):
        self.startTestStep("Read log channels names using diag")
        res = self.diag_manager.syn_send(0xF4, self.PP_DIAG_ADR,
                                         self.STATUS_DLT_READ_LOG_CHANNEL_NAMES)

        self.expectTrue(res != DiagResult.send_failure, Severity.BLOCKER, "Check the diagnostic job payload was sent")
        self.expectTrue(res != DiagResult.timeout, Severity.BLOCKER, "Check the dut respond to diagnostic")
        self.expectTrue(res == DiagResult.positive, Severity.BLOCKER, "Check the response of the diag")



        res_diag = self.diag_manager.get_latest_Response(self.PP_DIAG_ADR)
        logger.debug("Diag Job response -> returned payload: {}".format(
            self.diag_manager.payload_to_str(res_diag.get_payload())))
        self.startTestStep("Get log channels config file content")
        returned=self.ssh_manager.executeCommandInTarget(command=f"cat {self.log_channels_config_file_path}", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.parse_log_channel_config_file(config_content=returned, diag_result=res_diag)


    def tearDown(self):
        self.diag_manager.stop()
