from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_version_01_HLT(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_version_01_HLT"
    REQ_ID = ["/item/5911561"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports SW version information"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.version_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.Search_msg_array = self.statistic_data["HLT"]["version"]["Search_msg_array"]
        logger.info(f"Search message array = {self.Search_msg_array}")
        self.assertTrue(self.Search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.version_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_version_01_HLT(self):
        self.startTestStep("Wait the configured time for loop detection * 2")
        self.sleep_for(self.time_interval * 2)
        self.startTestStep("Get HLT DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.Search_msg_array)
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that DLT message exist")

        self.startTestStep("Get Git_hash value")
        Git_hash = self.get_statistic_value(message=messages[0], statistic_path="HLT.version.Statistics.Git_hash")
        self.expectTrue(Git_hash != self.INVALID_VALUE, Severity.MAJOR, "Check that DLT message contains Correct git hash")

        self.startTestStep("Get swName value")
        swName = self.get_statistic_value(message=messages[0], statistic_path="HLT.version.Statistics.swName")
        self.expectTrue(swName != self.INVALID_VALUE, Severity.MAJOR, "Check thatDLT message contains correct SW name")

        self.startTestStep("Get swVersion value")
        swVersion = self.get_statistic_value(message=messages[0], statistic_path="HLT.version.Statistics.swVersion")
        self.expectTrue(swVersion != self.INVALID_VALUE, Severity.MAJOR, "Check thatDLT message contains correct SW version")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
