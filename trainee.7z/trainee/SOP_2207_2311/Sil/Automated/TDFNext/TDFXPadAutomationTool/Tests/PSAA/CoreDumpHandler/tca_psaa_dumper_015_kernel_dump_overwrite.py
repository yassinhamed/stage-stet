from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_015_kernel_dump_overwrite(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_015_kernel_dump_overwrite"
    REQ_ID = ["/item/1736864","/item/1736961"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps created by different kernel crash before and after ecu reset are different"
    STATUS = "Ready"
    OS = ['LINUX']


    def setUp(self):
        pass

    def test_tca_psaa_dumper_015_kernel_dump_overwrite(self):

        self.startTestStep("Perform kernel panic")
        self.ssh_manager.executeCommandInTargetNoWait(command=self.kernel_panic_command,
                                                      timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                      ip_address=self.PP_IP)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)

        self.startTestStep("Get coredumps")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"ls -la {self.CoreDumps_Path}/kernel | grep -c kdump.vmcore",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Checking that the coredumps were generated")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

        self.startTestStep("Read checksum and check kernel exists")
        result = self.ssh_manager.executeCommandInTarget(command=f"cat {self.CoreDumps_Path}/checksum | grep kernel",
                                                         timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(result["exec_recv"] == 0, Severity.MAJOR,
                        "Checking that coredump is listed in checksum file {0}".format(result["stdout"]))
        kernelLog_1 = result["stdout"].strip()

        self.diag_manager.start()
        self.startTestStep("Reset ECU")
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.restart()

        self.startTestStep("Perform kernel panic")
        self.ssh_manager.executeCommandInTargetNoWait(command=self.kernel_panic_command,
                                                      timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                      ip_address=self.PP_IP)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)


        result = self.ssh_manager.executeCommandInTarget(command=f"cat {self.CoreDumps_Path}/checksum | grep kernel",
                                                         timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(result["exec_recv"] == 0, Severity.MAJOR,
                        "Checking that coredump is listed in checksum file {0}".format(result["stdout"]))
        kernelLog_2=result["stdout"].strip()

        self.expectTrue(not (kernelLog_1 == kernelLog_2), Severity.MAJOR, "Check the kernel dump log is not the same")

        self.startTestStep("Get coredumps")
        returnValue = self.ssh_manager.executeCommandInTarget(
            command=f"ls -la {self.CoreDumps_Path}/kernel | grep -c kdump.vmcore",
            timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Checking that the coredumps were generated")

    def tearDown(self):
        pass
