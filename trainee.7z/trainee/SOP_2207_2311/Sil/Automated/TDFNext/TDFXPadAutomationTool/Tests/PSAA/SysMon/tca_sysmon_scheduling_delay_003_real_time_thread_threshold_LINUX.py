from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_scheduling_delay_003_real_time_thread_threshold_LINUX(testfixture_PSAA_SysMon):
    TEST_ID = "PSAA/SysMon/tca_sysmon_scheduling_delay_003_real_time_thread_threshold_LINUX"
    REQ_ID = ["/item/5910112"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that  sysmon reports scheduling delay for real time threads only after exceeding the configured threshold"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.search_msg_array = self.statistic_data["Scheduling"]["real_time"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")

        self.threshold = self.get_config_value_linux(config_name=self.scheduling_delay_rt_threshold)
        logger.info(f"threshold = {self.threshold}")
        self.assertTrue(self.threshold is not None, Severity.BLOCKER, "Check that threshold was successfully retrieved")

        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.real_time_scheduling_delay_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_scheduling_delay_003_real_time_thread_threshold_LINUX(self):
        self.startTestStep("Wait 30 seconds")
        self.sleep_for(self.wait_for_scheduling_delay_reports_ms)

        self.startTestStep("Get SDRT DLT message")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that SDRT DLT messages are available")

        delays_are_bigger_than_threshold = self.check_reported_delays(messages=messages, threshold=self.threshold)
        self.assertTrue(delays_are_bigger_than_threshold, Severity.MAJOR, "Check that all reported delays are bigger than the configured threshold")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
