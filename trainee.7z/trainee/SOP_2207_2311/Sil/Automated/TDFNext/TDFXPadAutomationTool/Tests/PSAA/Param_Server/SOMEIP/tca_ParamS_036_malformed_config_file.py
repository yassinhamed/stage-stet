from Tests.PSAA.Param_Server.testfixture_PSAA_param_server import *


class tca_ParamS_036_malformed_config_file(testfixture_PSAA_param_server):

    TEST_ID = "ParamServer\tca_ParamS_036_malformed_config_file"
    REQ_ID = ["/item/727609"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    field_depends_on_coding = False

    def setUp(self):
        pass

    def test_malformed_config_file(self):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"mount -o rw,remount / && sed -i '1s/^/{{/' {self.param_server_etc_path}/{self.defaut_values_file_name} && mount -o ro,remount /", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.MAJOR, "Check that the command to corrupt default_values.json was successfully executed")

        returnValue = self.ssh_manager.executeCommandInTarget(command=f"head -1 {self.param_server_etc_path}/{self.defaut_values_file_name}", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.MAJOR, "Check that the command to print the first line in default_values.json was successfully executed")
        self.assertTrue(returnValue["stdout"].strip() != "{{{", Severity.MAJOR, "Check that the command to print 2 first line in default_values.json was successfully modified")


        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")

        expected_parsed_paramters = self.generate_paresed_payload_initial_values(field_name=self.tested_field)
        logger.info(f"expected parsed parameters with initValues \n{json.dumps(expected_parsed_paramters, indent=4)}")

        self.someip_manager.reset(ecu="TestEquipmentIntern")
        self.someip_controller.send_request("TestEquipmentIntern", service_id=self.AdpParameters_service_ID, instance_id=self.AdpParameters_instances[self.PP_NAME],
                                            method_id=self.someipIds['getterID'], interface_version=1, is_TCP=False)

        self.sleep_for(self.GETTER_RESPONSE_TIMEOUT_MS)

        someip_response_messages = self.get_someip_messages_from_queue(method_id=self.someipIds['getterID'])

        self.expectTrue(len(someip_response_messages) > 0, Severity.BLOCKER, "Check that a response of the getter request is received")
        self.expectTrue(len(someip_response_messages) == 1, Severity.MAJOR, "Check that exactly 1 response of the getter request is received")

        getter_response = someip_response_messages[-1].payload
        logger.info(f"Response payload of the getter = {getter_response}")

        getter_response_size = len(getter_response)
        logger.info(f"The size of the received Getter response = {getter_response_size}")
        self.assertTrue(getter_response_size == self.field_size, Severity.BLOCKER, "Check that the payload size of the getter response is correct.")

        parsed_getter_response = self.parse_field_someip_payload(payload=getter_response, field_structure=self.field_structure)
        logger.info(f"Parsed Getter response :\n{json.dumps(parsed_getter_response, indent=4)}")

        result = self.compare_2_dicts(parsed_getter_response,  expected_parsed_paramters)
        self.assertTrue(result, Severity.BLOCKER, "Check that the parameter Values in Getter response equals the expected value(all parameters equals to initValue)")

    def tearDown(self):
        self.revert_default_values_file_to_backup()
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.SC_DIAG_ADR, reset_duration=self.SC_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        self.sleep_for(self.PP_RESET_TIMEOUT_MS)
