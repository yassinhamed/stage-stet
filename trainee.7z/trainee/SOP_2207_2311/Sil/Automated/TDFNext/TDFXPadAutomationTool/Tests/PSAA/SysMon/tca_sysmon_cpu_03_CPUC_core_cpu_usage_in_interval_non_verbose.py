from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_cpu_03_CPUC_core_cpu_usage_in_interval_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_cpu_03_CPUC_core_cpu_usage_in_interval_non_verbose"
    REQ_ID = ["/item/5829101"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports the cpu usage in interval for each core in non-verbose mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.CPU_core_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        if self.os_name.lower() == "linux":
            self.setPrecondition("Get number of online cores using SSH command")
            number_of_cores = self.ssh_manager.executeCommandInTarget(command="grep -c 'cpu cores' /proc/cpuinfo", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
            self.expectTrue(number_of_cores["stdout"] != "", Severity.MAJOR, "Check that getting number of online cores using command was successfull")
        self.setPrecondition("Start monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_CPUC)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_cpu_03_CPUC_core_cpu_usage_in_interval_non_verbose(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_CPUC, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 10)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get CPUC non-verbose DLT message that contains the cpu usage in interval per core")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that CPU cores DLT messages are available")

        self.startTestStep("Get in_interval value")
        in_interval = float(dlt_messages[0]["payload"]["load"])
        self.expectTrue(in_interval != self.INVALID_VALUE, Severity.MAJOR, "Check that in_interval is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
