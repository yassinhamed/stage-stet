from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_002_MBUD_totals_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_002_MBUD_totals_QNX"
    REQ_ID = ["/item/5905540"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports total MBUD statistics"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.budget_report_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE,  Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.search_msg_array_part1 = self.statistic_data["Memory"]["mbud_total1_qnx"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array_part1}")
        self.assertTrue(self.search_msg_array_part1 is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.search_msg_array_part2 = self.statistic_data["Memory"]["mbud_total2_qnx"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array_part2}")
        self.assertTrue(self.search_msg_array_part2 is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.budget_report_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_memory_002_MBUD_totals_QNX(self):
        self.startTestStep("Wait cycle * 2")
        self.sleep_for(self.time_interval * 2)

        self.startTestStep("Get MBUD total1 DLT messages")
        message_count1, messages1 = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array_part1)

        self.assertTrue(message_count1 > 0, Severity.MAJOR, "Check that MBUD total1 DLT messages are available")
        logger.info(f"dlt messages: {messages1}")

        self.startTestStep("Get uss value")
        uss = self.get_statistic_value(message=messages1[0], statistic_path="Memory.mbud_total1_qnx.Statistics.uss")
        self.expectTrue(uss != self.INVALID_VALUE, Severity.MAJOR, "Check that uss is reported")

        self.startTestStep("Get MBUD total2 DLT messages")
        message_count2, messages2 = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array_part2)
        self.assertTrue(message_count2 > 0, Severity.MAJOR, "Check that MBUD total2 DLT messages are available")
        logger.info(f"dlt messages: {messages2}")

        self.startTestStep("Get total value")
        total = self.get_statistic_value(message=messages2[0], statistic_path="Memory.mbud_total2_qnx.Statistics.total")
        self.expectTrue(total != self.INVALID_VALUE, Severity.MAJOR, "Check that total is reported")

        self.startTestStep("Get free value")
        free = self.get_statistic_value(message=messages2[0], statistic_path="Memory.mbud_total2_qnx.Statistics.free")
        self.expectTrue(free != self.INVALID_VALUE, Severity.MAJOR, "Check that free is reported")

        self.startTestStep("Get available value")
        available = self.get_statistic_value(message=messages2[0], statistic_path="Memory.mbud_total2_qnx.Statistics.available")
        self.expectTrue(available != self.INVALID_VALUE, Severity.MAJOR, "Check that available is reported")

        self.startTestStep("Get shmem value")
        shmem = self.get_statistic_value(message=messages2[0], statistic_path="Memory.mbud_total2_qnx.Statistics.shmem")
        self.expectTrue(shmem != self.INVALID_VALUE, Severity.MAJOR, "Check that shmem is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
