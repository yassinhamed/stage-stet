from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_DDR_margin_01_DDR(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_DDR_margin_01_DDR"
    REQ_ID = ["/item/5835099"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon reports DDR margin statistics"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.search_msg_array = self.statistic_data["DDR"]["Margin"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")

        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.DDR_margin_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_DDR_margin_01_DDR(self):
        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.startTestStep("Check ECUs")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUs are Ok after ECU reset")

        self.startTestStep("Get DDR margin DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that CPUS number of online cores DLT messages are available")

        self.startTestStep("Get level value")
        level = self.get_statistic_value(message=messages[0], statistic_path="DDR.Margin.Statistics.level")
        self.expectTrue(level in self.valid_DDR_levels, Severity.MAJOR, "Check that level is valid")

        self.startTestStep("Get RxPdq value")
        RxPdq = self.get_statistic_value(message=messages[0], statistic_path="DDR.Margin.Statistics.RxPdq")
        self.expectTrue(RxPdq != self.INVALID_VALUE, Severity.MAJOR, "Check that RxPdq is reported")

        self.startTestStep("Get RxVref value")
        RxVref = self.get_statistic_value(message=messages[0], statistic_path="DDR.Margin.Statistics.RxVref")
        self.expectTrue(RxVref != self.INVALID_VALUE, Severity.MAJOR, "Check that RxVref is reported")

        self.startTestStep("Get TxPdq value")
        TxPdq = self.get_statistic_value(message=messages[0], statistic_path="DDR.Margin.Statistics.TxPdq")
        self.expectTrue(TxPdq != self.INVALID_VALUE, Severity.MAJOR, "Check that TxPdq is reported")

        self.startTestStep("Get TxVref value")
        TxVref = self.get_statistic_value(message=messages[0], statistic_path="DDR.Margin.Statistics.TxVref")
        self.expectTrue(TxVref != self.INVALID_VALUE, Severity.MAJOR, "Check that TxVref is reported")

    def tearDown(self):
        self.diag_manager.stop()
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
