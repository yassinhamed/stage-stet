from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_block_device_01_BLK_io_statistics(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_block_device_01_BLK_io_statistics"
    REQ_ID = ["/item/5833367"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports block device IO statistics"
    STATUS = "Ready"
    OS = ['LINUX']


    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.blk_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.Search_msg_array_read = self.statistic_data["BLK"]["IO"]["Search_msg_array_read"]
        logger.info(f"Search message array = {self.Search_msg_array_read}")
        self.assertTrue(self.Search_msg_array_read is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.Search_msg_array_write = self.statistic_data["BLK"]["IO"]["Search_msg_array_write"]
        logger.info(f"Search message array = {self.Search_msg_array_write}")
        self.assertTrue(self.Search_msg_array_write is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start Monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.blk_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_block_device_01_BLK_io_statistics(self):
        self.startTestStep("Wait one cycle * 10")
        self.sleep_for(self.time_interval * 10)

        self.startTestStep("Get BLK IO statistics DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.Search_msg_array_read)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that BLK IO statistics DLT messages are available")

        self.startTestStep("Get read_processed value")
        read_processed = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.read_processed")
        self.expectTrue(read_processed != self.INVALID_VALUE, Severity.MAJOR, "Check that read_processed is reported")

        self.startTestStep("Get read_merged value")
        read_merged = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.read_merged")
        self.expectTrue(read_merged != self.INVALID_VALUE, Severity.MAJOR, "Check that read_merged is reported")

        self.startTestStep("Get read_sectors value")
        read_sectors = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.read_sectors")
        self.expectTrue(read_sectors != self.INVALID_VALUE, Severity.MAJOR, "Check that read_sectors is reported")

        self.startTestStep("Get read_wait_time value")
        read_wait_time = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.read_wait_time")
        self.expectTrue(read_wait_time != self.INVALID_VALUE, Severity.MAJOR, "Check that read_wait_time is reported")

        self.startTestStep("Get BLK IO statistics DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.Search_msg_array_write)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that BLK IO statistics DLT messages are available")

        self.startTestStep("Get write_processed value")
        write_processed = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.write_processed")
        self.expectTrue(write_processed != self.INVALID_VALUE, Severity.MAJOR, "Check that write_processed is reported")

        self.startTestStep("Get write_merged value")
        write_merged = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.write_merged")
        self.expectTrue(write_merged != self.INVALID_VALUE, Severity.MAJOR, "Check that write_merged is reported")

        self.startTestStep("Get write_sectors value")
        write_sectors = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.write_sectors")
        self.expectTrue(write_sectors != self.INVALID_VALUE, Severity.MAJOR, "Check that write_sectors is reported")

        self.startTestStep("Get write_wait_time value")
        write_wait_time = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.write_wait_time")
        self.expectTrue(write_wait_time != self.INVALID_VALUE, Severity.MAJOR, "Check that write_wait_time is reported")

        self.startTestStep("Get requests value")
        requests = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.requests")
        self.expectTrue(requests != self.INVALID_VALUE, Severity.MAJOR, "Check that requests is reported")

        self.startTestStep("Get total_time_active value")
        total_time_active = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.total_time_active")
        self.expectTrue(total_time_active != self.INVALID_VALUE, Severity.MAJOR, "Check that total_time_active is reported")

        self.startTestStep("Get total_time_wait_time value")
        total_time_wait_time = self.get_statistic_value(message=messages[0], statistic_path="BLK.IO.Statistics.total_time_wait_time")
        self.expectTrue(total_time_wait_time != self.INVALID_VALUE, Severity.MAJOR, "Check that total_time_wait_time is reported")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
