from Tests.PSAA.CoreDumpHandler.testfixture_PSAA_CoreDumpHandler import *


class tca_psaa_dumper_016_adaptive_dump_persistent(testfixture_PSAA_CoreDumpHandler):

    TEST_ID = "PSAA\tca_psaa_dumper_016_adaptive_dump_persistent"
    REQ_ID = ["/item/1736864","/item/1736961"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    Priority = "N/A"
    DESCRIPTION = "Check coredumps created by killing adaptive application still exist after ecu reset"
    STATUS = "Ready"
    OS = ['LINUX']


    def setUp(self):
        pass

    def test_tca_psaa_dumper_016_adaptive_dump_persistent(self):

        self.startTestStep("Kill application ETS")
        ets_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(ets_is_killed, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

        self.startTestStep("Check application is not running")
        Planning_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not Planning_is_started, Severity.BLOCKER,
                        f"Checking that the {self.ETS_APP_NAME} is not running")

        self.startTestStep("check coredumps created")
        coredumps_created = self.check_coredumps(self.ETS_APP_NAME)
        self.assertTrue(coredumps_created,Severity.BLOCKER,"Checking that coredumps files were created properly.")

        self.diag_manager.start()
        self.startTestStep("Reset ECU")
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.restart()

        self.startTestStep("get coredumps related to ETS application")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path} | grep -w {self.ETS_APP_NAME}",
                                                              timeout=self.SSH_CONNECTION_TIMEOUT_MS,
                                                              ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER,
                        "Checking that 'ls' command executed successfully")
        dumps_list = returnValue["stdout"].splitlines()
        logger.info(f"core dumps {dumps_list}")
        logger.info("Number of core dumps" + str(len(dumps_list)))
        self.expectTrue(len(dumps_list) == self.Number_Of_Coredumps_Files_After_Reset, Severity.BLOCKER,
                        "Checking that coredumps files were created properly.")

    def tearDown(self):
        pass
