from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *

class tca_PSAA_uptimeCounter_StartupCycles_PWF(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_uptimeCounter_StartupCycles_PWF"
    REQ_ID = ["/item/6233405"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check startup cycles counter is incremented after Partial Network transition"
    STATUS = "Ready"
    OS = ["QNX", "LINUX"]


    def setUp(self):

        self.setPrecondition("Configuration of MediaGateway for simulation")
        self.set_MG_For_BCP_Simulation()

        self.setPrecondition("Start BCP simulation")
        self.start_bcp_simulation()

        self.setPrecondition("Start simulation")
        self.bcp21_nmController.start_udp_nm_simulation()
        self.Simulate_PWF_State(self.PWF_STATE_PAD)

        self.setPrecondition("Wait for ecu startup")
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)

        self.setPrecondition("Check that ECUs are OK")
        ECUs_are_OK = self.check_ECUs(is_BCP_simulated=True)
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")

        self.setPrecondition("Disable partial network configuration Autonomous_Driving_Ready")
        self.bcp21_nmController.set_functional_partial_network(self.AD_Ready_AUS_FUNCTIONAL_PARTIAL_NETWORK)

        self.setPrecondition("Check that partial network configuration Autonomous_Driving_Ready is disabled")
        udpnm_signals = self.get_UDPNM_signals()
        self.expectTrue(udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Autonomous_Driving_Ready_ein'] == 0,Severity.BLOCKER,"Checking that partial network configuration Autonomous_Driving_Ready is disabled")

        self.setPrecondition("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.setPrecondition("Getting StartupCycles counter value from kvs")
        self.First_Startup_cycles = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.StartupCycles_counter)
        logger.info(f"First_Startup_cycles_value: {self.First_Startup_cycles}")

    def test_tca_PSAA_uptimeCounter_StartupCycles_PWF(self):

        self.startTestStep("transition from PAD to Wohnen")
        self.Simulate_PWF_State(self.PWF_STATE_WOHNEN)
        udpnm_signals = self.get_UDPNM_signals()
        self.expectTrue(udpnm_signals['User data']['CTR_BS_PRINT_NM']['KOM_Wohnen'] == 1, Severity.BLOCKER,"check that UDPNM signal wohnen is set")

        self.startTestStep("Wait for shutdown")
        self.sleep_for(self.PP_SHUTDOWN_TIMEOUT_MS)

        self.startTestStep("ping ECU")
        ping_pp_result = self.network.ping_ecu(self.PP_IP)
        self.assertTrue(not(ping_pp_result), Severity.MAJOR, "Checking ECU is not pingable")


        self.startTestStep("transition from Wohnen to PAD")
        self.Simulate_PWF_State(self.PWF_STATE_PAD)


        self.startTestStep("Wait for ecu startup")
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)

        self.startTestStep("Check Ecus")
        ECUs_are_OK = self.check_ECUs(is_BCP_simulated=True)
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUS are correctly reset")

        self.startTestStep("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.expectTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.startTestStep("Getting StartupCycles counter value from kvs")
        Second_Startup_cycles = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.StartupCycles_counter)
        logger.info(f"Second_Startup_cycles_value: {Second_Startup_cycles}")

        self.assertTrue(int(Second_Startup_cycles) == int(self.First_Startup_cycles) + 1,Severity.BLOCKER,"Checking StartupCycles counter value is incremented")


    def tearDown(self):
        self.setPostcondition("stopping BCP simulation")
        self.stop_bcp_simulation()
        self.bcp21_nmController.stop_nm_udp_simulation()
        self.set_standard_MG()

