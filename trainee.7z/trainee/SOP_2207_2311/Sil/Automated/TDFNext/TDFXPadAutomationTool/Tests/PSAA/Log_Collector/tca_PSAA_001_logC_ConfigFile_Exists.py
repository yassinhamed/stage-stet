from Tests.PSAA.Log_Collector.testfixture_PSAA_Log_Collector import *


class tca_PSAA_001_logC_ConfigFile_Exists(testfixture_PSAA_Log_Collector):

    TEST_ID = "PSAA\tca_PSAA_001_logC_ConfigFile_Exists"
    REQ_ID = ["/item/2593628","/item/2593612"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX']

    def setUp(self):
        self.logCollectorRevertConfigFile()
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.apply_filter(appId=self.LOG_COLLECTOR_APP_ID, context_ID=self.Configuration_error_context_ID)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_PSAA_001_logC_ConfigFile_Exists(self):
        self.startTestStep("Check log collector application is running")
        grep_LogC = self.check_application_is_started(app_name=self.LOG_COLLECTOR_APP_NAME)
        self.expectTrue(grep_LogC, Severity.MAJOR, "Check The application was started")
        self.startTestStep("Check config file exist")
        check_file = self.ssh_manager.executeCommandInTarget(command=f"ls {self.Config_file_path}",timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(check_file["stdout"] != "", Severity.MAJOR, "Check Linux command executed")
        folder_contents = check_file["stdout"].strip()
        self.assertTrue(self.Config_file_name in folder_contents, Severity.BLOCKER,
                        "Check security configuration file does exist")
        self.startTestStep("Get cong file content")
        events_configuration = self.json_manager.findNodeFromJsonFile(
            filePath=self.Config_file_path + self.Config_file_name, nodePath="EventsConfigs",
            use_cache=False, delete_cache=False, upload_file=False)
        self.startTestStep("parse cong file content")
        res = self.security_events_file_parser(events_configuration)
        self.expectTrue(res, Severity.BLOCKER, "Check the existance of the fields in the security event file")
        self.startTestStep("Get DLT messages")
        number, message = self.dlt_manager.get_messages_by_AND(ecuId=self.PP_ECUID, appId=self.LOG_COLLECTOR_APP_ID,
                                                               context_ID=self.Configuration_error_context_ID,
                                                               searchMsgArray=["not", "security", "config"])
        self.assertTrue(number == 0, Severity.BLOCKER, "Check no error detected")

    def tearDown(self):
        pass
