from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter_With_Proxy_App import *


class tca_psaa_CrashReporter_025_IPC_Registered_observers(testfixture_PSAA_Crash_Reporter_With_Proxy_App):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_025_IPC_Registered_observers"
    REQ_ID = ["/item/6566027"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check IPC coredump notification is sent to registered observers"
    STATUS = "Obsolete"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Clear old core dumps")
        self.expectTrue(True, Severity.MAJOR, "Check the remove of old coredumps is done")
        self.setPrecondition("Check crash reporter is running")
        self.expectTrue(True, Severity.MAJOR, "Check that crash reporter is running")
        self.setPrecondition("Import proxy app library")

    def test_tca_psaa_CrashReporter_025_IPC_Registered_observers(self):
        self.startTestStep("Subscribe to IPC event using proxy app")
        self.startTestStep("Get pid of the application to be killed")
        self.assertTrue(True, Severity.MAJOR, "Check the application is running")
        self.startTestStep("Kill application")
        self.expectTrue(True, Severity.MAJOR, "Check the kill command is executed")
        self.startTestStep("Wait for coredumps creation")
        self.startTestStep("Check application is killed")
        self.assertTrue(True, Severity.MAJOR, "Check the application is killed")
        self.startTestStep("Get coredumps names using ls command")
        self.expectTrue(True, Severity.MAJOR, "Check the context file is created successfully under /persistent/coredumps")
        self.expectTrue(True, Severity.MAJOR, "Check the core file is created successfully under /persistent/coredumps")
        self.startTestStep("Get IPC coredump notification")
        self.assertTrue(True, Severity.MAJOR, "Check IPC coredump notification is sent")
        self.assertTrue(True, Severity.MAJOR, "Check IPC coredump notification contains the PID of the crashed process")

    def tearDown(self):
        self.setPostcondition("Remove proxy app library")
        self.setPostcondition("Reset ECU")
