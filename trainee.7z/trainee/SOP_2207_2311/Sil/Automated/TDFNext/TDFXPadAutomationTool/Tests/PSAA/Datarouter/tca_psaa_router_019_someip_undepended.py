from Tests.PSAA.Datarouter.testfixture_PSAA_Datarouter import *


class tca_psaa_router_019_someip_undepended(testfixture_PSAA_Datarouter):

    TEST_ID = "PSAA\tca_psaa_router_019_someip_undepended"
    REQ_ID = ["/item/863411","/item/145159"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = ""
    STATUS = "Ready"
    OS = ['LINUX']


    def setUp(self):
        pass

    def test_tca_psaa_router_019_someip_undepended(self):
        self.startTestStep("Get the PID of datarouter")
        datarouter_pid = self.get_process_id(app_name=self.DATA_ROUTER_APP_NAME, exclude=True, exclude_app_name="conf")
        self.assertTrue(datarouter_pid != -1, Severity.BLOCKER, "Checking that the pid of datarouter is returned successfully")

        self.startTestStep("Get the PID of someipd_posix")
        someipd_pid = self.get_process_id(app_name=self.SOMEIP_POSIX_APP_NAME)
        self.assertTrue(someipd_pid > datarouter_pid, Severity.BLOCKER, "Checking that the pid of someipd_posix is bigger than pid of datarouter")

    def tearDown(self):
        pass
