from Tests.PSAA.Crash_handler.testfixture_PSAA_CrashHandler import *


class tca_psaa_Chandler_016_transfert_rules_DLT_Reboot(testfixture_PSAA_CrashHandler):

    TEST_ID = "PSAA\tca_psaa_Chandler_016_transfert_rules_DLT_Reboot"
    REQ_ID = ["/item/2593168", "/item/2593369"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check core dumps for killing adaptive app not transferred over the DLT after reset"
    STATUS = "Ready"
    OS = ['LINUX', 'QNX']

    def setUp(self):
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.dlt_manager.add_callback_function(self.coredump_checker.coredumps_transfer_callback)
        self.sleep_for(self.DLT_START_MONITORING_TIMEOUT)

    def test_tca_psaa_Chandler_016_transfert_rules_DLT_Reboot(self):
        self.startTestStep("Get pid of the application to be killed")
        XPC_pid = self.get_process_id(app_name=self.XPC_APP_NAME)
        self.assertTrue(XPC_pid != -1, Severity.MAJOR, "Check the application is running")
        self.startTestStep("Kill ETS app")
        application_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal=self.killall_options["SIGSEGV"])
        self.expectTrue(application_is_killed, Severity.BLOCKER, f"Checking that the {self.ETS_APP_NAME} is killed")
        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)
        self.startTestStep("Check application ETS is not running")
        ets_is_started = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.expectTrue(not ets_is_started, Severity.BLOCKER, f"Checking that the {self.ETS_APP_NAME} is not running")
        self.startTestStep("Get coredumps files names")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.CoreDumps_Path}", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.assertTrue(returnValue["exec_recv"] == 0, Severity.BLOCKER, "Checking that 'ls' command executed successfully")
        dumps_list = returnValue["stdout"].splitlines()
        self.assertTrue(self.check_coredumps(app_name=self.ETS_APP_NAME), Severity.BLOCKER, f"Checking that coredumps files were created properly")
        self.startTestStep("check on DLT messages")
        check = self.coredump_checker.check_coredump_transfert(dumps_list)
        self.expectTrue(check[0], Severity.BLOCKER, "Check {0} was transferred via DLT".format(dumps_list[0]))
        self.expectTrue(check[1], Severity.BLOCKER, "Check {0} was transferred via DLT".format(dumps_list[1]))
        self.dlt_manager.stop_monitoring()
        self.dlt_manager.clear_all_dlt_messages()
        self.dlt_manager.remove_callback_function(self.coredump_checker.coredumps_transfer_callback)
        self.diag_manager.start()
        self.startTestStep("Reset ECU")
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)
        self.diag_manager.restart()

        self.sleep_for(self.COREDUMPS_GENERATION_TIMEOUT_MS)

        self.dlt_manager.start_monitoring("SRR-DLT")
        self.dlt_manager.add_callback_function(self.coredump_checker.coredumps_transfer_callback)
        self.startTestStep("check on DLT messages")
        check = self.coredump_checker.check_coredump_transfert(dumps_list)
        self.assertTrue(not check[0], Severity.BLOCKER, "Check {0} was not transferred via DLT".format(dumps_list[0]))
        self.assertTrue(not check[1], Severity.BLOCKER, "Check {0} was not transferred via DLT".format(dumps_list[1]))

    def tearDown(self):
        self.dlt_manager.stop_monitoring()
        self.dlt_manager.clear_all_dlt_messages()
        self.dlt_manager.remove_callback_function(self.coredump_checker.coredumps_transfer_callback)
