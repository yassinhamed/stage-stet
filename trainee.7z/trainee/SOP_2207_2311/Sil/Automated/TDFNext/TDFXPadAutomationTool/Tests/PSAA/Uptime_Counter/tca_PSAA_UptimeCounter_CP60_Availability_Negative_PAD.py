from Tests.PSAA.Uptime_Counter.testfixture_PSAA_UptimeCounter import *


class tca_PSAA_UptimeCounter_CP60_Availability_Negative_PAD(testfixture_PSAA_UptimeCounter):

    TEST_ID = "PSAA\tca_PSAA_UptimeCounter_CP60_Availability_Negative_PAD"
    REQ_ID = ["/item/2081694"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check CP60 system Availability time is not updated when partial network configuration Autonomous_Driving_Ready is disabled in PAD"
    STATUS = "Ready"
    OS = ["QNX"]


    def setUp(self):
        self.setPrecondition("Create backup of exec_config_file")
        self.create_uptime_counter_exec_config_backup()

        self.setPrecondition("Changing uptime_counter cyclicity under exec_config file to 10s")
        self.change_cyclicity(new_cyclicity=self.Cyclicity_10s_MS)

        self.setPrecondition("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()
        self.setPrecondition("Check Ecus")
        ECUs_are_OK = self.check_ECUs()
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check ECUS are correctly reset")

        self.setPrecondition("Get cyclicity from exec_config file")
        cyclicity = self.get_cyclicity_from_exec_config()
        logger.info(f"cyclicity_value: {cyclicity}")
        self.assertTrue(cyclicity == self.Cyclicity_10s_MS, Severity.MAJOR,"Checking cyclicity is successfully changed")
        self.setPrecondition("Configuration of MediaGateway for simulation")
        self.set_MG_For_BCP_Simulation()

        self.setPrecondition("Start BCP simulation")
        self.start_bcp_simulation()

        self.setPrecondition("Start simulation")
        self.bcp21_nmController.start_udp_nm_simulation()
        self.Simulate_PWF_State(self.PWF_STATE_PAD)

        self.setPrecondition("Wait for ecu startup")
        self.sleep_for(self.PP_STARTUP_TIMEOUT_MS)

        self.setPrecondition("Check that ECUs are OK")
        ECUs_are_OK = self.check_ECUs(is_BCP_simulated=True)
        self.expectTrue(ECUs_are_OK, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")

        udpnm_signals = self.get_UDPNM_signals()
        self.expectTrue(udpnm_signals['User data']['CTR_BS_PRINT_NM']['KOM_Pruefen_Analyse_Diagnose'] == 1,Severity.BLOCKER, "check that UDPNM signal PAD is set")

        self.setPrecondition("Set partial network configuration Autonomous_Driving_Ready")
        self.bcp21_nmController.set_functional_partial_network(self.DEFAULT_FUNCTIONAL_PARTIAL_NETWORK)

        self.setPrecondition("Check that partial network configuration Autonomous_Driving_Ready is enabled")
        udpnm_signals = self.get_UDPNM_signals()
        self.expectTrue(udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Autonomous_Driving_Ready_ein'] == 1,Severity.BLOCKER,"Checking that partial network configuration Autonomous_Driving_Ready is enabled")

        self.setPrecondition("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.setPrecondition("Getting CP60 Availability counter value from kvs")
        First_CP60_Availability = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.CP60_Uptime_counter)
        logger.info(f"First_CP60_Availability_value: {First_CP60_Availability}")

        self.setPrecondition("waiting CP60 UptimeCounter update cyclicity")
        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.setPrecondition("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.setPrecondition("Getting CP60 Availability counter value from kvs")
        Second_CP60_Availability = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.CP60_Uptime_counter)
        logger.info(f"Second_CP60_Availability_value: {Second_CP60_Availability}")

        self.expectTrue(First_CP60_Availability < Second_CP60_Availability, Severity.BLOCKER,"Checking CP60 system Availability time is updated")

        self.setPrecondition("Disable partial network configuration Autonomous_Driving_Ready")
        self.bcp21_nmController.set_functional_partial_network(self.AD_Ready_AUS_FUNCTIONAL_PARTIAL_NETWORK)

        self.setPrecondition("Check that partial network configuration Autonomous_Driving_Ready is disabled")
        udpnm_signals = self.get_UDPNM_signals()
        self.expectTrue(udpnm_signals['User data']['CTR_FKTN_PRINT_NM']['Autonomous_Driving_Ready_ein'] == 0,Severity.BLOCKER,"Checking that partial network configuration Autonomous_Driving_Ready is disabled")

    def test_tca_PSAA_UptimeCounter_CP60_Availability_Negative_PAD(self):
        self.startTestStep("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.startTestStep("Getting CP60 Availability counter value from kvs")
        First_CP60_Availability = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.CP60_Uptime_counter)
        logger.info(f"First_CP60_Availability_value: {First_CP60_Availability}")

        self.startTestStep("waiting CP60 UptimeCounter update cyclicity")
        self.sleep_for(self.Wait_for_counters_incrementation_MS)

        self.startTestStep("Getting UptimeCounter kvs file content")
        grep_kvs_file = self.ssh_manager.executeCommandInTarget(command=f"cat {self.uptimecounter_kvs_path}/{self.kvs_name}", timeout=self.SSH_CONNECTION_TIMEOUT_MS,ip_address=self.PP_IP)
        self.assertTrue(grep_kvs_file["exec_recv"] == 0, Severity.MAJOR, "Checking command is successfully executed")

        self.startTestStep("Getting CP60 Availability counter value from kvs")
        Second_CP60_Availability = self.get_Counter_values(stdout_kvs=grep_kvs_file["stdout"],counter_name=self.CP60_Uptime_counter)
        logger.info(f"Second_CP60_Availability_value: {Second_CP60_Availability}")

        self.assertTrue(First_CP60_Availability == Second_CP60_Availability, Severity.BLOCKER,"Checking CP60 system Availability time is not updated")

    def tearDown(self):
        self.setPostcondition("stopping BCP simulation")
        self.stop_bcp_simulation()
        self.bcp21_nmController.stop_nm_udp_simulation()
        self.set_standard_MG()

        self.setPostcondition("Reverting uptime_counter exec_config file ")
        self.set_default_uptime_counter_exec_config()

        self.setPostcondition("Resetting ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.stop()

        self.setPostcondition("Check uptime_counter exec_config file is reverted")
        cyclicity = self.get_cyclicity_from_exec_config()
        logger.info(f"cyclicity_value: {cyclicity}")
        self.expectTrue(cyclicity == self.Cyclicity_60m_MS, Severity.MAJOR,"Checking cyclicity is successfully reverted")
