from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_block_device_01_BLK_partitions_statistics_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_block_device_01_BLK_partitions_statistics_non_verbose"
    REQ_ID = ["/item/5833706"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports partitions statistics in non-verbose mode"
    OS = ['QNX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Get logging time interval")
        self.time_interval = self.get_time_interval(contextID=self.blk_context_id)
        logger.info(f"Time interval = {self.time_interval}")
        self.assertTrue(self.time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_BLK_FS)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_block_device_01_BLK_partitions_statistics_non_verbose(self):
        self.startTestStep("Get all mount partitions and their path, sizes and filesystem")
        file_systems, partitions = self.get_partitions_info()
        self.expectTrue(file_systems != -1 and partitions != -1, Severity.MAJOR, "Check that partitions info is got")
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_BLK_FS, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Wait the configured time interval * 2")
        self.sleep_for(self.time_interval * 10)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get BLK non-verbose DLT messages that contains the partition statistics")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that messages exit")
        self.expectTrue(True, Severity.MAJOR, "Check that all partitions are reported")
        self.expectTrue(True, Severity.MAJOR, "Check that each partition report contains the correct statistics")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
