from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_memory_003_OOM_detailed_memory_usage_QNX(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/SysMon/tca_sysmon_memory_003_OOM_detailed_memory_usage_QNX"
    REQ_ID = ["/item/5911326"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "23-07"
    DESCRIPTION = "Check that sysmon reports detailed memory usage when the usage threshold is reached"
    OS = ['QNX']
    STATUS = "Obsolete"

    def setUp(self):
        self.setPrecondition("Upload ram_allocator_qnx to target /persistent")
        self.ssh_manager.uploadFileToTarget(self.input_folder, "ram_allocator_linux", "/persistent", self.PP_IP)
        self.setPrecondition("Give the Execution Right to all the ram_allocator_qnx.")
        self.ssh_manager.executeCommandInTarget(command="chmod +x /persistent/ram_allocator_linux", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)

        self.setPrecondition("Get logging time interval of MEMS")
        self.MEMS_time_interval = self.get_time_interval(contextID=self.memory_total_usage_context_id + "total")
        logger.info(f"Time interval of MEMS = {self.MEMS_time_interval}")
        self.assertTrue(self.MEMS_time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        self.setPrecondition("Get logging time interval of OOM")
        self.OOM_time_interval = self.get_time_interval(contextID=self.cgroup_oom_report_context_id)
        logger.info(f"Time interval of OOM = {self.OOM_time_interval}")
        self.assertTrue(self.OOM_time_interval != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        self.setPrecondition("Get threshold of OOM")
        self.OOM_threshold = self.get_time_interval(contextID=self.cgroup_oom_report_context_id + "limit")
        logger.info(f"threshold of OOM = {self.OOM_threshold}")
        self.assertTrue(self.OOM_threshold != self.INVALID_VALUE, Severity.BLOCKER, "Check that threshold was successfully retrieved")

        self.search_msg_array_MEMS = self.statistic_data["Memory"]["mems_total"]["Search_msg_array"]
        logger.info(f"Search message array of MEMS = {self.search_msg_array_MEMS}")
        self.assertTrue(self.search_msg_array_MEMS is not None, Severity.BLOCKER, "Check that search message array of MEMS was successfully retrieved")

        self.search_msg_array_OOM = self.statistic_data["Memory"]["oom_memory_change"]["Search_msg_array"]
        logger.info(f"Search message array of OOM = {self.search_msg_array_OOM}")
        self.assertTrue(self.search_msg_array_OOM is not None, Severity.BLOCKER, "Check that search message array of OOM was successfully retrieved")

        # self.setPrecondition("Read Secondary info memory and get Status of DTC Maximale Speicherplatz Ausnutzung erreicht.")
        # read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Maximale_Speicherplatz_Ausnutzung_erreicht"][self.PP_NAME], memory_type="secondary")
        # logger.info("Status of DTC Maximale Speicherplatz Ausnutzung erreicht in SetUp :" + str(read_status))
        # self.expectTrue(read_status == self.DTC_NOT_PRESENT, Severity.BLOCKER, "Checking that DTC Maximale Speicherplatz Ausnutzung erreicht is Not Present: 0x50 or None.")

        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.cgroup_oom_report_context_id)
        self.dlt_manager.apply_filter(contextId=self.memory_total_usage_context_id)
        self.dlt_manager.start_monitoring("SRR-DLT")

    def test_tca_sysmon_memory_003_OOM_detailed_memory_usage_QNX(self):
        self.startTestStep("Wait cycle of total MEMS * 2")
        self.sleep_for(self.MEMS_time_interval * 2)
        self.startTestStep("Get MEMS total RAM DLT messages")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array_MEMS)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that MEMS total RAM DLT messages are available")

        self.startTestStep("Get total_memory value")
        total_memory = self.get_statistic_value(message=messages[0], statistic_path="Memory.mems_total.Statistics.total_memory")
        self.expectTrue(total_memory != self.INVALID_VALUE, Severity.MAJOR, "Check that total_memory is reported")

        self.startTestStep("Get available_memory value")
        available_memory = self.get_statistic_value(message=messages[0], statistic_path="Memory.mems_total.Statistics.available_memory")
        self.expectTrue(available_memory != self.INVALID_VALUE, Severity.MAJOR, "Check that available_memory is not reported")

        self.startTestStep("Use ram_allocator_qnx to cause RAM overload (Allocate 93 percent of the memory for 10s.")
        return_value = self.ssh_manager.executeCommandInTarget(command=f"cd /persistent && ./ram_allocator_linux {self.Calculate_Alocate(memTotal=total_memory, memAvailable=available_memory, percentage=98)} 20", timeout=self.SSH_CONNECTION_TIMEOUT_MS, ip_address=self.PP_IP)
        self.expectTrue(return_value['exec_recv'] == 0 and return_value['stderr'] == '', Severity.BLOCKER, "Checking command executed executed properly")
        self.sleep_for(self.OOM_time_interval)

        self.startTestStep("Read Secondary info memory and get Status of DTC Maximale Speicherplatz Ausnutzung erreicht.")
        read_status = self.dtc_manager.read_dtc_status(target=self.PP_DIAG_ADR, dtc=self.DTC_LIST["Maximale_Speicherplatz_Ausnutzung_erreicht"][self.PP_NAME], memory_type="secondary")
        logger.info("Status of DTC Maximale Speicherplatz Ausnutzung erreicht in test main :" + str(read_status))
        self.expectTrue(read_status == self.DTC_ACTIVE, Severity.BLOCKER, "Checking that DTC Maximale Speicherplatz Ausnutzung erreicht is ACTIVE.")

        self.startTestStep("Get DLT OOM detailed DLT message")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array_OOM)
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that DLT OOM detailed message exits")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
