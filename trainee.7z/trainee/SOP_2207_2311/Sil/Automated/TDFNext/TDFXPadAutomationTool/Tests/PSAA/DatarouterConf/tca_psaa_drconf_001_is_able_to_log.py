from Tests.PSAA.DatarouterConf.testfixture_PSAA_DatarouterConf import *


class tca_psaa_drconf_001_is_able_to_log(testfixture_PSAA_DatarouterConf):

    TEST_ID = "PSAA\tca_psaa_drconf_001_is_able_to_log"
    REQ_ID = ["/item/1019008"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "check logging.json config file"
    STATUS = "Ready"
    OS = ['LINUX','QNX']

    def setUp(self):
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls /opt | grep -c '{self.DATA_ROUTER_CONF_APP_NAME}'", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Check Data Router configurator is under /opt")

    def test_psaa_drconf_001_is_able_to_log(self):
        self.startTestStep("Check the logging.json exists")
        returnValue = self.ssh_manager.executeCommandInTarget(command=f"ls {self.dconf_config_path} | grep -c '{self.LOGGING_FILE_NAME}'", ip_address=self.PP_IP, timeout=self.SSH_CONNECTION_TIMEOUT_MS)
        self.assertTrue(returnValue["stdout"].strip() == "1", Severity.BLOCKER,
                        "Check Data Router configurator contain a valid logging config file")
        self.startTestStep("Check the appId in logging.json file")
        appId = self.json_manager.getInfoFromJsonFile(filePath=f"{self.dconf_config_path}/{self.LOGGING_FILE_NAME}",
                                                      valuePath="appId", use_cache=False, delete_cache=False)
        self.assertTrue(appId is not None, Severity.BLOCKER, f"Check {self.LOGGING_FILE_NAME} file contain a valid appId")
        self.startTestStep("Check the appDesc in logging.json file")
        appDesc = self.json_manager.getInfoFromJsonFile(filePath=f"{self.dconf_config_path}/{self.LOGGING_FILE_NAME}",
                                                        valuePath="appDesc", use_cache=True, delete_cache=False)
        self.assertTrue(appDesc is not None, Severity.BLOCKER, f"Check {self.LOGGING_FILE_NAME} file contain a valid appDesc")

    def tearDown(self):
        pass
