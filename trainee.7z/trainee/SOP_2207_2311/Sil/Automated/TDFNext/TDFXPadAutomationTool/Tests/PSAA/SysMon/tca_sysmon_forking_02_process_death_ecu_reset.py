from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_forking_02_process_death_ecu_reset(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_forking_02_process_death_ecu_reset"
    REQ_ID = ["/item/5833129"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon report process death after ECU reset"
    OS = ['QNX', 'LINUX']
    STATUS = "Ready"

    def setUp(self):
        self.search_msg_array = self.statistic_data["PMON"]["termination"]["Search_msg_array"]
        logger.info(f"Search message array = {self.search_msg_array}")
        self.assertTrue(self.search_msg_array is not None, Severity.BLOCKER, "Check that search message array was successfully retrieved")
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(appID=self.SYSMON_APP_ID)
        self.dlt_manager.apply_filter(contextId=self.process_forking_context_id)

    def test_tca_sysmon_forking_02_process_death_ecu_reset(self):
        self.startTestStep("Reset ECU")
        self.diag_manager.start()
        self.diag_manager.ecu_reset(target=self.PP_DIAG_ADR, reset_duration=self.PP_RESET_TIMEOUT_S)
        self.diag_manager.restart()
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.startTestStep("Check ECUs")
        ecus_are_ok = self.check_ECUs()
        self.expectTrue(ecus_are_ok, Severity.MAJOR, "Check that ECUs are OK after the ECU reset")
        self.startTestStep("Wait for DLT (3 seconds)")
        self.sleep_for(10000)

        self.startTestStep("Get PMON DLT messages that contains process death")
        message_count, messages = self.dlt_manager.get_messages_by_AND(searchMsgArray=self.search_msg_array)
        logger.info(f"dlt messages: {messages}")
        self.assertTrue(message_count > 0, Severity.MAJOR, "Check that the terminated apps death was reported")

        process_name = self.get_statistic_value(message=messages[0], statistic_path="PMON.termination.Statistics.process_name")
        self.assertTrue(process_name != -1, Severity.MAJOR, "Check that process was reported")

        process_pid = self.get_statistic_value(message=messages[0], statistic_path="PMON.termination.Statistics.pid")
        self.expectTrue(process_pid != -1, Severity.MAJOR, "Check that the DLT contains the PID")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
