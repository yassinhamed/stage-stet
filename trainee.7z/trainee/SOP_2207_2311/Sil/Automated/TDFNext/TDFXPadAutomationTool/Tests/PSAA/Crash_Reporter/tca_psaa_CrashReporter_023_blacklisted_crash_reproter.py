from Tests.PSAA.Crash_Reporter.testfixture_PSAA_Crash_Reporter import *


class tca_psaa_CrashReporter_023_blacklisted_crash_reproter(testfixture_PSAA_Crash_Reporter):

    TEST_ID = "PSAA\Crash_Reporter\tca_psaa_CrashReporter_023_blacklisted_crash_reproter"
    REQ_ID = ["/item/7590375"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High', 'mPAD_Performance_AddOn']
    ValidFrom = "23-11"
    ValidUntil = "unlimited"
    Priority = "N/A"
    DESCRIPTION = "Check the creation of coredumps related to crash reporter application mentioned in ignorelist.json file"
    STATUS = "Obsolete"
    OS = ['QNX']

    def setUp(self):
        self.setPrecondition("Cat ignorelist.json file")
        self.setPrecondition("Add crash reporter in ignorelist.json file if not exist")
        self.assertTrue(True, Severity.MAJOR, "Check the crash reporter application name is in ignorelist.json")
        self.setPrecondition("Reset ECU")
        self.setPrecondition("Clear old core dumps")
        self.setPrecondition("Get dumper process informations using ps -A -o pid,args | grep dumper")
        self.assertTrue(True, Severity.MAJOR, "Check dumper is running")
        self.setPrecondition("Get crash reporter process informations using ps -A -o pid,args | grep crash_reporter")
        self.assertTrue(True, Severity.MAJOR, "Check crash reporter is running")
        self.expectTrue(True, Severity.MAJOR, "Check quota value")
        self.expectTrue(True, Severity.MAJOR, "Check min free space value")

    def test_tca_psaa_CrashReporter_023_blacklisted_crash_reproter(self):
        self.startTestStep("Get pid of crash reporter application")
        self.assertTrue(True, Severity.MAJOR, "Check crash reporter is running")
        self.startTestStep("Kill crash reporter")
        self.assertTrue(True, Severity.MAJOR, "Check the kill command is executed")
        self.startTestStep("Get pid of crash reporter")
        self.assertTrue(True, Severity.MAJOR, "Check crash reporter is not running")
        self.startTestStep("Wait for coredumps creation")
        self.startTestStep("Get coredumps names using ls command")
        self.assertTrue(True, Severity.MAJOR, "Check no coredumps are created under /persistent/coredumps")
        self.assertTrue(True, Severity.MAJOR, "Check only core file is created under /persistent/coredumps/tmp")
        self.setPostcondition("Reset ECU")
        self.startTestStep("Get coredumps names using ls command")
        self.assertTrue(True, Severity.MAJOR, "Check core file moved under /persistent/coredumps")

    def tearDown(self):
        self.setPostcondition("Revert ignorelist.json file")
        self.setPostcondition("Reset ECU")
