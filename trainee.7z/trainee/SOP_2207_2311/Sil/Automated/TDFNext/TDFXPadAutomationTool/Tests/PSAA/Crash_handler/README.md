# Crash handler  

This is an adaptive application started by Execution Manager and listening to write notifications on the core dump non-volatile storage. It does the below functionalities: 

- Monitor *application* coredumps availability in */persistent/coredumps/* storage. 

- Monitor *kernel* coredumps availability in */persistent/coredumps/kernel/* storage. 

- Send core dump information files over dlt. 

- Clean up persistent storage on exceeding allowed storage capacity. 

- Setting of primary and secondary DTCs for application and kernel coredumps. 

 

**Monitoring application and kernel coredumps** 

- Monitoring of the coredumps start only when the ecu machine state is in Running. 

- Application core dumps: 

  - Register for inotify event i.e. *IN_CREATE* for */persistent/coredumps/* storage. 

**Coredump file transfer**

- Transfer of coredumps files are done only for the coredumps which are not transferred in previous cycles based on *checksum* file data available in */persistent/coredumps/*. 

- For each successful transfer of coredump file, *checksum* file is updated with absolute file name along with calculated checksum information. 

- *checksum* provides the information whether the coredump file should be transferred or not. 

**Persistent clean up** 

- Persistent house keeping starts when the storage */persistent/coredumps/* reaches max water mark. 

- Max water mark is defined when storage i.e. */persistent/coredumps/* reaches *50%* of *100MB*. 

- Oldest coredump files are removed from */persistent/coredumps/* on reach of max water mark. 

- Detecting oldest coredump file available in */persistent/coredumps/* 

  - Each cordump file name contains the timestamp when the coredump is generated. 

  - Based on this timestamp information, application removes the coredumps file from oldest to newest. 

**DTC handling** 

- On startup: 

  - No early coredumps in */persistent/coredumps/* below DTCs are set to *kPassed* 

    - Primary dtc i.e. *0x482e81* 

    - Secondary dtc i.e. *0x482f7e* 

    - KernelOopsPanic dtc i.e. *0x482f76* 

  - On Early coredumps: 

    - Dtcs are set only for the coredumps which are not set in previous cycles. 

    - Application coredumps available in */persistent/coredumps/* below DTCs are set to *kFailed* 

      - Primary dtc i.e. *0x482e81* 

      - Secondary dtc i.e. *0x482f7e* 

      - Sets the DTCs to OK again i.e *kPassed* right after it 

    - Kernel coredumps */persistent/coredumps/kernel/* below DTCs are set to *kFailed* 

      - Primary dtc i.e. *0x482e81* 

      - Sets the DTCs to OK again i.e *kPassed* right after it 

      - KernelOopsPanic dtc i.e. *0x482f76* 

- Application crash during the run: 

  - Below DTCs are set to *kFailed* 

    - Primary dtc i.e. *0x482e81* 

    - Secondary dtc i.e. *0x482f7e* 

    - Sets the DTCs to OK again i.e *kPassed* right after it 

- Kernel crash during the run: 

  - On kernel crash, *kernel* coredumps are wrtitten to */persistent/coredumps/kernel/*. 

  - System gets re-booted. 

  - Setting of DTCs as defined above i.e. Kernel coredumps in *On Early coredump* section 

 