from Tests.PSAA.testfixture_PSAA import *


class testfixture_PSAA_param_server_ProxyApp(testfixture_PSAA):

    @classmethod
    def setUpClass(cls):
        logger.info("start testfixture_PSAA_param_server_ProxyApp setUpClass")
        cls.deploy_proxy_app()
        cls.start_tdf_proxy_communication()
        cls.check_proxy_app()
        cls.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=path.join(OutputPathManager.get_tests_group_path(), "coredumps_setupclass_with_proxyapp"),check_empty=False,ip_address=cls.PP_IP,ignored_files=["currentswversion", "tmp"])

    @classmethod
    def tearDownClass(cls):
        logger.info("start testfixture_PSAA_param_server_ProxyApp tearDownClass")
        cls.stop_tdf_proxy_communication()
        cls.undeploy_proxy_app()

    def setUp(self):
        self.check_proxy_app()
        self.proxy_app_manager.using_proxy_app_lib(libName.PARAM_SERVER.value)

        result = self.proxy_app_manager.PARAM_SERVER_comm.get_supported_fields()
        self.expectTrue(result == araParamServExitCode.SUCCESS.value, Severity.MAJOR, "Check exit code is success")

        supported_fields = self.proxy_app_manager.PARAM_SERVER_comm.supportedFields
        self.field_name = supported_fields[0].name
        logger.info(f"tested field = {self.field_name}")

        result = self.proxy_app_manager.PARAM_SERVER_comm.get_field_parameters(fieldName=self.field_name)
        self.expectTrue(result == araParamServExitCode.SUCCESS.value, Severity.MAJOR, "Check exit code is success")
        field_parameters = self.proxy_app_manager.PARAM_SERVER_comm.fieldParameters

        self.parameter_name = field_parameters[0]
        logger.info(f"tested parameter = {self.parameter_name}")

    def tearDown(self):
        self.proxy_app_manager.remove_proxy_app_lib(libName.PARAM_SERVER.value)
        self.ecu_utilities.download_coredumps_and_clear(coredumps_folder="/persistent/coredumps/",output_folder=OutputPathManager.get_test_case_path(),check_empty=False,ip_address=self.PP_IP,ignored_files=["currentswversion", "tmp"])

