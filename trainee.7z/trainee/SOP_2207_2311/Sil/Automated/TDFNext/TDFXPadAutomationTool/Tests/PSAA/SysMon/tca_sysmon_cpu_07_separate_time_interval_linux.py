from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_cpu_07_separate_time_interval_linux(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_cpu_07_separate_time_interval_linux"
    REQ_ID = ["/item/5829173"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that time interval are separately specified for system, core, thread CPU and iowait"
    OS = ['LINUX']
    STATUS = "Ready"

    def setUp(self):
        pass

    def test_tca_sysmon_cpu_07_separate_time_interval_linux(self):

        self.startTestStep("get all time interval variables from the config file")
        system_variable = self.linux_time_interval_mapping[self.CPU_system_context_id]
        self.time_interval_system = self.get_time_interval(contextID=self.CPU_system_context_id)
        logger.info(f"Time interval = {self.time_interval_system}")
        self.expectTrue(self.time_interval_system != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        core_variable = self.linux_time_interval_mapping[self.CPU_core_context_id]
        self.time_interval_core = self.get_time_interval(contextID=self.CPU_core_context_id)
        logger.info(f"Time interval = {self.time_interval_core}")
        self.expectTrue(self.time_interval_core != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        thread_variable = self.linux_time_interval_mapping[self.thread_cpu_usage_context_id]
        self.time_interval_thread = self.get_time_interval(contextID=self.thread_cpu_usage_context_id)
        logger.info(f"Time interval = {self.time_interval_thread}")
        self.expectTrue(self.time_interval_thread != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        iowait_variable = self.linux_time_interval_mapping[self.IOWAIT_system_context_id]
        self.time_interval_iowait = self.get_time_interval(contextID=self.IOWAIT_system_context_id)
        logger.info(f"Time interval = {self.time_interval_iowait}")
        self.expectTrue(self.time_interval_iowait != self.INVALID_VALUE, Severity.BLOCKER, "Check that time interval was successfully retrieved")

        all_variables = [system_variable, core_variable, thread_variable, iowait_variable]
        logger.info(f"all vairables =\n{all_variables}")

        self.startTestStep("get all time interval variables from the config file")
        all_variables = list(dict.fromkeys(all_variables))
        self.assertTrue(len(all_variables) == 1, Severity.BLOCKER, "Check that all variables are different")

    def tearDown(self):
        pass
