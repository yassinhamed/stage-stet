from Tests.PSAA.SysMon.testfixture_PSAA_SysMon import *


class tca_sysmon_forking_02_process_death_kill_cmd_non_verbose(testfixture_PSAA_SysMon):

    TEST_ID = "PSAA/sysmon/tca_sysmon_forking_02_process_death_kill_cmd_non_verbose"
    REQ_ID = ["/item/5833129"]
    DEV_OBJ = ['mPAD_Performance_2C', 'mPAD_Performance_4C', 'mPAD_Performance_High']
    ValidFrom = "21-07"
    ValidUntil = "unlimited"
    DESCRIPTION = "Check that sysmon report process death using kill command in non-verbose mode"
    OS = ['QNX']
    STATUS = "Ready"

    def setUp(self):
        self.setPrecondition("Start DLT monitoring")
        self.dlt_manager.set_min_max_log_level(dltLogLevel.DLT_LOG_OFF.value, dltLogLevel.DLT_LOG_VERBOSE.value)
        self.dlt_manager.use_fibex_dissector(use=True)
        self.dlt_manager.apply_filter(ecuId=self.PP_ECUID)
        self.dlt_manager.apply_filter(messageId=self.non_verbose_message_id_of_PMON_death)
        self.dlt_manager.start_monitoring("SRR-DLT")
        self.setPrecondition("Get pid of the application to be killed")
        self.ETS_APP_pid = self.get_process_id(app_name=self.ETS_APP_NAME)
        self.expectTrue(self.ETS_APP_pid != -1, Severity.MAJOR, "Check the application is running")

    def test_tca_sysmon_forking_02_process_death_kill_cmd_non_verbose(self):
        self.dlt_manager.start_capturing_non_verbose_message(msg_short_name=self.non_verbose_message_short_name_of_PMON_death, sender=self.PP_ECUID, filter_attributes=None)
        self.startTestStep("Execute cmd kill application")
        application_is_killed = self.kill_application(app_name=self.ETS_APP_NAME, signal="SIGSEGV")
        self.expectTrue(application_is_killed, Severity.MAJOR, "Check the kill command is executed")
        self.sleep_for(5000)
        self.startTestStep("Check application is killed")
        ETS_still_running = self.check_application_is_started(app_name=self.ETS_APP_NAME)
        self.assertTrue(not ETS_still_running, Severity.MAJOR, "Check the application is killed")
        self.startTestStep(f"Wait for DLT ({self.wait_for_forking_non_verbose_message_ms})")
        self.sleep_for(self.wait_for_forking_non_verbose_message_ms)
        self.dlt_manager.stop_capturing_non_verbose_message()
        self.startTestStep("Get PMON non-verbose DLT messages that contains process death")
        dlt_messages = self.dlt_manager.get_non_verbose_messages()
        logger.info(f"dlt messages: {dlt_messages}")
        self.assertTrue(len(dlt_messages) > 0, Severity.MAJOR, "Check that the killed app process death was reported")
        search_message = self.get_non_verbose_message_by_pid(self.ETS_APP_pid,dlt_messages)
        self.assertTrue(search_message is not None, Severity.MAJOR, "Check that the DLT contains the PID")
        self.expectTrue(search_message['payload'].get('name') is not None, Severity.MAJOR, "Check that the DLT contains the process name")

    def tearDown(self):
        self.setPostcondition("Stop DLT monitoring")
        self.dlt_manager.clear_all_filters()
        self.dlt_manager.stop_monitoring()
