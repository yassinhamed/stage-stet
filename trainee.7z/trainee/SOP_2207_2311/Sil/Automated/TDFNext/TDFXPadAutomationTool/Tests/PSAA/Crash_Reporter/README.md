# Crash reporter

CrashReporter is a service that registers for the coredump event of a process from the QNX kernel and gathers additional, useful information for debugging an issue. CrashReporter does not replace the QNX dumper. Instead, registers for the same 'coredump' event in QNX OS and passes a message from the QNX kernel to the original QNX dumper after saving the required additional information file. This is achieved by registering as a resource manager for /proc/dumper.

**Crash reporter has two threads:**

Main thread:

1. Receive system event in dispatching loop. Dispatch event, which shall be followed by receiving a callback for a write operation.
2. Check if process name is in the blacklist. If yes, write info log, reply to the kernel with the "receive ID" and reject coredump for the process.
3. Push request (PID and "receive ID") to the queue. This operation is blocking while the queue is full.
4. Reply to resource manager library with _RESMGR_NOREPLY
5. Wait for the next event to dispatch

Worker thread:
1. Pop request (PID and "receive ID") from the queue. This operation is blocking
   while the queue is empty. Timout is used to allow cyclic sending  of
   CoreDumpStatus.
2. Send CoreDumpStatus to notify other applications. In case of pop timeout
   return to 1.
3. Open context file for writing
   (file name: context.<crashed_process_name>.<crashed_process_PID>.tmp)
4. Read required common `/proc` information and save it to the file.
   - If the operation fails, log and continue to the next step.
5. Read required `/proc/<PID>` information for crashed process and save to the
   file.
   - If the operation fails, log and continue to the next step.
6. Read Git hash, SW name, and version information for crashed process and save
   to the file.
   - If the information doesn't exist or the operation fails, log and continue
     to the next step.
7. Close context file and update name to indicate it's complete.
   (file name: context.<crashed_process_name>.<crashed_process_PID>.txt)
8. Setup a timeout timer for running QNX dumper process.
9. Run QNX dumper with `-p <PID> -v` and read its standard output. If timer
   times out:
  - Kill QNX dumper with `SIGKILL`.
  - Log the error.
  - Go to step 12.
10. Check QNX dumper exit code. If not zero:
  - Delete coredump file.
  - Log the error.
  - Go to step 12.
11. Extract coredump path from QNX dumper standard output. If fails:
  - Log the error.
12. Move files (coredump, if available + context file) to the `/persistent/coredumps`
   directory.
   - Modify file names according to the requirements.
   - Check if files with the same name already exists in
     `/persistent/coredumps`.
     - If so, add `_N` to the new filename, where N is the first
     available number starting from 1.
13. Set the files permissions
14. In case of error at previous steps, reply to kernel with an error `-1`.
    Otherwise reply with the "receive ID".
15. If the queue is empty: Update CoreDumpStatus (CoreDumpComplete) and send
    CoreDumpStatus

**Create context file**

Context file is created during the coredump event, along with the new coredump file.

**Context information gathered by CrashReporter**

Provided information:

- Source-code Git hash, SW name and SW version of a crashed application (if present)
- QNX version (uname())
- Signal number
- Process crash timestamp (coredump file modification time)
- Common /proc information:
  - cmdline - kernel parameters
  - config - system information
  - vm/stats - virtual memory information
- /proc/<PID> information of crashed process
  - cmdline - arguments passed to the process
  - exefile - path of the executable file used to run the process
  - pmap - process mappings
  - vmstat - process virtual memory
  - as - size (B) of process address space (only size, no content of as)
  - list of threads

 **Blacklist config file**

 Blacklist is stored in json format. File location is /opt/crash_reporter/etc/ignorelist.json. File should contain one json array filled with strings. Every string is single process name.
 
Example:

```ignorelist.json
{
  "blacklist" = ["crash_reporter", "dumper"]
}
```

If file is missing or format is incorrect, all coredumps shall be processed.

**Command line parameters**

Crash reporter parameters:

- `--coredump-quota-mb` - Max quota in MB for coredumps storage on
  `/persistent/coredumps`. Includes all subdirectories.
  Value `0` - disable storage quota check.
- `--min-persistent-space-mb` - Minimal free space in MB on `/persistent` that
  CrashReporter needs to preserve. If the parameter value is 0, CrashReporter
  will check only whether the coredump save was successful, and coredump taking
  all the remaining free space will be accepted.
- `--coredump-storage-path` - Path to the storage directory with coredumps. If
  the path doesn't exist, will be created with correct permissions as described
  in the
  chapter. The `tmp` directory will be created as a subdirectory.
  Note that documentation assumes the use of `/persistent/coredumps`. If another
  path is provided through this parameter, it replaces `/persistent/coredumps`
  and shall be treated the same way.
- `-U` - Specifies the user (and optionally the group) to run CrashReporter
  as. The string can be in one of these forms:
  - `uid[:gid[,sup_gid]*]`
  - `user_name[,sup_gid]*`

```
crash_reporter
  --coredump-quota-mb 100
  --min-persistent-space-mb 40 &
```

dumper parameters:

```
dumper
  -d "/persistent/coredumps/tmp"
  -p <PID>
  -I (PID in file name)
  -U crash_handler:crash_services (user+group)
  -z 4 (compression level)
  -s 100M (max single coredump size) [VALUE TO BE CONFIRMED]
```

**LoLa IPC communication**

CrashReporter provides CrashReporterStatus ara::com interface using LoLa binding. Using this interface CrashReporter shall notify CrashReporterAraProxy and MachineStateManager about current core dump status. LoLa communication needs to be configured in each application (service provider and consumer). 