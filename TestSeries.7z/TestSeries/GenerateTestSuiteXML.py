import os
import argparse
import xml.etree.cElementTree as ET
import json

class GenerateTestSuiteXML:
    """
    Class which processes al test cases from a specific domain and generates
    the TestSuite.xml required by TDFNext to run all test cases.

    e.g of execution: python GenerateTestsuiteXML.py --ecu mpad --controller PP
    --input C:\Repositories\platform_tests\platform-tests\Hil\Automated\
    TDFNext\TDFXPadAutomationTool\Tests --output C:\Repositories\
    platform_tests\platform-tests\Hil\Automated\TDFNext
    """
    __ecu = None
    __controller = None
    __domain = None
    __source_folder = ""
    __destination_folder = ""
    __output_file = ""
    __root_xml = None

    def __init__(self, __source_folder="", __destination_folder="",
                 __out_file="TestSuite.xml"):
        """
        Constructor of the main class.

        :param __source_folder : Input folder to look for ready test cases.
        :param __destination_folder : Folder where the TestSuite.xml will
        be placed.
        :param __out_file : Name of the generated TestSuite.xml.
        """
        self.__source_folder = __source_folder
        self.__destination_folder = __destination_folder
        self.__output_file = __out_file

    def get_arguments(self):
        """
        Function to parse the given parameters via command line.
        The given parameters could be:

        --ecu : Param to set the name of the ECU where the tests have to run.
        This parameter is mandatory, otherwise the script will not run.
        --controller : Param to set the name of the specific controller of the
        ECU. This parameter is mandatory, otherwise the script will not run.
        --input : Param used to look for the ready test cases to run.
        --output : Param used to tell TDFNext where is going to be placed the
        TestSuite.xml.
        """

        parser = argparse.ArgumentParser(
            description='Arguments passed to generate TestSuite.xml according '
                        'to the desired ECU and Controller. Also, it is '
                        'specified where the TestSuite.xml will be generated.',
        )
        parser.add_argument('--ecu',
                            help='Parameter which specifies which ECU is '
                                 'selected. It could be hPAD, mPAD or uPAD.',
                            required=True
                            )
        parser.add_argument('--controller',
                            help='Parameter which specifies which controller '
                                 'will run the test series. It could FPP, SPP'
                                 ', SC or PP.',
                            required=True)
        parser.add_argument('--domain',
                            help='Parameter which specifies a domain test '
                                 'series which will run.',
                            default="All")
        parser.add_argument('--input',
                            help='Parameter which defines where are the tests '
                                 'which have to generate the TestSuite.xml',
                            default='.')
        parser.add_argument('--output',
                            help='Parameter which defines where the '
                                 'TestSuite.xml will be stored.',
                            default='.')
        args = parser.parse_args()
        self.__ecu = args.ecu
        self.__controller = args.controller
        self.__domain = args.domain
        self.__source_folder = args.input
        self.__destination_folder = args.output

    def get_all_domains(self):
        """
        Function used to create the root of the XML file.
        :return: No returned statement.
        """

        self.create_testsuite_xml()
        # First check to see if it is selected a domain to run test cases.
        # If there is no domain selected then the file will be empty.
        folders = []
        if self.__domain == "All":
            folders = os.listdir(self.__source_folder)
        else:
            # folders = os.listdir(self.__source_folder)
            domain_found = False
            for root, dir, file in os.walk(self.__source_folder):
                if self.__domain in dir:
                    print("Selected the domain {0} to run test cases."
                          "".format(self.__domain))
                    folders.append(os.path.join(root, self.__domain))
                    domain_found = True
            if not domain_found:
                print ("There is no valid domain specified to run TDFNext "
                    "test cases.")
        for fo in folders:
            if os.path.isdir(fo):
                print (fo, self.__domain)
                self.get_all_tests(self.__domain, fo)
        self.finish_testsuite_xml()

    def get_all_tests(self, group, folder):
        """
        Function created to get the domains where there are at least
        one test case ready to run. Avoids __init__.py which does not have
        to run.

        If there are no ready test cases inside a domain folder, that domain
        will not be added to the TestSuite.xml.

        :param group : Name of the domain.
        :param folder : Folder where the test cases are place inside a domain.
        """
        for root, dir, tests in os.walk(folder):
            group_xml = self.include_group_xml(os.path.basename(root))
            ready_tests = 0
            for t in tests:
                if t != "__init__.py":
                    if self.read_file(group_xml, os.path.join(root, t)):
                        ready_tests += 1
            if ready_tests == 0:
                self.remove_group_xml(group_xml)

    def read_file(self, folder, file):
        """
        Function used to parse the test case looking for the following
        fields.

        :param folder : Path of the folder of the test case.
        :param file : Name of the test case.

        class: Name of the test case which has to be integrated in the
        TestSuite.xml.
        #STATUS: To recognize if the test case is under design or ready.
        If it is ready it will be added to the TestSuite.xml.
        #DEV_OBJ: Specifies to which ECU and controller the test case should
         run. If it mataches with the params __ecu and __controller then the
         test case is added to TestSuite.xml.

         :returns True if the testcase is ready or False if the test case is
         not ready to run.
        """

        if os.path.isfile(file):
            testname = ""
            status = ""
            obj = ""
            with open(file, 'r', errors='ignore') as f:
                for line in f:
                    line = line.strip()
                    if line.startswith("class"):
                        testname = line.split(" ")[1].split("(")[0]
                    if line.startswith("STATUS"):
                        status = str.upper(line.split("=")[1].
                                           strip().strip('"'))
                    if line.startswith("DEV_OBJ"):
                        print(str.upper(line.split("=")[1].strip()))
                        line = json.loads(str.upper(
                            line.split("=")[1].strip()))
                        for elem in line:
                            splitLine = elem.split(",")
                            if str.upper(self.__ecu + "_" + self.__controller) \
                                in splitLine:
                                obj = self.__controller
            if testname != "" and status == "READY" and obj != "":
                self.include_test_xml(folder, testname)
                print (testname, obj)
                return True
            else:
                return False

    def create_testsuite_xml(self):
        """
        Function which creates the root of the XML file, in this case
        TestSuite.xml
        """
        self.__root_xml = ET.Element("TestSeries", name="testSeries_{0}".
                                     format(self.__domain))

    def include_test_xml(self, group, testname):
        """
        Function which adds a a testcase from a specific domain
        into TestSuite.xml.
        :param group : Name of the domain where the testcase must be added.
        :param testname : Name of the test case which is added into
        TestSuite.xml.
        """
        ET.SubElement(group, "Test", name=testname, repetition="1")

    def include_group_xml(self, groupname):
        """
        Function which adds a group into TestSuite.xml.
        :param groupname: Name of the domain to add to TestSuite.xml.
        :return: Returns the domain which was added to TestSuite.xml.
        """
        group = ET.SubElement(self.__root_xml, "Group", name=groupname)
        return group

    def remove_group_xml(self, groupname):
        """
        Function which removes a domain from TestSuite.xml.
        :param groupname: Name of the domain.
        :return: No returned statement.
        """
        tree = ET.ElementTree(self.__root_xml).getroot()
        tree.remove(groupname)

    def finish_testsuite_xml(self):
        """
        Function which writes the TestSuite.xml when the processing has
        finished.
        :return: No returned statement.
        """
        tree = ET.ElementTree(self.__root_xml)
        tree.write(os.path.abspath(
            os.path.join(self.__destination_folder, self.__output_file)))

if __name__ == "__main__":
    gXML = GenerateTestSuiteXML()
    gXML.get_arguments()
    gXML.get_all_domains()